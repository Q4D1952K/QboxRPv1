local objs = {}
local cam
local weather = false

local function getComponent(blob)
    local lockHash = string.unpack('<i4', blob, 1)
    local hash = string.unpack('<i4', blob, 9)
    local locate = string.unpack('<i4', blob, 17)
    local drawable = string.unpack('<i4', blob, 25)
    local texture = string.unpack('<i4', blob, 33)
    local field5 = string.unpack('<i4', blob, 41)
    local componentType = string.unpack('<i4', blob, 49)
    local field7 = string.unpack('<i4', blob, 57)
    local field8 = string.unpack('<i4', blob, 65)
    local gxt = string.unpack('z', blob, 73)
    local myObject = {
      LockHash = lockHash,
      Hash = hash,
      Locate = locate,
      Drawable = drawable,
      Texture = texture,
      Price = field5,
      ComponentType = componentType,
      f_7 = field7,
      f_8 = field8,
      Label = gxt
    }
    return myObject
end

local function PedComponent(componentHash)
    local blob = string.rep('\0\0\0\0\0\0\0\0', 9+16)
    Citizen.InvokeNative(0x74C0E2A57EC66760, componentHash, blob)
    local myObject = getComponent(blob)

    return myObject
end

local function PedProp(componentHash)
    local blob = string.rep('\0\0\0\0\0\0\0\0', 9+16)
    Citizen.InvokeNative(0x5D5CAFF661DDF6FC, componentHash, blob)
    local myObject = getComponent(blob)

    return myObject
end

local function LoadDefaultModel(malePed, cb)
    local characterModel = GetHashKey('mp_m_freemode_01')
    if malePed then
      characterModel = GetHashKey('mp_m_freemode_01')
    else
      characterModel = GetHashKey('mp_f_freemode_01')
    end
    RequestModel(characterModel)
    Citizen.CreateThread(function()
      while not HasModelLoaded(characterModel) do
        RequestModel(characterModel)
        Citizen.Wait(0)
      end
      if IsModelInCdimage(characterModel) and IsModelValid(characterModel) then
        SetPlayerModel(PlayerId(), characterModel)
        SetPedDefaultComponentVariation(cache.ped)
        Wait(1000)
        SetPedMaxHealth(PlayerId(), 200.0)
        Wait(1000)
        SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)
        SetPlayerHealthRechargeLimit(PlayerId(), 0.0)
      end
      SetModelAsNoLongerNeeded(characterModel)
      if cb ~= nil then
        cb()
      end
      ClearPedProp(cache.ped, 0)
    end)
end

RegisterCommand('clothingdev', function(source, args, rawCommand)
    DisplayRadar(false)
    TriggerEvent('qb-weathersync:client:DisableSync')
    weather = true
    local _gender = args[1] or 'male'
    for _index, _value in pairs(Config.ClothingDev) do
        ClearPedTasks(cache.ped)
        local p = promise.new()
        LoadDefaultModel(_gender == 'male' and true or false, function()
            SetPedComponentVariation(cache.ped, 0, 0, 1, 0)
            p:resolve('done')
        end)
        Citizen.Await(p)
        lib.requestAnimDict('anim@mp_corona_idles@female_b@idle_a')
        TaskPlayAnim(cache.ped, 'anim@mp_corona_idles@female_b@idle_a', 'idle_a', 1.0, 1.0, -1, 1, 1, true, true, true)
        Wait(5000)
        SetPedComponentVariation(cache.ped, 1, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 2, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 3, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 4, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 6, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 8, -1, 0, 0)
        SetPedComponentVariation(cache.ped, 11, -1, 0, 0)
        lib.requestModel('prop_big_cin_screen')
        local pedCoords = GetEntityCoords(cache.ped)
        local obj = CreateObject(joaat('prop_big_cin_screen'), pedCoords.x, pedCoords.y, pedCoords.z, true, true, false)
        FreezeEntityPosition(obj, true)
        table.insert(objs , obj)
        SetEntityCoords(cache.ped, pedCoords.x, pedCoords.y, pedCoords.z + 5.0, false, false, false, false)
        SetEntityHeading(cache.ped, 180.0)
        FreezeEntityPosition(cache.ped, true)
        local camCoords = GetOffsetFromEntityInWorldCoords(cache.ped, 0.0, 2.0, 0.0)
        cam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", camCoords.x, camCoords.y, camCoords.z, 0.00, 0.00, 0.00, 50.00, false, 0)
        SetCamActive(cam, true)
        SetCamCoord(cam,  camCoords.x,  camCoords.y,  camCoords.z)
        PointCamAtEntity(cam,  cache.ped)
        RenderScriptCams(true, false, 0, true, true)
        if _value then
            local headCoords = GetPedBoneCoords(cache.ped, _value.bone, 0.0, 0.0, 0.0)
            local camCoords = GetOffsetFromEntityInWorldCoords(cache.ped, _value.camCoords[1], _value.camCoords[2], _value.camCoords[3])
            SetEntityHeading(cache.ped, _value.heading)
            -- Nếu chụp watches vs backpack thì bỏ comment dòng này trong client
            if _index == 'watch' or _index == 'backpack' or _index == 'bracelet' then
                SetEntityHeading(obj, _value.heading)
            end
            SetCamCoord(cam,  camCoords.x + _value.offsetCamCoords[1],  camCoords.y + _value.offsetCamCoords[2],  camCoords.z + _value.offsetCamCoords[3])
            PointCamAtCoord(cam, headCoords.x + _value.offsetPointCam[1], headCoords.y + _value.offsetPointCam[2], headCoords.z + _value.offsetPointCam[3])
            SetCamFov(cam, _value.camFov + 0.0)
            local numDrawable
            if _value.type == 'component' then
                numDrawable = GetNumberOfPedDrawableVariations(cache.ped, _value.componentId)
            else
                numDrawable = GetNumberOfPedPropDrawableVariations(cache.ped, _value.componentId)
            end
            for drawableId = 0, numDrawable, 1 do
                local numTexture
                if _value.type == 'component' then
                    numTexture = GetNumberOfPedTextureVariations(cache.ped, _value.componentId, tonumber(drawableId))
                else
                    numTexture = GetNumberOfPedPropTextureVariations(cache.ped, _value.componentId, tonumber(drawableId))
                end
                for textureId = 0, numTexture, 1 do
                    if _value.type == 'component' then
                        if IsPedComponentVariationValid(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId)) then
                            local curTime = GetGameTimer()
                            while not HasPedPreloadVariationDataFinished(cache.ped) and GetGameTimer() - curTime < 5000 do
                                SetPedPreloadVariationData(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId))
                                Wait(1)
                                print('waiting preload 1', drawableId , textureId)
                            end
                            if HasPedPreloadVariationDataFinished(cache.ped) then
                                TaskPlayAnim(cache.ped, 'anim@mp_corona_idles@female_b@idle_a', 'idle_a', 1.0, 1.0, -1, 1, 1, true, true, true)
                                SetPedComponentVariation(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId), 0)
                                local _hash = GetHashNameForComponent(PlayerPedId(), _value.componentId, drawableId, textureId)
                                local _data = PedComponent(_hash)
                                local _label = GetLabelText(_data.Label)
                                if _label == "NULL" then
                                    _label = Config.ClothingDev[_index].itemLabel:format(tonumber(drawableId), tonumber(textureId))
                                end
                                Wait(100)
                                local result = lib.callback.await('rep-base/callback/saveImage', false, _index, _gender, tonumber(drawableId), tonumber(textureId), _label)
                                Wait(500)
                            end
                            ReleasePedPreloadVariationData(cache.ped)
                        end
                    else
                        local cTime = GetGameTimer()
                        while not HasPedPreloadPropDataFinished(cache.ped) do
                            Wait(1)
                            SetPedPreloadPropData(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId))
                            print('waiting preload 2', drawableId , textureId)
                            if GetGameTimer() - cTime > 5000 then
                                goto next
                            end
                        end
                        if HasPedPreloadPropDataFinished(cache.ped) then
                            TaskPlayAnim(cache.ped, 'anim@mp_corona_idles@female_b@idle_a', 'idle_a', 1.0, 1.0, -1, 1, 1, true, true, true)
                            ClearPedProp(cache.ped, 0)
                            ClearPedProp(cache.ped, 1)
                            ClearPedProp(cache.ped, 2)
                            ClearPedProp(cache.ped, 6)
                            ClearPedProp(cache.ped, 7)
                            SetPedPropIndex(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId), true)
                            local _hash = GetHashNameForProp(PlayerPedId(), _value.componentId, tonumber(drawableId), tonumber(textureId))
                            local _data = PedProp(_hash)
                            local _label = GetLabelText(_data.Label)
                            if _label == "NULL" then
                                _label = Config.ClothingDev[_index].itemLabel:format(tonumber(drawableId), tonumber(textureId))
                            end
                            Wait(100)
                            local result = lib.callback.await('rep-base/callback/saveImage', false, _index, _gender, tonumber(drawableId), tonumber(textureId), _label)
                            Wait(500)
                            Wait(10)
                        end
                        ::next::
                        ReleasePedPreloadPropData(cache.ped)
                    end
                end
            end
            Wait(5000)
            for k, v in pairs(objs) do
                DeleteEntity(v)
            end
            FreezeEntityPosition(cache.ped, false)
            DestroyCam(cam, true)
            cam = nil
            ClearPedTasks(cache.ped)
            Wait(5000)
        end
    end
    weather = false
end, false)

RegisterCommand('clothingitem', function(source, args, rawCommand)
    DisplayRadar(false)
    TriggerEvent('qb-weathersync:client:DisableSync')
    weather = true
    local _gender = args[1] or 'male'
    for _index, _value in pairs(Config.ClothingDev) do
        if _value then
            local numDrawable
            if _value.type == 'component' then
                numDrawable = GetNumberOfPedDrawableVariations(cache.ped, _value.componentId)
            else
                numDrawable = GetNumberOfPedPropDrawableVariations(cache.ped, _value.componentId)
            end
            for drawableId = 0, numDrawable, 1 do
                local numTexture
                if _value.type == 'component' then
                    numTexture = GetNumberOfPedTextureVariations(cache.ped, _value.componentId, tonumber(drawableId))
                else
                    numTexture = GetNumberOfPedPropTextureVariations(cache.ped, _value.componentId, tonumber(drawableId))
                end
                for textureId = 0, numTexture, 1 do
                    if _value.type == 'component' then
                        local _hash = GetHashNameForComponent(cache.ped, _value.componentId, drawableId, textureId)
                        local _data = PedComponent(_hash)
                        local _label = GetLabelText(_data.Label)
                        if _label == "NULL" then
                            _label = Config.ClothingDev[_index].itemLabel:format(tonumber(drawableId), tonumber(textureId))
                        end
                        TriggerServerEvent('rep-base:server:addClothing', _index, _gender, tonumber(drawableId), tonumber(textureId), _label)
                        Wait(10)
                    else
                        local _hash = GetHashNameForProp(cache.ped, _value.componentId, tonumber(drawableId), tonumber(textureId))
                        local _data = PedProp(_hash)
                        local _label = GetLabelText(_data.Label)
                        if _label == "NULL" then
                            _label = Config.ClothingDev[_index].itemLabel:format(tonumber(drawableId), tonumber(textureId))
                        end
                        TriggerServerEvent('rep-base:server:addClothing', _index, _gender, tonumber(drawableId), tonumber(textureId), _label)
                        Wait(10)
                    end
                end
            end
        end
        TriggerServerEvent('rep-base/server/saveClothingData', _index)
        end
end, false)

CreateThread(function()
    while true do
        if weather == true then
            -- SetParkedVehicleDensityMultiplierThisFrame(0.0)
            -- SetVehicleDensityMultiplierThisFrame(0.0)
            -- SetRandomVehicleDensityMultiplierThisFrame(0.0)
            -- SetPedDensityMultiplierThisFrame(0.0)
            -- SetScenarioPedDensityMultiplierThisFrame(0.0, 0.0) -- Walking NPC Density
            SetRainLevel(0.0)
			SetWeatherTypePersist('EXTRASUNNY')
			SetWeatherTypeNow('EXTRASUNNY')
			SetWeatherTypeNowPersist('EXTRASUNNY')
			NetworkOverrideClockTime(13, 0, 0)
        end
        Wait(1000)
    end
end)

AddEventHandler('onResourceStop', function(rsName)
    if rsName == GetCurrentResourceName() then
        for k, v in pairs(objs) do
            DeleteEntity(v)
        end
        FreezeEntityPosition(cache.ped, false)
        DestroyCam(cam, true)
        DisplayRadar(true)
        TriggerEvent('fivem-appearance:client:reloadSkin')
    end
end)