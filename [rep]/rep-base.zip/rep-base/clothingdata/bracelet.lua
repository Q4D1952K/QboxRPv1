bracelet = {
    female = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Snake Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_0_0"
                },
                [1] = {
                    label = "Bracelet (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_0_1"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_1_0"
                },
                [1] = {
                    label = "Bracelet (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Plain Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_2_0"
                },
                [1] = {
                    label = "Bracelet (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_2_1"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Le Chien Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_3_0"
                },
                [1] = {
                    label = "Bracelet (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_3_1"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Detail Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_4_0"
                },
                [1] = {
                    label = "Bracelet (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_4_1"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Swirl Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_5_0"
                },
                [1] = {
                    label = "Bracelet (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_5_1"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Textured Cuff",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_6_0"
                },
                [1] = {
                    label = "Bracelet (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_6_1"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Light Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_7_0"
                },
                [1] = {
                    label = "Bracelet (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_7_1"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chunky Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_8_0"
                },
                [1] = {
                    label = "Bracelet (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_8_1"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Square Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_9_0"
                },
                [1] = {
                    label = "Bracelet (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_9_1"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_10_0"
                },
                [1] = {
                    label = "Bracelet (10-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_10_1"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tread Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_11_0"
                },
                [1] = {
                    label = "Bracelet (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_11_1"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gear Wrist Chains (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_12_0"
                },
                [1] = {
                    label = "Bracelet (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_12_1"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_13_0"
                },
                [1] = {
                    label = "Bracelet (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_13_1"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_14_0"
                },
                [1] = {
                    label = "Chocolate Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_14_1"
                },
                [2] = {
                    label = "Tan Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_14_2"
                },
                [3] = {
                    label = "Ox Blood Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_14_3"
                },
                [4] = {
                    label = "Bracelet (14-4)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_14_4"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_0"
                },
                [1] = {
                    label = "Red Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_1"
                },
                [2] = {
                    label = "Pink Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_2"
                },
                [3] = {
                    label = "Yellow Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_3"
                },
                [4] = {
                    label = "Orange Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_4"
                },
                [5] = {
                    label = "Green Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_5"
                },
                [6] = {
                    label = "Red & Blue Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_6"
                },
                [7] = {
                    label = "Yellow & Orange Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_7"
                },
                [8] = {
                    label = "Green & Pink Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_8"
                },
                [9] = {
                    label = "Rainbow Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_9"
                },
                [10] = {
                    label = "Sunset Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_10"
                },
                [11] = {
                    label = "Tropical Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_11"
                },
                [12] = {
                    label = "Bracelet (15-12)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_15_12"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_16_0"
                },
                [1] = {
                    label = "Silver Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_16_1"
                },
                [2] = {
                    label = "Rose Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_16_2"
                },
                [3] = {
                    label = "Bracelet (16-3)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_16_3"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_0"
                },
                [1] = {
                    label = "Mono Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_1"
                },
                [2] = {
                    label = "Gold Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_2"
                },
                [3] = {
                    label = "Rose Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_3"
                },
                [4] = {
                    label = "Copper Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_4"
                },
                [5] = {
                    label = "Bracelet (17-5)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_17_5"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_0"
                },
                [1] = {
                    label = "Mono Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_1"
                },
                [2] = {
                    label = "Gold Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_2"
                },
                [3] = {
                    label = "Rose Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_3"
                },
                [4] = {
                    label = "Copper Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_4"
                },
                [5] = {
                    label = "Bracelet (18-5)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_18_5"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_0"
                },
                [1] = {
                    label = "Dark Gray Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_1"
                },
                [2] = {
                    label = "Light Gray Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_2"
                },
                [3] = {
                    label = "White Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_3"
                },
                [4] = {
                    label = "Ox Blood Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_4"
                },
                [5] = {
                    label = "Crimson Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_5"
                },
                [6] = {
                    label = "Green Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_6"
                },
                [7] = {
                    label = "Red Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_7"
                },
                [8] = {
                    label = "Orange Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_8"
                },
                [9] = {
                    label = "Mustard Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_9"
                },
                [10] = {
                    label = "Chestnut Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_10"
                },
                [11] = {
                    label = "Dark Nut Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_11"
                },
                [12] = {
                    label = "Blue Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_12"
                },
                [13] = {
                    label = "Light Blue Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_13"
                },
                [14] = {
                    label = "Bracelet (19-14)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_19_14"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Aqua Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_0"
                },
                [1] = {
                    label = "Moss Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_1"
                },
                [2] = {
                    label = "Sand Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_2"
                },
                [3] = {
                    label = "Stone Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_3"
                },
                [4] = {
                    label = "Bright Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_4"
                },
                [5] = {
                    label = "Rust Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_5"
                },
                [6] = {
                    label = "Bracelet (20-6)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_20_6"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Thick Silver Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_0"
                },
                [1] = {
                    label = "Thick Dark Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_1"
                },
                [2] = {
                    label = "Thick Gold Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_2"
                },
                [3] = {
                    label = "Thick Rose Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_3"
                },
                [4] = {
                    label = "Thick Bronze Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_4"
                },
                [5] = {
                    label = "Bracelet (21-5)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_21_5"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_0"
                },
                [1] = {
                    label = "Dark Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_1"
                },
                [2] = {
                    label = "Gold Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_2"
                },
                [3] = {
                    label = "Rose Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_3"
                },
                [4] = {
                    label = "Bronze Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_4"
                },
                [5] = {
                    label = "Bracelet (22-5)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_22_5"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bracelet (23-0)",
                    price = 500,
                    type = "money",
                    image = "female_bracelet_23_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Light Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_0_0"
                },
                [1] = {
                    label = "Bracelet (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_0_1"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chunky Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_1_0"
                },
                [1] = {
                    label = "Bracelet (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Square Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_2_0"
                },
                [1] = {
                    label = "Bracelet (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_2_1"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_3_0"
                },
                [1] = {
                    label = "Bracelet (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_3_1"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tread Wrist Chain (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_4_0"
                },
                [1] = {
                    label = "Bracelet (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_4_1"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gear Wrist Chains (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_5_0"
                },
                [1] = {
                    label = "Bracelet (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_5_1"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_6_0"
                },
                [1] = {
                    label = "Bracelet (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_6_1"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_7_0"
                },
                [1] = {
                    label = "Chocolate Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_7_1"
                },
                [2] = {
                    label = "Tan Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_7_2"
                },
                [3] = {
                    label = "Ox Blood Gauntlet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_7_3"
                },
                [4] = {
                    label = "Bracelet (7-4)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_7_4"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_0"
                },
                [1] = {
                    label = "Red Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_1"
                },
                [2] = {
                    label = "Pink Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_2"
                },
                [3] = {
                    label = "Yellow Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_3"
                },
                [4] = {
                    label = "Orange Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_4"
                },
                [5] = {
                    label = "Green Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_5"
                },
                [6] = {
                    label = "Red & Blue Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_6"
                },
                [7] = {
                    label = "Yellow & Orange Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_7"
                },
                [8] = {
                    label = "Green & Pink Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_8"
                },
                [9] = {
                    label = "Rainbow Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_9"
                },
                [10] = {
                    label = "Sunset Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_10"
                },
                [11] = {
                    label = "Tropical Bangles (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_11"
                },
                [12] = {
                    label = "Bracelet (8-12)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_8_12"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_9_0"
                },
                [1] = {
                    label = "Silver Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_9_1"
                },
                [2] = {
                    label = "Rose Meander Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_9_2"
                },
                [3] = {
                    label = "Bracelet (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_9_3"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_0"
                },
                [1] = {
                    label = "Mono Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_1"
                },
                [2] = {
                    label = "Gold Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_2"
                },
                [3] = {
                    label = "Rose Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_3"
                },
                [4] = {
                    label = "Copper Chunky Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_4"
                },
                [5] = {
                    label = "Bracelet (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_10_5"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_0"
                },
                [1] = {
                    label = "Mono Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_1"
                },
                [2] = {
                    label = "Gold Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_2"
                },
                [3] = {
                    label = "Rose Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_3"
                },
                [4] = {
                    label = "Copper Chain Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_4"
                },
                [5] = {
                    label = "Bracelet (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_11_5"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_0"
                },
                [1] = {
                    label = "Dark Gray Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_1"
                },
                [2] = {
                    label = "Light Gray Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_2"
                },
                [3] = {
                    label = "White Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_3"
                },
                [4] = {
                    label = "Ox Blood Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_4"
                },
                [5] = {
                    label = "Crimson Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_5"
                },
                [6] = {
                    label = "Green Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_6"
                },
                [7] = {
                    label = "Red Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_7"
                },
                [8] = {
                    label = "Orange Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_8"
                },
                [9] = {
                    label = "Mustard Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_9"
                },
                [10] = {
                    label = "Chestnut Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_10"
                },
                [11] = {
                    label = "Dark Nut Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_11"
                },
                [12] = {
                    label = "Blue Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_12"
                },
                [13] = {
                    label = "Light Blue Woven Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_13"
                },
                [14] = {
                    label = "Bracelet (12-14)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_12_14"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Aqua Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_0"
                },
                [1] = {
                    label = "Moss Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_1"
                },
                [2] = {
                    label = "Sand Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_2"
                },
                [3] = {
                    label = "Stone Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_3"
                },
                [4] = {
                    label = "Bright Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_4"
                },
                [5] = {
                    label = "Rust Hippy Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_5"
                },
                [6] = {
                    label = "Bracelet (13-6)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_13_6"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Thick Silver Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_0"
                },
                [1] = {
                    label = "Thick Dark Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_1"
                },
                [2] = {
                    label = "Thick Gold Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_2"
                },
                [3] = {
                    label = "Thick Rose Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_3"
                },
                [4] = {
                    label = "Thick Bronze Chain Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_4"
                },
                [5] = {
                    label = "Bracelet (14-5)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_14_5"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_0"
                },
                [1] = {
                    label = "Dark Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_1"
                },
                [2] = {
                    label = "Gold Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_2"
                },
                [3] = {
                    label = "Rose Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_3"
                },
                [4] = {
                    label = "Bronze Bangle Cuff Bracelet (R)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_4"
                },
                [5] = {
                    label = "Bracelet (15-5)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_15_5"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bracelet (16-0)",
                    price = 500,
                    type = "money",
                    image = "male_bracelet_16_0"
                },
            },
        },
    },
}
