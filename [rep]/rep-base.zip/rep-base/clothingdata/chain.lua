chain = {

    female = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_0_0"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_0"
                },
                [1] = {
                    label = "Accessories (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_1"
                },
                [2] = {
                    label = "Accessories (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_2"
                },
                [3] = {
                    label = "Accessories (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_3"
                },
                [4] = {
                    label = "Accessories (1-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_4"
                },
                [5] = {
                    label = "Accessories (1-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_1_5"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_0"
                },
                [1] = {
                    label = "Accessories (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_1"
                },
                [2] = {
                    label = "Accessories (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_2"
                },
                [3] = {
                    label = "Accessories (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_3"
                },
                [4] = {
                    label = "Accessories (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_4"
                },
                [5] = {
                    label = "Accessories (2-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_2_5"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_0"
                },
                [1] = {
                    label = "Accessories (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_1"
                },
                [2] = {
                    label = "Accessories (3-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_2"
                },
                [3] = {
                    label = "Accessories (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_3"
                },
                [4] = {
                    label = "Accessories (3-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_4"
                },
                [5] = {
                    label = "Accessories (3-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_3_5"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_0"
                },
                [1] = {
                    label = "Accessories (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_1"
                },
                [2] = {
                    label = "Accessories (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_2"
                },
                [3] = {
                    label = "Accessories (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_3"
                },
                [4] = {
                    label = "Accessories (4-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_4"
                },
                [5] = {
                    label = "Accessories (4-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_4_5"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_0"
                },
                [1] = {
                    label = "Accessories (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_1"
                },
                [2] = {
                    label = "Accessories (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_2"
                },
                [3] = {
                    label = "Accessories (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_3"
                },
                [4] = {
                    label = "Accessories (5-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_4"
                },
                [5] = {
                    label = "Accessories (5-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_5_5"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_0"
                },
                [1] = {
                    label = "Accessories (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_1"
                },
                [2] = {
                    label = "Accessories (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_2"
                },
                [3] = {
                    label = "Accessories (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_3"
                },
                [4] = {
                    label = "Accessories (6-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_4"
                },
                [5] = {
                    label = "Accessories (6-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_6_5"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_0"
                },
                [1] = {
                    label = "Accessories (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_1"
                },
                [2] = {
                    label = "Accessories (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_2"
                },
                [3] = {
                    label = "Accessories (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_3"
                },
                [4] = {
                    label = "Accessories (7-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_4"
                },
                [5] = {
                    label = "Accessories (7-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_7_5"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (8-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_0"
                },
                [1] = {
                    label = "Accessories (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_1"
                },
                [2] = {
                    label = "Accessories (8-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_2"
                },
                [3] = {
                    label = "Accessories (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_3"
                },
                [4] = {
                    label = "Accessories (8-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_4"
                },
                [5] = {
                    label = "Accessories (8-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_8_5"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (9-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_0"
                },
                [1] = {
                    label = "Accessories (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_1"
                },
                [2] = {
                    label = "Accessories (9-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_2"
                },
                [3] = {
                    label = "Accessories (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_3"
                },
                [4] = {
                    label = "Accessories (9-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_4"
                },
                [5] = {
                    label = "Accessories (9-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_9_5"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Floral Bangles",
                    price = 500,
                    type = "money",
                    image = "female_chain_10_0"
                },
                [1] = {
                    label = "MyMy Psychedelic Bangles",
                    price = 500,
                    type = "money",
                    image = "female_chain_10_1"
                },
                [2] = {
                    label = "Green Bangles",
                    price = 500,
                    type = "money",
                    image = "female_chain_10_2"
                },
                [3] = {
                    label = "Red Bangles",
                    price = 500,
                    type = "money",
                    image = "female_chain_10_3"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "MyMy Black Heart Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_11_0"
                },
                [1] = {
                    label = "MyMy Pink Heart Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_11_1"
                },
                [2] = {
                    label = "Rose Heart Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_11_2"
                },
                [3] = {
                    label = "All Silver Heart Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_11_3"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Beads",
                    price = 500,
                    type = "money",
                    image = "female_chain_12_0"
                },
                [1] = {
                    label = "Silver Beads",
                    price = 500,
                    type = "money",
                    image = "female_chain_12_1"
                },
                [2] = {
                    label = "Black Beads",
                    price = 500,
                    type = "money",
                    image = "female_chain_12_2"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Spotted Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_0"
                },
                [1] = {
                    label = "Floral Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_1"
                },
                [2] = {
                    label = "Pink Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_2"
                },
                [3] = {
                    label = "Red Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_3"
                },
                [4] = {
                    label = "Leopard Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_4"
                },
                [5] = {
                    label = "White Bow Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_13_5"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black & White Leather Straps",
                    price = 500,
                    type = "money",
                    image = "female_chain_14_0"
                },
                [1] = {
                    label = "Summer Leather Straps",
                    price = 500,
                    type = "money",
                    image = "female_chain_14_1"
                },
                [2] = {
                    label = "Candy Leather Straps",
                    price = 500,
                    type = "money",
                    image = "female_chain_14_2"
                },
                [3] = {
                    label = "Pink Check Leather Straps",
                    price = 500,
                    type = "money",
                    image = "female_chain_14_3"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Tassel Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_15_0"
                },
                [1] = {
                    label = "Purple Tassel Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_15_1"
                },
                [2] = {
                    label = "Olive Tassel Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_15_2"
                },
                [3] = {
                    label = "Pink Tassel Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_15_3"
                },
                [4] = {
                    label = "Teal Tassel Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_15_4"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (16-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_16_0"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stripy Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_17_0"
                },
                [1] = {
                    label = "Joy Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_17_1"
                },
                [2] = {
                    label = "Snowflake Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_17_2"
                },
                [3] = {
                    label = "Storm Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_17_3"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stripy Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_18_0"
                },
                [1] = {
                    label = "Joy Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_18_1"
                },
                [2] = {
                    label = "Snowflake Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_18_2"
                },
                [3] = {
                    label = "Storm Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_18_3"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_19_0"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_0"
                },
                [1] = {
                    label = "Khaki Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_1"
                },
                [2] = {
                    label = "White Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_2"
                },
                [3] = {
                    label = "Green Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_3"
                },
                [4] = {
                    label = "Purple Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_4"
                },
                [5] = {
                    label = "Fuchsia Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_5"
                },
                [6] = {
                    label = "Gray Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_6"
                },
                [7] = {
                    label = "Tan Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_7"
                },
                [8] = {
                    label = "Blue Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_8"
                },
                [9] = {
                    label = "Teal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_9"
                },
                [10] = {
                    label = "Orange Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_10"
                },
                [11] = {
                    label = "Blue Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_11"
                },
                [12] = {
                    label = "Tan Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_12"
                },
                [13] = {
                    label = "Pink Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_13"
                },
                [14] = {
                    label = "Green Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_14"
                },
                [15] = {
                    label = "Blue Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_20_15"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_21_0"
                },
                [1] = {
                    label = "Gray Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_21_1"
                },
                [2] = {
                    label = "Black Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_21_2"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_0"
                },
                [1] = {
                    label = "Khaki Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_1"
                },
                [2] = {
                    label = "White Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_2"
                },
                [3] = {
                    label = "Green Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_3"
                },
                [4] = {
                    label = "Purple Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_4"
                },
                [5] = {
                    label = "Fuchsia Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_5"
                },
                [6] = {
                    label = "Gray Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_6"
                },
                [7] = {
                    label = "Tan Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_7"
                },
                [8] = {
                    label = "Blue Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_8"
                },
                [9] = {
                    label = "Teal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_9"
                },
                [10] = {
                    label = "Orange Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_10"
                },
                [11] = {
                    label = "Blue Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_11"
                },
                [12] = {
                    label = "Tan Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_12"
                },
                [13] = {
                    label = "Pink Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_13"
                },
                [14] = {
                    label = "Green Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_14"
                },
                [15] = {
                    label = "Blue Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_22_15"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bow Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_23_0"
                },
                [1] = {
                    label = "White Bow Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_23_1"
                },
                [2] = {
                    label = "Red Bow Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_23_2"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (24-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_24_0"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (25-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_25_0"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_0"
                },
                [1] = {
                    label = "Khaki Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_1"
                },
                [2] = {
                    label = "White Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_2"
                },
                [3] = {
                    label = "Green Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_3"
                },
                [4] = {
                    label = "Purple Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_4"
                },
                [5] = {
                    label = "Fuchsia Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_5"
                },
                [6] = {
                    label = "Gray Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_6"
                },
                [7] = {
                    label = "Tan Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_7"
                },
                [8] = {
                    label = "Blue Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_8"
                },
                [9] = {
                    label = "Teal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_9"
                },
                [10] = {
                    label = "Orange Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_10"
                },
                [11] = {
                    label = "Blue Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_11"
                },
                [12] = {
                    label = "Tan Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_12"
                },
                [13] = {
                    label = "Pink Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_13"
                },
                [14] = {
                    label = "Green Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_14"
                },
                [15] = {
                    label = "Blue Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_26_15"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_27_0"
                },
                [1] = {
                    label = "Gray Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_27_1"
                },
                [2] = {
                    label = "Black Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_27_2"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_0"
                },
                [1] = {
                    label = "Khaki Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_1"
                },
                [2] = {
                    label = "White Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_2"
                },
                [3] = {
                    label = "Accessories (28-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_3"
                },
                [4] = {
                    label = "Purple Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_4"
                },
                [5] = {
                    label = "Fuchsia Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_5"
                },
                [6] = {
                    label = "Gray Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_6"
                },
                [7] = {
                    label = "Tan Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_7"
                },
                [8] = {
                    label = "Blue Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_8"
                },
                [9] = {
                    label = "Teal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_9"
                },
                [10] = {
                    label = "Orange Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_10"
                },
                [11] = {
                    label = "Blue Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_11"
                },
                [12] = {
                    label = "Tan Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_12"
                },
                [13] = {
                    label = "Pink Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_13"
                },
                [14] = {
                    label = "Green Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_14"
                },
                [15] = {
                    label = "Blue Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "female_chain_28_15"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold SN Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_29_0"
                },
                [1] = {
                    label = "Platinum SN Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_29_1"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_30_0"
                },
                [1] = {
                    label = "Platinum Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_30_1"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Platinum Balaclava Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_31_0"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_32_0"
                },
                [1] = {
                    label = "Platinum Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_32_1"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LC Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_33_0"
                },
                [1] = {
                    label = "Platinum LC Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_33_1"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_34_0"
                },
                [1] = {
                    label = "Platinum Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_34_1"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_35_0"
                },
                [1] = {
                    label = "Platinum Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_35_1"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold SN Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_36_0"
                },
                [1] = {
                    label = "Platinum SN Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_36_1"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_37_0"
                },
                [1] = {
                    label = "Platinum Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_37_1"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Platinum Balaclava Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_38_0"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_39_0"
                },
                [1] = {
                    label = "Platinum Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_39_1"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LC Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_40_0"
                },
                [1] = {
                    label = "Platinum LC Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_40_1"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_41_0"
                },
                [1] = {
                    label = "Platinum Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_41_1"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_42_0"
                },
                [1] = {
                    label = "Platinum Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_42_1"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (43-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_43_0"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (44-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_44_0"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (45-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_45_0"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (46-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_46_0"
                },
                [1] = {
                    label = "Accessories (46-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_46_1"
                },
                [2] = {
                    label = "Accessories (46-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_46_2"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (47-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_47_0"
                },
                [1] = {
                    label = "Accessories (47-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_47_1"
                },
                [2] = {
                    label = "Accessories (47-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_47_2"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (48-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_48_0"
                },
                [1] = {
                    label = "Accessories (48-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_48_1"
                },
                [2] = {
                    label = "Accessories (48-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_48_2"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (49-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_49_0"
                },
                [1] = {
                    label = "Accessories (49-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_49_1"
                },
                [2] = {
                    label = "Accessories (49-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_49_2"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (50-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_50_0"
                },
                [1] = {
                    label = "Accessories (50-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_50_1"
                },
                [2] = {
                    label = "Accessories (50-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_50_2"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (51-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_51_0"
                },
                [1] = {
                    label = "Accessories (51-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_51_1"
                },
                [2] = {
                    label = "Accessories (51-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_51_2"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (52-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_52_0"
                },
                [1] = {
                    label = "Accessories (52-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_52_1"
                },
                [2] = {
                    label = "Accessories (52-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_52_2"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_53_0"
                },
                [1] = {
                    label = "Platinum Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_53_1"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_54_0"
                },
                [1] = {
                    label = "Platinum Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_54_1"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_55_0"
                },
                [1] = {
                    label = "Platinum Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_55_1"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_56_0"
                },
                [1] = {
                    label = "Platinum Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_56_1"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_57_0"
                },
                [1] = {
                    label = "Platinum Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_57_1"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_58_0"
                },
                [1] = {
                    label = "Platinum Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_58_1"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_59_0"
                },
                [1] = {
                    label = "Platinum Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_59_1"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_60_0"
                },
                [1] = {
                    label = "Platinum Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_60_1"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_61_0"
                },
                [1] = {
                    label = "Platinum Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_61_1"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rope Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_62_0"
                },
                [1] = {
                    label = "Platinum Rope Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_62_1"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_0"
                },
                [1] = {
                    label = "Green Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_1"
                },
                [2] = {
                    label = "Tan Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_2"
                },
                [3] = {
                    label = "Gray Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_3"
                },
                [4] = {
                    label = "Black Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_4"
                },
                [5] = {
                    label = "Peach Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_63_5"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_64_0"
                },
                [1] = {
                    label = "Platinum Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_64_1"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_65_0"
                },
                [1] = {
                    label = "Platinum Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_65_1"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_66_0"
                },
                [1] = {
                    label = "Platinum Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_66_1"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_67_0"
                },
                [1] = {
                    label = "Platinum Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_67_1"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_68_0"
                },
                [1] = {
                    label = "Platinum Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_68_1"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_69_0"
                },
                [1] = {
                    label = "Platinum Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_69_1"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_70_0"
                },
                [1] = {
                    label = "Platinum Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_70_1"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_71_0"
                },
                [1] = {
                    label = "Platinum Square Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_71_1"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_72_0"
                },
                [1] = {
                    label = "Platinum Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_72_1"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rope Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_73_0"
                },
                [1] = {
                    label = "Platinum Rope Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_73_1"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (74-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_74_0"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (75-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_75_0"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (76-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_76_0"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (77-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_77_0"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (78-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_78_0"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (79-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_79_0"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (80-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_80_0"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_81_0"
                },
                [1] = {
                    label = "Platinum Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_81_1"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_82_0"
                },
                [1] = {
                    label = "Platinum Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_82_1"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_83_0"
                },
                [1] = {
                    label = "Khaki Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_83_1"
                },
                [2] = {
                    label = "Black Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "female_chain_83_2"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_84_0"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (85-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_85_0"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (86-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_86_0"
                },
                [1] = {
                    label = "Accessories (86-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_86_1"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (87-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_0"
                },
                [1] = {
                    label = "Accessories (87-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_1"
                },
                [2] = {
                    label = "Accessories (87-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_2"
                },
                [3] = {
                    label = "Accessories (87-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_3"
                },
                [4] = {
                    label = "Accessories (87-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_4"
                },
                [5] = {
                    label = "Accessories (87-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_5"
                },
                [6] = {
                    label = "Accessories (87-6)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_6"
                },
                [7] = {
                    label = "Accessories (87-7)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_7"
                },
                [8] = {
                    label = "Accessories (87-8)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_8"
                },
                [9] = {
                    label = "Accessories (87-9)",
                    price = 500,
                    type = "money",
                    image = "female_chain_87_9"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Suspenders",
                    price = 500,
                    type = "money",
                    image = "female_chain_88_0"
                },
                [1] = {
                    label = "White Suspenders",
                    price = 500,
                    type = "money",
                    image = "female_chain_88_1"
                },
                [2] = {
                    label = "Red Suspenders",
                    price = 500,
                    type = "money",
                    image = "female_chain_88_2"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_89_0"
                },
                [1] = {
                    label = "Platinum Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_89_1"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_90_0"
                },
                [1] = {
                    label = "Platinum Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_90_1"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_91_0"
                },
                [1] = {
                    label = "Platinum Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_91_1"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_92_0"
                },
                [1] = {
                    label = "Platinum Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_92_1"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_93_0"
                },
                [1] = {
                    label = "Pearl Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_93_1"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (94-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_94_0"
                },
                [1] = {
                    label = "Accessories (94-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_94_1"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (95-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_95_0"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (96-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_96_0"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (97-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_97_0"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (98-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_98_0"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "female_chain_99_0"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "female_chain_100_0"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "female_chain_101_0"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (102-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_0"
                },
                [1] = {
                    label = "Accessories (102-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_1"
                },
                [2] = {
                    label = "Accessories (102-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_2"
                },
                [3] = {
                    label = "Accessories (102-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_3"
                },
                [4] = {
                    label = "Accessories (102-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_4"
                },
                [5] = {
                    label = "Accessories (102-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_5"
                },
                [6] = {
                    label = "Accessories (102-6)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_6"
                },
                [7] = {
                    label = "Accessories (102-7)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_7"
                },
                [8] = {
                    label = "Accessories (102-8)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_8"
                },
                [9] = {
                    label = "Accessories (102-9)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_9"
                },
                [10] = {
                    label = "Accessories (102-10)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_10"
                },
                [11] = {
                    label = "Accessories (102-11)",
                    price = 500,
                    type = "money",
                    image = "female_chain_102_11"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_103_0"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_104_0"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_105_0"
                },
                [1] = {
                    label = "Silver LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_105_1"
                },
                [2] = {
                    label = "Copper LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_105_2"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_106_0"
                },
                [1] = {
                    label = "Silver LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_106_1"
                },
                [2] = {
                    label = "Copper LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_106_2"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Enamel LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_107_0"
                },
                [1] = {
                    label = "Silver Plate LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_107_1"
                },
                [2] = {
                    label = "Two-Tone LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_107_2"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Enamel LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_108_0"
                },
                [1] = {
                    label = "Silver Plate LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_108_1"
                },
                [2] = {
                    label = "Two-Tone LS Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_108_2"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_109_0"
                },
                [1] = {
                    label = "Silver Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_109_1"
                },
                [2] = {
                    label = "Bronze Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_109_2"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_110_0"
                },
                [1] = {
                    label = "Silver Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_110_1"
                },
                [2] = {
                    label = "Bronze Tags",
                    price = 500,
                    type = "money",
                    image = "female_chain_110_2"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_111_0"
                },
                [1] = {
                    label = "Silver L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_111_1"
                },
                [2] = {
                    label = "Two-Tone L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_111_2"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_112_0"
                },
                [1] = {
                    label = "Silver L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_112_1"
                },
                [2] = {
                    label = "Two-Tone L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_112_2"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_113_0"
                },
                [1] = {
                    label = "Silver Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_113_1"
                },
                [2] = {
                    label = "Bronze Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_113_2"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_114_0"
                },
                [1] = {
                    label = "Silver Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_114_1"
                },
                [2] = {
                    label = "Bronze Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_114_2"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (115-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_0"
                },
                [1] = {
                    label = "Accessories (115-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_1"
                },
                [2] = {
                    label = "Accessories (115-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_2"
                },
                [3] = {
                    label = "Accessories (115-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_3"
                },
                [4] = {
                    label = "Accessories (115-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_4"
                },
                [5] = {
                    label = "Accessories (115-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_5"
                },
                [6] = {
                    label = "Accessories (115-6)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_6"
                },
                [7] = {
                    label = "Accessories (115-7)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_7"
                },
                [8] = {
                    label = "Accessories (115-8)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_8"
                },
                [9] = {
                    label = "Accessories (115-9)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_9"
                },
                [10] = {
                    label = "Accessories (115-10)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_10"
                },
                [11] = {
                    label = "Accessories (115-11)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_11"
                },
                [12] = {
                    label = "Accessories (115-12)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_12"
                },
                [13] = {
                    label = "Accessories (115-13)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_13"
                },
                [14] = {
                    label = "Accessories (115-14)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_14"
                },
                [15] = {
                    label = "Accessories (115-15)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_15"
                },
                [16] = {
                    label = "Accessories (115-16)",
                    price = 500,
                    type = "money",
                    image = "female_chain_115_16"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (116-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_0"
                },
                [1] = {
                    label = "Accessories (116-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_1"
                },
                [2] = {
                    label = "Accessories (116-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_2"
                },
                [3] = {
                    label = "Accessories (116-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_3"
                },
                [4] = {
                    label = "Accessories (116-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_4"
                },
                [5] = {
                    label = "Accessories (116-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_5"
                },
                [6] = {
                    label = "Accessories (116-6)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_6"
                },
                [7] = {
                    label = "Accessories (116-7)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_7"
                },
                [8] = {
                    label = "Accessories (116-8)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_8"
                },
                [9] = {
                    label = "Accessories (116-9)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_9"
                },
                [10] = {
                    label = "Accessories (116-10)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_10"
                },
                [11] = {
                    label = "Accessories (116-11)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_11"
                },
                [12] = {
                    label = "Accessories (116-12)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_12"
                },
                [13] = {
                    label = "Accessories (116-13)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_13"
                },
                [14] = {
                    label = "Accessories (116-14)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_14"
                },
                [15] = {
                    label = "Accessories (116-15)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_15"
                },
                [16] = {
                    label = "Accessories (116-16)",
                    price = 500,
                    type = "money",
                    image = "female_chain_116_16"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (117-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_0"
                },
                [1] = {
                    label = "Accessories (117-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_1"
                },
                [2] = {
                    label = "Accessories (117-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_2"
                },
                [3] = {
                    label = "Accessories (117-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_3"
                },
                [4] = {
                    label = "Accessories (117-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_4"
                },
                [5] = {
                    label = "Accessories (117-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_5"
                },
                [6] = {
                    label = "Accessories (117-6)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_6"
                },
                [7] = {
                    label = "Accessories (117-7)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_7"
                },
                [8] = {
                    label = "Accessories (117-8)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_8"
                },
                [9] = {
                    label = "Accessories (117-9)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_9"
                },
                [10] = {
                    label = "Accessories (117-10)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_10"
                },
                [11] = {
                    label = "Accessories (117-11)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_11"
                },
                [12] = {
                    label = "Accessories (117-12)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_12"
                },
                [13] = {
                    label = "Accessories (117-13)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_13"
                },
                [14] = {
                    label = "Accessories (117-14)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_14"
                },
                [15] = {
                    label = "Accessories (117-15)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_15"
                },
                [16] = {
                    label = "Accessories (117-16)",
                    price = 500,
                    type = "money",
                    image = "female_chain_117_16"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_0"
                },
                [1] = {
                    label = "Red Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_1"
                },
                [2] = {
                    label = "Pink Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_2"
                },
                [3] = {
                    label = "Yellow Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_3"
                },
                [4] = {
                    label = "Orange Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_4"
                },
                [5] = {
                    label = "Green Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_5"
                },
                [6] = {
                    label = "Festival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_6"
                },
                [7] = {
                    label = "Carnival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_7"
                },
                [8] = {
                    label = "Tropical Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_8"
                },
                [9] = {
                    label = "Hot Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_9"
                },
                [10] = {
                    label = "Neon Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_10"
                },
                [11] = {
                    label = "Party Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_11"
                },
                [12] = {
                    label = "Sunset Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_12"
                },
                [13] = {
                    label = "Radiant Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_13"
                },
                [14] = {
                    label = "Sunrise Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_14"
                },
                [15] = {
                    label = "Session Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_118_15"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_0"
                },
                [1] = {
                    label = "Red Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_1"
                },
                [2] = {
                    label = "Pink Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_2"
                },
                [3] = {
                    label = "Yellow Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_3"
                },
                [4] = {
                    label = "Orange Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_4"
                },
                [5] = {
                    label = "Green Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_5"
                },
                [6] = {
                    label = "Festival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_6"
                },
                [7] = {
                    label = "Carnival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_7"
                },
                [8] = {
                    label = "Tropical Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_8"
                },
                [9] = {
                    label = "Hot Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_9"
                },
                [10] = {
                    label = "Neon Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_10"
                },
                [11] = {
                    label = "Party Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_11"
                },
                [12] = {
                    label = "Sunset Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_12"
                },
                [13] = {
                    label = "Radiant Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_13"
                },
                [14] = {
                    label = "Sunrise Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_14"
                },
                [15] = {
                    label = "Session Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_119_15"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (120-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_120_0"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (121-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_121_0"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (122-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_122_0"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Le Chien Whistle Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_123_0"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Le Chien Whistle Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_124_0"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_0"
                },
                [1] = {
                    label = "Black Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_1"
                },
                [2] = {
                    label = "Gold Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_2"
                },
                [3] = {
                    label = "Rose Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_3"
                },
                [4] = {
                    label = "Lilac Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_4"
                },
                [5] = {
                    label = "Silver Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_5"
                },
                [6] = {
                    label = "Brown Agate Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_6"
                },
                [7] = {
                    label = "White & Turquoise Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_7"
                },
                [8] = {
                    label = "White & Dark Blue Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_8"
                },
                [9] = {
                    label = "White & Purple Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_125_9"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_0"
                },
                [1] = {
                    label = "Black Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_1"
                },
                [2] = {
                    label = "Gold Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_2"
                },
                [3] = {
                    label = "Rose Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_3"
                },
                [4] = {
                    label = "Lilac Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_4"
                },
                [5] = {
                    label = "Silver Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_5"
                },
                [6] = {
                    label = "Brown Agate Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_6"
                },
                [7] = {
                    label = "White & Turquoise Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_7"
                },
                [8] = {
                    label = "White & Dark Blue Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_8"
                },
                [9] = {
                    label = "White & Purple Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_126_9"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heartbreak Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_127_0"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heartbreak Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_128_0"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_129_0"
                },
                [1] = {
                    label = "Black Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_129_1"
                },
                [2] = {
                    label = "Gold Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_129_2"
                },
                [3] = {
                    label = "Rose Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_129_3"
                },
                [4] = {
                    label = "Copper Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_129_4"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_130_0"
                },
                [1] = {
                    label = "Black Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_130_1"
                },
                [2] = {
                    label = "Gold Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_130_2"
                },
                [3] = {
                    label = "Rose Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_130_3"
                },
                [4] = {
                    label = "Copper Mesh Link",
                    price = 500,
                    type = "money",
                    image = "female_chain_130_4"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_131_0"
                },
                [1] = {
                    label = "Black Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_131_1"
                },
                [2] = {
                    label = "Gold Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_131_2"
                },
                [3] = {
                    label = "Rose Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_131_3"
                },
                [4] = {
                    label = "Copper Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_131_4"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_132_0"
                },
                [1] = {
                    label = "Black Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_132_1"
                },
                [2] = {
                    label = "Gold Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_132_2"
                },
                [3] = {
                    label = "Rose Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_132_3"
                },
                [4] = {
                    label = "Copper Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "female_chain_132_4"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_133_0"
                },
                [1] = {
                    label = "Black Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_133_1"
                },
                [2] = {
                    label = "Gold Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_133_2"
                },
                [3] = {
                    label = "Rose Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_133_3"
                },
                [4] = {
                    label = "Copper Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_133_4"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_134_0"
                },
                [1] = {
                    label = "Black Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_134_1"
                },
                [2] = {
                    label = "Gold Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_134_2"
                },
                [3] = {
                    label = "Rose Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_134_3"
                },
                [4] = {
                    label = "Copper Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_134_4"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (135-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_135_0"
                },
                [1] = {
                    label = "Accessories (135-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_135_1"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (136-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_136_0"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (137-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_137_0"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (138-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_138_0"
                },
                [1] = {
                    label = "Accessories (138-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_138_1"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (139-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_139_0"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (140-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_140_0"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_141_0"
                },
                [1] = {
                    label = "Dark Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_141_1"
                },
                [2] = {
                    label = "Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_141_2"
                },
                [3] = {
                    label = "Rose Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_141_3"
                },
                [4] = {
                    label = "Copper Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_141_4"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_142_0"
                },
                [1] = {
                    label = "Dark Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_142_1"
                },
                [2] = {
                    label = "Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_142_2"
                },
                [3] = {
                    label = "Rose Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_142_3"
                },
                [4] = {
                    label = "Copper Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "female_chain_142_4"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cliffford Remote",
                    price = 500,
                    type = "money",
                    image = "female_chain_143_0"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cliffford Remote",
                    price = 500,
                    type = "money",
                    image = "female_chain_144_0"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (145-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_145_0"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (146-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_146_0"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (147-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_0"
                },
                [1] = {
                    label = "Accessories (147-1)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_1"
                },
                [2] = {
                    label = "Accessories (147-2)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_2"
                },
                [3] = {
                    label = "Accessories (147-3)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_3"
                },
                [4] = {
                    label = "Accessories (147-4)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_4"
                },
                [5] = {
                    label = "Accessories (147-5)",
                    price = 500,
                    type = "money",
                    image = "female_chain_147_5"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_148_0"
                },
                [1] = {
                    label = "Black Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_148_1"
                },
                [2] = {
                    label = "Gold Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_148_2"
                },
                [3] = {
                    label = "Rose Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_148_3"
                },
                [4] = {
                    label = "Bronze Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_148_4"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_149_0"
                },
                [1] = {
                    label = "Black Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_149_1"
                },
                [2] = {
                    label = "Gold Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_149_2"
                },
                [3] = {
                    label = "Rose Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_149_3"
                },
                [4] = {
                    label = "Bronze Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_149_4"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_150_0"
                },
                [1] = {
                    label = "Black DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_150_1"
                },
                [2] = {
                    label = "Gold DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_150_2"
                },
                [3] = {
                    label = "Rose DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_150_3"
                },
                [4] = {
                    label = "Bronze DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_150_4"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_151_0"
                },
                [1] = {
                    label = "Black DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_151_1"
                },
                [2] = {
                    label = "Gold DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_151_2"
                },
                [3] = {
                    label = "Rose DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_151_3"
                },
                [4] = {
                    label = "Bronze DS Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_151_4"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_152_0"
                },
                [1] = {
                    label = "Black Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_152_1"
                },
                [2] = {
                    label = "Gold Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_152_2"
                },
                [3] = {
                    label = "Rose Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_152_3"
                },
                [4] = {
                    label = "Bronze Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_152_4"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_153_0"
                },
                [1] = {
                    label = "Black Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_153_1"
                },
                [2] = {
                    label = "Gold Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_153_2"
                },
                [3] = {
                    label = "Rose Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_153_3"
                },
                [4] = {
                    label = "Bronze Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_153_4"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Marble Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_154_0"
                },
                [1] = {
                    label = "Turquoise Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_154_1"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Marble Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_155_0"
                },
                [1] = {
                    label = "Turquoise Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_155_1"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "Thick Silver Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_156_0"
                },
                [1] = {
                    label = "Thick Black Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_156_1"
                },
                [2] = {
                    label = "Thick Gold Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_156_2"
                },
                [3] = {
                    label = "Thick Rose Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_156_3"
                },
                [4] = {
                    label = "Thick Bronze Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_156_4"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "Thick Silver Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_157_0"
                },
                [1] = {
                    label = "Thick Black Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_157_1"
                },
                [2] = {
                    label = "Thick Gold Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_157_2"
                },
                [3] = {
                    label = "Thick Rose Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_157_3"
                },
                [4] = {
                    label = "Thick Bronze Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_157_4"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_158_0"
                },
                [1] = {
                    label = "Black Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_158_1"
                },
                [2] = {
                    label = "Gold Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_158_2"
                },
                [3] = {
                    label = "Rose Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_158_3"
                },
                [4] = {
                    label = "Bronze Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_158_4"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_159_0"
                },
                [1] = {
                    label = "Black Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_159_1"
                },
                [2] = {
                    label = "Gold Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_159_2"
                },
                [3] = {
                    label = "Rose Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_159_3"
                },
                [4] = {
                    label = "Bronze Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "female_chain_159_4"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (160-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_160_0"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (161-0)",
                    price = 500,
                    type = "money",
                    image = "female_chain_161_0"
                },
            },
        },
    },

    male = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_0_0"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_1_0"
                },
                [1] = {
                    label = "Accessories (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_1_1"
                },
                [2] = {
                    label = "Accessories (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_1_2"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_2_0"
                },
                [1] = {
                    label = "Accessories (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_2_1"
                },
                [2] = {
                    label = "Accessories (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_2_2"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_3_0"
                },
                [1] = {
                    label = "Accessories (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_3_1"
                },
                [2] = {
                    label = "Accessories (3-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_3_2"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_0"
                },
                [1] = {
                    label = "Accessories (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_1"
                },
                [2] = {
                    label = "Accessories (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_2"
                },
                [3] = {
                    label = "Accessories (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_3"
                },
                [4] = {
                    label = "Accessories (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_4"
                },
                [5] = {
                    label = "Accessories (4-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_5"
                },
                [6] = {
                    label = "Accessories (4-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_6"
                },
                [7] = {
                    label = "Accessories (4-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_7"
                },
                [8] = {
                    label = "Accessories (4-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_8"
                },
                [9] = {
                    label = "Accessories (4-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_9"
                },
                [10] = {
                    label = "Accessories (4-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_10"
                },
                [11] = {
                    label = "Accessories (4-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_11"
                },
                [12] = {
                    label = "Accessories (4-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_12"
                },
                [13] = {
                    label = "Accessories (4-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_13"
                },
                [14] = {
                    label = "Accessories (4-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_14"
                },
                [15] = {
                    label = "Accessories (4-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_4_15"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_0"
                },
                [1] = {
                    label = "Accessories (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_1"
                },
                [2] = {
                    label = "Accessories (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_2"
                },
                [3] = {
                    label = "Accessories (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_3"
                },
                [4] = {
                    label = "Accessories (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_4"
                },
                [5] = {
                    label = "Accessories (5-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_5_5"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_0"
                },
                [1] = {
                    label = "Accessories (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_1"
                },
                [2] = {
                    label = "Accessories (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_2"
                },
                [3] = {
                    label = "Accessories (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_3"
                },
                [4] = {
                    label = "Accessories (6-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_4"
                },
                [5] = {
                    label = "Accessories (6-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_6_5"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_7_0"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (8-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_8_0"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (9-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_9_0"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (10-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_0"
                },
                [1] = {
                    label = "Accessories (10-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_1"
                },
                [2] = {
                    label = "Accessories (10-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_2"
                },
                [3] = {
                    label = "Accessories (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_3"
                },
                [4] = {
                    label = "Accessories (10-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_4"
                },
                [5] = {
                    label = "Accessories (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_5"
                },
                [6] = {
                    label = "Accessories (10-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_6"
                },
                [7] = {
                    label = "Accessories (10-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_7"
                },
                [8] = {
                    label = "Accessories (10-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_8"
                },
                [9] = {
                    label = "Accessories (10-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_9"
                },
                [10] = {
                    label = "Accessories (10-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_10"
                },
                [11] = {
                    label = "Accessories (10-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_11"
                },
                [12] = {
                    label = "Accessories (10-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_12"
                },
                [13] = {
                    label = "Accessories (10-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_13"
                },
                [14] = {
                    label = "Accessories (10-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_14"
                },
                [15] = {
                    label = "Accessories (10-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_10_15"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (11-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_0"
                },
                [1] = {
                    label = "Accessories (11-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_1"
                },
                [2] = {
                    label = "Accessories (11-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_2"
                },
                [3] = {
                    label = "Accessories (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_3"
                },
                [4] = {
                    label = "Accessories (11-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_4"
                },
                [5] = {
                    label = "Accessories (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_5"
                },
                [6] = {
                    label = "Accessories (11-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_6"
                },
                [7] = {
                    label = "Accessories (11-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_7"
                },
                [8] = {
                    label = "Accessories (11-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_8"
                },
                [9] = {
                    label = "Accessories (11-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_9"
                },
                [10] = {
                    label = "Accessories (11-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_10"
                },
                [11] = {
                    label = "Accessories (11-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_11"
                },
                [12] = {
                    label = "Accessories (11-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_12"
                },
                [13] = {
                    label = "Accessories (11-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_13"
                },
                [14] = {
                    label = "Accessories (11-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_14"
                },
                [15] = {
                    label = "Accessories (11-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_11_15"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (12-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_0"
                },
                [1] = {
                    label = "Accessories (12-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_1"
                },
                [2] = {
                    label = "Accessories (12-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_2"
                },
                [3] = {
                    label = "Accessories (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_3"
                },
                [4] = {
                    label = "Accessories (12-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_4"
                },
                [5] = {
                    label = "Accessories (12-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_5"
                },
                [6] = {
                    label = "Accessories (12-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_6"
                },
                [7] = {
                    label = "Accessories (12-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_7"
                },
                [8] = {
                    label = "Accessories (12-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_8"
                },
                [9] = {
                    label = "Accessories (12-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_9"
                },
                [10] = {
                    label = "Accessories (12-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_10"
                },
                [11] = {
                    label = "Accessories (12-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_11"
                },
                [12] = {
                    label = "Accessories (12-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_12"
                },
                [13] = {
                    label = "Accessories (12-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_13"
                },
                [14] = {
                    label = "Accessories (12-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_14"
                },
                [15] = {
                    label = "Accessories (12-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_12_15"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (13-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_13_0"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (14-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_14_0"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (15-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_15_0"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Covgari Silver Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_16_0"
                },
                [1] = {
                    label = "Gaulle Gold Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_16_1"
                },
                [2] = {
                    label = "Bronze Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_16_2"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Covgari Silver Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_17_0"
                },
                [1] = {
                    label = "Gaulle Gold Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_17_1"
                },
                [2] = {
                    label = "Bronze Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_17_2"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Christmas Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_18_0"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skinny Christmas Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_19_0"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Vest Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_20_0"
                },
                [1] = {
                    label = "Pink Vest Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_20_1"
                },
                [2] = {
                    label = "Ivory Vest Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_20_2"
                },
                [3] = {
                    label = "Brown Vest Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_20_3"
                },
                [4] = {
                    label = "Navy Vest Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_20_4"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_0"
                },
                [1] = {
                    label = "Navy Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_1"
                },
                [2] = {
                    label = "Red Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_2"
                },
                [3] = {
                    label = "Green Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_3"
                },
                [4] = {
                    label = "Orange Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_4"
                },
                [5] = {
                    label = "Yellow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_5"
                },
                [6] = {
                    label = "Purple Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_6"
                },
                [7] = {
                    label = "Brown Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_7"
                },
                [8] = {
                    label = "Stone Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_8"
                },
                [9] = {
                    label = "Smoky Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_9"
                },
                [10] = {
                    label = "Tan Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_10"
                },
                [11] = {
                    label = "Gold Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_11"
                },
                [12] = {
                    label = "Gent Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_21_12"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_0"
                },
                [1] = {
                    label = "Gray Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_1"
                },
                [2] = {
                    label = "Blue Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_2"
                },
                [3] = {
                    label = "Navy Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_3"
                },
                [4] = {
                    label = "Red Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_4"
                },
                [5] = {
                    label = "Green Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_5"
                },
                [6] = {
                    label = "Orange Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_6"
                },
                [7] = {
                    label = "Yellow Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_7"
                },
                [8] = {
                    label = "Purple Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_8"
                },
                [9] = {
                    label = "Brown Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_9"
                },
                [10] = {
                    label = "Stone Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_10"
                },
                [11] = {
                    label = "Ocean Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_11"
                },
                [12] = {
                    label = "Sandy Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_12"
                },
                [13] = {
                    label = "Earth Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_13"
                },
                [14] = {
                    label = "Berry Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_22_14"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_0"
                },
                [1] = {
                    label = "Navy Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_1"
                },
                [2] = {
                    label = "Red Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_2"
                },
                [3] = {
                    label = "Green Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_3"
                },
                [4] = {
                    label = "Orange Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_4"
                },
                [5] = {
                    label = "Yellow Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_5"
                },
                [6] = {
                    label = "Purple Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_6"
                },
                [7] = {
                    label = "Brown Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_7"
                },
                [8] = {
                    label = "Stone Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_8"
                },
                [9] = {
                    label = "Smoky Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_9"
                },
                [10] = {
                    label = "Tan Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_10"
                },
                [11] = {
                    label = "Gold Striped Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_11"
                },
                [12] = {
                    label = "Gent Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_23_12"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_0"
                },
                [1] = {
                    label = "Gray Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_1"
                },
                [2] = {
                    label = "Black Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_2"
                },
                [3] = {
                    label = "Blue Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_3"
                },
                [4] = {
                    label = "Navy Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_4"
                },
                [5] = {
                    label = "Red Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_5"
                },
                [6] = {
                    label = "Green Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_6"
                },
                [7] = {
                    label = "Orange Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_7"
                },
                [8] = {
                    label = "Yellow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_8"
                },
                [9] = {
                    label = "Purple Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_9"
                },
                [10] = {
                    label = "Brown Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_10"
                },
                [11] = {
                    label = "Stone Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_11"
                },
                [12] = {
                    label = "Smoky Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_12"
                },
                [13] = {
                    label = "Tan Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_13"
                },
                [14] = {
                    label = "Gold Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_14"
                },
                [15] = {
                    label = "Gent Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_24_15"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_0"
                },
                [1] = {
                    label = "Gray Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_1"
                },
                [2] = {
                    label = "Black Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_2"
                },
                [3] = {
                    label = "Blue Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_3"
                },
                [4] = {
                    label = "Navy Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_4"
                },
                [5] = {
                    label = "Red Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_5"
                },
                [6] = {
                    label = "Green Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_6"
                },
                [7] = {
                    label = "Orange Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_7"
                },
                [8] = {
                    label = "Yellow Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_8"
                },
                [9] = {
                    label = "Purple Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_9"
                },
                [10] = {
                    label = "Brown Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_10"
                },
                [11] = {
                    label = "Stone Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_11"
                },
                [12] = {
                    label = "Smoky Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_12"
                },
                [13] = {
                    label = "Tan Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_13"
                },
                [14] = {
                    label = "Gold Striped Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_14"
                },
                [15] = {
                    label = "Gent Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_25_15"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_0"
                },
                [1] = {
                    label = "Gray Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_1"
                },
                [2] = {
                    label = "Black Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_2"
                },
                [3] = {
                    label = "Blue Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_3"
                },
                [4] = {
                    label = "Navy Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_4"
                },
                [5] = {
                    label = "Red Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_5"
                },
                [6] = {
                    label = "Green Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_6"
                },
                [7] = {
                    label = "Orange Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_7"
                },
                [8] = {
                    label = "Yellow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_8"
                },
                [9] = {
                    label = "Purple Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_9"
                },
                [10] = {
                    label = "Brown Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_10"
                },
                [11] = {
                    label = "Stone Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_11"
                },
                [12] = {
                    label = "Smoky Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_12"
                },
                [13] = {
                    label = "Tan Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_13"
                },
                [14] = {
                    label = "Gold Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_14"
                },
                [15] = {
                    label = "Gent Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_26_15"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_0"
                },
                [1] = {
                    label = "Gray Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_1"
                },
                [2] = {
                    label = "Black Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_2"
                },
                [3] = {
                    label = "Blue Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_3"
                },
                [4] = {
                    label = "Navy Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_4"
                },
                [5] = {
                    label = "Red Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_5"
                },
                [6] = {
                    label = "Green Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_6"
                },
                [7] = {
                    label = "Orange Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_7"
                },
                [8] = {
                    label = "Yellow Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_8"
                },
                [9] = {
                    label = "Purple Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_9"
                },
                [10] = {
                    label = "Brown Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_10"
                },
                [11] = {
                    label = "Stone Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_11"
                },
                [12] = {
                    label = "Smoky Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_12"
                },
                [13] = {
                    label = "Tan Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_13"
                },
                [14] = {
                    label = "Gold Striped Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_14"
                },
                [15] = {
                    label = "Gent Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_27_15"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_0"
                },
                [1] = {
                    label = "Gray Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_1"
                },
                [2] = {
                    label = "Black Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_2"
                },
                [3] = {
                    label = "Blue Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_3"
                },
                [4] = {
                    label = "Navy Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_4"
                },
                [5] = {
                    label = "Red Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_5"
                },
                [6] = {
                    label = "Green Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_6"
                },
                [7] = {
                    label = "Orange Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_7"
                },
                [8] = {
                    label = "Yellow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_8"
                },
                [9] = {
                    label = "Purple Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_9"
                },
                [10] = {
                    label = "Brown Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_10"
                },
                [11] = {
                    label = "Stone Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_11"
                },
                [12] = {
                    label = "Smoky Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_12"
                },
                [13] = {
                    label = "Tan Plaid Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_13"
                },
                [14] = {
                    label = "Gold Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_14"
                },
                [15] = {
                    label = "Gent Striped Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_28_15"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_0"
                },
                [1] = {
                    label = "Gray Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_1"
                },
                [2] = {
                    label = "Black Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_2"
                },
                [3] = {
                    label = "Blue Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_3"
                },
                [4] = {
                    label = "Navy Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_4"
                },
                [5] = {
                    label = "Red Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_5"
                },
                [6] = {
                    label = "Green Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_6"
                },
                [7] = {
                    label = "Orange Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_7"
                },
                [8] = {
                    label = "Yellow Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_8"
                },
                [9] = {
                    label = "Purple Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_9"
                },
                [10] = {
                    label = "Brown Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_10"
                },
                [11] = {
                    label = "Stone Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_11"
                },
                [12] = {
                    label = "Smoky Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_12"
                },
                [13] = {
                    label = "Tan Plaid Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_13"
                },
                [14] = {
                    label = "Gold Striped Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_14"
                },
                [15] = {
                    label = "Gent Skinny Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_29_15"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_0"
                },
                [1] = {
                    label = "Gray Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_1"
                },
                [2] = {
                    label = "Black Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_2"
                },
                [3] = {
                    label = "Navy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_3"
                },
                [4] = {
                    label = "Red Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_4"
                },
                [5] = {
                    label = "Green Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_30_5"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_0"
                },
                [1] = {
                    label = "Gray Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_1"
                },
                [2] = {
                    label = "Black Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_2"
                },
                [3] = {
                    label = "Navy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_3"
                },
                [4] = {
                    label = "Red Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_4"
                },
                [5] = {
                    label = "Green Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_31_5"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "USA Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_32_0"
                },
                [1] = {
                    label = "Blue Star Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_32_1"
                },
                [2] = {
                    label = "White Star Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_32_2"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (33-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stripy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_34_0"
                },
                [1] = {
                    label = "Joy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_34_1"
                },
                [2] = {
                    label = "Snowflake Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_34_2"
                },
                [3] = {
                    label = "Storm Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_34_3"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stripy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_35_0"
                },
                [1] = {
                    label = "Joy Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_35_1"
                },
                [2] = {
                    label = "Snowflake Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_35_2"
                },
                [3] = {
                    label = "Storm Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_35_3"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_36_0"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_0"
                },
                [1] = {
                    label = "Khaki Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_1"
                },
                [2] = {
                    label = "White Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_2"
                },
                [3] = {
                    label = "Green Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_3"
                },
                [4] = {
                    label = "Purple Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_4"
                },
                [5] = {
                    label = "Fuchsia Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_5"
                },
                [6] = {
                    label = "Gray Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_6"
                },
                [7] = {
                    label = "Tan Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_7"
                },
                [8] = {
                    label = "Blue Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_8"
                },
                [9] = {
                    label = "Teal Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_9"
                },
                [10] = {
                    label = "Orange Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_10"
                },
                [11] = {
                    label = "Blue Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_11"
                },
                [12] = {
                    label = "Tan Stripy Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_12"
                },
                [13] = {
                    label = "Pink Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_13"
                },
                [14] = {
                    label = "Green Diamond Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_14"
                },
                [15] = {
                    label = "Blue Hatch Loose Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_37_15"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_0"
                },
                [1] = {
                    label = "Khaki Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_1"
                },
                [2] = {
                    label = "White Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_2"
                },
                [3] = {
                    label = "Green Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_3"
                },
                [4] = {
                    label = "Purple Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_4"
                },
                [5] = {
                    label = "Fuchsia Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_5"
                },
                [6] = {
                    label = "Gray Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_6"
                },
                [7] = {
                    label = "Tan Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_7"
                },
                [8] = {
                    label = "Blue Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_8"
                },
                [9] = {
                    label = "Teal Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_9"
                },
                [10] = {
                    label = "Orange Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_10"
                },
                [11] = {
                    label = "Blue Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_11"
                },
                [12] = {
                    label = "Tan Stripy Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_12"
                },
                [13] = {
                    label = "Pink Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_13"
                },
                [14] = {
                    label = "Green Diamond Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_14"
                },
                [15] = {
                    label = "Blue Hatch Straight Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_38_15"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_0"
                },
                [1] = {
                    label = "Khaki Hatch Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_1"
                },
                [2] = {
                    label = "White Stripy Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_2"
                },
                [3] = {
                    label = "Green Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_3"
                },
                [4] = {
                    label = "Purple Diamond Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_4"
                },
                [5] = {
                    label = "Fuchsia Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_5"
                },
                [6] = {
                    label = "Gray Diamond Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_6"
                },
                [7] = {
                    label = "Tan Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_7"
                },
                [8] = {
                    label = "Blue Stripy Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_8"
                },
                [9] = {
                    label = "Teal Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_9"
                },
                [10] = {
                    label = "Orange Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_10"
                },
                [11] = {
                    label = "Blue Diamond Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_11"
                },
                [12] = {
                    label = "Tan Stripy Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_12"
                },
                [13] = {
                    label = "Pink Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_13"
                },
                [14] = {
                    label = "Green Diamond Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_14"
                },
                [15] = {
                    label = "Blue Hatch Slack Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_39_15"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (40-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_40_0"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (41-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_41_0"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold SN Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_42_0"
                },
                [1] = {
                    label = "Platinum SN Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_42_1"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_43_0"
                },
                [1] = {
                    label = "Platinum Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_43_1"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Platinum Balaclava Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_44_0"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_45_0"
                },
                [1] = {
                    label = "Platinum Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_45_1"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LC Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_46_0"
                },
                [1] = {
                    label = "Platinum LC Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_46_1"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_47_0"
                },
                [1] = {
                    label = "Platinum Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_47_1"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_48_0"
                },
                [1] = {
                    label = "Platinum Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_48_1"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold SN Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_49_0"
                },
                [1] = {
                    label = "Platinum SN Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_50_0"
                },
                [1] = {
                    label = "Platinum Skull Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_50_1"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Platinum Balaclava Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_51_0"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_52_0"
                },
                [1] = {
                    label = "Platinum Zorse Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LC Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_53_0"
                },
                [1] = {
                    label = "Platinum LC Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_53_1"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_54_0"
                },
                [1] = {
                    label = "Platinum Dix Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_54_1"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_55_0"
                },
                [1] = {
                    label = "Platinum Le Chien Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_55_1"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (56-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_56_0"
                },
                [1] = {
                    label = "Accessories (56-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_56_1"
                },
                [2] = {
                    label = "Accessories (56-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_56_2"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (57-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_57_0"
                },
                [1] = {
                    label = "Accessories (57-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_57_1"
                },
                [2] = {
                    label = "Accessories (57-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_57_2"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (58-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_58_0"
                },
                [1] = {
                    label = "Accessories (58-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_58_1"
                },
                [2] = {
                    label = "Accessories (58-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_58_2"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (59-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_59_0"
                },
                [1] = {
                    label = "Accessories (59-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_59_1"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (60-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_60_0"
                },
                [1] = {
                    label = "Accessories (60-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_60_1"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (61-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_61_0"
                },
                [1] = {
                    label = "Accessories (61-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_61_1"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (62-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_62_0"
                },
                [1] = {
                    label = "Accessories (62-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_62_1"
                },
                [2] = {
                    label = "Accessories (62-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_62_2"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (63-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_63_0"
                },
                [1] = {
                    label = "Accessories (63-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_63_1"
                },
                [2] = {
                    label = "Accessories (63-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_63_2"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (64-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_64_0"
                },
                [1] = {
                    label = "Accessories (64-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_64_1"
                },
                [2] = {
                    label = "Accessories (64-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_64_2"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (65-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_65_0"
                },
                [1] = {
                    label = "Accessories (65-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_65_1"
                },
                [2] = {
                    label = "Accessories (65-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_65_2"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (66-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_66_0"
                },
                [1] = {
                    label = "Accessories (66-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_66_1"
                },
                [2] = {
                    label = "Accessories (66-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_66_2"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (67-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_67_0"
                },
                [1] = {
                    label = "Accessories (67-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_67_1"
                },
                [2] = {
                    label = "Accessories (67-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_67_2"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (68-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_68_0"
                },
                [1] = {
                    label = "Accessories (68-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_68_1"
                },
                [2] = {
                    label = "Accessories (68-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_68_2"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (69-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_69_0"
                },
                [1] = {
                    label = "Accessories (69-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_69_1"
                },
                [2] = {
                    label = "Accessories (69-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_69_2"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (70-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_70_0"
                },
                [1] = {
                    label = "Accessories (70-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_70_1"
                },
                [2] = {
                    label = "Accessories (70-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_70_2"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (71-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_71_0"
                },
                [1] = {
                    label = "Accessories (71-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_71_1"
                },
                [2] = {
                    label = "Accessories (71-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_71_2"
                },
                [3] = {
                    label = "Accessories (71-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_71_3"
                },
                [4] = {
                    label = "Accessories (71-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_71_4"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (72-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_72_0"
                },
                [1] = {
                    label = "Accessories (72-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_72_1"
                },
                [2] = {
                    label = "Accessories (72-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_72_2"
                },
                [3] = {
                    label = "Accessories (72-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_72_3"
                },
                [4] = {
                    label = "Accessories (72-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_72_4"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (73-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_73_0"
                },
                [1] = {
                    label = "Accessories (73-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_73_1"
                },
                [2] = {
                    label = "Accessories (73-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_73_2"
                },
                [3] = {
                    label = "Accessories (73-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_73_3"
                },
                [4] = {
                    label = "Accessories (73-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_73_4"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_74_0"
                },
                [1] = {
                    label = "Platinum Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_74_1"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_75_0"
                },
                [1] = {
                    label = "Platinum Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_75_1"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_76_0"
                },
                [1] = {
                    label = "Platinum Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_76_1"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_77_0"
                },
                [1] = {
                    label = "Platinum Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_77_1"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_78_0"
                },
                [1] = {
                    label = "Platinum Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_78_1"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_79_0"
                },
                [1] = {
                    label = "Platinum Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_79_1"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_80_0"
                },
                [1] = {
                    label = "Platinum Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_80_1"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_81_0"
                },
                [1] = {
                    label = "Platinum Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_81_1"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_82_0"
                },
                [1] = {
                    label = "Platinum Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_82_1"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rope Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_83_0"
                },
                [1] = {
                    label = "Platinum Rope Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_83_1"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_0"
                },
                [1] = {
                    label = "Green Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_1"
                },
                [2] = {
                    label = "Tan Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_2"
                },
                [3] = {
                    label = "Gray Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_3"
                },
                [4] = {
                    label = "Black Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_4"
                },
                [5] = {
                    label = "Peach Plaid Woolen Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_84_5"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_85_0"
                },
                [1] = {
                    label = "Platinum Loose Link Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_85_1"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_86_0"
                },
                [1] = {
                    label = "Platinum Belcher Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_86_1"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_87_0"
                },
                [1] = {
                    label = "Platinum Pretzel Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_87_1"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_88_0"
                },
                [1] = {
                    label = "Platinum Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_88_1"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_89_0"
                },
                [1] = {
                    label = "Platinum Diamond Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_89_1"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_90_0"
                },
                [1] = {
                    label = "Platinum Heavy Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_90_1"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_91_0"
                },
                [1] = {
                    label = "Platinum Heavy Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_91_1"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_92_0"
                },
                [1] = {
                    label = "Platinum Square Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_92_1"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_93_0"
                },
                [1] = {
                    label = "Platinum Popcorn Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_93_1"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rope Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_94_0"
                },
                [1] = {
                    label = "Platinum Rope Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_94_1"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (95-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_95_0"
                },
                [1] = {
                    label = "Accessories (95-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_95_1"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (96-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_96_0"
                },
                [1] = {
                    label = "Accessories (96-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_96_1"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (97-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_97_0"
                },
                [1] = {
                    label = "Accessories (97-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_97_1"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (98-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_98_0"
                },
                [1] = {
                    label = "Accessories (98-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_98_1"
                },
                [2] = {
                    label = "Accessories (98-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_98_2"
                },
                [3] = {
                    label = "Accessories (98-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_98_3"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (99-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_99_0"
                },
                [1] = {
                    label = "Accessories (99-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_99_1"
                },
                [2] = {
                    label = "Accessories (99-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_99_2"
                },
                [3] = {
                    label = "Accessories (99-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_99_3"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (100-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_100_0"
                },
                [1] = {
                    label = "Accessories (100-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_100_1"
                },
                [2] = {
                    label = "Accessories (100-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_100_2"
                },
                [3] = {
                    label = "Accessories (100-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_100_3"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (101-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_101_0"
                },
                [1] = {
                    label = "Accessories (101-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_101_1"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (102-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_102_0"
                },
                [1] = {
                    label = "Accessories (102-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_102_1"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (103-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_103_0"
                },
                [1] = {
                    label = "Accessories (103-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_103_1"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (104-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_104_0"
                },
                [1] = {
                    label = "Accessories (104-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_104_1"
                },
                [2] = {
                    label = "Accessories (104-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_104_2"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (105-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_105_0"
                },
                [1] = {
                    label = "Accessories (105-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_105_1"
                },
                [2] = {
                    label = "Accessories (105-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_105_2"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (106-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_106_0"
                },
                [1] = {
                    label = "Accessories (106-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_106_1"
                },
                [2] = {
                    label = "Accessories (106-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_106_2"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (107-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_107_0"
                },
                [1] = {
                    label = "Accessories (107-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_107_1"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (108-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_108_0"
                },
                [1] = {
                    label = "Accessories (108-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_108_1"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (109-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_109_0"
                },
                [1] = {
                    label = "Accessories (109-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_109_1"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_110_0"
                },
                [1] = {
                    label = "Platinum Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_110_1"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_111_0"
                },
                [1] = {
                    label = "Platinum Magnetics Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_111_1"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_112_0"
                },
                [1] = {
                    label = "Khaki Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_112_1"
                },
                [2] = {
                    label = "Black Desert Scarf",
                    price = 500,
                    type = "money",
                    image = "male_chain_112_2"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_113_0"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (114-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_114_0"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (115-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_115_0"
                },
                [1] = {
                    label = "Accessories (115-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_115_1"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (116-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_0"
                },
                [1] = {
                    label = "Accessories (116-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_1"
                },
                [2] = {
                    label = "Accessories (116-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_2"
                },
                [3] = {
                    label = "Accessories (116-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_3"
                },
                [4] = {
                    label = "Accessories (116-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_4"
                },
                [5] = {
                    label = "Accessories (116-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_5"
                },
                [6] = {
                    label = "Accessories (116-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_6"
                },
                [7] = {
                    label = "Accessories (116-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_7"
                },
                [8] = {
                    label = "Accessories (116-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_8"
                },
                [9] = {
                    label = "Accessories (116-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_116_9"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (117-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_0"
                },
                [1] = {
                    label = "Accessories (117-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_1"
                },
                [2] = {
                    label = "Accessories (117-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_2"
                },
                [3] = {
                    label = "Accessories (117-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_3"
                },
                [4] = {
                    label = "Accessories (117-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_4"
                },
                [5] = {
                    label = "Accessories (117-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_5"
                },
                [6] = {
                    label = "Accessories (117-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_6"
                },
                [7] = {
                    label = "Accessories (117-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_7"
                },
                [8] = {
                    label = "Accessories (117-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_8"
                },
                [9] = {
                    label = "Accessories (117-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_117_9"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Full Bowtie",
                    price = 500,
                    type = "money",
                    image = "male_chain_118_0"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_119_0"
                },
                [1] = {
                    label = "Platinum Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_119_1"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_120_0"
                },
                [1] = {
                    label = "Platinum Rim Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_120_1"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_121_0"
                },
                [1] = {
                    label = "Platinum Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_121_1"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_122_0"
                },
                [1] = {
                    label = "Platinum Alloy Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_122_1"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_123_0"
                },
                [1] = {
                    label = "Pearl Bead Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_123_1"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (124-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_124_0"
                },
                [1] = {
                    label = "Accessories (124-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_124_1"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (125-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_125_0"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (126-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_126_0"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (127-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_127_0"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (128-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_128_0"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "male_chain_129_0"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "male_chain_130_0"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Epsilon Medallion",
                    price = 500,
                    type = "money",
                    image = "male_chain_131_0"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_0"
                },
                [1] = {
                    label = "White Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_1"
                },
                [2] = {
                    label = "Gray Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_2"
                },
                [3] = {
                    label = "Blue Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_3"
                },
                [4] = {
                    label = "Navy Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_4"
                },
                [5] = {
                    label = "Red Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_5"
                },
                [6] = {
                    label = "Green Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_6"
                },
                [7] = {
                    label = "Orange Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_7"
                },
                [8] = {
                    label = "Yellow Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_8"
                },
                [9] = {
                    label = "Purple Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_9"
                },
                [10] = {
                    label = "Mocha Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_10"
                },
                [11] = {
                    label = "Beige Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_11"
                },
                [12] = {
                    label = "Blue Pattern Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_12"
                },
                [13] = {
                    label = "Yellow Pattern Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_13"
                },
                [14] = {
                    label = "Brown Pattern Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_14"
                },
                [15] = {
                    label = "Pink Pattern Loose Bow Tie",
                    price = 500,
                    type = "money",
                    image = "male_chain_132_15"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (133-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_0"
                },
                [1] = {
                    label = "Accessories (133-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_1"
                },
                [2] = {
                    label = "Accessories (133-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_2"
                },
                [3] = {
                    label = "Accessories (133-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_3"
                },
                [4] = {
                    label = "Accessories (133-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_4"
                },
                [5] = {
                    label = "Accessories (133-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_5"
                },
                [6] = {
                    label = "Accessories (133-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_6"
                },
                [7] = {
                    label = "Accessories (133-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_7"
                },
                [8] = {
                    label = "Accessories (133-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_8"
                },
                [9] = {
                    label = "Accessories (133-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_9"
                },
                [10] = {
                    label = "Accessories (133-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_10"
                },
                [11] = {
                    label = "Accessories (133-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_133_11"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_134_0"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_135_0"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_136_0"
                },
                [1] = {
                    label = "Silver LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_136_1"
                },
                [2] = {
                    label = "Copper LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_136_2"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_137_0"
                },
                [1] = {
                    label = "Silver LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_137_1"
                },
                [2] = {
                    label = "Copper LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_137_2"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Enamel LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_138_0"
                },
                [1] = {
                    label = "Silver Plate LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_138_1"
                },
                [2] = {
                    label = "Two-Tone LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_138_2"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Enamel LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_139_0"
                },
                [1] = {
                    label = "Silver Plate LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_139_1"
                },
                [2] = {
                    label = "Two-Tone LS Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_139_2"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_140_0"
                },
                [1] = {
                    label = "Silver Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_140_1"
                },
                [2] = {
                    label = "Bronze Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_140_2"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_141_0"
                },
                [1] = {
                    label = "Silver Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_141_1"
                },
                [2] = {
                    label = "Bronze Tags",
                    price = 500,
                    type = "money",
                    image = "male_chain_141_2"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_142_0"
                },
                [1] = {
                    label = "Silver L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_142_1"
                },
                [2] = {
                    label = "Two-Tone L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_142_2"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_143_0"
                },
                [1] = {
                    label = "Silver L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_143_1"
                },
                [2] = {
                    label = "Two-Tone L$ Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_143_2"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_144_0"
                },
                [1] = {
                    label = "Silver Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_144_1"
                },
                [2] = {
                    label = "Bronze Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_144_2"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_145_0"
                },
                [1] = {
                    label = "Silver Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_145_1"
                },
                [2] = {
                    label = "Bronze Coin Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_145_2"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (146-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_0"
                },
                [1] = {
                    label = "Accessories (146-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_1"
                },
                [2] = {
                    label = "Accessories (146-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_2"
                },
                [3] = {
                    label = "Accessories (146-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_3"
                },
                [4] = {
                    label = "Accessories (146-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_4"
                },
                [5] = {
                    label = "Accessories (146-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_5"
                },
                [6] = {
                    label = "Accessories (146-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_6"
                },
                [7] = {
                    label = "Accessories (146-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_7"
                },
                [8] = {
                    label = "Accessories (146-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_8"
                },
                [9] = {
                    label = "Accessories (146-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_9"
                },
                [10] = {
                    label = "Accessories (146-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_10"
                },
                [11] = {
                    label = "Accessories (146-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_11"
                },
                [12] = {
                    label = "Accessories (146-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_12"
                },
                [13] = {
                    label = "Accessories (146-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_13"
                },
                [14] = {
                    label = "Accessories (146-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_14"
                },
                [15] = {
                    label = "Accessories (146-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_15"
                },
                [16] = {
                    label = "Accessories (146-16)",
                    price = 500,
                    type = "money",
                    image = "male_chain_146_16"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (147-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_0"
                },
                [1] = {
                    label = "Accessories (147-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_1"
                },
                [2] = {
                    label = "Accessories (147-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_2"
                },
                [3] = {
                    label = "Accessories (147-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_3"
                },
                [4] = {
                    label = "Accessories (147-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_4"
                },
                [5] = {
                    label = "Accessories (147-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_5"
                },
                [6] = {
                    label = "Accessories (147-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_6"
                },
                [7] = {
                    label = "Accessories (147-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_7"
                },
                [8] = {
                    label = "Accessories (147-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_8"
                },
                [9] = {
                    label = "Accessories (147-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_9"
                },
                [10] = {
                    label = "Accessories (147-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_10"
                },
                [11] = {
                    label = "Accessories (147-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_11"
                },
                [12] = {
                    label = "Accessories (147-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_12"
                },
                [13] = {
                    label = "Accessories (147-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_13"
                },
                [14] = {
                    label = "Accessories (147-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_14"
                },
                [15] = {
                    label = "Accessories (147-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_15"
                },
                [16] = {
                    label = "Accessories (147-16)",
                    price = 500,
                    type = "money",
                    image = "male_chain_147_16"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (148-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_0"
                },
                [1] = {
                    label = "Accessories (148-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_1"
                },
                [2] = {
                    label = "Accessories (148-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_2"
                },
                [3] = {
                    label = "Accessories (148-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_3"
                },
                [4] = {
                    label = "Accessories (148-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_4"
                },
                [5] = {
                    label = "Accessories (148-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_5"
                },
                [6] = {
                    label = "Accessories (148-6)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_6"
                },
                [7] = {
                    label = "Accessories (148-7)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_7"
                },
                [8] = {
                    label = "Accessories (148-8)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_8"
                },
                [9] = {
                    label = "Accessories (148-9)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_9"
                },
                [10] = {
                    label = "Accessories (148-10)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_10"
                },
                [11] = {
                    label = "Accessories (148-11)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_11"
                },
                [12] = {
                    label = "Accessories (148-12)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_12"
                },
                [13] = {
                    label = "Accessories (148-13)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_13"
                },
                [14] = {
                    label = "Accessories (148-14)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_14"
                },
                [15] = {
                    label = "Accessories (148-15)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_15"
                },
                [16] = {
                    label = "Accessories (148-16)",
                    price = 500,
                    type = "money",
                    image = "male_chain_148_16"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_0"
                },
                [1] = {
                    label = "Red Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_1"
                },
                [2] = {
                    label = "Pink Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_2"
                },
                [3] = {
                    label = "Yellow Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_3"
                },
                [4] = {
                    label = "Orange Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_4"
                },
                [5] = {
                    label = "Green Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_5"
                },
                [6] = {
                    label = "Festival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_6"
                },
                [7] = {
                    label = "Carnival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_7"
                },
                [8] = {
                    label = "Tropical Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_8"
                },
                [9] = {
                    label = "Hot Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_9"
                },
                [10] = {
                    label = "Neon Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_10"
                },
                [11] = {
                    label = "Party Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_11"
                },
                [12] = {
                    label = "Sunset Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_12"
                },
                [13] = {
                    label = "Radiant Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_13"
                },
                [14] = {
                    label = "Sunrise Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_14"
                },
                [15] = {
                    label = "Session Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_149_15"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_0"
                },
                [1] = {
                    label = "Red Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_1"
                },
                [2] = {
                    label = "Pink Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_2"
                },
                [3] = {
                    label = "Yellow Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_3"
                },
                [4] = {
                    label = "Orange Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_4"
                },
                [5] = {
                    label = "Green Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_5"
                },
                [6] = {
                    label = "Festival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_6"
                },
                [7] = {
                    label = "Carnival Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_7"
                },
                [8] = {
                    label = "Tropical Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_8"
                },
                [9] = {
                    label = "Hot Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_9"
                },
                [10] = {
                    label = "Neon Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_10"
                },
                [11] = {
                    label = "Party Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_11"
                },
                [12] = {
                    label = "Sunset Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_12"
                },
                [13] = {
                    label = "Radiant Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_13"
                },
                [14] = {
                    label = "Sunrise Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_14"
                },
                [15] = {
                    label = "Session Glow Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_150_15"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (151-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_151_0"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (152-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (153-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_153_0"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Le Chien Whistle Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_154_0"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Le Chien Whistle Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_155_0"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_0"
                },
                [1] = {
                    label = "Black Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_1"
                },
                [2] = {
                    label = "Gold Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_2"
                },
                [3] = {
                    label = "Rose Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_3"
                },
                [4] = {
                    label = "Lilac Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_4"
                },
                [5] = {
                    label = "Silver Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_5"
                },
                [6] = {
                    label = "Brown Agate Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_6"
                },
                [7] = {
                    label = "White & Turquoise Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_7"
                },
                [8] = {
                    label = "White & Dark Blue Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_8"
                },
                [9] = {
                    label = "White & Purple Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_156_9"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_0"
                },
                [1] = {
                    label = "Black Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_1"
                },
                [2] = {
                    label = "Gold Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_2"
                },
                [3] = {
                    label = "Rose Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_3"
                },
                [4] = {
                    label = "Lilac Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_4"
                },
                [5] = {
                    label = "Silver Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_5"
                },
                [6] = {
                    label = "Brown Agate Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_6"
                },
                [7] = {
                    label = "White & Turquoise Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_7"
                },
                [8] = {
                    label = "White & Dark Blue Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_8"
                },
                [9] = {
                    label = "White & Purple Pearl Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_157_9"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heartbreak Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_158_0"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heartbreak Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_159_0"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_160_0"
                },
                [1] = {
                    label = "Black Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_160_1"
                },
                [2] = {
                    label = "Gold Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_160_2"
                },
                [3] = {
                    label = "Rose Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_160_3"
                },
                [4] = {
                    label = "Copper Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_160_4"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_161_0"
                },
                [1] = {
                    label = "Black Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_161_1"
                },
                [2] = {
                    label = "Gold Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_161_2"
                },
                [3] = {
                    label = "Rose Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_161_3"
                },
                [4] = {
                    label = "Copper Mesh Link",
                    price = 500,
                    type = "money",
                    image = "male_chain_161_4"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_162_0"
                },
                [1] = {
                    label = "Black Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_162_1"
                },
                [2] = {
                    label = "Gold Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_162_2"
                },
                [3] = {
                    label = "Rose Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_162_3"
                },
                [4] = {
                    label = "Copper Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_162_4"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_163_0"
                },
                [1] = {
                    label = "Black Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_163_1"
                },
                [2] = {
                    label = "Gold Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_163_2"
                },
                [3] = {
                    label = "Rose Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_163_3"
                },
                [4] = {
                    label = "Copper Thick Curb Chain",
                    price = 500,
                    type = "money",
                    image = "male_chain_163_4"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_164_0"
                },
                [1] = {
                    label = "Black Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_164_1"
                },
                [2] = {
                    label = "Gold Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_164_2"
                },
                [3] = {
                    label = "Rose Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_164_3"
                },
                [4] = {
                    label = "Copper Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_164_4"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_165_0"
                },
                [1] = {
                    label = "Black Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_165_1"
                },
                [2] = {
                    label = "Gold Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_165_2"
                },
                [3] = {
                    label = "Rose Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_165_3"
                },
                [4] = {
                    label = "Copper Bar Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_165_4"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (166-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_166_0"
                },
                [1] = {
                    label = "Accessories (166-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_166_1"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (167-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_167_0"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (168-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_168_0"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (169-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_169_0"
                },
                [1] = {
                    label = "Accessories (169-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_169_1"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (170-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_170_0"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_171_0"
                },
                [1] = {
                    label = "Dark Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_171_1"
                },
                [2] = {
                    label = "Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_171_2"
                },
                [3] = {
                    label = "Rose Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_171_3"
                },
                [4] = {
                    label = "Copper Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_171_4"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_172_0"
                },
                [1] = {
                    label = "Dark Silver Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_172_1"
                },
                [2] = {
                    label = "Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_172_2"
                },
                [3] = {
                    label = "Rose Gold Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_172_3"
                },
                [4] = {
                    label = "Copper Lock Pendant",
                    price = 500,
                    type = "money",
                    image = "male_chain_172_4"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cliffford Remote",
                    price = 500,
                    type = "money",
                    image = "male_chain_173_0"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cliffford Remote",
                    price = 500,
                    type = "money",
                    image = "male_chain_174_0"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (175-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_175_0"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (176-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_176_0"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (177-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_0"
                },
                [1] = {
                    label = "Accessories (177-1)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_1"
                },
                [2] = {
                    label = "Accessories (177-2)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_2"
                },
                [3] = {
                    label = "Accessories (177-3)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_3"
                },
                [4] = {
                    label = "Accessories (177-4)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_4"
                },
                [5] = {
                    label = "Accessories (177-5)",
                    price = 500,
                    type = "money",
                    image = "male_chain_177_5"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_178_0"
                },
                [1] = {
                    label = "Black Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_178_1"
                },
                [2] = {
                    label = "Gold Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_178_2"
                },
                [3] = {
                    label = "Rose Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_178_3"
                },
                [4] = {
                    label = "Bronze Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_178_4"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_179_0"
                },
                [1] = {
                    label = "Black Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_179_1"
                },
                [2] = {
                    label = "Gold Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_179_2"
                },
                [3] = {
                    label = "Rose Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_179_3"
                },
                [4] = {
                    label = "Bronze Layered Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_179_4"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_180_0"
                },
                [1] = {
                    label = "Black DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_180_1"
                },
                [2] = {
                    label = "Gold DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_180_2"
                },
                [3] = {
                    label = "Rose DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_180_3"
                },
                [4] = {
                    label = "Bronze DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_180_4"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_181_0"
                },
                [1] = {
                    label = "Black DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_181_1"
                },
                [2] = {
                    label = "Gold DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_181_2"
                },
                [3] = {
                    label = "Rose DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_181_3"
                },
                [4] = {
                    label = "Bronze DS Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_181_4"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_182_0"
                },
                [1] = {
                    label = "Black Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_182_1"
                },
                [2] = {
                    label = "Gold Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_182_2"
                },
                [3] = {
                    label = "Rose Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_182_3"
                },
                [4] = {
                    label = "Bronze Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_182_4"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_183_0"
                },
                [1] = {
                    label = "Black Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_183_1"
                },
                [2] = {
                    label = "Gold Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_183_2"
                },
                [3] = {
                    label = "Rose Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_183_3"
                },
                [4] = {
                    label = "Bronze Moon Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_183_4"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'component',
            textures = {
                [0] = {
                    label = "Marble Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_184_0"
                },
                [1] = {
                    label = "Turquoise Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_184_1"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'component',
            textures = {
                [0] = {
                    label = "Marble Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_185_0"
                },
                [1] = {
                    label = "Turquoise Stone Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_185_1"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'component',
            textures = {
                [0] = {
                    label = "Thick Silver Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_186_0"
                },
                [1] = {
                    label = "Thick Black Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_186_1"
                },
                [2] = {
                    label = "Thick Gold Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_186_2"
                },
                [3] = {
                    label = "Thick Rose Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_186_3"
                },
                [4] = {
                    label = "Thick Bronze Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_186_4"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'component',
            textures = {
                [0] = {
                    label = "Thick Silver Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_187_0"
                },
                [1] = {
                    label = "Thick Black Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_187_1"
                },
                [2] = {
                    label = "Thick Gold Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_187_2"
                },
                [3] = {
                    label = "Thick Rose Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_187_3"
                },
                [4] = {
                    label = "Thick Bronze Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_187_4"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_188_0"
                },
                [1] = {
                    label = "Black Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_188_1"
                },
                [2] = {
                    label = "Gold Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_188_2"
                },
                [3] = {
                    label = "Rose Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_188_3"
                },
                [4] = {
                    label = "Bronze Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_188_4"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silver Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_189_0"
                },
                [1] = {
                    label = "Black Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_189_1"
                },
                [2] = {
                    label = "Gold Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_189_2"
                },
                [3] = {
                    label = "Rose Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_189_3"
                },
                [4] = {
                    label = "Bronze Gun Necklace",
                    price = 500,
                    type = "money",
                    image = "male_chain_189_4"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (190-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_190_0"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'component',
            textures = {
                [0] = {
                    label = "Accessories (191-0)",
                    price = 500,
                    type = "money",
                    image = "male_chain_191_0"
                },
            },
        },
    },
}
