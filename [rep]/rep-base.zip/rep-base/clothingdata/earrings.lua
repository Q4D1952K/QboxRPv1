earrings = {
    female = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Earpiece",
                    price = 500,
                    type = "money",
                    image = "female_earrings_0_0"
                },
                [1] = {
                    label = "Earrings (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_0_1"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Earpiece",
                    price = 500,
                    type = "money",
                    image = "female_earrings_1_0"
                },
                [1] = {
                    label = "Earrings (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LCD Earpiece",
                    price = 500,
                    type = "money",
                    image = "female_earrings_2_0"
                },
                [1] = {
                    label = "Earrings (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_2_1"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Pendulums",
                    price = 500,
                    type = "money",
                    image = "female_earrings_3_0"
                },
                [1] = {
                    label = "Earrings (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_3_1"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Pendulums",
                    price = 500,
                    type = "money",
                    image = "female_earrings_4_0"
                },
                [1] = {
                    label = "Earrings (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_4_1"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Rounds",
                    price = 500,
                    type = "money",
                    image = "female_earrings_5_0"
                },
                [1] = {
                    label = "Earrings (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_5_1"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_6_0"
                },
                [1] = {
                    label = "Platinum Diamond Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_6_1"
                },
                [2] = {
                    label = "Black Gold Diamond Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_6_2"
                },
                [3] = {
                    label = "Earrings (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_6_3"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Waterfalls",
                    price = 500,
                    type = "money",
                    image = "female_earrings_7_0"
                },
                [1] = {
                    label = "Platinum Waterfalls",
                    price = 500,
                    type = "money",
                    image = "female_earrings_7_1"
                },
                [2] = {
                    label = "Black Gold Waterfalls",
                    price = 500,
                    type = "money",
                    image = "female_earrings_7_2"
                },
                [3] = {
                    label = "Earrings (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_7_3"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Totems",
                    price = 500,
                    type = "money",
                    image = "female_earrings_8_0"
                },
                [1] = {
                    label = "Black Gold Totems",
                    price = 500,
                    type = "money",
                    image = "female_earrings_8_1"
                },
                [2] = {
                    label = "Platinum Totems",
                    price = 500,
                    type = "money",
                    image = "female_earrings_8_2"
                },
                [3] = {
                    label = "Earrings (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_8_3"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_9_0"
                },
                [1] = {
                    label = "Platinum Diamond Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_9_1"
                },
                [2] = {
                    label = "Black Gold Diamond Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_9_2"
                },
                [3] = {
                    label = "Earrings (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_9_3"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Emerald Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_10_0"
                },
                [1] = {
                    label = "Platinum Emerald Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_10_1"
                },
                [2] = {
                    label = "Black Gold Emerald Chains",
                    price = 500,
                    type = "money",
                    image = "female_earrings_10_2"
                },
                [3] = {
                    label = "Earrings (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_10_3"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Sun Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_11_0"
                },
                [1] = {
                    label = "Platinum Sun Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_11_1"
                },
                [2] = {
                    label = "Black Gold Sun Drops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_11_2"
                },
                [3] = {
                    label = "Earrings (11-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_11_3"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "female_earrings_12_0"
                },
                [1] = {
                    label = "Gold Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "female_earrings_12_1"
                },
                [2] = {
                    label = "Black Gold Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "female_earrings_12_2"
                },
                [3] = {
                    label = "Earrings (12-3)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_12_3"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Assault Hoops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_13_0"
                },
                [1] = {
                    label = "Earrings (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_13_1"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chunky Hoops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_14_0"
                },
                [1] = {
                    label = "Earrings (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_14_1"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Classic Hoops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_15_0"
                },
                [1] = {
                    label = "Earrings (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_15_1"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "FU Hoops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_16_0"
                },
                [1] = {
                    label = "Earrings (16-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_16_1"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Screw You Hoops",
                    price = 500,
                    type = "money",
                    image = "female_earrings_17_0"
                },
                [1] = {
                    label = "Earrings (17-1)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_17_1"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Fame or Shame Mics",
                    price = 500,
                    type = "money",
                    image = "female_earrings_18_0"
                },
                [1] = {
                    label = "Silver Fame or Shame Mics",
                    price = 500,
                    type = "money",
                    image = "female_earrings_18_1"
                },
                [2] = {
                    label = "Earrings (18-2)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_18_2"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Clubs Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_19_0"
                },
                [1] = {
                    label = "Diamonds Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_19_1"
                },
                [2] = {
                    label = "Hearts Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_19_2"
                },
                [3] = {
                    label = "Spades Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_19_3"
                },
                [4] = {
                    label = "Earrings (19-4)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_19_4"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_20_0"
                },
                [1] = {
                    label = "Red Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_20_1"
                },
                [2] = {
                    label = "Tan Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_20_2"
                },
                [3] = {
                    label = "Gray Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_20_3"
                },
                [4] = {
                    label = "Earrings (20-4)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_20_4"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_21_0"
                },
                [1] = {
                    label = "Yellow Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_21_1"
                },
                [2] = {
                    label = "Red Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_21_2"
                },
                [3] = {
                    label = "Pink Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "female_earrings_21_3"
                },
                [4] = {
                    label = "Earrings (21-4)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_21_4"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_0"
                },
                [1] = {
                    label = "Yellow Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_1"
                },
                [2] = {
                    label = "Salmon Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_2"
                },
                [3] = {
                    label = "Orange Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_3"
                },
                [4] = {
                    label = "Purple Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_4"
                },
                [5] = {
                    label = "Pink Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_5"
                },
                [6] = {
                    label = "Turquoise Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_6"
                },
                [7] = {
                    label = "Blue Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_7"
                },
                [8] = {
                    label = "Black Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_8"
                },
                [9] = {
                    label = "Gray Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_9"
                },
                [10] = {
                    label = "Teal Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_10"
                },
                [11] = {
                    label = "Red Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_11"
                },
                [12] = {
                    label = "Earrings (22-12)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_22_12"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Earrings (23-0)",
                    price = 500,
                    type = "money",
                    image = "female_earrings_23_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Earpiece",
                    price = 500,
                    type = "money",
                    image = "male_earrings_0_0"
                },
                [1] = {
                    label = "Earrings (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_0_1"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Earpiece",
                    price = 500,
                    type = "money",
                    image = "male_earrings_1_0"
                },
                [1] = {
                    label = "Earrings (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LCD Earpiece",
                    price = 500,
                    type = "money",
                    image = "male_earrings_2_0"
                },
                [1] = {
                    label = "Earrings (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_2_1"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Angled Hoop (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_3_0"
                },
                [1] = {
                    label = "Black Angled Hoop (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_3_1"
                },
                [2] = {
                    label = "Platinum Angled Hoop (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_3_2"
                },
                [3] = {
                    label = "Earrings (3-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_3_3"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Angled Hoop (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_4_0"
                },
                [1] = {
                    label = "Black Angled Hoop (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_4_1"
                },
                [2] = {
                    label = "Platinum Angled Hoop (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_4_2"
                },
                [3] = {
                    label = "Earrings (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_4_3"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Angled Hoops",
                    price = 500,
                    type = "money",
                    image = "male_earrings_5_0"
                },
                [1] = {
                    label = "Black Angled Hoops",
                    price = 500,
                    type = "money",
                    image = "male_earrings_5_1"
                },
                [2] = {
                    label = "Platinum Angled Hoops",
                    price = 500,
                    type = "money",
                    image = "male_earrings_5_2"
                },
                [3] = {
                    label = "Earrings (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_5_3"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Circle Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_6_0"
                },
                [1] = {
                    label = "Platinum Circle Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_6_1"
                },
                [2] = {
                    label = "Earrings (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_6_2"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Circle Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_7_0"
                },
                [1] = {
                    label = "Platinum Circle Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_7_1"
                },
                [2] = {
                    label = "Earrings (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_7_2"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Circle Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_8_0"
                },
                [1] = {
                    label = "Platinum Circle Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_8_1"
                },
                [2] = {
                    label = "Earrings (8-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_8_2"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_9_0"
                },
                [1] = {
                    label = "Black Diamond Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_9_1"
                },
                [2] = {
                    label = "Platinum Diamond Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_9_2"
                },
                [3] = {
                    label = "Earrings (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_9_3"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_10_0"
                },
                [1] = {
                    label = "Black Diamond Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_10_1"
                },
                [2] = {
                    label = "Platinum Diamond Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_10_2"
                },
                [3] = {
                    label = "Earrings (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_10_3"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_11_0"
                },
                [1] = {
                    label = "Black Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_11_1"
                },
                [2] = {
                    label = "Platinum Diamond Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_11_2"
                },
                [3] = {
                    label = "Earrings (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_11_3"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Pillow Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_12_0"
                },
                [1] = {
                    label = "Black Pillow Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_12_1"
                },
                [2] = {
                    label = "Platinum Pillow Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_12_2"
                },
                [3] = {
                    label = "Earrings (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_12_3"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Pillow Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_13_0"
                },
                [1] = {
                    label = "Black Pillow Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_13_1"
                },
                [2] = {
                    label = "Platinum Pillow Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_13_2"
                },
                [3] = {
                    label = "Earrings (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_13_3"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Pillow Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_14_0"
                },
                [1] = {
                    label = "Black Pillow Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_14_1"
                },
                [2] = {
                    label = "Platinum Pillow Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_14_2"
                },
                [3] = {
                    label = "Earrings (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_14_3"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Gem Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_15_0"
                },
                [1] = {
                    label = "Black Gem Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_15_1"
                },
                [2] = {
                    label = "Platinum Gem Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_15_2"
                },
                [3] = {
                    label = "Earrings (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_15_3"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Gem Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_16_0"
                },
                [1] = {
                    label = "Black Gem Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_16_1"
                },
                [2] = {
                    label = "Platinum Gem Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_16_2"
                },
                [3] = {
                    label = "Earrings (16-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_16_3"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Gem Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_17_0"
                },
                [1] = {
                    label = "Black Gem Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_17_1"
                },
                [2] = {
                    label = "Platinum Gem Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_17_2"
                },
                [3] = {
                    label = "Earrings (17-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_17_3"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Illusion Square Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_0"
                },
                [1] = {
                    label = "Gold Grid Square Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_1"
                },
                [2] = {
                    label = "Gold Noir Square Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_2"
                },
                [3] = {
                    label = "Platinum Grid Square Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_3"
                },
                [4] = {
                    label = "Platinum Noir Square Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_4"
                },
                [5] = {
                    label = "Earrings (18-5)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_18_5"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Illusion Square Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_0"
                },
                [1] = {
                    label = "Gold Grid Square Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_1"
                },
                [2] = {
                    label = "Gold Noir Square Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_2"
                },
                [3] = {
                    label = "Platinum Grid Square Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_3"
                },
                [4] = {
                    label = "Platinum Noir Square Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_4"
                },
                [5] = {
                    label = "Earrings (19-5)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_19_5"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Illusion Square Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_0"
                },
                [1] = {
                    label = "Gold Grid Square Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_1"
                },
                [2] = {
                    label = "Gold Noir Square Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_2"
                },
                [3] = {
                    label = "Platinum Grid Square Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_3"
                },
                [4] = {
                    label = "Platinum Noir Square Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_4"
                },
                [5] = {
                    label = "Earrings (20-5)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_20_5"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold SN Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_21_0"
                },
                [1] = {
                    label = "Platinum SN Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_21_1"
                },
                [2] = {
                    label = "Earrings (21-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_21_2"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold SN Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_22_0"
                },
                [1] = {
                    label = "Platinum SN Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_22_1"
                },
                [2] = {
                    label = "Earrings (22-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_22_2"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold SN Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_23_0"
                },
                [1] = {
                    label = "Platinum SN Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_23_1"
                },
                [2] = {
                    label = "Earrings (23-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_23_2"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Skull Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_24_0"
                },
                [1] = {
                    label = "Gold Skull Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_24_1"
                },
                [2] = {
                    label = "Black Skull Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_24_2"
                },
                [3] = {
                    label = "Platinum Skull Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_24_3"
                },
                [4] = {
                    label = "Earrings (24-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_24_4"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Skull Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_25_0"
                },
                [1] = {
                    label = "Gold Skull Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_25_1"
                },
                [2] = {
                    label = "Black Skull Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_25_2"
                },
                [3] = {
                    label = "Platinum Skull Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_25_3"
                },
                [4] = {
                    label = "Earrings (25-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_25_4"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Skull Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_26_0"
                },
                [1] = {
                    label = "Gold Skull Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_26_1"
                },
                [2] = {
                    label = "Black Skull Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_26_2"
                },
                [3] = {
                    label = "Platinum Skull Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_26_3"
                },
                [4] = {
                    label = "Earrings (26-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_26_4"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Spike Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_27_0"
                },
                [1] = {
                    label = "Gold Spike Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_27_1"
                },
                [2] = {
                    label = "Earrings (27-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_27_2"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Spike Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_28_0"
                },
                [1] = {
                    label = "Gold Spike Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_28_1"
                },
                [2] = {
                    label = "Earrings (28-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_28_2"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Spike Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_29_0"
                },
                [1] = {
                    label = "Gold Spike Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_29_1"
                },
                [2] = {
                    label = "Earrings (29-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_29_2"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Onyx Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_30_0"
                },
                [1] = {
                    label = "Black Onyx Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_30_1"
                },
                [2] = {
                    label = "Platinum Onyx Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_30_2"
                },
                [3] = {
                    label = "Earrings (30-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_30_3"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Onyx Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_31_0"
                },
                [1] = {
                    label = "Black Onyx Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_31_1"
                },
                [2] = {
                    label = "Platinum Onyx Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_31_2"
                },
                [3] = {
                    label = "Earrings (31-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_31_3"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Onyx Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_32_0"
                },
                [1] = {
                    label = "Black Onyx Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_32_1"
                },
                [2] = {
                    label = "Platinum Onyx Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_32_2"
                },
                [3] = {
                    label = "Earrings (32-3)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_32_3"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Earrings (33-0)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_33_0"
                },
                [1] = {
                    label = "Earrings (33-1)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_33_1"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum SN Bullion Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_34_0"
                },
                [1] = {
                    label = "Gold SN Bullion Stud (L)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_34_1"
                },
                [2] = {
                    label = "Earrings (34-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_34_2"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum SN Bullion Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_35_0"
                },
                [1] = {
                    label = "Gold SN Bullion Stud (R)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_35_1"
                },
                [2] = {
                    label = "Earrings (35-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_35_2"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum SN Bullion Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_36_0"
                },
                [1] = {
                    label = "Gold SN Bullion Studs",
                    price = 500,
                    type = "money",
                    image = "male_earrings_36_1"
                },
                [2] = {
                    label = "Earrings (36-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_36_2"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Fame or Shame Mics",
                    price = 500,
                    type = "money",
                    image = "male_earrings_37_0"
                },
                [1] = {
                    label = "Silver Fame or Shame Mics",
                    price = 500,
                    type = "money",
                    image = "male_earrings_37_1"
                },
                [2] = {
                    label = "Earrings (37-2)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_37_2"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Clubs Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_38_0"
                },
                [1] = {
                    label = "Diamonds Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_38_1"
                },
                [2] = {
                    label = "Hearts Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_38_2"
                },
                [3] = {
                    label = "Spades Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_38_3"
                },
                [4] = {
                    label = "Earrings (38-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_38_4"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_39_0"
                },
                [1] = {
                    label = "Red Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_39_1"
                },
                [2] = {
                    label = "Tan Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_39_2"
                },
                [3] = {
                    label = "Gray Dice Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_39_3"
                },
                [4] = {
                    label = "Earrings (39-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_39_4"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_40_0"
                },
                [1] = {
                    label = "Yellow Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_40_1"
                },
                [2] = {
                    label = "Red Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_40_2"
                },
                [3] = {
                    label = "Pink Chips Earringss",
                    price = 500,
                    type = "money",
                    image = "male_earrings_40_3"
                },
                [4] = {
                    label = "Earrings (40-4)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_40_4"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_0"
                },
                [1] = {
                    label = "Yellow Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_1"
                },
                [2] = {
                    label = "Salmon Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_2"
                },
                [3] = {
                    label = "Orange Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_3"
                },
                [4] = {
                    label = "Purple Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_4"
                },
                [5] = {
                    label = "Pink Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_5"
                },
                [6] = {
                    label = "Turquoise Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_6"
                },
                [7] = {
                    label = "Blue Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_7"
                },
                [8] = {
                    label = "Black Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_8"
                },
                [9] = {
                    label = "Gray Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_9"
                },
                [10] = {
                    label = "Teal Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_10"
                },
                [11] = {
                    label = "Red Beat Off Earphones",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_11"
                },
                [12] = {
                    label = "Earrings (41-12)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_41_12"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Earrings (42-0)",
                    price = 500,
                    type = "money",
                    image = "male_earrings_42_0"
                },
            },
        },
    },
}
