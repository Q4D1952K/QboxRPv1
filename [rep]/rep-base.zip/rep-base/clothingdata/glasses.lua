glasses = {
    female = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_0"
                },
                [1] = {
                    label = "Glass (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_1"
                },
                [2] = {
                    label = "Glass (0-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_2"
                },
                [3] = {
                    label = "Glass (0-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_3"
                },
                [4] = {
                    label = "Glass (0-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_4"
                },
                [5] = {
                    label = "Glass (0-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_5"
                },
                [6] = {
                    label = "Glass (0-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_6"
                },
                [7] = {
                    label = "Glass (0-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_7"
                },
                [8] = {
                    label = "Glass (0-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_8"
                },
                [9] = {
                    label = "Glass (0-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_9"
                },
                [10] = {
                    label = "Glass (0-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_10"
                },
                [11] = {
                    label = "Glass (0-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_0_11"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_0"
                },
                [1] = {
                    label = "Glass (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_1"
                },
                [2] = {
                    label = "Glass (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_2"
                },
                [3] = {
                    label = "Glass (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_3"
                },
                [4] = {
                    label = "Glass (1-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_4"
                },
                [5] = {
                    label = "Glass (1-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_5"
                },
                [6] = {
                    label = "Glass (1-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_6"
                },
                [7] = {
                    label = "Glass (1-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_7"
                },
                [8] = {
                    label = "Glass (1-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_8"
                },
                [9] = {
                    label = "Glass (1-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_9"
                },
                [10] = {
                    label = "Glass (1-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_10"
                },
                [11] = {
                    label = "Glass (1-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_1_11"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_0"
                },
                [1] = {
                    label = "Glass (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_1"
                },
                [2] = {
                    label = "Glass (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_2"
                },
                [3] = {
                    label = "Glass (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_3"
                },
                [4] = {
                    label = "Glass (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_4"
                },
                [5] = {
                    label = "Glass (2-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_5"
                },
                [6] = {
                    label = "Glass (2-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_6"
                },
                [7] = {
                    label = "Glass (2-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_7"
                },
                [8] = {
                    label = "Glass (2-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_8"
                },
                [9] = {
                    label = "Glass (2-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_9"
                },
                [10] = {
                    label = "Glass (2-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_10"
                },
                [11] = {
                    label = "Glass (2-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_2_11"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_0"
                },
                [1] = {
                    label = "Glass (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_1"
                },
                [2] = {
                    label = "Glass (3-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_2"
                },
                [3] = {
                    label = "Glass (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_3"
                },
                [4] = {
                    label = "Glass (3-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_4"
                },
                [5] = {
                    label = "Glass (3-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_5"
                },
                [6] = {
                    label = "Glass (3-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_6"
                },
                [7] = {
                    label = "Glass (3-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_7"
                },
                [8] = {
                    label = "Glass (3-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_8"
                },
                [9] = {
                    label = "Glass (3-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_9"
                },
                [10] = {
                    label = "Glass (3-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_10"
                },
                [11] = {
                    label = "Glass (3-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_3_11"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_0"
                },
                [1] = {
                    label = "Glass (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_1"
                },
                [2] = {
                    label = "Glass (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_2"
                },
                [3] = {
                    label = "Glass (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_3"
                },
                [4] = {
                    label = "Glass (4-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_4"
                },
                [5] = {
                    label = "Glass (4-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_5"
                },
                [6] = {
                    label = "Glass (4-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_6"
                },
                [7] = {
                    label = "Glass (4-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_7"
                },
                [8] = {
                    label = "Glass (4-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_8"
                },
                [9] = {
                    label = "Glass (4-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_9"
                },
                [10] = {
                    label = "Glass (4-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_10"
                },
                [11] = {
                    label = "Glass (4-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_4_11"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_0"
                },
                [1] = {
                    label = "Glass (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_1"
                },
                [2] = {
                    label = "Glass (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_2"
                },
                [3] = {
                    label = "Glass (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_3"
                },
                [4] = {
                    label = "Glass (5-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_4"
                },
                [5] = {
                    label = "Glass (5-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_5"
                },
                [6] = {
                    label = "Glass (5-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_6"
                },
                [7] = {
                    label = "Glass (5-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_7"
                },
                [8] = {
                    label = "Glass (5-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_8"
                },
                [9] = {
                    label = "Glass (5-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_9"
                },
                [10] = {
                    label = "Glass (5-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_10"
                },
                [11] = {
                    label = "Glass (5-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_5_11"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_0"
                },
                [1] = {
                    label = "Glass (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_1"
                },
                [2] = {
                    label = "Glass (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_2"
                },
                [3] = {
                    label = "Glass (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_3"
                },
                [4] = {
                    label = "Glass (6-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_4"
                },
                [5] = {
                    label = "Glass (6-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_5"
                },
                [6] = {
                    label = "Glass (6-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_6"
                },
                [7] = {
                    label = "Glass (6-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_7"
                },
                [8] = {
                    label = "Glass (6-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_8"
                },
                [9] = {
                    label = "Glass (6-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_9"
                },
                [10] = {
                    label = "Glass (6-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_10"
                },
                [11] = {
                    label = "Glass (6-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_6_11"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_0"
                },
                [1] = {
                    label = "Glass (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_1"
                },
                [2] = {
                    label = "Glass (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_2"
                },
                [3] = {
                    label = "Glass (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_3"
                },
                [4] = {
                    label = "Glass (7-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_4"
                },
                [5] = {
                    label = "Glass (7-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_5"
                },
                [6] = {
                    label = "Glass (7-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_6"
                },
                [7] = {
                    label = "Glass (7-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_7"
                },
                [8] = {
                    label = "Glass (7-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_8"
                },
                [9] = {
                    label = "Glass (7-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_9"
                },
                [10] = {
                    label = "Glass (7-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_10"
                },
                [11] = {
                    label = "Glass (7-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_7_11"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (8-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_0"
                },
                [1] = {
                    label = "Glass (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_1"
                },
                [2] = {
                    label = "Glass (8-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_2"
                },
                [3] = {
                    label = "Glass (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_3"
                },
                [4] = {
                    label = "Glass (8-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_4"
                },
                [5] = {
                    label = "Glass (8-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_5"
                },
                [6] = {
                    label = "Glass (8-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_6"
                },
                [7] = {
                    label = "Glass (8-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_7"
                },
                [8] = {
                    label = "Glass (8-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_8"
                },
                [9] = {
                    label = "Glass (8-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_9"
                },
                [10] = {
                    label = "Glass (8-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_10"
                },
                [11] = {
                    label = "Glass (8-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_8_11"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (9-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_0"
                },
                [1] = {
                    label = "Glass (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_1"
                },
                [2] = {
                    label = "Glass (9-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_2"
                },
                [3] = {
                    label = "Glass (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_3"
                },
                [4] = {
                    label = "Glass (9-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_4"
                },
                [5] = {
                    label = "Glass (9-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_5"
                },
                [6] = {
                    label = "Glass (9-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_6"
                },
                [7] = {
                    label = "Glass (9-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_7"
                },
                [8] = {
                    label = "Glass (9-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_8"
                },
                [9] = {
                    label = "Glass (9-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_9"
                },
                [10] = {
                    label = "Glass (9-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_10"
                },
                [11] = {
                    label = "Glass (9-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_9_11"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (10-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_0"
                },
                [1] = {
                    label = "Glass (10-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_1"
                },
                [2] = {
                    label = "Glass (10-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_2"
                },
                [3] = {
                    label = "Glass (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_3"
                },
                [4] = {
                    label = "Glass (10-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_4"
                },
                [5] = {
                    label = "Glass (10-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_5"
                },
                [6] = {
                    label = "Glass (10-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_6"
                },
                [7] = {
                    label = "Glass (10-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_7"
                },
                [8] = {
                    label = "Glass (10-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_8"
                },
                [9] = {
                    label = "Glass (10-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_9"
                },
                [10] = {
                    label = "Glass (10-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_10"
                },
                [11] = {
                    label = "Glass (10-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_10_11"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (11-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_0"
                },
                [1] = {
                    label = "Glass (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_1"
                },
                [2] = {
                    label = "Glass (11-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_2"
                },
                [3] = {
                    label = "Glass (11-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_3"
                },
                [4] = {
                    label = "Glass (11-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_4"
                },
                [5] = {
                    label = "Glass (11-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_5"
                },
                [6] = {
                    label = "Glass (11-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_6"
                },
                [7] = {
                    label = "Glass (11-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_7"
                },
                [8] = {
                    label = "Glass (11-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_11_8"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (12-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_0"
                },
                [1] = {
                    label = "Glass (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_1"
                },
                [2] = {
                    label = "Glass (12-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_2"
                },
                [3] = {
                    label = "Glass (12-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_3"
                },
                [4] = {
                    label = "Glass (12-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_4"
                },
                [5] = {
                    label = "Glass (12-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_5"
                },
                [6] = {
                    label = "Glass (12-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_6"
                },
                [7] = {
                    label = "Glass (12-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_7"
                },
                [8] = {
                    label = "Glass (12-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_12_8"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (13-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_0"
                },
                [1] = {
                    label = "Glass (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_1"
                },
                [2] = {
                    label = "Glass (13-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_2"
                },
                [3] = {
                    label = "Glass (13-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_3"
                },
                [4] = {
                    label = "Glass (13-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_4"
                },
                [5] = {
                    label = "Glass (13-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_5"
                },
                [6] = {
                    label = "Glass (13-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_6"
                },
                [7] = {
                    label = "Glass (13-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_7"
                },
                [8] = {
                    label = "Glass (13-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_13_8"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (14-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_0"
                },
                [1] = {
                    label = "Glass (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_1"
                },
                [2] = {
                    label = "Glass (14-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_2"
                },
                [3] = {
                    label = "Glass (14-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_3"
                },
                [4] = {
                    label = "Glass (14-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_4"
                },
                [5] = {
                    label = "Glass (14-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_5"
                },
                [6] = {
                    label = "Glass (14-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_6"
                },
                [7] = {
                    label = "Glass (14-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_7"
                },
                [8] = {
                    label = "Glass (14-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_8"
                },
                [9] = {
                    label = "Glass (14-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_9"
                },
                [10] = {
                    label = "Glass (14-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_10"
                },
                [11] = {
                    label = "Glass (14-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_14_11"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (15-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_0"
                },
                [1] = {
                    label = "Glass (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_1"
                },
                [2] = {
                    label = "Glass (15-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_2"
                },
                [3] = {
                    label = "Glass (15-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_3"
                },
                [4] = {
                    label = "Glass (15-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_4"
                },
                [5] = {
                    label = "Glass (15-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_5"
                },
                [6] = {
                    label = "Glass (15-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_6"
                },
                [7] = {
                    label = "Glass (15-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_7"
                },
                [8] = {
                    label = "Glass (15-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_15_8"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "DS Brown Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_0"
                },
                [1] = {
                    label = "DS Blue Tint Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_1"
                },
                [2] = {
                    label = "DS Green Marble Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_2"
                },
                [3] = {
                    label = "DS Teal Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_3"
                },
                [4] = {
                    label = "DS White Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_4"
                },
                [5] = {
                    label = "DS Pink Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_5"
                },
                [6] = {
                    label = "DS Red Bugs",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_6"
                },
                [7] = {
                    label = "Glass (16-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_7"
                },
                [8] = {
                    label = "Glass (16-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_8"
                },
                [9] = {
                    label = "Glass (16-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_9"
                },
                [10] = {
                    label = "Glass (16-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_16_10"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Tint Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_0"
                },
                [1] = {
                    label = "Blue Leopard Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_1"
                },
                [2] = {
                    label = "Purple Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_2"
                },
                [3] = {
                    label = "Teal Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_3"
                },
                [4] = {
                    label = "Tan Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_4"
                },
                [5] = {
                    label = "Pink Striped Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_5"
                },
                [6] = {
                    label = "White Squared",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_6"
                },
                [7] = {
                    label = "Glass (17-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_7"
                },
                [8] = {
                    label = "Glass (17-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_8"
                },
                [9] = {
                    label = "Glass (17-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_9"
                },
                [10] = {
                    label = "Glass (17-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_17_10"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Steel Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_0"
                },
                [1] = {
                    label = "Pewter Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_1"
                },
                [2] = {
                    label = "Gold Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_2"
                },
                [3] = {
                    label = "Black Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_3"
                },
                [4] = {
                    label = "Yellow Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_4"
                },
                [5] = {
                    label = "Copper Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_5"
                },
                [6] = {
                    label = "Gold Stem Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_6"
                },
                [7] = {
                    label = "Silver Stem Slim Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_7"
                },
                [8] = {
                    label = "Glass (18-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_8"
                },
                [9] = {
                    label = "Glass (18-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_9"
                },
                [10] = {
                    label = "Glass (18-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_10"
                },
                [11] = {
                    label = "Glass (18-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_18_11"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_0"
                },
                [1] = {
                    label = "Orange Hinge Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_1"
                },
                [2] = {
                    label = "Pink Hinge Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_2"
                },
                [3] = {
                    label = "Marbled Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_3"
                },
                [4] = {
                    label = "Latte Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_4"
                },
                [5] = {
                    label = "Vixen Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_5"
                },
                [6] = {
                    label = "Sunshine Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_6"
                },
                [7] = {
                    label = "Eccentric Plastic Frames",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_7"
                },
                [8] = {
                    label = "Shell Plastic Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_8"
                },
                [9] = {
                    label = "Black Plastic Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_9"
                },
                [10] = {
                    label = "White Plastic Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_10"
                },
                [11] = {
                    label = "Glass (19-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_19_11"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_0"
                },
                [1] = {
                    label = "Two-Tone Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_1"
                },
                [2] = {
                    label = "Red Marble Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_2"
                },
                [3] = {
                    label = "Multicolored Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_3"
                },
                [4] = {
                    label = "Peach Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_4"
                },
                [5] = {
                    label = "Baby Blue Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_5"
                },
                [6] = {
                    label = "Red Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_6"
                },
                [7] = {
                    label = "Lime Retro Classics",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_7"
                },
                [8] = {
                    label = "Glass (20-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_20_8"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_0"
                },
                [1] = {
                    label = "Blue Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_1"
                },
                [2] = {
                    label = "Marble Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_2"
                },
                [3] = {
                    label = "Dipped Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_3"
                },
                [4] = {
                    label = "Red Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_4"
                },
                [5] = {
                    label = "Orange Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_5"
                },
                [6] = {
                    label = "Hot Pink Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_6"
                },
                [7] = {
                    label = "Brown Hipsters",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_7"
                },
                [8] = {
                    label = "Glass (21-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_21_8"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Star Frame Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_22_0"
                },
                [1] = {
                    label = "Glass (22-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_22_1"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Star Spangled Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_23_0"
                },
                [1] = {
                    label = "Glass (23-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_23_1"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_0"
                },
                [1] = {
                    label = "Zap Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_1"
                },
                [2] = {
                    label = "Tortoiseshell Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_2"
                },
                [3] = {
                    label = "Red Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_3"
                },
                [4] = {
                    label = "White Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_4"
                },
                [5] = {
                    label = "Camo Collection Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_5"
                },
                [6] = {
                    label = "Lemon Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_6"
                },
                [7] = {
                    label = "Blood Casuals",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_7"
                },
                [8] = {
                    label = "Shell Casual Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_8"
                },
                [9] = {
                    label = "Black Casual Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_9"
                },
                [10] = {
                    label = "White Casual Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_10"
                },
                [11] = {
                    label = "Glass (24-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_24_11"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (25-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_0"
                },
                [1] = {
                    label = "Glass (25-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_1"
                },
                [2] = {
                    label = "Glass (25-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_2"
                },
                [3] = {
                    label = "Glass (25-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_3"
                },
                [4] = {
                    label = "Glass (25-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_4"
                },
                [5] = {
                    label = "Glass (25-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_5"
                },
                [6] = {
                    label = "Glass (25-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_6"
                },
                [7] = {
                    label = "Glass (25-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_7"
                },
                [8] = {
                    label = "Glass (25-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_8"
                },
                [9] = {
                    label = "Glass (25-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_9"
                },
                [10] = {
                    label = "Glass (25-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_25_10"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_0"
                },
                [1] = {
                    label = "Black Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_1"
                },
                [2] = {
                    label = "Mono Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_2"
                },
                [3] = {
                    label = "Ox Blood Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_3"
                },
                [4] = {
                    label = "Blue Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_4"
                },
                [5] = {
                    label = "Beige Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_5"
                },
                [6] = {
                    label = "Glass (26-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_26_6"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tropical Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_0"
                },
                [1] = {
                    label = "Yellow Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_1"
                },
                [2] = {
                    label = "Green Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_2"
                },
                [3] = {
                    label = "Dusk Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_3"
                },
                [4] = {
                    label = "Grayscale Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_4"
                },
                [5] = {
                    label = "Pink Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_5"
                },
                [6] = {
                    label = "Orange Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_6"
                },
                [7] = {
                    label = "Brown Urban Ski",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_7"
                },
                [8] = {
                    label = "Glass (27-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_27_8"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (28-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_0"
                },
                [1] = {
                    label = "Glass (28-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_1"
                },
                [2] = {
                    label = "Glass (28-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_2"
                },
                [3] = {
                    label = "Glass (28-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_3"
                },
                [4] = {
                    label = "Glass (28-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_4"
                },
                [5] = {
                    label = "Glass (28-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_5"
                },
                [6] = {
                    label = "Glass (28-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_6"
                },
                [7] = {
                    label = "Glass (28-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_7"
                },
                [8] = {
                    label = "Glass (28-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_8"
                },
                [9] = {
                    label = "Glass (28-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_9"
                },
                [10] = {
                    label = "Glass (28-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_10"
                },
                [11] = {
                    label = "Glass (28-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_11"
                },
                [12] = {
                    label = "Glass (28-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_12"
                },
                [13] = {
                    label = "Glass (28-13)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_13"
                },
                [14] = {
                    label = "Glass (28-14)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_14"
                },
                [15] = {
                    label = "Glass (28-15)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_15"
                },
                [16] = {
                    label = "Glass (28-16)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_16"
                },
                [17] = {
                    label = "Glass (28-17)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_17"
                },
                [18] = {
                    label = "Glass (28-18)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_18"
                },
                [19] = {
                    label = "Glass (28-19)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_19"
                },
                [20] = {
                    label = "Glass (28-20)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_20"
                },
                [21] = {
                    label = "Glass (28-21)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_21"
                },
                [22] = {
                    label = "Glass (28-22)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_22"
                },
                [23] = {
                    label = "Glass (28-23)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_23"
                },
                [24] = {
                    label = "Glass (28-24)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_24"
                },
                [25] = {
                    label = "Glass (28-25)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_25"
                },
                [26] = {
                    label = "Glass (28-26)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_28_26"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (29-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_29_0"
                },
                [1] = {
                    label = "Glass (29-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_29_1"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Dot Fade Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_0"
                },
                [1] = {
                    label = "Orange Fade Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_1"
                },
                [2] = {
                    label = "Walnut Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_2"
                },
                [3] = {
                    label = "Horizon Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_3"
                },
                [4] = {
                    label = "Purple Vine Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_4"
                },
                [5] = {
                    label = "Herringbone Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_5"
                },
                [6] = {
                    label = "Gold Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_6"
                },
                [7] = {
                    label = "Magenta Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_7"
                },
                [8] = {
                    label = "Electric Blue Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_8"
                },
                [9] = {
                    label = "Blue Argyle Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_9"
                },
                [10] = {
                    label = "Black Rim Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_10"
                },
                [11] = {
                    label = "White Rim Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_11"
                },
                [12] = {
                    label = "Glass (30-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_30_12"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_0"
                },
                [1] = {
                    label = "Two Tone Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_1"
                },
                [2] = {
                    label = "White Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_2"
                },
                [3] = {
                    label = "Red Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_3"
                },
                [4] = {
                    label = "Aqua Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_4"
                },
                [5] = {
                    label = "Green Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_5"
                },
                [6] = {
                    label = "Green Urban Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_6"
                },
                [7] = {
                    label = "Pink Urban Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_7"
                },
                [8] = {
                    label = "Digital Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_8"
                },
                [9] = {
                    label = "Splinter Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_9"
                },
                [10] = {
                    label = "Zebra Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_10"
                },
                [11] = {
                    label = "Houndstooth Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_11"
                },
                [12] = {
                    label = "Mute Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_12"
                },
                [13] = {
                    label = "Sunrise Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_13"
                },
                [14] = {
                    label = "Striped Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_14"
                },
                [15] = {
                    label = "Mono Deep Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_15"
                },
                [16] = {
                    label = "Black Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_16"
                },
                [17] = {
                    label = "Red Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_17"
                },
                [18] = {
                    label = "Blue Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_18"
                },
                [19] = {
                    label = "White Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_19"
                },
                [20] = {
                    label = "Glass (31-20)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_31_20"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue & Pink Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_0"
                },
                [1] = {
                    label = "Red Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_1"
                },
                [2] = {
                    label = "Orange Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_2"
                },
                [3] = {
                    label = "Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_3"
                },
                [4] = {
                    label = "Green Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_4"
                },
                [5] = {
                    label = "Blue Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_5"
                },
                [6] = {
                    label = "Pink Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_6"
                },
                [7] = {
                    label = "Blue & Magenta Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_7"
                },
                [8] = {
                    label = "Purple & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_8"
                },
                [9] = {
                    label = "Blue & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_9"
                },
                [10] = {
                    label = "Pink & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_10"
                },
                [11] = {
                    label = "Red & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_11"
                },
                [12] = {
                    label = "Glass (32-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_32_12"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Midnight Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_0"
                },
                [1] = {
                    label = "Sunset Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_1"
                },
                [2] = {
                    label = "Black Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_2"
                },
                [3] = {
                    label = "Blue Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_3"
                },
                [4] = {
                    label = "Gold Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_4"
                },
                [5] = {
                    label = "Green Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_5"
                },
                [6] = {
                    label = "Orange Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_6"
                },
                [7] = {
                    label = "Red Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_7"
                },
                [8] = {
                    label = "Pink Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_8"
                },
                [9] = {
                    label = "Yellow Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_9"
                },
                [10] = {
                    label = "Lemon Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_10"
                },
                [11] = {
                    label = "Gold Rimmed Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_11"
                },
                [12] = {
                    label = "Glass (33-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_33_12"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_0"
                },
                [1] = {
                    label = "Pink Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_1"
                },
                [2] = {
                    label = "Yellow Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_2"
                },
                [3] = {
                    label = "Red Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_3"
                },
                [4] = {
                    label = "White Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_4"
                },
                [5] = {
                    label = "Black Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_5"
                },
                [6] = {
                    label = "Pink Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_6"
                },
                [7] = {
                    label = "Blue Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_7"
                },
                [8] = {
                    label = "Green Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_8"
                },
                [9] = {
                    label = "Blue Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_9"
                },
                [10] = {
                    label = "Orange Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_10"
                },
                [11] = {
                    label = "Green Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_11"
                },
                [12] = {
                    label = "Glass (34-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_34_12"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_0"
                },
                [1] = {
                    label = "Yellow Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_1"
                },
                [2] = {
                    label = "Black Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_2"
                },
                [3] = {
                    label = "Tortoiseshell Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_3"
                },
                [4] = {
                    label = "Green Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_4"
                },
                [5] = {
                    label = "Red Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_5"
                },
                [6] = {
                    label = "Pink Tinted Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_6"
                },
                [7] = {
                    label = "Blue Tinted Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_7"
                },
                [8] = {
                    label = "White Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_8"
                },
                [9] = {
                    label = "Pink Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_9"
                },
                [10] = {
                    label = "All White Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_10"
                },
                [11] = {
                    label = "Mono Square Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_11"
                },
                [12] = {
                    label = "Glass (35-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_35_12"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_0"
                },
                [1] = {
                    label = "Silver Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_1"
                },
                [2] = {
                    label = "Gold Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_2"
                },
                [3] = {
                    label = "Rose Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_3"
                },
                [4] = {
                    label = "Tortoiseshell Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_4"
                },
                [5] = {
                    label = "Gold Framed Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_5"
                },
                [6] = {
                    label = "Blue Framed Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_6"
                },
                [7] = {
                    label = "Tortoiseshell & Silver Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_7"
                },
                [8] = {
                    label = "Tortoiseshell & Gold Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_8"
                },
                [9] = {
                    label = "Gray Tortoiseshell Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_9"
                },
                [10] = {
                    label = "Gold Swirl Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_10"
                },
                [11] = {
                    label = "Gold Fade Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_11"
                },
                [12] = {
                    label = "Glass (36-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_36_12"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_0"
                },
                [1] = {
                    label = "Silver Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_1"
                },
                [2] = {
                    label = "Gold Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_2"
                },
                [3] = {
                    label = "Rose Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_3"
                },
                [4] = {
                    label = "Black & Red Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_4"
                },
                [5] = {
                    label = "Black & Brown Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_5"
                },
                [6] = {
                    label = "Black & Blue Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_6"
                },
                [7] = {
                    label = "Tortoiseshell & Brown Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_7"
                },
                [8] = {
                    label = "Gold & Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_8"
                },
                [9] = {
                    label = "Gray Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_9"
                },
                [10] = {
                    label = "Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_10"
                },
                [11] = {
                    label = "Pink & Black Square",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_11"
                },
                [12] = {
                    label = "Glass (37-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_37_12"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_0"
                },
                [1] = {
                    label = "Silver Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_1"
                },
                [2] = {
                    label = "Gold Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_2"
                },
                [3] = {
                    label = "Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_3"
                },
                [4] = {
                    label = "Black & Green Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_4"
                },
                [5] = {
                    label = "Dark Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_5"
                },
                [6] = {
                    label = "Black & Teal Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_6"
                },
                [7] = {
                    label = "Black & Red Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_7"
                },
                [8] = {
                    label = "Gold & Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_8"
                },
                [9] = {
                    label = "Navy Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_9"
                },
                [10] = {
                    label = "Pink & Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_10"
                },
                [11] = {
                    label = "Gold Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_11"
                },
                [12] = {
                    label = "Glass (38-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_38_12"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_0"
                },
                [1] = {
                    label = "Silver Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_1"
                },
                [2] = {
                    label = "Gold Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_2"
                },
                [3] = {
                    label = "Light Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_3"
                },
                [4] = {
                    label = "Claret Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_4"
                },
                [5] = {
                    label = "Blue Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_5"
                },
                [6] = {
                    label = "Gray & Red Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_6"
                },
                [7] = {
                    label = "Teal Fade Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_7"
                },
                [8] = {
                    label = "Yellow Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_8"
                },
                [9] = {
                    label = "Green Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_9"
                },
                [10] = {
                    label = "Red Fade Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_10"
                },
                [11] = {
                    label = "Dark Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_11"
                },
                [12] = {
                    label = "Glass (39-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_39_12"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_0"
                },
                [1] = {
                    label = "Silver Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_1"
                },
                [2] = {
                    label = "Gold Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_2"
                },
                [3] = {
                    label = "Tortoiseshell Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_3"
                },
                [4] = {
                    label = "Green Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_4"
                },
                [5] = {
                    label = "Dark Tortoiseshell Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_5"
                },
                [6] = {
                    label = "Teal Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_6"
                },
                [7] = {
                    label = "Red Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_7"
                },
                [8] = {
                    label = "Gold & Black Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_8"
                },
                [9] = {
                    label = "Blue Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_9"
                },
                [10] = {
                    label = "Pink Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_10"
                },
                [11] = {
                    label = "Tiger Ergonomic",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_11"
                },
                [12] = {
                    label = "Glass (40-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_40_12"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_0"
                },
                [1] = {
                    label = "Silver Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_1"
                },
                [2] = {
                    label = "Gold Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_2"
                },
                [3] = {
                    label = "Rose Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_3"
                },
                [4] = {
                    label = "Black & Pink Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_4"
                },
                [5] = {
                    label = "Black & Brown Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_5"
                },
                [6] = {
                    label = "Black & Navy Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_6"
                },
                [7] = {
                    label = "Tortoiseshell Rim Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_7"
                },
                [8] = {
                    label = "Gold & Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_8"
                },
                [9] = {
                    label = "Black Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_9"
                },
                [10] = {
                    label = "Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_10"
                },
                [11] = {
                    label = "Gold & Black Retro Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_11"
                },
                [12] = {
                    label = "Glass (41-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_41_12"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (42-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_0"
                },
                [1] = {
                    label = "Glass (42-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_1"
                },
                [2] = {
                    label = "Glass (42-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_2"
                },
                [3] = {
                    label = "Glass (42-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_3"
                },
                [4] = {
                    label = "Glass (42-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_4"
                },
                [5] = {
                    label = "Glass (42-5)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_5"
                },
                [6] = {
                    label = "Glass (42-6)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_6"
                },
                [7] = {
                    label = "Glass (42-7)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_7"
                },
                [8] = {
                    label = "Glass (42-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_8"
                },
                [9] = {
                    label = "Glass (42-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_9"
                },
                [10] = {
                    label = "Glass (42-10)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_10"
                },
                [11] = {
                    label = "Glass (42-11)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_11"
                },
                [12] = {
                    label = "Glass (42-12)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_12"
                },
                [13] = {
                    label = "Glass (42-13)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_13"
                },
                [14] = {
                    label = "Glass (42-14)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_14"
                },
                [15] = {
                    label = "Glass (42-15)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_15"
                },
                [16] = {
                    label = "Glass (42-16)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_16"
                },
                [17] = {
                    label = "Glass (42-17)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_17"
                },
                [18] = {
                    label = "Glass (42-18)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_18"
                },
                [19] = {
                    label = "Glass (42-19)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_19"
                },
                [20] = {
                    label = "Glass (42-20)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_42_20"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Mono Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_0"
                },
                [1] = {
                    label = "Gray Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_1"
                },
                [2] = {
                    label = "Ash Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_2"
                },
                [3] = {
                    label = "White Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_3"
                },
                [4] = {
                    label = "Red Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_4"
                },
                [5] = {
                    label = "Navy Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_5"
                },
                [6] = {
                    label = "Green Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_6"
                },
                [7] = {
                    label = "Moss Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_7"
                },
                [8] = {
                    label = "Olive Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_8"
                },
                [9] = {
                    label = "Dark Tan Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_9"
                },
                [10] = {
                    label = "Desert Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_10"
                },
                [11] = {
                    label = "Tan Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_11"
                },
                [12] = {
                    label = "Light Woodland Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_12"
                },
                [13] = {
                    label = "Flecktarn Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_13"
                },
                [14] = {
                    label = "Peach Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_14"
                },
                [15] = {
                    label = "Contrast Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_15"
                },
                [16] = {
                    label = "Aqua Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_16"
                },
                [17] = {
                    label = "Olive Digital Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_17"
                },
                [18] = {
                    label = "Brown Digital Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_18"
                },
                [19] = {
                    label = "Fall Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_19"
                },
                [20] = {
                    label = "Glass (43-20)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_43_20"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_0"
                },
                [1] = {
                    label = "White Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_1"
                },
                [2] = {
                    label = "Magenta Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_2"
                },
                [3] = {
                    label = "Red Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_3"
                },
                [4] = {
                    label = "Orange Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_4"
                },
                [5] = {
                    label = "Mustard Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_5"
                },
                [6] = {
                    label = "Lemon Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_6"
                },
                [7] = {
                    label = "Blue Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_7"
                },
                [8] = {
                    label = "Cyan Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_8"
                },
                [9] = {
                    label = "Green Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_9"
                },
                [10] = {
                    label = "Lime Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_10"
                },
                [11] = {
                    label = "Lavender Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_11"
                },
                [12] = {
                    label = "Purple Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_12"
                },
                [13] = {
                    label = "Tortoiseshell Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_13"
                },
                [14] = {
                    label = "Orange Tint Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_14"
                },
                [15] = {
                    label = "Blue Tint Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_15"
                },
                [16] = {
                    label = "Glass (44-16)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_44_16"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Manor Round Brow Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_45_0"
                },
                [1] = {
                    label = "Glass (45-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_45_1"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_46_0"
                },
                [1] = {
                    label = "Silver New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_46_1"
                },
                [2] = {
                    label = "Rainbow New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "female_glasses_46_2"
                },
                [3] = {
                    label = "Glass (46-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_46_3"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_0"
                },
                [1] = {
                    label = "Purple Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_1"
                },
                [2] = {
                    label = "White Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_2"
                },
                [3] = {
                    label = "Zebra Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_3"
                },
                [4] = {
                    label = "Pink Zebra Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_4"
                },
                [5] = {
                    label = "Blue DS Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_5"
                },
                [6] = {
                    label = "Green Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_6"
                },
                [7] = {
                    label = "Orange Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_7"
                },
                [8] = {
                    label = "Pink Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_8"
                },
                [9] = {
                    label = "Purple Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_9"
                },
                [10] = {
                    label = "Red Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_10"
                },
                [11] = {
                    label = "Magenta Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_11"
                },
                [12] = {
                    label = "Cyan Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_12"
                },
                [13] = {
                    label = "Moss Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_13"
                },
                [14] = {
                    label = "Blue Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_14"
                },
                [15] = {
                    label = "White Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_15"
                },
                [16] = {
                    label = "Green Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_16"
                },
                [17] = {
                    label = "Orange Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_17"
                },
                [18] = {
                    label = "Purple Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_18"
                },
                [19] = {
                    label = "Pink Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_19"
                },
                [20] = {
                    label = "Gray Camo Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_20"
                },
                [21] = {
                    label = "Aqua Camo Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_21"
                },
                [22] = {
                    label = "Gray Dazzle Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_22"
                },
                [23] = {
                    label = "Aqua Dazzle Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_23"
                },
                [24] = {
                    label = "Black SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_24"
                },
                [25] = {
                    label = "Blue SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_25"
                },
                [26] = {
                    label = "Glass (47-26)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_47_26"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Lime SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_48_0"
                },
                [1] = {
                    label = "Pink SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_48_1"
                },
                [2] = {
                    label = "Red SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_48_2"
                },
                [3] = {
                    label = "White SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "female_glasses_48_3"
                },
                [4] = {
                    label = "Glass (48-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_48_4"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_0"
                },
                [1] = {
                    label = "Pink Bigness Zebra Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_1"
                },
                [2] = {
                    label = "Green Flames Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_2"
                },
                [3] = {
                    label = "Orange Flames Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_3"
                },
                [4] = {
                    label = "Pink Flames Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_4"
                },
                [5] = {
                    label = "Purple Flames Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_5"
                },
                [6] = {
                    label = "Red Flames Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_6"
                },
                [7] = {
                    label = "Black Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_7"
                },
                [8] = {
                    label = "Teal Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_8"
                },
                [9] = {
                    label = "Red Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_9"
                },
                [10] = {
                    label = "White Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_10"
                },
                [11] = {
                    label = "Blue Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_11"
                },
                [12] = {
                    label = "Gray Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_12"
                },
                [13] = {
                    label = "Green Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_13"
                },
                [14] = {
                    label = "Orange Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_14"
                },
                [15] = {
                    label = "Purple Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_15"
                },
                [16] = {
                    label = "Red Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_16"
                },
                [17] = {
                    label = "White Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_17"
                },
                [18] = {
                    label = "Blue Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_18"
                },
                [19] = {
                    label = "Lemon Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_19"
                },
                [20] = {
                    label = "Tortoiseshell Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_20"
                },
                [21] = {
                    label = "Orange Marble Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_21"
                },
                [22] = {
                    label = "Dark Tortoiseshell Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_22"
                },
                [23] = {
                    label = "Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_23"
                },
                [24] = {
                    label = "Gray Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_24"
                },
                [25] = {
                    label = "Pink Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_25"
                },
                [26] = {
                    label = "Glass (49-26)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_49_26"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_0"
                },
                [1] = {
                    label = "White Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_1"
                },
                [2] = {
                    label = "Hot Pink Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_2"
                },
                [3] = {
                    label = "Scarlet Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_3"
                },
                [4] = {
                    label = "Orange Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_4"
                },
                [5] = {
                    label = "Amber Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_5"
                },
                [6] = {
                    label = "Lemon Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_6"
                },
                [7] = {
                    label = "Blue Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_7"
                },
                [8] = {
                    label = "Cyan Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_8"
                },
                [9] = {
                    label = "Emerald Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_9"
                },
                [10] = {
                    label = "Lime Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_10"
                },
                [11] = {
                    label = "Lavender Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_11"
                },
                [12] = {
                    label = "Magenta Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_12"
                },
                [13] = {
                    label = "Tortoiseshell Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_13"
                },
                [14] = {
                    label = "Dark Tortoiseshell Feline Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_14"
                },
                [15] = {
                    label = "Glass (50-15)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_50_15"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (51-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_51_0"
                },
                [1] = {
                    label = "Glass (51-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_51_1"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (52-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_52_0"
                },
                [1] = {
                    label = "Glass (52-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_0"
                },
                [1] = {
                    label = "Dark Silver/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_1"
                },
                [2] = {
                    label = "Gold/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_2"
                },
                [3] = {
                    label = "Rose Gold/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_3"
                },
                [4] = {
                    label = "Copper/Green Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_4"
                },
                [5] = {
                    label = "Gold/Orange Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_5"
                },
                [6] = {
                    label = "Gold/Blue Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_6"
                },
                [7] = {
                    label = "Gold/Green Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_7"
                },
                [8] = {
                    label = "Rose Gold/Pink Octagonal",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_8"
                },
                [9] = {
                    label = "Glass (53-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_53_9"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Junk Energy Goggles",
                    price = 500,
                    type = "money",
                    image = "female_glasses_54_0"
                },
                [1] = {
                    label = "Glass (54-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_54_1"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_0"
                },
                [1] = {
                    label = "Red Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_1"
                },
                [2] = {
                    label = "Orange Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_2"
                },
                [3] = {
                    label = "Yellow Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_3"
                },
                [4] = {
                    label = "Green Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_4"
                },
                [5] = {
                    label = "Blue Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_5"
                },
                [6] = {
                    label = "Purple Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_6"
                },
                [7] = {
                    label = "Black Heart Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_7"
                },
                [8] = {
                    label = "Glass (55-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_55_8"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Retro Aviator Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_56_0"
                },
                [1] = {
                    label = "Shell Retro Aviator Shades",
                    price = 500,
                    type = "money",
                    image = "female_glasses_56_1"
                },
                [2] = {
                    label = "Glass (56-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_56_2"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (57-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_57_0"
                },
                [1] = {
                    label = "Glass (57-1)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_57_1"
                },
                [2] = {
                    label = "Glass (57-2)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_57_2"
                },
                [3] = {
                    label = "Glass (57-3)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_57_3"
                },
                [4] = {
                    label = "Glass (57-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_57_4"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold & Black Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_0"
                },
                [1] = {
                    label = "Brown & Gold Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_1"
                },
                [2] = {
                    label = "Gold & Red Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_2"
                },
                [3] = {
                    label = "Silver & Black Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_3"
                },
                [4] = {
                    label = "Silver & Pink Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_4"
                },
                [5] = {
                    label = "Silver & Aqua Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_5"
                },
                [6] = {
                    label = "Dark Silver & Black Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_6"
                },
                [7] = {
                    label = "Black & Indigo Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_7"
                },
                [8] = {
                    label = "Dark Silver & Green Round",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_8"
                },
                [9] = {
                    label = "Glass (58-9)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_58_9"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_0"
                },
                [1] = {
                    label = "Black & Amber Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_1"
                },
                [2] = {
                    label = "Black & Yellow Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_2"
                },
                [3] = {
                    label = "White & Gray Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_3"
                },
                [4] = {
                    label = "White & Amber Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_4"
                },
                [5] = {
                    label = "White & Yellow Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_5"
                },
                [6] = {
                    label = "Black Tortoiseshell Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_6"
                },
                [7] = {
                    label = "Amber Tortoiseshell Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_7"
                },
                [8] = {
                    label = "Glass (59-8)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_59_8"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Sunrise Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_60_0"
                },
                [1] = {
                    label = "Black Twilight Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_60_1"
                },
                [2] = {
                    label = "White Sunrise Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_60_2"
                },
                [3] = {
                    label = "White Twilight Shields",
                    price = 500,
                    type = "money",
                    image = "female_glasses_60_3"
                },
                [4] = {
                    label = "Glass (60-4)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_60_4"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (61-0)",
                    price = 500,
                    type = "money",
                    image = "female_glasses_61_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_0"
                },
                [1] = {
                    label = "Glass (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_1"
                },
                [2] = {
                    label = "Glass (0-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_2"
                },
                [3] = {
                    label = "Glass (0-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_3"
                },
                [4] = {
                    label = "Glass (0-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_4"
                },
                [5] = {
                    label = "Glass (0-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_5"
                },
                [6] = {
                    label = "Glass (0-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_6"
                },
                [7] = {
                    label = "Glass (0-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_7"
                },
                [8] = {
                    label = "Glass (0-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_8"
                },
                [9] = {
                    label = "Glass (0-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_9"
                },
                [10] = {
                    label = "Glass (0-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_10"
                },
                [11] = {
                    label = "Glass (0-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_0_11"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_0"
                },
                [1] = {
                    label = "Glass (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_1"
                },
                [2] = {
                    label = "Glass (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_2"
                },
                [3] = {
                    label = "Glass (1-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_3"
                },
                [4] = {
                    label = "Glass (1-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_4"
                },
                [5] = {
                    label = "Glass (1-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_5"
                },
                [6] = {
                    label = "Glass (1-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_6"
                },
                [7] = {
                    label = "Glass (1-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_7"
                },
                [8] = {
                    label = "Glass (1-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_1_8"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_0"
                },
                [1] = {
                    label = "Glass (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_1"
                },
                [2] = {
                    label = "Glass (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_2"
                },
                [3] = {
                    label = "Glass (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_3"
                },
                [4] = {
                    label = "Glass (2-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_4"
                },
                [5] = {
                    label = "Glass (2-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_5"
                },
                [6] = {
                    label = "Glass (2-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_6"
                },
                [7] = {
                    label = "Glass (2-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_7"
                },
                [8] = {
                    label = "Glass (2-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_8"
                },
                [9] = {
                    label = "Glass (2-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_9"
                },
                [10] = {
                    label = "Glass (2-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_10"
                },
                [11] = {
                    label = "Glass (2-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_2_11"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_0"
                },
                [1] = {
                    label = "Glass (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_1"
                },
                [2] = {
                    label = "Glass (3-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_2"
                },
                [3] = {
                    label = "Glass (3-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_3"
                },
                [4] = {
                    label = "Glass (3-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_4"
                },
                [5] = {
                    label = "Glass (3-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_5"
                },
                [6] = {
                    label = "Glass (3-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_6"
                },
                [7] = {
                    label = "Glass (3-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_7"
                },
                [8] = {
                    label = "Glass (3-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_8"
                },
                [9] = {
                    label = "Glass (3-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_9"
                },
                [10] = {
                    label = "Glass (3-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_10"
                },
                [11] = {
                    label = "Glass (3-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_3_11"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_0"
                },
                [1] = {
                    label = "Glass (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_1"
                },
                [2] = {
                    label = "Glass (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_2"
                },
                [3] = {
                    label = "Glass (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_3"
                },
                [4] = {
                    label = "Glass (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_4"
                },
                [5] = {
                    label = "Glass (4-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_5"
                },
                [6] = {
                    label = "Glass (4-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_6"
                },
                [7] = {
                    label = "Glass (4-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_7"
                },
                [8] = {
                    label = "Glass (4-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_8"
                },
                [9] = {
                    label = "Glass (4-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_9"
                },
                [10] = {
                    label = "Glass (4-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_10"
                },
                [11] = {
                    label = "Glass (4-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_4_11"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_0"
                },
                [1] = {
                    label = "Glass (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_1"
                },
                [2] = {
                    label = "Glass (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_2"
                },
                [3] = {
                    label = "Glass (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_3"
                },
                [4] = {
                    label = "Glass (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_4"
                },
                [5] = {
                    label = "Glass (5-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_5"
                },
                [6] = {
                    label = "Glass (5-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_6"
                },
                [7] = {
                    label = "Glass (5-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_7"
                },
                [8] = {
                    label = "Glass (5-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_8"
                },
                [9] = {
                    label = "Glass (5-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_9"
                },
                [10] = {
                    label = "Glass (5-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_10"
                },
                [11] = {
                    label = "Glass (5-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_5_11"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_0"
                },
                [1] = {
                    label = "Glass (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_1"
                },
                [2] = {
                    label = "Glass (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_2"
                },
                [3] = {
                    label = "Glass (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_3"
                },
                [4] = {
                    label = "Glass (6-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_4"
                },
                [5] = {
                    label = "Glass (6-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_5"
                },
                [6] = {
                    label = "Glass (6-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_6"
                },
                [7] = {
                    label = "Glass (6-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_7"
                },
                [8] = {
                    label = "Glass (6-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_6_8"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_0"
                },
                [1] = {
                    label = "Glass (7-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_1"
                },
                [2] = {
                    label = "Glass (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_2"
                },
                [3] = {
                    label = "Glass (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_3"
                },
                [4] = {
                    label = "Glass (7-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_4"
                },
                [5] = {
                    label = "Glass (7-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_5"
                },
                [6] = {
                    label = "Glass (7-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_6"
                },
                [7] = {
                    label = "Glass (7-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_7"
                },
                [8] = {
                    label = "Glass (7-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_8"
                },
                [9] = {
                    label = "Glass (7-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_9"
                },
                [10] = {
                    label = "Glass (7-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_10"
                },
                [11] = {
                    label = "Glass (7-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_7_11"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (8-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_0"
                },
                [1] = {
                    label = "Glass (8-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_1"
                },
                [2] = {
                    label = "Glass (8-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_2"
                },
                [3] = {
                    label = "Glass (8-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_3"
                },
                [4] = {
                    label = "Glass (8-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_4"
                },
                [5] = {
                    label = "Glass (8-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_5"
                },
                [6] = {
                    label = "Glass (8-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_6"
                },
                [7] = {
                    label = "Glass (8-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_7"
                },
                [8] = {
                    label = "Glass (8-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_8"
                },
                [9] = {
                    label = "Glass (8-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_9"
                },
                [10] = {
                    label = "Glass (8-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_10"
                },
                [11] = {
                    label = "Glass (8-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_8_11"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (9-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_0"
                },
                [1] = {
                    label = "Glass (9-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_1"
                },
                [2] = {
                    label = "Glass (9-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_2"
                },
                [3] = {
                    label = "Glass (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_3"
                },
                [4] = {
                    label = "Glass (9-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_4"
                },
                [5] = {
                    label = "Glass (9-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_5"
                },
                [6] = {
                    label = "Glass (9-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_6"
                },
                [7] = {
                    label = "Glass (9-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_7"
                },
                [8] = {
                    label = "Glass (9-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_8"
                },
                [9] = {
                    label = "Glass (9-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_9"
                },
                [10] = {
                    label = "Glass (9-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_10"
                },
                [11] = {
                    label = "Glass (9-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_9_11"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (10-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_0"
                },
                [1] = {
                    label = "Glass (10-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_1"
                },
                [2] = {
                    label = "Glass (10-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_2"
                },
                [3] = {
                    label = "Glass (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_3"
                },
                [4] = {
                    label = "Glass (10-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_4"
                },
                [5] = {
                    label = "Glass (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_5"
                },
                [6] = {
                    label = "Glass (10-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_6"
                },
                [7] = {
                    label = "Glass (10-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_7"
                },
                [8] = {
                    label = "Glass (10-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_8"
                },
                [9] = {
                    label = "Glass (10-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_9"
                },
                [10] = {
                    label = "Glass (10-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_10"
                },
                [11] = {
                    label = "Glass (10-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_10_11"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (11-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_0"
                },
                [1] = {
                    label = "Glass (11-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_1"
                },
                [2] = {
                    label = "Glass (11-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_2"
                },
                [3] = {
                    label = "Glass (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_3"
                },
                [4] = {
                    label = "Glass (11-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_4"
                },
                [5] = {
                    label = "Glass (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_5"
                },
                [6] = {
                    label = "Glass (11-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_6"
                },
                [7] = {
                    label = "Glass (11-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_7"
                },
                [8] = {
                    label = "Glass (11-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_11_8"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (12-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_0"
                },
                [1] = {
                    label = "Glass (12-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_1"
                },
                [2] = {
                    label = "Glass (12-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_2"
                },
                [3] = {
                    label = "Glass (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_3"
                },
                [4] = {
                    label = "Glass (12-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_4"
                },
                [5] = {
                    label = "Glass (12-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_5"
                },
                [6] = {
                    label = "Glass (12-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_6"
                },
                [7] = {
                    label = "Glass (12-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_7"
                },
                [8] = {
                    label = "Glass (12-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_8"
                },
                [9] = {
                    label = "Glass (12-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_9"
                },
                [10] = {
                    label = "Glass (12-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_10"
                },
                [11] = {
                    label = "Glass (12-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_12_11"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (13-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_0"
                },
                [1] = {
                    label = "Glass (13-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_1"
                },
                [2] = {
                    label = "Glass (13-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_2"
                },
                [3] = {
                    label = "Glass (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_3"
                },
                [4] = {
                    label = "Glass (13-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_4"
                },
                [5] = {
                    label = "Glass (13-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_5"
                },
                [6] = {
                    label = "Glass (13-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_6"
                },
                [7] = {
                    label = "Glass (13-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_7"
                },
                [8] = {
                    label = "Glass (13-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_8"
                },
                [9] = {
                    label = "Glass (13-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_9"
                },
                [10] = {
                    label = "Glass (13-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_10"
                },
                [11] = {
                    label = "Glass (13-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_13_11"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (14-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_0"
                },
                [1] = {
                    label = "Glass (14-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_1"
                },
                [2] = {
                    label = "Glass (14-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_2"
                },
                [3] = {
                    label = "Glass (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_3"
                },
                [4] = {
                    label = "Glass (14-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_4"
                },
                [5] = {
                    label = "Glass (14-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_5"
                },
                [6] = {
                    label = "Glass (14-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_6"
                },
                [7] = {
                    label = "Glass (14-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_7"
                },
                [8] = {
                    label = "Glass (14-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_14_8"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (15-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_0"
                },
                [1] = {
                    label = "Glass (15-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_1"
                },
                [2] = {
                    label = "Glass (15-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_2"
                },
                [3] = {
                    label = "Glass (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_3"
                },
                [4] = {
                    label = "Glass (15-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_4"
                },
                [5] = {
                    label = "Glass (15-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_5"
                },
                [6] = {
                    label = "Glass (15-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_6"
                },
                [7] = {
                    label = "Glass (15-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_7"
                },
                [8] = {
                    label = "Glass (15-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_8"
                },
                [9] = {
                    label = "Glass (15-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_9"
                },
                [10] = {
                    label = "Glass (15-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_10"
                },
                [11] = {
                    label = "Glass (15-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_15_11"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Broker Pink Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_0"
                },
                [1] = {
                    label = "Broker Purple Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_1"
                },
                [2] = {
                    label = "Broker Orange Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_2"
                },
                [3] = {
                    label = "Broker Red Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_3"
                },
                [4] = {
                    label = "Broker Crimson Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_4"
                },
                [5] = {
                    label = "Broker Lime Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_5"
                },
                [6] = {
                    label = "Broker Yellow Wraparounds",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_6"
                },
                [7] = {
                    label = "Shell Wraparound Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_7"
                },
                [8] = {
                    label = "Black Wraparound Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_8"
                },
                [9] = {
                    label = "White Wraparound Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_9"
                },
                [10] = {
                    label = "Glass (16-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_16_10"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_0"
                },
                [1] = {
                    label = "Gold Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_1"
                },
                [2] = {
                    label = "Brown Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_2"
                },
                [3] = {
                    label = "Steel Refined, Warm Tint",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_3"
                },
                [4] = {
                    label = "Steel Refined, Cool Tint",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_4"
                },
                [5] = {
                    label = "Hornet Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_5"
                },
                [6] = {
                    label = "Charcoal Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_6"
                },
                [7] = {
                    label = "Black Refined",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_7"
                },
                [8] = {
                    label = "Shell Refined Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_8"
                },
                [9] = {
                    label = "Black Refined Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_9"
                },
                [10] = {
                    label = "White Refined Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_10"
                },
                [11] = {
                    label = "Glass (17-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_17_11"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Superior",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_0"
                },
                [1] = {
                    label = "Steel Superior",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_1"
                },
                [2] = {
                    label = "Black Superior",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_2"
                },
                [3] = {
                    label = "Silver Superior",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_3"
                },
                [4] = {
                    label = "Blue Superior",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_4"
                },
                [5] = {
                    label = "Bronze Superior, Warm Tint",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_5"
                },
                [6] = {
                    label = "White Superior, Cool Tint",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_6"
                },
                [7] = {
                    label = "Silver Superior, Hot Tint",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_7"
                },
                [8] = {
                    label = "Shell Superior Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_8"
                },
                [9] = {
                    label = "Black Superior Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_9"
                },
                [10] = {
                    label = "White Superior Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_10"
                },
                [11] = {
                    label = "Glass (18-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_18_11"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black & Gold Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_0"
                },
                [1] = {
                    label = "Black & Silver Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_1"
                },
                [2] = {
                    label = "Silver Dipped Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_2"
                },
                [3] = {
                    label = "Green Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_3"
                },
                [4] = {
                    label = "Crimson Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_4"
                },
                [5] = {
                    label = "Orange Dipped Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_5"
                },
                [6] = {
                    label = "Gray Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_6"
                },
                [7] = {
                    label = "White & Gold Trends",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_7"
                },
                [8] = {
                    label = "Shell Trend Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_8"
                },
                [9] = {
                    label = "Black Trend Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_9"
                },
                [10] = {
                    label = "White Trend Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_10"
                },
                [11] = {
                    label = "Glass (19-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_19_11"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Sunset Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_0"
                },
                [1] = {
                    label = "Brown Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_1"
                },
                [2] = {
                    label = "Black Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_2"
                },
                [3] = {
                    label = "Checked Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_3"
                },
                [4] = {
                    label = "White Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_4"
                },
                [5] = {
                    label = "Red Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_5"
                },
                [6] = {
                    label = "Crimson Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_6"
                },
                [7] = {
                    label = "Yellow Docks",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_7"
                },
                [8] = {
                    label = "Shell Dock Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_8"
                },
                [9] = {
                    label = "Black Dock Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_9"
                },
                [10] = {
                    label = "White Dock Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_10"
                },
                [11] = {
                    label = "Glass (20-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_20_11"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Star Frame Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_21_0"
                },
                [1] = {
                    label = "Glass (21-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_21_1"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Star Spangled Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_22_0"
                },
                [1] = {
                    label = "Glass (22-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_22_1"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (23-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_0"
                },
                [1] = {
                    label = "Glass (23-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_1"
                },
                [2] = {
                    label = "Glass (23-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_2"
                },
                [3] = {
                    label = "Glass (23-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_3"
                },
                [4] = {
                    label = "Glass (23-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_4"
                },
                [5] = {
                    label = "Glass (23-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_5"
                },
                [6] = {
                    label = "Glass (23-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_6"
                },
                [7] = {
                    label = "Glass (23-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_7"
                },
                [8] = {
                    label = "Glass (23-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_8"
                },
                [9] = {
                    label = "Glass (23-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_9"
                },
                [10] = {
                    label = "Glass (23-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_23_10"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_0"
                },
                [1] = {
                    label = "Black Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_1"
                },
                [2] = {
                    label = "Mono Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_2"
                },
                [3] = {
                    label = "Ox Blood Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_3"
                },
                [4] = {
                    label = "Blue Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_4"
                },
                [5] = {
                    label = "Beige Outlaw Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_5"
                },
                [6] = {
                    label = "Glass (24-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_24_6"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tropical Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_0"
                },
                [1] = {
                    label = "Yellow Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_1"
                },
                [2] = {
                    label = "Green Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_2"
                },
                [3] = {
                    label = "Dusk Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_3"
                },
                [4] = {
                    label = "Grayscale Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_4"
                },
                [5] = {
                    label = "Pink Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_5"
                },
                [6] = {
                    label = "Orange Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_6"
                },
                [7] = {
                    label = "Brown Urban Ski",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_7"
                },
                [8] = {
                    label = "Glass (25-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_25_8"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (26-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_0"
                },
                [1] = {
                    label = "Glass (26-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_1"
                },
                [2] = {
                    label = "Glass (26-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_2"
                },
                [3] = {
                    label = "Glass (26-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_3"
                },
                [4] = {
                    label = "Glass (26-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_4"
                },
                [5] = {
                    label = "Glass (26-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_5"
                },
                [6] = {
                    label = "Glass (26-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_6"
                },
                [7] = {
                    label = "Glass (26-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_7"
                },
                [8] = {
                    label = "Glass (26-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_8"
                },
                [9] = {
                    label = "Glass (26-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_9"
                },
                [10] = {
                    label = "Glass (26-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_10"
                },
                [11] = {
                    label = "Glass (26-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_11"
                },
                [12] = {
                    label = "Glass (26-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_12"
                },
                [13] = {
                    label = "Glass (26-13)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_13"
                },
                [14] = {
                    label = "Glass (26-14)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_14"
                },
                [15] = {
                    label = "Glass (26-15)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_15"
                },
                [16] = {
                    label = "Glass (26-16)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_16"
                },
                [17] = {
                    label = "Glass (26-17)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_17"
                },
                [18] = {
                    label = "Glass (26-18)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_18"
                },
                [19] = {
                    label = "Glass (26-19)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_19"
                },
                [20] = {
                    label = "Glass (26-20)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_20"
                },
                [21] = {
                    label = "Glass (26-21)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_21"
                },
                [22] = {
                    label = "Glass (26-22)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_22"
                },
                [23] = {
                    label = "Glass (26-23)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_23"
                },
                [24] = {
                    label = "Glass (26-24)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_24"
                },
                [25] = {
                    label = "Glass (26-25)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_25"
                },
                [26] = {
                    label = "Glass (26-26)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_26_26"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (27-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_27_0"
                },
                [1] = {
                    label = "Glass (27-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_27_1"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Dot Fade Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_0"
                },
                [1] = {
                    label = "Orange Fade Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_1"
                },
                [2] = {
                    label = "Walnut Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_2"
                },
                [3] = {
                    label = "Horizon Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_3"
                },
                [4] = {
                    label = "Purple Vine Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_4"
                },
                [5] = {
                    label = "Herringbone Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_5"
                },
                [6] = {
                    label = "Gold Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_6"
                },
                [7] = {
                    label = "Magenta Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_7"
                },
                [8] = {
                    label = "Electric Blue Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_8"
                },
                [9] = {
                    label = "Blue Argyle Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_9"
                },
                [10] = {
                    label = "Black Rim Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_10"
                },
                [11] = {
                    label = "White Rim Tint Aviators",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_11"
                },
                [12] = {
                    label = "Glass (28-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_28_12"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_0"
                },
                [1] = {
                    label = "Two Tone Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_1"
                },
                [2] = {
                    label = "White Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_2"
                },
                [3] = {
                    label = "Red Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_3"
                },
                [4] = {
                    label = "Aqua Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_4"
                },
                [5] = {
                    label = "Green Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_5"
                },
                [6] = {
                    label = "Green Urban Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_6"
                },
                [7] = {
                    label = "Pink Urban Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_7"
                },
                [8] = {
                    label = "Digital Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_8"
                },
                [9] = {
                    label = "Splinter Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_9"
                },
                [10] = {
                    label = "Zebra Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_10"
                },
                [11] = {
                    label = "Houndstooth Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_11"
                },
                [12] = {
                    label = "Mute Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_12"
                },
                [13] = {
                    label = "Sunrise Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_13"
                },
                [14] = {
                    label = "Striped Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_14"
                },
                [15] = {
                    label = "Mono Deep Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_15"
                },
                [16] = {
                    label = "Black Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_16"
                },
                [17] = {
                    label = "Red Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_17"
                },
                [18] = {
                    label = "Blue Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_18"
                },
                [19] = {
                    label = "White Fame or Shame Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_19"
                },
                [20] = {
                    label = "Glass (29-20)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_29_20"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue & Pink Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_0"
                },
                [1] = {
                    label = "Red Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_1"
                },
                [2] = {
                    label = "Orange Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_2"
                },
                [3] = {
                    label = "Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_3"
                },
                [4] = {
                    label = "Green Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_4"
                },
                [5] = {
                    label = "Blue Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_5"
                },
                [6] = {
                    label = "Pink Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_6"
                },
                [7] = {
                    label = "Blue & Magenta Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_7"
                },
                [8] = {
                    label = "Purple & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_8"
                },
                [9] = {
                    label = "Blue & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_9"
                },
                [10] = {
                    label = "Pink & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_10"
                },
                [11] = {
                    label = "Red & Yellow Glow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_11"
                },
                [12] = {
                    label = "Glass (30-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_30_12"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Midnight Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_0"
                },
                [1] = {
                    label = "Sunset Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_1"
                },
                [2] = {
                    label = "Black Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_2"
                },
                [3] = {
                    label = "Blue Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_3"
                },
                [4] = {
                    label = "Gold Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_4"
                },
                [5] = {
                    label = "Green Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_5"
                },
                [6] = {
                    label = "Orange Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_6"
                },
                [7] = {
                    label = "Red Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_7"
                },
                [8] = {
                    label = "Pink Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_8"
                },
                [9] = {
                    label = "Yellow Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_9"
                },
                [10] = {
                    label = "Lemon Tint Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_10"
                },
                [11] = {
                    label = "Gold Rimmed Oversize Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_11"
                },
                [12] = {
                    label = "Glass (31-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_31_12"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_0"
                },
                [1] = {
                    label = "Pink Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_1"
                },
                [2] = {
                    label = "Yellow Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_2"
                },
                [3] = {
                    label = "Red Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_3"
                },
                [4] = {
                    label = "White Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_4"
                },
                [5] = {
                    label = "Black Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_5"
                },
                [6] = {
                    label = "Pink Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_6"
                },
                [7] = {
                    label = "Blue Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_7"
                },
                [8] = {
                    label = "Green Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_8"
                },
                [9] = {
                    label = "Blue Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_9"
                },
                [10] = {
                    label = "Orange Checked Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_10"
                },
                [11] = {
                    label = "Green Tinted Round Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_11"
                },
                [12] = {
                    label = "Glass (32-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_32_12"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_0"
                },
                [1] = {
                    label = "Yellow Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_1"
                },
                [2] = {
                    label = "Black Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_2"
                },
                [3] = {
                    label = "Tortoiseshell Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_3"
                },
                [4] = {
                    label = "Green Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_4"
                },
                [5] = {
                    label = "Red Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_5"
                },
                [6] = {
                    label = "Pink Tinted Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_6"
                },
                [7] = {
                    label = "Blue Tinted Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_7"
                },
                [8] = {
                    label = "White Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_8"
                },
                [9] = {
                    label = "Pink Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_9"
                },
                [10] = {
                    label = "All White Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_10"
                },
                [11] = {
                    label = "Mono Square Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_11"
                },
                [12] = {
                    label = "Glass (33-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_33_12"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_0"
                },
                [1] = {
                    label = "Silver Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_1"
                },
                [2] = {
                    label = "Gold Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_2"
                },
                [3] = {
                    label = "Rose Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_3"
                },
                [4] = {
                    label = "Tortoiseshell Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_4"
                },
                [5] = {
                    label = "Gold Framed Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_5"
                },
                [6] = {
                    label = "Blue Framed Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_6"
                },
                [7] = {
                    label = "Tortoiseshell & Silver Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_7"
                },
                [8] = {
                    label = "Tortoiseshell & Gold Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_8"
                },
                [9] = {
                    label = "Gray Tortoiseshell Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_9"
                },
                [10] = {
                    label = "Gold Swirl Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_10"
                },
                [11] = {
                    label = "Gold Fade Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_11"
                },
                [12] = {
                    label = "Glass (34-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_34_12"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_0"
                },
                [1] = {
                    label = "Silver Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_1"
                },
                [2] = {
                    label = "Gold Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_2"
                },
                [3] = {
                    label = "Rose Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_3"
                },
                [4] = {
                    label = "Black & Red Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_4"
                },
                [5] = {
                    label = "Black & Brown Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_5"
                },
                [6] = {
                    label = "Black & Blue Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_6"
                },
                [7] = {
                    label = "Tortoiseshell & Brown Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_7"
                },
                [8] = {
                    label = "Gold & Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_8"
                },
                [9] = {
                    label = "Gray Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_9"
                },
                [10] = {
                    label = "Tortoiseshell Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_10"
                },
                [11] = {
                    label = "Pink & Black Square",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_11"
                },
                [12] = {
                    label = "Glass (35-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_35_12"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_0"
                },
                [1] = {
                    label = "Silver Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_1"
                },
                [2] = {
                    label = "Gold Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_2"
                },
                [3] = {
                    label = "Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_3"
                },
                [4] = {
                    label = "Black & Green Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_4"
                },
                [5] = {
                    label = "Dark Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_5"
                },
                [6] = {
                    label = "Black & Teal Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_6"
                },
                [7] = {
                    label = "Black & Red Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_7"
                },
                [8] = {
                    label = "Gold & Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_8"
                },
                [9] = {
                    label = "Navy Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_9"
                },
                [10] = {
                    label = "Pink & Black Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_10"
                },
                [11] = {
                    label = "Gold Tortoiseshell Cat Eye",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_11"
                },
                [12] = {
                    label = "Glass (36-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_36_12"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_0"
                },
                [1] = {
                    label = "Silver Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_1"
                },
                [2] = {
                    label = "Gold Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_2"
                },
                [3] = {
                    label = "Light Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_3"
                },
                [4] = {
                    label = "Claret Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_4"
                },
                [5] = {
                    label = "Blue Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_5"
                },
                [6] = {
                    label = "Gray & Red Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_6"
                },
                [7] = {
                    label = "Teal Fade Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_7"
                },
                [8] = {
                    label = "Yellow Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_8"
                },
                [9] = {
                    label = "Green Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_9"
                },
                [10] = {
                    label = "Red Fade Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_10"
                },
                [11] = {
                    label = "Dark Tortoiseshell Rectangular",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_11"
                },
                [12] = {
                    label = "Glass (37-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_37_12"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_0"
                },
                [1] = {
                    label = "Silver Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_1"
                },
                [2] = {
                    label = "Gold Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_2"
                },
                [3] = {
                    label = "Tortoiseshell Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_3"
                },
                [4] = {
                    label = "Green Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_4"
                },
                [5] = {
                    label = "Dark Tortoiseshell Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_5"
                },
                [6] = {
                    label = "Teal Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_6"
                },
                [7] = {
                    label = "Red Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_7"
                },
                [8] = {
                    label = "Gold & Black Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_8"
                },
                [9] = {
                    label = "Blue Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_9"
                },
                [10] = {
                    label = "Pink Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_10"
                },
                [11] = {
                    label = "Tiger Ergonomic",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_11"
                },
                [12] = {
                    label = "Glass (38-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_38_12"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_0"
                },
                [1] = {
                    label = "Silver Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_1"
                },
                [2] = {
                    label = "Gold Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_2"
                },
                [3] = {
                    label = "Rose Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_3"
                },
                [4] = {
                    label = "Black & Pink Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_4"
                },
                [5] = {
                    label = "Black & Brown Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_5"
                },
                [6] = {
                    label = "Black & Navy Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_6"
                },
                [7] = {
                    label = "Tortoiseshell Rim Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_7"
                },
                [8] = {
                    label = "Gold & Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_8"
                },
                [9] = {
                    label = "Black Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_9"
                },
                [10] = {
                    label = "Tortoiseshell Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_10"
                },
                [11] = {
                    label = "Gold & Black Retro Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_11"
                },
                [12] = {
                    label = "Glass (39-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_39_12"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (40-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_0"
                },
                [1] = {
                    label = "Glass (40-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_1"
                },
                [2] = {
                    label = "Glass (40-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_2"
                },
                [3] = {
                    label = "Glass (40-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_3"
                },
                [4] = {
                    label = "Glass (40-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_4"
                },
                [5] = {
                    label = "Glass (40-5)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_5"
                },
                [6] = {
                    label = "Glass (40-6)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_6"
                },
                [7] = {
                    label = "Glass (40-7)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_7"
                },
                [8] = {
                    label = "Glass (40-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_8"
                },
                [9] = {
                    label = "Glass (40-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_9"
                },
                [10] = {
                    label = "Glass (40-10)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_10"
                },
                [11] = {
                    label = "Glass (40-11)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_11"
                },
                [12] = {
                    label = "Glass (40-12)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_12"
                },
                [13] = {
                    label = "Glass (40-13)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_13"
                },
                [14] = {
                    label = "Glass (40-14)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_14"
                },
                [15] = {
                    label = "Glass (40-15)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_15"
                },
                [16] = {
                    label = "Glass (40-16)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_16"
                },
                [17] = {
                    label = "Glass (40-17)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_17"
                },
                [18] = {
                    label = "Glass (40-18)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_18"
                },
                [19] = {
                    label = "Glass (40-19)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_19"
                },
                [20] = {
                    label = "Glass (40-20)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_40_20"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Mono Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_0"
                },
                [1] = {
                    label = "Gray Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_1"
                },
                [2] = {
                    label = "Ash Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_2"
                },
                [3] = {
                    label = "White Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_3"
                },
                [4] = {
                    label = "Red Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_4"
                },
                [5] = {
                    label = "Navy Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_5"
                },
                [6] = {
                    label = "Green Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_6"
                },
                [7] = {
                    label = "Moss Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_7"
                },
                [8] = {
                    label = "Olive Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_8"
                },
                [9] = {
                    label = "Dark Tan Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_9"
                },
                [10] = {
                    label = "Desert Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_10"
                },
                [11] = {
                    label = "Tan Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_11"
                },
                [12] = {
                    label = "Light Woodland Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_12"
                },
                [13] = {
                    label = "Flecktarn Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_13"
                },
                [14] = {
                    label = "Peach Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_14"
                },
                [15] = {
                    label = "Contrast Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_15"
                },
                [16] = {
                    label = "Aqua Camo Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_16"
                },
                [17] = {
                    label = "Olive Digital Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_17"
                },
                [18] = {
                    label = "Brown Digital Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_18"
                },
                [19] = {
                    label = "Fall Tactical Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_19"
                },
                [20] = {
                    label = "Glass (41-20)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_41_20"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_0"
                },
                [1] = {
                    label = "White Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_1"
                },
                [2] = {
                    label = "Magenta Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_2"
                },
                [3] = {
                    label = "Red Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_3"
                },
                [4] = {
                    label = "Orange Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_4"
                },
                [5] = {
                    label = "Mustard Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_5"
                },
                [6] = {
                    label = "Lemon Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_6"
                },
                [7] = {
                    label = "Blue Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_7"
                },
                [8] = {
                    label = "Cyan Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_8"
                },
                [9] = {
                    label = "Green Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_9"
                },
                [10] = {
                    label = "Lime Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_10"
                },
                [11] = {
                    label = "Lavender Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_11"
                },
                [12] = {
                    label = "Purple Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_12"
                },
                [13] = {
                    label = "Tortoiseshell Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_13"
                },
                [14] = {
                    label = "Orange Tint Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_14"
                },
                [15] = {
                    label = "Blue Tint Cat Eye Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_15"
                },
                [16] = {
                    label = "Glass (42-16)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_42_16"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Manor Round Brow Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_43_0"
                },
                [1] = {
                    label = "Glass (43-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_43_1"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_44_0"
                },
                [1] = {
                    label = "Silver New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_44_1"
                },
                [2] = {
                    label = "Rainbow New Year Glasses",
                    price = 500,
                    type = "money",
                    image = "male_glasses_44_2"
                },
                [3] = {
                    label = "Glass (44-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_44_3"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_0"
                },
                [1] = {
                    label = "Purple Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_1"
                },
                [2] = {
                    label = "White Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_2"
                },
                [3] = {
                    label = "Zebra Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_3"
                },
                [4] = {
                    label = "Pink Zebra Bigness Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_4"
                },
                [5] = {
                    label = "Blue DS Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_5"
                },
                [6] = {
                    label = "Green Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_6"
                },
                [7] = {
                    label = "Orange Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_7"
                },
                [8] = {
                    label = "Pink Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_8"
                },
                [9] = {
                    label = "Purple Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_9"
                },
                [10] = {
                    label = "Red Flames Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_10"
                },
                [11] = {
                    label = "Magenta Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_11"
                },
                [12] = {
                    label = "Cyan Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_12"
                },
                [13] = {
                    label = "Moss Leopard Güffy Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_13"
                },
                [14] = {
                    label = "Blue Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_14"
                },
                [15] = {
                    label = "White Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_15"
                },
                [16] = {
                    label = "Green Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_16"
                },
                [17] = {
                    label = "Orange Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_17"
                },
                [18] = {
                    label = "Purple Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_18"
                },
                [19] = {
                    label = "Pink Lightning Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_19"
                },
                [20] = {
                    label = "Gray Camo Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_20"
                },
                [21] = {
                    label = "Aqua Camo Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_21"
                },
                [22] = {
                    label = "Gray Dazzle Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_22"
                },
                [23] = {
                    label = "Aqua Dazzle Sand Castle Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_23"
                },
                [24] = {
                    label = "Black SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_24"
                },
                [25] = {
                    label = "Blue SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_25"
                },
                [26] = {
                    label = "Glass (45-26)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_45_26"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Lime SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_46_0"
                },
                [1] = {
                    label = "Pink SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_46_1"
                },
                [2] = {
                    label = "Red SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_46_2"
                },
                [3] = {
                    label = "White SC Coin Wraps",
                    price = 500,
                    type = "money",
                    image = "male_glasses_46_3"
                },
                [4] = {
                    label = "Glass (46-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_46_4"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_0"
                },
                [1] = {
                    label = "Pink Bigness Zebra Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_1"
                },
                [2] = {
                    label = "Green Flames Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_2"
                },
                [3] = {
                    label = "Orange Flames Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_3"
                },
                [4] = {
                    label = "Pink Flames Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_4"
                },
                [5] = {
                    label = "Purple Flames Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_5"
                },
                [6] = {
                    label = "Red Flames Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_6"
                },
                [7] = {
                    label = "Black Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_7"
                },
                [8] = {
                    label = "Teal Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_8"
                },
                [9] = {
                    label = "Red Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_9"
                },
                [10] = {
                    label = "White Le Chien Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_10"
                },
                [11] = {
                    label = "Blue Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_11"
                },
                [12] = {
                    label = "Gray Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_12"
                },
                [13] = {
                    label = "Green Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_13"
                },
                [14] = {
                    label = "Orange Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_14"
                },
                [15] = {
                    label = "Purple Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_15"
                },
                [16] = {
                    label = "Red Lightning Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_16"
                },
                [17] = {
                    label = "White Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_17"
                },
                [18] = {
                    label = "Blue Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_18"
                },
                [19] = {
                    label = "Lemon Leopard Slab Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_19"
                },
                [20] = {
                    label = "Tortoiseshell Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_20"
                },
                [21] = {
                    label = "Orange Marble Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_21"
                },
                [22] = {
                    label = "Dark Tortoiseshell Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_22"
                },
                [23] = {
                    label = "Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_23"
                },
                [24] = {
                    label = "Gray Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_24"
                },
                [25] = {
                    label = "Pink Camo Yeti Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_25"
                },
                [26] = {
                    label = "Glass (47-26)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_47_26"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_0"
                },
                [1] = {
                    label = "White Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_1"
                },
                [2] = {
                    label = "Hot Pink Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_2"
                },
                [3] = {
                    label = "Scarlet Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_3"
                },
                [4] = {
                    label = "Orange Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_4"
                },
                [5] = {
                    label = "Amber Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_5"
                },
                [6] = {
                    label = "Lemon Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_6"
                },
                [7] = {
                    label = "Blue Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_7"
                },
                [8] = {
                    label = "Cyan Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_8"
                },
                [9] = {
                    label = "Emerald Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_9"
                },
                [10] = {
                    label = "Lime Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_10"
                },
                [11] = {
                    label = "Lavender Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_11"
                },
                [12] = {
                    label = "Magenta Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_12"
                },
                [13] = {
                    label = "Tortoiseshell Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_13"
                },
                [14] = {
                    label = "Dark Tortoiseshell Feline Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_14"
                },
                [15] = {
                    label = "Glass (48-15)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_48_15"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (49-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_49_0"
                },
                [1] = {
                    label = "Glass (49-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (50-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_50_0"
                },
                [1] = {
                    label = "Glass (50-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_50_1"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_0"
                },
                [1] = {
                    label = "Dark Silver/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_1"
                },
                [2] = {
                    label = "Gold/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_2"
                },
                [3] = {
                    label = "Rose Gold/Black Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_3"
                },
                [4] = {
                    label = "Copper/Green Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_4"
                },
                [5] = {
                    label = "Gold/Orange Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_5"
                },
                [6] = {
                    label = "Gold/Blue Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_6"
                },
                [7] = {
                    label = "Gold/Green Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_7"
                },
                [8] = {
                    label = "Rose Gold/Pink Octagonal",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_8"
                },
                [9] = {
                    label = "Glass (51-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_51_9"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Junk Energy Goggles",
                    price = 500,
                    type = "money",
                    image = "male_glasses_52_0"
                },
                [1] = {
                    label = "Glass (52-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_0"
                },
                [1] = {
                    label = "Red Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_1"
                },
                [2] = {
                    label = "Orange Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_2"
                },
                [3] = {
                    label = "Yellow Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_3"
                },
                [4] = {
                    label = "Green Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_4"
                },
                [5] = {
                    label = "Blue Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_5"
                },
                [6] = {
                    label = "Purple Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_6"
                },
                [7] = {
                    label = "Black Heart Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_7"
                },
                [8] = {
                    label = "Glass (53-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_53_8"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Retro Aviator Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_54_0"
                },
                [1] = {
                    label = "Shell Retro Aviator Shades",
                    price = 500,
                    type = "money",
                    image = "male_glasses_54_1"
                },
                [2] = {
                    label = "Glass (54-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_54_2"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (55-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_55_0"
                },
                [1] = {
                    label = "Glass (55-1)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_55_1"
                },
                [2] = {
                    label = "Glass (55-2)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_55_2"
                },
                [3] = {
                    label = "Glass (55-3)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_55_3"
                },
                [4] = {
                    label = "Glass (55-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_55_4"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold & Black Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_0"
                },
                [1] = {
                    label = "Brown & Gold Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_1"
                },
                [2] = {
                    label = "Gold & Red Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_2"
                },
                [3] = {
                    label = "Silver & Black Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_3"
                },
                [4] = {
                    label = "Silver & Pink Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_4"
                },
                [5] = {
                    label = "Silver & Aqua Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_5"
                },
                [6] = {
                    label = "Dark Silver & Black Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_6"
                },
                [7] = {
                    label = "Black & Indigo Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_7"
                },
                [8] = {
                    label = "Dark Silver & Green Round",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_8"
                },
                [9] = {
                    label = "Glass (56-9)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_56_9"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_0"
                },
                [1] = {
                    label = "Black & Amber Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_1"
                },
                [2] = {
                    label = "Black & Yellow Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_2"
                },
                [3] = {
                    label = "White & Gray Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_3"
                },
                [4] = {
                    label = "White & Amber Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_4"
                },
                [5] = {
                    label = "White & Yellow Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_5"
                },
                [6] = {
                    label = "Black Tortoiseshell Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_6"
                },
                [7] = {
                    label = "Amber Tortoiseshell Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_7"
                },
                [8] = {
                    label = "Glass (57-8)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_57_8"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Sunrise Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_58_0"
                },
                [1] = {
                    label = "Black Twilight Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_58_1"
                },
                [2] = {
                    label = "White Sunrise Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_58_2"
                },
                [3] = {
                    label = "White Twilight Shields",
                    price = 500,
                    type = "money",
                    image = "male_glasses_58_3"
                },
                [4] = {
                    label = "Glass (58-4)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_58_4"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glass (59-0)",
                    price = 500,
                    type = "money",
                    image = "male_glasses_59_0"
                },
            },
        },
    },
}
