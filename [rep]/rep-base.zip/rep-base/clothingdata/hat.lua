hat = {
    female = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_0"
                },
                [1] = {
                    label = "Hat (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_1"
                },
                [2] = {
                    label = "Hat (0-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_2"
                },
                [3] = {
                    label = "Hat (0-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_3"
                },
                [4] = {
                    label = "Hat (0-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_4"
                },
                [5] = {
                    label = "Hat (0-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_5"
                },
                [6] = {
                    label = "Hat (0-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_6"
                },
                [7] = {
                    label = "Hat (0-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_7"
                },
                [8] = {
                    label = "Hat (0-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_0_8"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_1_0"
                },
                [1] = {
                    label = "Hat (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_0"
                },
                [1] = {
                    label = "Hat (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_1"
                },
                [2] = {
                    label = "Hat (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_2"
                },
                [3] = {
                    label = "Hat (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_3"
                },
                [4] = {
                    label = "Hat (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_4"
                },
                [5] = {
                    label = "Hat (2-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_5"
                },
                [6] = {
                    label = "Hat (2-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_6"
                },
                [7] = {
                    label = "Hat (2-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_7"
                },
                [8] = {
                    label = "Hat (2-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_2_8"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_0"
                },
                [1] = {
                    label = "Hat (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_1"
                },
                [2] = {
                    label = "Hat (3-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_2"
                },
                [3] = {
                    label = "Hat (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_3"
                },
                [4] = {
                    label = "Hat (3-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_4"
                },
                [5] = {
                    label = "Hat (3-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_5"
                },
                [6] = {
                    label = "Hat (3-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_6"
                },
                [7] = {
                    label = "Hat (3-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_7"
                },
                [8] = {
                    label = "Hat (3-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_3_8"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_0"
                },
                [1] = {
                    label = "Hat (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_1"
                },
                [2] = {
                    label = "Hat (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_2"
                },
                [3] = {
                    label = "Hat (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_3"
                },
                [4] = {
                    label = "Hat (4-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_4"
                },
                [5] = {
                    label = "Hat (4-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_5"
                },
                [6] = {
                    label = "Hat (4-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_6"
                },
                [7] = {
                    label = "Hat (4-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_7"
                },
                [8] = {
                    label = "Hat (4-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_4_8"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_0"
                },
                [1] = {
                    label = "Hat (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_1"
                },
                [2] = {
                    label = "Hat (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_2"
                },
                [3] = {
                    label = "Hat (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_3"
                },
                [4] = {
                    label = "Hat (5-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_4"
                },
                [5] = {
                    label = "Hat (5-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_5"
                },
                [6] = {
                    label = "Hat (5-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_6"
                },
                [7] = {
                    label = "Hat (5-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_7"
                },
                [8] = {
                    label = "Hat (5-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_5_8"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_0"
                },
                [1] = {
                    label = "Hat (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_1"
                },
                [2] = {
                    label = "Hat (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_2"
                },
                [3] = {
                    label = "Hat (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_3"
                },
                [4] = {
                    label = "Hat (6-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_4"
                },
                [5] = {
                    label = "Hat (6-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_5"
                },
                [6] = {
                    label = "Hat (6-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_6"
                },
                [7] = {
                    label = "Hat (6-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_7"
                },
                [8] = {
                    label = "Hat (6-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_6_8"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_0"
                },
                [1] = {
                    label = "Hat (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_1"
                },
                [2] = {
                    label = "Hat (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_2"
                },
                [3] = {
                    label = "Hat (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_3"
                },
                [4] = {
                    label = "Hat (7-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_4"
                },
                [5] = {
                    label = "Hat (7-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_5"
                },
                [6] = {
                    label = "Hat (7-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_6"
                },
                [7] = {
                    label = "Hat (7-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_7"
                },
                [8] = {
                    label = "Hat (7-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_7_8"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (8-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_0"
                },
                [1] = {
                    label = "Hat (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_1"
                },
                [2] = {
                    label = "Hat (8-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_2"
                },
                [3] = {
                    label = "Hat (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_3"
                },
                [4] = {
                    label = "Hat (8-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_4"
                },
                [5] = {
                    label = "Hat (8-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_5"
                },
                [6] = {
                    label = "Hat (8-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_6"
                },
                [7] = {
                    label = "Hat (8-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_7"
                },
                [8] = {
                    label = "Hat (8-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_8_8"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (9-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_0"
                },
                [1] = {
                    label = "Hat (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_1"
                },
                [2] = {
                    label = "Hat (9-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_2"
                },
                [3] = {
                    label = "Hat (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_3"
                },
                [4] = {
                    label = "Hat (9-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_4"
                },
                [5] = {
                    label = "Hat (9-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_5"
                },
                [6] = {
                    label = "Hat (9-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_6"
                },
                [7] = {
                    label = "Hat (9-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_7"
                },
                [8] = {
                    label = "Hat (9-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_9_8"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (10-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_0"
                },
                [1] = {
                    label = "Hat (10-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_1"
                },
                [2] = {
                    label = "Hat (10-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_2"
                },
                [3] = {
                    label = "Hat (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_3"
                },
                [4] = {
                    label = "Hat (10-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_4"
                },
                [5] = {
                    label = "Hat (10-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_5"
                },
                [6] = {
                    label = "Hat (10-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_6"
                },
                [7] = {
                    label = "Hat (10-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_7"
                },
                [8] = {
                    label = "Hat (10-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_10_8"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (11-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_0"
                },
                [1] = {
                    label = "Hat (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_1"
                },
                [2] = {
                    label = "Hat (11-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_2"
                },
                [3] = {
                    label = "Hat (11-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_3"
                },
                [4] = {
                    label = "Hat (11-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_4"
                },
                [5] = {
                    label = "Hat (11-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_5"
                },
                [6] = {
                    label = "Hat (11-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_6"
                },
                [7] = {
                    label = "Hat (11-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_7"
                },
                [8] = {
                    label = "Hat (11-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_11_8"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (12-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_0"
                },
                [1] = {
                    label = "Hat (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_1"
                },
                [2] = {
                    label = "Hat (12-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_2"
                },
                [3] = {
                    label = "Hat (12-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_3"
                },
                [4] = {
                    label = "Hat (12-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_4"
                },
                [5] = {
                    label = "Hat (12-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_5"
                },
                [6] = {
                    label = "Hat (12-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_6"
                },
                [7] = {
                    label = "Hat (12-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_7"
                },
                [8] = {
                    label = "Hat (12-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_12_8"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (13-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_0"
                },
                [1] = {
                    label = "Hat (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_1"
                },
                [2] = {
                    label = "Hat (13-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_2"
                },
                [3] = {
                    label = "Hat (13-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_3"
                },
                [4] = {
                    label = "Hat (13-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_4"
                },
                [5] = {
                    label = "Hat (13-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_5"
                },
                [6] = {
                    label = "Hat (13-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_6"
                },
                [7] = {
                    label = "Hat (13-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_7"
                },
                [8] = {
                    label = "Hat (13-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_13_8"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (14-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_0"
                },
                [1] = {
                    label = "Hat (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_1"
                },
                [2] = {
                    label = "Hat (14-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_2"
                },
                [3] = {
                    label = "Hat (14-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_3"
                },
                [4] = {
                    label = "Hat (14-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_4"
                },
                [5] = {
                    label = "Hat (14-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_5"
                },
                [6] = {
                    label = "Hat (14-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_6"
                },
                [7] = {
                    label = "Hat (14-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_7"
                },
                [8] = {
                    label = "Hat (14-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_14_8"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (15-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_0"
                },
                [1] = {
                    label = "Hat (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_1"
                },
                [2] = {
                    label = "Hat (15-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_2"
                },
                [3] = {
                    label = "Hat (15-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_3"
                },
                [4] = {
                    label = "Hat (15-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_4"
                },
                [5] = {
                    label = "Hat (15-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_5"
                },
                [6] = {
                    label = "Hat (15-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_6"
                },
                [7] = {
                    label = "Hat (15-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_7"
                },
                [8] = {
                    label = "Hat (15-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_15_8"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (16-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_0"
                },
                [1] = {
                    label = "Hat (16-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_1"
                },
                [2] = {
                    label = "Hat (16-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_2"
                },
                [3] = {
                    label = "Hat (16-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_3"
                },
                [4] = {
                    label = "Hat (16-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_4"
                },
                [5] = {
                    label = "Hat (16-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_5"
                },
                [6] = {
                    label = "Hat (16-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_6"
                },
                [7] = {
                    label = "Hat (16-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_7"
                },
                [8] = {
                    label = "Hat (16-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_16_8"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (17-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_0"
                },
                [1] = {
                    label = "Hat (17-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_1"
                },
                [2] = {
                    label = "Hat (17-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_2"
                },
                [3] = {
                    label = "Hat (17-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_3"
                },
                [4] = {
                    label = "Hat (17-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_4"
                },
                [5] = {
                    label = "Hat (17-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_5"
                },
                [6] = {
                    label = "Hat (17-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_6"
                },
                [7] = {
                    label = "Hat (17-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_7"
                },
                [8] = {
                    label = "Hat (17-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_17_8"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (18-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_0"
                },
                [1] = {
                    label = "Hat (18-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_1"
                },
                [2] = {
                    label = "Hat (18-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_2"
                },
                [3] = {
                    label = "Hat (18-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_3"
                },
                [4] = {
                    label = "Hat (18-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_4"
                },
                [5] = {
                    label = "Hat (18-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_5"
                },
                [6] = {
                    label = "Hat (18-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_6"
                },
                [7] = {
                    label = "Hat (18-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_7"
                },
                [8] = {
                    label = "Hat (18-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_18_8"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (19-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_19_0"
                },
                [1] = {
                    label = "Hat (19-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_19_1"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_0"
                },
                [1] = {
                    label = "Two-Tone Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_1"
                },
                [2] = {
                    label = "Farshtunken Black Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_2"
                },
                [3] = {
                    label = "MyMy Pink Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_3"
                },
                [4] = {
                    label = "Red Striped Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_4"
                },
                [5] = {
                    label = "Logger Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_5"
                },
                [6] = {
                    label = "Striped Cowgirl Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_6"
                },
                [7] = {
                    label = "Hat (20-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_20_7"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "CaCa Pink Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_0"
                },
                [1] = {
                    label = "Crevis Blue Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_1"
                },
                [2] = {
                    label = "Tan Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_2"
                },
                [3] = {
                    label = "Red Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_3"
                },
                [4] = {
                    label = "Hawaiian Snow Yellow Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_4"
                },
                [5] = {
                    label = "Hawaiian Snow Blue Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_5"
                },
                [6] = {
                    label = "Hawaiian Snow Spotted Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_6"
                },
                [7] = {
                    label = "Hat (21-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_21_7"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Beige Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_0"
                },
                [1] = {
                    label = "Cream Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_1"
                },
                [2] = {
                    label = "Navy Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_2"
                },
                [3] = {
                    label = "Two-Tone Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_3"
                },
                [4] = {
                    label = "Dark Brown Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_4"
                },
                [5] = {
                    label = "MyMy Passion Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_5"
                },
                [6] = {
                    label = "MyMy Wild Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_6"
                },
                [7] = {
                    label = "Hat (22-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_22_7"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Santa Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_23_0"
                },
                [1] = {
                    label = "Green Santa Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_23_1"
                },
                [2] = {
                    label = "Hat (23-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_23_2"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Elf Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_24_0"
                },
                [1] = {
                    label = "Hat (24-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_24_1"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Reindeer Antlers",
                    price = 500,
                    type = "money",
                    image = "female_hat_25_0"
                },
                [1] = {
                    label = "Hat (25-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_25_1"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_0"
                },
                [1] = {
                    label = "Gray Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_1"
                },
                [2] = {
                    label = "Blue Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_2"
                },
                [3] = {
                    label = "Light Gray Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_3"
                },
                [4] = {
                    label = "Olive Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_4"
                },
                [5] = {
                    label = "Purple Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_5"
                },
                [6] = {
                    label = "Lobster Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_6"
                },
                [7] = {
                    label = "Brown Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_7"
                },
                [8] = {
                    label = "Vintage Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_8"
                },
                [9] = {
                    label = "Cream Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_9"
                },
                [10] = {
                    label = "Ash Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_10"
                },
                [11] = {
                    label = "Navy Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_11"
                },
                [12] = {
                    label = "Silver Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_12"
                },
                [13] = {
                    label = "White Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_13"
                },
                [14] = {
                    label = "Hat (26-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_26_14"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_0"
                },
                [1] = {
                    label = "Gray Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_1"
                },
                [2] = {
                    label = "Blue Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_2"
                },
                [3] = {
                    label = "Light Gray Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_3"
                },
                [4] = {
                    label = "Olive Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_4"
                },
                [5] = {
                    label = "Purple Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_5"
                },
                [6] = {
                    label = "Lobster Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_6"
                },
                [7] = {
                    label = "Brown Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_7"
                },
                [8] = {
                    label = "Vintage Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_8"
                },
                [9] = {
                    label = "Cream Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_9"
                },
                [10] = {
                    label = "Ash Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_10"
                },
                [11] = {
                    label = "Navy Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_11"
                },
                [12] = {
                    label = "Silver Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_12"
                },
                [13] = {
                    label = "White Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_13"
                },
                [14] = {
                    label = "Hat (27-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_27_14"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_0"
                },
                [1] = {
                    label = "Cream Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_1"
                },
                [2] = {
                    label = "White Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_2"
                },
                [3] = {
                    label = "Black Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_3"
                },
                [4] = {
                    label = "Gray Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_4"
                },
                [5] = {
                    label = "Red Plaid Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_5"
                },
                [6] = {
                    label = "Brown Plaid Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_6"
                },
                [7] = {
                    label = "Pink Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_7"
                },
                [8] = {
                    label = "Hat (28-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_28_8"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_0"
                },
                [1] = {
                    label = "White Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_1"
                },
                [2] = {
                    label = "Fuchsia Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_2"
                },
                [3] = {
                    label = "Red Striped Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_3"
                },
                [4] = {
                    label = "Gray Striped Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_4"
                },
                [5] = {
                    label = "Hat (29-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_29_5"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_30_0"
                },
                [1] = {
                    label = "Hat (30-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_30_1"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Top Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_31_0"
                },
                [1] = {
                    label = "Hat (31-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_31_1"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Top Foam Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_32_0"
                },
                [1] = {
                    label = "Blue Top Foam Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_32_1"
                },
                [2] = {
                    label = "Hat (32-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_32_2"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Patriotic Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_33_0"
                },
                [1] = {
                    label = "Hat (33-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_33_1"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Crown",
                    price = 500,
                    type = "money",
                    image = "female_hat_34_0"
                },
                [1] = {
                    label = "Hat (34-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_34_1"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Boppers",
                    price = 500,
                    type = "money",
                    image = "female_hat_35_0"
                },
                [1] = {
                    label = "Hat (35-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_35_1"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pisswasser Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_0"
                },
                [1] = {
                    label = "Benedict Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_1"
                },
                [2] = {
                    label = "J Lager Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_2"
                },
                [3] = {
                    label = "Patriot Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_3"
                },
                [4] = {
                    label = "Blarneys Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_4"
                },
                [5] = {
                    label = "Supa Wet Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_5"
                },
                [6] = {
                    label = "Hat (36-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_36_6"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_37_0"
                },
                [1] = {
                    label = "Hat (37-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_37_1"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bulletproof",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_0"
                },
                [1] = {
                    label = "Gray Bulletproof",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_1"
                },
                [2] = {
                    label = "Charcoal Bulletproof",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_2"
                },
                [3] = {
                    label = "Tan Bulletproof",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_3"
                },
                [4] = {
                    label = "Forest Bulletproof",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_4"
                },
                [5] = {
                    label = "Hat (38-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_38_5"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Classic Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_0"
                },
                [1] = {
                    label = "Purple Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_1"
                },
                [2] = {
                    label = "Holly Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_2"
                },
                [3] = {
                    label = "Red Stripy Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_3"
                },
                [4] = {
                    label = "Green Stripy Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_4"
                },
                [5] = {
                    label = "Star Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_5"
                },
                [6] = {
                    label = "Santa Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_6"
                },
                [7] = {
                    label = "Elf Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_7"
                },
                [8] = {
                    label = "Hat (39-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_39_8"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pudding Woolly Knit",
                    price = 500,
                    type = "money",
                    image = "female_hat_40_0"
                },
                [1] = {
                    label = "Hat (40-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_40_1"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cheeky Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "female_hat_41_0"
                },
                [1] = {
                    label = "Naughty Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "female_hat_41_1"
                },
                [2] = {
                    label = "Happy Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "female_hat_41_2"
                },
                [3] = {
                    label = "Silly Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "female_hat_41_3"
                },
                [4] = {
                    label = "Hat (41-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_41_4"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Clan Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "female_hat_42_0"
                },
                [1] = {
                    label = "Highland Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "female_hat_42_1"
                },
                [2] = {
                    label = "Chieftain Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "female_hat_42_2"
                },
                [3] = {
                    label = "Heritage Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "female_hat_42_3"
                },
                [4] = {
                    label = "Hat (42-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_42_4"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Naughty Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_0"
                },
                [1] = {
                    label = "Black Ho Ho Ho Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_1"
                },
                [2] = {
                    label = "Blue Snowflake Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_2"
                },
                [3] = {
                    label = "Nice Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_3"
                },
                [4] = {
                    label = "Green Ho Ho Ho Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_4"
                },
                [5] = {
                    label = "Red Snowflake Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_5"
                },
                [6] = {
                    label = "Gingerbread Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_6"
                },
                [7] = {
                    label = "Bah Humbug Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_7"
                },
                [8] = {
                    label = "Hat (43-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_43_8"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Naughty Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_0"
                },
                [1] = {
                    label = "Black Ho Ho Ho Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_1"
                },
                [2] = {
                    label = "Blue Snowflake Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_2"
                },
                [3] = {
                    label = "Nice Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_3"
                },
                [4] = {
                    label = "Green Ho Ho Ho Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_4"
                },
                [5] = {
                    label = "Red Snowflake Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_5"
                },
                [6] = {
                    label = "Gingerbread Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_6"
                },
                [7] = {
                    label = "Bah Humbug Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_7"
                },
                [8] = {
                    label = "Hat (44-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_44_8"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (45-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_45_0"
                },
                [1] = {
                    label = "Hat (45-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_45_1"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_46_0"
                },
                [1] = {
                    label = "Hat (46-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_46_1"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Black Off-road",
                    price = 500,
                    type = "money",
                    image = "female_hat_47_0"
                },
                [1] = {
                    label = "Hat (47-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_47_1"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Black Off-road",
                    price = 500,
                    type = "money",
                    image = "female_hat_48_0"
                },
                [1] = {
                    label = "Hat (48-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_48_1"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy All Black Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_49_0"
                },
                [1] = {
                    label = "Hat (49-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_50_0"
                },
                [1] = {
                    label = "Hat (50-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_50_1"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte All Black Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_51_0"
                },
                [1] = {
                    label = "Hat (51-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_51_1"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_52_0"
                },
                [1] = {
                    label = "Hat (52-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (53-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_53_0"
                },
                [1] = {
                    label = "Hat (53-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_53_1"
                },
                [2] = {
                    label = "Hat (53-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_53_2"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_0"
                },
                [1] = {
                    label = "Light Gray Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_1"
                },
                [2] = {
                    label = "Brown Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_2"
                },
                [3] = {
                    label = "Red Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_3"
                },
                [4] = {
                    label = "Gray Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_4"
                },
                [5] = {
                    label = "Navy Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_5"
                },
                [6] = {
                    label = "Green Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_6"
                },
                [7] = {
                    label = "White Cashmere Fedora",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_7"
                },
                [8] = {
                    label = "Hat (54-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_54_8"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_0"
                },
                [1] = {
                    label = "Charcoal Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_1"
                },
                [2] = {
                    label = "Cream Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_2"
                },
                [3] = {
                    label = "Navy Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_3"
                },
                [4] = {
                    label = "Brown Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_4"
                },
                [5] = {
                    label = "Brown Harsh Souls Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_5"
                },
                [6] = {
                    label = "Orange Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_6"
                },
                [7] = {
                    label = "Blue Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_7"
                },
                [8] = {
                    label = "Stripy Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_8"
                },
                [9] = {
                    label = "Link Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_9"
                },
                [10] = {
                    label = "Diamond Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_10"
                },
                [11] = {
                    label = "Cherry Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_11"
                },
                [12] = {
                    label = "Tan Fruntalot Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_12"
                },
                [13] = {
                    label = "Green Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_13"
                },
                [14] = {
                    label = "Jungle Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_14"
                },
                [15] = {
                    label = "Forest Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_15"
                },
                [16] = {
                    label = "Coffee Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_16"
                },
                [17] = {
                    label = "Dual Trey Baker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_17"
                },
                [18] = {
                    label = "Gray Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_18"
                },
                [19] = {
                    label = "Cream Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_19"
                },
                [20] = {
                    label = "Red Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_20"
                },
                [21] = {
                    label = "White Harsh Souls Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_21"
                },
                [22] = {
                    label = "Navy Fruntalot Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_22"
                },
                [23] = {
                    label = "Yellow Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_23"
                },
                [24] = {
                    label = "All Black Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_24"
                },
                [25] = {
                    label = "Black Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_25"
                },
                [26] = {
                    label = "Hat (55-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_55_26"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Magnetics Script Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_0"
                },
                [1] = {
                    label = "Magnetics Block Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_1"
                },
                [2] = {
                    label = "Low Santos Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_2"
                },
                [3] = {
                    label = "Boars Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_3"
                },
                [4] = {
                    label = "Benny's Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_4"
                },
                [5] = {
                    label = "Westside Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_5"
                },
                [6] = {
                    label = "Eastside Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_6"
                },
                [7] = {
                    label = "Strawberry Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_7"
                },
                [8] = {
                    label = "Black SA Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_8"
                },
                [9] = {
                    label = "Davis Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_9"
                },
                [10] = {
                    label = "Hat (56-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_56_10"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (57-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_57_0"
                },
                [1] = {
                    label = "Hat (57-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_57_1"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_58_0"
                },
                [1] = {
                    label = "Khaki Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_58_1"
                },
                [2] = {
                    label = "Black Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_58_2"
                },
                [3] = {
                    label = "Hat (58-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_58_3"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (59-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_0"
                },
                [1] = {
                    label = "Hat (59-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_1"
                },
                [2] = {
                    label = "Hat (59-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_2"
                },
                [3] = {
                    label = "Hat (59-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_3"
                },
                [4] = {
                    label = "Hat (59-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_4"
                },
                [5] = {
                    label = "Hat (59-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_5"
                },
                [6] = {
                    label = "Hat (59-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_6"
                },
                [7] = {
                    label = "Hat (59-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_7"
                },
                [8] = {
                    label = "Hat (59-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_8"
                },
                [9] = {
                    label = "Hat (59-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_9"
                },
                [10] = {
                    label = "Hat (59-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_59_10"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (60-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_0"
                },
                [1] = {
                    label = "Hat (60-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_1"
                },
                [2] = {
                    label = "Hat (60-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_2"
                },
                [3] = {
                    label = "Hat (60-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_3"
                },
                [4] = {
                    label = "Hat (60-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_4"
                },
                [5] = {
                    label = "Hat (60-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_5"
                },
                [6] = {
                    label = "Hat (60-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_6"
                },
                [7] = {
                    label = "Hat (60-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_7"
                },
                [8] = {
                    label = "Hat (60-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_8"
                },
                [9] = {
                    label = "Hat (60-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_9"
                },
                [10] = {
                    label = "Hat (60-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_60_10"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (61-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_0"
                },
                [1] = {
                    label = "Hat (61-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_1"
                },
                [2] = {
                    label = "Hat (61-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_2"
                },
                [3] = {
                    label = "Hat (61-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_3"
                },
                [4] = {
                    label = "Hat (61-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_4"
                },
                [5] = {
                    label = "Hat (61-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_5"
                },
                [6] = {
                    label = "Hat (61-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_6"
                },
                [7] = {
                    label = "Hat (61-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_7"
                },
                [8] = {
                    label = "Hat (61-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_8"
                },
                [9] = {
                    label = "Hat (61-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_9"
                },
                [10] = {
                    label = "Hat (61-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_61_10"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (62-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_0"
                },
                [1] = {
                    label = "Hat (62-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_1"
                },
                [2] = {
                    label = "Hat (62-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_2"
                },
                [3] = {
                    label = "Hat (62-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_3"
                },
                [4] = {
                    label = "Hat (62-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_4"
                },
                [5] = {
                    label = "Hat (62-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_5"
                },
                [6] = {
                    label = "Hat (62-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_6"
                },
                [7] = {
                    label = "Hat (62-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_7"
                },
                [8] = {
                    label = "Hat (62-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_8"
                },
                [9] = {
                    label = "Hat (62-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_9"
                },
                [10] = {
                    label = "Hat (62-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_62_10"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (63-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_0"
                },
                [1] = {
                    label = "Hat (63-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_1"
                },
                [2] = {
                    label = "Hat (63-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_2"
                },
                [3] = {
                    label = "Hat (63-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_3"
                },
                [4] = {
                    label = "Hat (63-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_4"
                },
                [5] = {
                    label = "Hat (63-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_5"
                },
                [6] = {
                    label = "Hat (63-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_6"
                },
                [7] = {
                    label = "Hat (63-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_7"
                },
                [8] = {
                    label = "Hat (63-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_8"
                },
                [9] = {
                    label = "Hat (63-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_9"
                },
                [10] = {
                    label = "Hat (63-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_63_10"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'prop',
            textures = {
                [0] = {
                    label = "SecuroServ Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_64_0"
                },
                [1] = {
                    label = "Hat (64-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_64_1"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'prop',
            textures = {
                [0] = {
                    label = "SecuroServ Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_65_0"
                },
                [1] = {
                    label = "Hat (65-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_65_1"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Shatter Pattern Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_0"
                },
                [1] = {
                    label = "Stars Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_1"
                },
                [2] = {
                    label = "Squared Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_2"
                },
                [3] = {
                    label = "Crimson Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_3"
                },
                [4] = {
                    label = "Skull Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_4"
                },
                [5] = {
                    label = "Ace of Spades Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_5"
                },
                [6] = {
                    label = "Flamejob Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_6"
                },
                [7] = {
                    label = "White Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_7"
                },
                [8] = {
                    label = "Downhill Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_8"
                },
                [9] = {
                    label = "Slalom Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_9"
                },
                [10] = {
                    label = "SA Assault Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_10"
                },
                [11] = {
                    label = "Vibe Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_11"
                },
                [12] = {
                    label = "Burst Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_12"
                },
                [13] = {
                    label = "Tri Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_13"
                },
                [14] = {
                    label = "Sprunk Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_14"
                },
                [15] = {
                    label = "Skeleton Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_15"
                },
                [16] = {
                    label = "Death Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_16"
                },
                [17] = {
                    label = "Cobble Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_17"
                },
                [18] = {
                    label = "Cubist Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_18"
                },
                [19] = {
                    label = "Digital Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_19"
                },
                [20] = {
                    label = "Snakeskin Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_20"
                },
                [21] = {
                    label = "Boost Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_21"
                },
                [22] = {
                    label = "Tropic Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_22"
                },
                [23] = {
                    label = "Atomic Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_23"
                },
                [24] = {
                    label = "Hat (66-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_66_24"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy All Black Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_67_0"
                },
                [1] = {
                    label = "Hat (67-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_67_1"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_68_0"
                },
                [1] = {
                    label = "Hat (68-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_68_1"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte All Black Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_69_0"
                },
                [1] = {
                    label = "Hat (69-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_69_1"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "female_hat_70_0"
                },
                [1] = {
                    label = "Hat (70-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_70_1"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (71-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_0"
                },
                [1] = {
                    label = "Hat (71-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_1"
                },
                [2] = {
                    label = "Hat (71-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_2"
                },
                [3] = {
                    label = "Hat (71-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_3"
                },
                [4] = {
                    label = "Hat (71-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_4"
                },
                [5] = {
                    label = "Hat (71-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_5"
                },
                [6] = {
                    label = "Hat (71-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_6"
                },
                [7] = {
                    label = "Hat (71-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_7"
                },
                [8] = {
                    label = "Hat (71-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_8"
                },
                [9] = {
                    label = "Hat (71-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_9"
                },
                [10] = {
                    label = "Hat (71-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_71_10"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_0"
                },
                [1] = {
                    label = "Gray Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_1"
                },
                [2] = {
                    label = "Orange Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_2"
                },
                [3] = {
                    label = "Pale Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_3"
                },
                [4] = {
                    label = "Hat (72-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_4"
                },
                [5] = {
                    label = "Hat (72-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_5"
                },
                [6] = {
                    label = "Hat (72-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_6"
                },
                [7] = {
                    label = "Hat (72-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_7"
                },
                [8] = {
                    label = "White Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_8"
                },
                [9] = {
                    label = "Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_9"
                },
                [10] = {
                    label = "Red Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_10"
                },
                [11] = {
                    label = "Black Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_11"
                },
                [12] = {
                    label = "Pink Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_12"
                },
                [13] = {
                    label = "Hat (72-13)",
                    price = 500,
                    type = "money",
                    image = "female_hat_72_13"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_0"
                },
                [1] = {
                    label = "Gray Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_1"
                },
                [2] = {
                    label = "Orange Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_2"
                },
                [3] = {
                    label = "Pale Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_3"
                },
                [4] = {
                    label = "Hat (73-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_4"
                },
                [5] = {
                    label = "Hat (73-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_5"
                },
                [6] = {
                    label = "Hat (73-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_6"
                },
                [7] = {
                    label = "Hat (73-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_7"
                },
                [8] = {
                    label = "White Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_8"
                },
                [9] = {
                    label = "Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_9"
                },
                [10] = {
                    label = "Red Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_10"
                },
                [11] = {
                    label = "Black Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_11"
                },
                [12] = {
                    label = "Pink Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_12"
                },
                [13] = {
                    label = "Hat (73-13)",
                    price = 500,
                    type = "money",
                    image = "female_hat_73_13"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (74-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_0"
                },
                [1] = {
                    label = "Hat (74-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_1"
                },
                [2] = {
                    label = "Hat (74-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_2"
                },
                [3] = {
                    label = "Hat (74-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_3"
                },
                [4] = {
                    label = "Swirl Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_4"
                },
                [5] = {
                    label = "Red Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_5"
                },
                [6] = {
                    label = "Brown Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_6"
                },
                [7] = {
                    label = "White Flag Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_7"
                },
                [8] = {
                    label = "Blue Stars Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_8"
                },
                [9] = {
                    label = "Black Slash Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_9"
                },
                [10] = {
                    label = "White Stars Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_10"
                },
                [11] = {
                    label = "Blue Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_11"
                },
                [12] = {
                    label = "Red Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_12"
                },
                [13] = {
                    label = "Blue Chain Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_13"
                },
                [14] = {
                    label = "Black Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_14"
                },
                [15] = {
                    label = "Black Jag Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_15"
                },
                [16] = {
                    label = "Hat (74-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_74_16"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Atomic Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_0"
                },
                [1] = {
                    label = "Auto Exotic Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_1"
                },
                [2] = {
                    label = "Chepalle Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_2"
                },
                [3] = {
                    label = "Cunning Stunts Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_3"
                },
                [4] = {
                    label = "Flash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_4"
                },
                [5] = {
                    label = "Fukaru Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_5"
                },
                [6] = {
                    label = "Globe Oil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_6"
                },
                [7] = {
                    label = "Grotti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_7"
                },
                [8] = {
                    label = "Imponte Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_8"
                },
                [9] = {
                    label = "Lampadati Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_9"
                },
                [10] = {
                    label = "LTD Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_10"
                },
                [11] = {
                    label = "Nagasaki Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_11"
                },
                [12] = {
                    label = "Nagasaki Moto Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_12"
                },
                [13] = {
                    label = "Patriot Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_13"
                },
                [14] = {
                    label = "Rebel Radio Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_14"
                },
                [15] = {
                    label = "Redwood Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_15"
                },
                [16] = {
                    label = "Scooter Brothers Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_16"
                },
                [17] = {
                    label = "The Mount Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_17"
                },
                [18] = {
                    label = "Total Ride Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_18"
                },
                [19] = {
                    label = "Vapid Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_19"
                },
                [20] = {
                    label = "Xero Gas Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_20"
                },
                [21] = {
                    label = "Hat (75-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_75_21"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Atomic Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_0"
                },
                [1] = {
                    label = "Auto Exotic Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_1"
                },
                [2] = {
                    label = "Chepalle Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_2"
                },
                [3] = {
                    label = "Cunning Stunts Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_3"
                },
                [4] = {
                    label = "Flash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_4"
                },
                [5] = {
                    label = "Fukaru Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_5"
                },
                [6] = {
                    label = "Globe Oil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_6"
                },
                [7] = {
                    label = "Grotti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_7"
                },
                [8] = {
                    label = "Imponte Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_8"
                },
                [9] = {
                    label = "Lampadati Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_9"
                },
                [10] = {
                    label = "LTD Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_10"
                },
                [11] = {
                    label = "Nagasaki Racing Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_11"
                },
                [12] = {
                    label = "Nagasaki Moto Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_12"
                },
                [13] = {
                    label = "Patriot Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_13"
                },
                [14] = {
                    label = "Rebel Radio Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_14"
                },
                [15] = {
                    label = "Redwood Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_15"
                },
                [16] = {
                    label = "Scooter Brothers Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_16"
                },
                [17] = {
                    label = "The Mount Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_17"
                },
                [18] = {
                    label = "Total Ride Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_18"
                },
                [19] = {
                    label = "Vapid Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_19"
                },
                [20] = {
                    label = "Xero Gas Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_20"
                },
                [21] = {
                    label = "Hat (76-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_76_21"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_0"
                },
                [1] = {
                    label = "Blue JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_1"
                },
                [2] = {
                    label = "Red JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_2"
                },
                [3] = {
                    label = "Black JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_3"
                },
                [4] = {
                    label = "Pink JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_4"
                },
                [5] = {
                    label = "Hat (77-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_77_5"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_0"
                },
                [1] = {
                    label = "Blue JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_1"
                },
                [2] = {
                    label = "Red JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_2"
                },
                [3] = {
                    label = "Black JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_3"
                },
                [4] = {
                    label = "Pink JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_4"
                },
                [5] = {
                    label = "Hat (78-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_78_5"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_79_0"
                },
                [1] = {
                    label = "Silver JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_79_1"
                },
                [2] = {
                    label = "Gold Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_79_2"
                },
                [3] = {
                    label = "Silver Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_79_3"
                },
                [4] = {
                    label = "Hat (79-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_79_4"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_80_0"
                },
                [1] = {
                    label = "Silver JC Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_80_1"
                },
                [2] = {
                    label = "Gold Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_80_2"
                },
                [3] = {
                    label = "Silver Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "female_hat_80_3"
                },
                [4] = {
                    label = "Hat (80-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_80_4"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Shatter Pattern Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_0"
                },
                [1] = {
                    label = "Stars Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_1"
                },
                [2] = {
                    label = "Squared Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_2"
                },
                [3] = {
                    label = "Crimson Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_3"
                },
                [4] = {
                    label = "Skull Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_4"
                },
                [5] = {
                    label = "Ace of Spades Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_5"
                },
                [6] = {
                    label = "Flamejob Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_6"
                },
                [7] = {
                    label = "White Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_7"
                },
                [8] = {
                    label = "Downhill Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_8"
                },
                [9] = {
                    label = "Slalom Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_9"
                },
                [10] = {
                    label = "SA Assault Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_10"
                },
                [11] = {
                    label = "Vibe Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_11"
                },
                [12] = {
                    label = "Burst Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_12"
                },
                [13] = {
                    label = "Tri Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_13"
                },
                [14] = {
                    label = "Sprunk Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_14"
                },
                [15] = {
                    label = "Skeleton Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_15"
                },
                [16] = {
                    label = "Death Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_16"
                },
                [17] = {
                    label = "Cobble Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_17"
                },
                [18] = {
                    label = "Cubist Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_18"
                },
                [19] = {
                    label = "Digital Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_19"
                },
                [20] = {
                    label = "Snakeskin Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_20"
                },
                [21] = {
                    label = "Boost Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_21"
                },
                [22] = {
                    label = "Tropic Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_22"
                },
                [23] = {
                    label = "Atomic Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_23"
                },
                [24] = {
                    label = "Hat (81-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_81_24"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_0"
                },
                [1] = {
                    label = "Uptown Riders Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_1"
                },
                [2] = {
                    label = "Ride Free Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_2"
                },
                [3] = {
                    label = "Ace of Spades Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_3"
                },
                [4] = {
                    label = "Skull and Snake Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_4"
                },
                [5] = {
                    label = "Ox and Hatchets Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_5"
                },
                [6] = {
                    label = "Stars and Stripes Tied",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_6"
                },
                [7] = {
                    label = "Hat (82-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_82_7"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_0"
                },
                [1] = {
                    label = "Carbon Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_1"
                },
                [2] = {
                    label = "Orange Fiber Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_2"
                },
                [3] = {
                    label = "Star and Stripes Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_3"
                },
                [4] = {
                    label = "Green Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_4"
                },
                [5] = {
                    label = "Feathers Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_5"
                },
                [6] = {
                    label = "Ox and Hatchets Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_6"
                },
                [7] = {
                    label = "Ride Free Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_7"
                },
                [8] = {
                    label = "Ace of Spades Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_8"
                },
                [9] = {
                    label = "Skull and Snake Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_9"
                },
                [10] = {
                    label = "Hat (83-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_83_10"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_84_0"
                },
                [1] = {
                    label = "Hat (84-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_84_1"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Visored Skull Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_85_0"
                },
                [1] = {
                    label = "Hat (85-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_85_1"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Finned Skull Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_86_0"
                },
                [1] = {
                    label = "Hat (86-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_86_1"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Skull Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_87_0"
                },
                [1] = {
                    label = "Hat (87-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_87_1"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_0"
                },
                [1] = {
                    label = "Carbon Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_1"
                },
                [2] = {
                    label = "Orange Fiber Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_2"
                },
                [3] = {
                    label = "Star and Stripes Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_3"
                },
                [4] = {
                    label = "Green Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_4"
                },
                [5] = {
                    label = "Feathers Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_5"
                },
                [6] = {
                    label = "Ox and Hatchets Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_6"
                },
                [7] = {
                    label = "Ride Free Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_7"
                },
                [8] = {
                    label = "Ace of Spades Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_8"
                },
                [9] = {
                    label = "Skull and Snake Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_9"
                },
                [10] = {
                    label = "Hat (88-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_88_10"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chromed Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_89_0"
                },
                [1] = {
                    label = "Hat (89-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_89_1"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Deadline Yellow",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_0"
                },
                [1] = {
                    label = "Deadline Green",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_1"
                },
                [2] = {
                    label = "Deadline Orange",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_2"
                },
                [3] = {
                    label = "Deadline Purple",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_3"
                },
                [4] = {
                    label = "Deadline Pink",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_4"
                },
                [5] = {
                    label = "Deadline Red",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_5"
                },
                [6] = {
                    label = "Deadline Blue",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_6"
                },
                [7] = {
                    label = "Hat (90-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_7"
                },
                [8] = {
                    label = "Hat (90-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_8"
                },
                [9] = {
                    label = "Deadline White",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_9"
                },
                [10] = {
                    label = "Hat (90-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_10"
                },
                [11] = {
                    label = "Hat (90-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_90_11"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Deadline Yellow",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_0"
                },
                [1] = {
                    label = "Deadline Green",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_1"
                },
                [2] = {
                    label = "Deadline Orange",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_2"
                },
                [3] = {
                    label = "Deadline Purple",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_3"
                },
                [4] = {
                    label = "Deadline Pink",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_4"
                },
                [5] = {
                    label = "Deadline Red",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_5"
                },
                [6] = {
                    label = "Deadline Blue",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_6"
                },
                [7] = {
                    label = "Hat (91-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_7"
                },
                [8] = {
                    label = "Hat (91-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_8"
                },
                [9] = {
                    label = "Deadline White",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_9"
                },
                [10] = {
                    label = "Hat (91-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_10"
                },
                [11] = {
                    label = "Hat (91-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_91_11"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Roundel Mod",
                    price = 500,
                    type = "money",
                    image = "female_hat_92_0"
                },
                [1] = {
                    label = "Faggio Mod",
                    price = 500,
                    type = "money",
                    image = "female_hat_92_1"
                },
                [2] = {
                    label = "Green Roundel Mod",
                    price = 500,
                    type = "money",
                    image = "female_hat_92_2"
                },
                [3] = {
                    label = "Green Faggio Mod",
                    price = 500,
                    type = "money",
                    image = "female_hat_92_3"
                },
                [4] = {
                    label = "Hat (92-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_92_4"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_0"
                },
                [1] = {
                    label = "Red Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_1"
                },
                [2] = {
                    label = "Blue Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_2"
                },
                [3] = {
                    label = "Cyan Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_3"
                },
                [4] = {
                    label = "White Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_4"
                },
                [5] = {
                    label = "Ash Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_5"
                },
                [6] = {
                    label = "Navy Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_6"
                },
                [7] = {
                    label = "Dark Red Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_7"
                },
                [8] = {
                    label = "Slate Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_8"
                },
                [9] = {
                    label = "Moss Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_9"
                },
                [10] = {
                    label = "Hat (93-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_93_10"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_0"
                },
                [1] = {
                    label = "Red Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_1"
                },
                [2] = {
                    label = "Blue Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_2"
                },
                [3] = {
                    label = "Cyan Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_3"
                },
                [4] = {
                    label = "White Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_4"
                },
                [5] = {
                    label = "Ash Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_5"
                },
                [6] = {
                    label = "Navy Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_6"
                },
                [7] = {
                    label = "Dark Red Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_7"
                },
                [8] = {
                    label = "Slate Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_8"
                },
                [9] = {
                    label = "Moss Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_9"
                },
                [10] = {
                    label = "Hat (94-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_94_10"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_0"
                },
                [1] = {
                    label = "Red Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_1"
                },
                [2] = {
                    label = "Orange Camo Sand Castle Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_2"
                },
                [3] = {
                    label = "Purple Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_3"
                },
                [4] = {
                    label = "Off-White Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_4"
                },
                [5] = {
                    label = "Bold Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_5"
                },
                [6] = {
                    label = "Gray Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_6"
                },
                [7] = {
                    label = "Pale Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_7"
                },
                [8] = {
                    label = "Primary Squash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_8"
                },
                [9] = {
                    label = "Spots Squash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_9"
                },
                [10] = {
                    label = "Banana Squash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_10"
                },
                [11] = {
                    label = "Splat Squash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_11"
                },
                [12] = {
                    label = "OJ Squash Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_12"
                },
                [13] = {
                    label = "Multicolor Leaves Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_13"
                },
                [14] = {
                    label = "Red Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_14"
                },
                [15] = {
                    label = "White Painted Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_15"
                },
                [16] = {
                    label = "Hat (95-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_95_16"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Classic Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_96_0"
                },
                [1] = {
                    label = "Glow Purple Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_96_1"
                },
                [2] = {
                    label = "Glow Holly Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_96_2"
                },
                [3] = {
                    label = "Glow Star Tree",
                    price = 500,
                    type = "money",
                    image = "female_hat_96_3"
                },
                [4] = {
                    label = "Hat (96-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_96_4"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Pudding Woolly Knit",
                    price = 500,
                    type = "money",
                    image = "female_hat_97_0"
                },
                [1] = {
                    label = "Hat (97-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_97_1"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Cheeky Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "female_hat_98_0"
                },
                [1] = {
                    label = "Hat (98-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_98_1"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Elf Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_99_0"
                },
                [1] = {
                    label = "Hat (99-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_99_1"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Reindeer Antlers",
                    price = 500,
                    type = "money",
                    image = "female_hat_100_0"
                },
                [1] = {
                    label = "Hat (100-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_100_1"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (101-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_0"
                },
                [1] = {
                    label = "Hat (101-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_1"
                },
                [2] = {
                    label = "Hat (101-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_2"
                },
                [3] = {
                    label = "Hat (101-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_3"
                },
                [4] = {
                    label = "Hat (101-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_4"
                },
                [5] = {
                    label = "Hat (101-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_5"
                },
                [6] = {
                    label = "Hat (101-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_6"
                },
                [7] = {
                    label = "Hat (101-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_7"
                },
                [8] = {
                    label = "Hat (101-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_8"
                },
                [9] = {
                    label = "Hat (101-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_9"
                },
                [10] = {
                    label = "Hat (101-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_101_10"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_0"
                },
                [1] = {
                    label = "Brown Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_1"
                },
                [2] = {
                    label = "Green Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_2"
                },
                [3] = {
                    label = "Gray Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_3"
                },
                [4] = {
                    label = "Peach Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_4"
                },
                [5] = {
                    label = "Fall Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_5"
                },
                [6] = {
                    label = "Dark Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_6"
                },
                [7] = {
                    label = "Crosshatch Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_7"
                },
                [8] = {
                    label = "Moss Digital Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_8"
                },
                [9] = {
                    label = "Gray Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_9"
                },
                [10] = {
                    label = "Aqua Camo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_10"
                },
                [11] = {
                    label = "Splinter Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_11"
                },
                [12] = {
                    label = "Contrast Camo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_12"
                },
                [13] = {
                    label = "Cobble Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_13"
                },
                [14] = {
                    label = "Peach Camo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_14"
                },
                [15] = {
                    label = "Brushstroke Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_15"
                },
                [16] = {
                    label = "Flecktarn Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_16"
                },
                [17] = {
                    label = "Light Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_17"
                },
                [18] = {
                    label = "Moss Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_18"
                },
                [19] = {
                    label = "Sand Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_19"
                },
                [20] = {
                    label = "Hat (102-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_102_20"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_0"
                },
                [1] = {
                    label = "Brown Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_1"
                },
                [2] = {
                    label = "Green Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_2"
                },
                [3] = {
                    label = "Gray Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_3"
                },
                [4] = {
                    label = "Peach Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_4"
                },
                [5] = {
                    label = "Fall Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_5"
                },
                [6] = {
                    label = "Dark Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_6"
                },
                [7] = {
                    label = "Crosshatch Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_7"
                },
                [8] = {
                    label = "Moss Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_8"
                },
                [9] = {
                    label = "Gray Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_9"
                },
                [10] = {
                    label = "Aqua Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_10"
                },
                [11] = {
                    label = "Splinter Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_11"
                },
                [12] = {
                    label = "Contrast Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_12"
                },
                [13] = {
                    label = "Cobble Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_13"
                },
                [14] = {
                    label = "Peach Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_14"
                },
                [15] = {
                    label = "Brushstroke Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_15"
                },
                [16] = {
                    label = "Flecktarn Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_16"
                },
                [17] = {
                    label = "Light Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_17"
                },
                [18] = {
                    label = "Moss Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_18"
                },
                [19] = {
                    label = "Sand Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_19"
                },
                [20] = {
                    label = "Black Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_20"
                },
                [21] = {
                    label = "Slate Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_21"
                },
                [22] = {
                    label = "White Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_22"
                },
                [23] = {
                    label = "Chocolate Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_23"
                },
                [24] = {
                    label = "Olive Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_24"
                },
                [25] = {
                    label = "Light Brown Boonie Down",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_25"
                },
                [26] = {
                    label = "Hat (103-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_103_26"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_0"
                },
                [1] = {
                    label = "Brown Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_1"
                },
                [2] = {
                    label = "Green Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_2"
                },
                [3] = {
                    label = "Gray Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_3"
                },
                [4] = {
                    label = "Peach Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_4"
                },
                [5] = {
                    label = "Fall Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_5"
                },
                [6] = {
                    label = "Dark Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_6"
                },
                [7] = {
                    label = "Crosshatch Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_7"
                },
                [8] = {
                    label = "Moss Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_8"
                },
                [9] = {
                    label = "Gray Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_9"
                },
                [10] = {
                    label = "Aqua Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_10"
                },
                [11] = {
                    label = "Splinter Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_11"
                },
                [12] = {
                    label = "Contrast Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_12"
                },
                [13] = {
                    label = "Cobble Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_13"
                },
                [14] = {
                    label = "Peach Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_14"
                },
                [15] = {
                    label = "Brushstroke Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_15"
                },
                [16] = {
                    label = "Flecktarn Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_16"
                },
                [17] = {
                    label = "Light Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_17"
                },
                [18] = {
                    label = "Moss Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_18"
                },
                [19] = {
                    label = "Sand Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_19"
                },
                [20] = {
                    label = "Black Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_20"
                },
                [21] = {
                    label = "Slate Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_21"
                },
                [22] = {
                    label = "White Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_22"
                },
                [23] = {
                    label = "Chocolate Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_23"
                },
                [24] = {
                    label = "Olive Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_24"
                },
                [25] = {
                    label = "Light Brown Boonie Up",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_25"
                },
                [26] = {
                    label = "Hat (104-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_104_26"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_0"
                },
                [1] = {
                    label = "Brown Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_1"
                },
                [2] = {
                    label = "Green Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_2"
                },
                [3] = {
                    label = "Gray Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_3"
                },
                [4] = {
                    label = "Peach Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_4"
                },
                [5] = {
                    label = "Fall Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_5"
                },
                [6] = {
                    label = "Dark Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_6"
                },
                [7] = {
                    label = "Crosshatch Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_7"
                },
                [8] = {
                    label = "Moss Digital Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_8"
                },
                [9] = {
                    label = "Gray Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_9"
                },
                [10] = {
                    label = "Aqua Camo Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_10"
                },
                [11] = {
                    label = "Splinter Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_11"
                },
                [12] = {
                    label = "Contrast Camo Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_12"
                },
                [13] = {
                    label = "Cobble Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_13"
                },
                [14] = {
                    label = "Peach Camo Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_14"
                },
                [15] = {
                    label = "Brushstroke Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_15"
                },
                [16] = {
                    label = "Flecktarn Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_16"
                },
                [17] = {
                    label = "Light Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_17"
                },
                [18] = {
                    label = "Moss Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_18"
                },
                [19] = {
                    label = "Sand Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_19"
                },
                [20] = {
                    label = "Midnight Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_20"
                },
                [21] = {
                    label = "Slate Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_21"
                },
                [22] = {
                    label = "Ice Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_22"
                },
                [23] = {
                    label = "Chocolate Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_23"
                },
                [24] = {
                    label = "Olive Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_24"
                },
                [25] = {
                    label = "Light Brown Beret",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_25"
                },
                [26] = {
                    label = "Hat (105-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_105_26"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_0"
                },
                [1] = {
                    label = "Brown Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_1"
                },
                [2] = {
                    label = "Green Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_2"
                },
                [3] = {
                    label = "Gray Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_3"
                },
                [4] = {
                    label = "Peach Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_4"
                },
                [5] = {
                    label = "Fall Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_5"
                },
                [6] = {
                    label = "Dark Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_6"
                },
                [7] = {
                    label = "Crosshatch Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_7"
                },
                [8] = {
                    label = "Moss Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_8"
                },
                [9] = {
                    label = "Gray Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_9"
                },
                [10] = {
                    label = "Aqua Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_10"
                },
                [11] = {
                    label = "Splinter Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_11"
                },
                [12] = {
                    label = "Contrast Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_12"
                },
                [13] = {
                    label = "Cobble Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_13"
                },
                [14] = {
                    label = "Peach Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_14"
                },
                [15] = {
                    label = "Brushstroke Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_15"
                },
                [16] = {
                    label = "Flecktarn Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_16"
                },
                [17] = {
                    label = "Light Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_17"
                },
                [18] = {
                    label = "Moss Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_18"
                },
                [19] = {
                    label = "Sand Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_19"
                },
                [20] = {
                    label = "Black Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_20"
                },
                [21] = {
                    label = "Slate Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_21"
                },
                [22] = {
                    label = "White Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_22"
                },
                [23] = {
                    label = "Chocolate Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_23"
                },
                [24] = {
                    label = "Olive Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_24"
                },
                [25] = {
                    label = "Light Brown Utility Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_25"
                },
                [26] = {
                    label = "Hat (106-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_106_26"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_0"
                },
                [1] = {
                    label = "Brown Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_1"
                },
                [2] = {
                    label = "Green Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_2"
                },
                [3] = {
                    label = "Gray Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_3"
                },
                [4] = {
                    label = "Peach Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_4"
                },
                [5] = {
                    label = "Fall Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_5"
                },
                [6] = {
                    label = "Dark Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_6"
                },
                [7] = {
                    label = "Crosshatch Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_7"
                },
                [8] = {
                    label = "Moss Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_8"
                },
                [9] = {
                    label = "Gray Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_9"
                },
                [10] = {
                    label = "Aqua Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_10"
                },
                [11] = {
                    label = "Splinter Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_11"
                },
                [12] = {
                    label = "Contrast Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_12"
                },
                [13] = {
                    label = "Cobble Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_13"
                },
                [14] = {
                    label = "Peach Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_14"
                },
                [15] = {
                    label = "Brushstroke Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_15"
                },
                [16] = {
                    label = "Flecktarn Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_16"
                },
                [17] = {
                    label = "Light Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_17"
                },
                [18] = {
                    label = "Moss Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_18"
                },
                [19] = {
                    label = "Sand Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_19"
                },
                [20] = {
                    label = "Black Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_20"
                },
                [21] = {
                    label = "Slate Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_21"
                },
                [22] = {
                    label = "White Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_22"
                },
                [23] = {
                    label = "Chocolate Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_23"
                },
                [24] = {
                    label = "Olive Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_24"
                },
                [25] = {
                    label = "Light Brown Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_25"
                },
                [26] = {
                    label = "Hat (107-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_107_26"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_0"
                },
                [1] = {
                    label = "Black Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_1"
                },
                [2] = {
                    label = "White Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_2"
                },
                [3] = {
                    label = "Black Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_3"
                },
                [4] = {
                    label = "White Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_4"
                },
                [5] = {
                    label = "Black Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_5"
                },
                [6] = {
                    label = "Wine Coil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_6"
                },
                [7] = {
                    label = "Black Coil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_7"
                },
                [8] = {
                    label = "Black Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_8"
                },
                [9] = {
                    label = "Red Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_9"
                },
                [10] = {
                    label = "Warstock Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_10"
                },
                [11] = {
                    label = "Hat (108-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_108_11"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_0"
                },
                [1] = {
                    label = "Black Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_1"
                },
                [2] = {
                    label = "White Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_2"
                },
                [3] = {
                    label = "Black Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_3"
                },
                [4] = {
                    label = "White Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_4"
                },
                [5] = {
                    label = "Black Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_5"
                },
                [6] = {
                    label = "Wine Coil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_6"
                },
                [7] = {
                    label = "Black Coil Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_7"
                },
                [8] = {
                    label = "Black Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_8"
                },
                [9] = {
                    label = "Red Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_9"
                },
                [10] = {
                    label = "Warstock Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_10"
                },
                [11] = {
                    label = "Hat (109-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_109_11"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Orange Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_0"
                },
                [1] = {
                    label = "Green Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_1"
                },
                [2] = {
                    label = "Brown Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_2"
                },
                [3] = {
                    label = "White Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_3"
                },
                [4] = {
                    label = "Hat (110-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_4"
                },
                [5] = {
                    label = "Hat (110-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_5"
                },
                [6] = {
                    label = "Hat (110-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_6"
                },
                [7] = {
                    label = "Hat (110-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_7"
                },
                [8] = {
                    label = "Lime & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_8"
                },
                [9] = {
                    label = "51st Squad Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_9"
                },
                [10] = {
                    label = "Orange & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_10"
                },
                [11] = {
                    label = "Zeus Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_11"
                },
                [12] = {
                    label = "Green & Yellow Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_12"
                },
                [13] = {
                    label = "Blue & Orange Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_13"
                },
                [14] = {
                    label = "DFA Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_14"
                },
                [15] = {
                    label = "Snake Killers Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_15"
                },
                [16] = {
                    label = "Mind Over Matter Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_16"
                },
                [17] = {
                    label = "Red & White Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_17"
                },
                [18] = {
                    label = "Other Side Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_18"
                },
                [19] = {
                    label = "STFU Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_19"
                },
                [20] = {
                    label = "Patriot Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_20"
                },
                [21] = {
                    label = "Zebra Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_21"
                },
                [22] = {
                    label = "Tiger Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_22"
                },
                [23] = {
                    label = "Leopard Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_23"
                },
                [24] = {
                    label = "Shark Mouth Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_24"
                },
                [25] = {
                    label = "Yellow & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_25"
                },
                [26] = {
                    label = "Hat (110-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_110_26"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Woodland Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_0"
                },
                [1] = {
                    label = "Dark Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_1"
                },
                [2] = {
                    label = "Light Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_2"
                },
                [3] = {
                    label = "Flecktarn Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_3"
                },
                [4] = {
                    label = "Black Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_4"
                },
                [5] = {
                    label = "Medic Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_5"
                },
                [6] = {
                    label = "Gray Woodland Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_6"
                },
                [7] = {
                    label = "Tan Digital Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_7"
                },
                [8] = {
                    label = "Aqua Camo Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_8"
                },
                [9] = {
                    label = "Splinter Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_9"
                },
                [10] = {
                    label = "Red Star Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_10"
                },
                [11] = {
                    label = "Brown Digital Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_11"
                },
                [12] = {
                    label = "MP Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_12"
                },
                [13] = {
                    label = "Zebra Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_13"
                },
                [14] = {
                    label = "Leopard Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_14"
                },
                [15] = {
                    label = "Tiger Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_15"
                },
                [16] = {
                    label = "Police Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_16"
                },
                [17] = {
                    label = "Flames Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_17"
                },
                [18] = {
                    label = "Stars & Stripes Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_18"
                },
                [19] = {
                    label = "Patriot Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_19"
                },
                [20] = {
                    label = "Green Stars Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_20"
                },
                [21] = {
                    label = "Peace Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_21"
                },
                [22] = {
                    label = "Hat (111-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_22"
                },
                [23] = {
                    label = "Hat (111-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_23"
                },
                [24] = {
                    label = "Hat (111-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_24"
                },
                [25] = {
                    label = "Hat (111-25)",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_25"
                },
                [26] = {
                    label = "Hat (111-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_111_26"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_0"
                },
                [1] = {
                    label = "Black Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_1"
                },
                [2] = {
                    label = "Blue Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_2"
                },
                [3] = {
                    label = "Navy Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_3"
                },
                [4] = {
                    label = "Aqua Camo Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_4"
                },
                [5] = {
                    label = "White Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_5"
                },
                [6] = {
                    label = "White & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_6"
                },
                [7] = {
                    label = "Gray Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_7"
                },
                [8] = {
                    label = "Green & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_8"
                },
                [9] = {
                    label = "Brown & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_9"
                },
                [10] = {
                    label = "Light Brown Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_10"
                },
                [11] = {
                    label = "Moss Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_11"
                },
                [12] = {
                    label = "Gray Digital Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_12"
                },
                [13] = {
                    label = "Dark Woodland Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_13"
                },
                [14] = {
                    label = "Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_14"
                },
                [15] = {
                    label = "Chocolate Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_15"
                },
                [16] = {
                    label = "Hat (112-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_16"
                },
                [17] = {
                    label = "Hat (112-17)",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_17"
                },
                [18] = {
                    label = "Hat (112-18)",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_18"
                },
                [19] = {
                    label = "Hat (112-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_19"
                },
                [20] = {
                    label = "Hat (112-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_112_20"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White & Gold Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_0"
                },
                [1] = {
                    label = "White & Blue Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_1"
                },
                [2] = {
                    label = "Gray Leopard Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_2"
                },
                [3] = {
                    label = "Navy Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_3"
                },
                [4] = {
                    label = "Blue Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_4"
                },
                [5] = {
                    label = "Teal Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_5"
                },
                [6] = {
                    label = "Aqua Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_6"
                },
                [7] = {
                    label = "Black Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_7"
                },
                [8] = {
                    label = "Chocolate Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_8"
                },
                [9] = {
                    label = "Red Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_9"
                },
                [10] = {
                    label = "Red & Navy Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_10"
                },
                [11] = {
                    label = "Red Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_11"
                },
                [12] = {
                    label = "Brushstroke Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_12"
                },
                [13] = {
                    label = "Moss Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_13"
                },
                [14] = {
                    label = "Brown Digital Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_14"
                },
                [15] = {
                    label = "Beige Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_15"
                },
                [16] = {
                    label = "White Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_16"
                },
                [17] = {
                    label = "Gray Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_17"
                },
                [18] = {
                    label = "Zebra Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_18"
                },
                [19] = {
                    label = "Hat (113-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_19"
                },
                [20] = {
                    label = "Hat (113-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_20"
                },
                [21] = {
                    label = "Hat (113-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_21"
                },
                [22] = {
                    label = "Hat (113-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_22"
                },
                [23] = {
                    label = "Hat (113-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_113_23"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_0"
                },
                [1] = {
                    label = "Moss Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_1"
                },
                [2] = {
                    label = "Brown Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_2"
                },
                [3] = {
                    label = "White Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_3"
                },
                [4] = {
                    label = "Hat (114-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_4"
                },
                [5] = {
                    label = "Hat (114-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_5"
                },
                [6] = {
                    label = "Hat (114-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_6"
                },
                [7] = {
                    label = "Hat (114-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_7"
                },
                [8] = {
                    label = "Leopard Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_8"
                },
                [9] = {
                    label = "Brown Digital Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_9"
                },
                [10] = {
                    label = "Tiger Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_10"
                },
                [11] = {
                    label = "Pink Pattern Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_11"
                },
                [12] = {
                    label = "Peach Digital Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_12"
                },
                [13] = {
                    label = "Fall Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_13"
                },
                [14] = {
                    label = "Dark Woodland Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_14"
                },
                [15] = {
                    label = "Crosshatch Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_15"
                },
                [16] = {
                    label = "Green Pattern Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_16"
                },
                [17] = {
                    label = "Gray Woodland Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_17"
                },
                [18] = {
                    label = "Aqua Camo Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_18"
                },
                [19] = {
                    label = "Splinter Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_19"
                },
                [20] = {
                    label = "Contrast Camo Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_20"
                },
                [21] = {
                    label = "Cobble Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_21"
                },
                [22] = {
                    label = "Brushstroke Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_22"
                },
                [23] = {
                    label = "Flecktarn Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_23"
                },
                [24] = {
                    label = "Black & Red Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_24"
                },
                [25] = {
                    label = "Zebra Full Face",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_25"
                },
                [26] = {
                    label = "Hat (114-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_114_26"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_0"
                },
                [1] = {
                    label = "Moss Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_1"
                },
                [2] = {
                    label = "Brown Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_2"
                },
                [3] = {
                    label = "White Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_3"
                },
                [4] = {
                    label = "Hat (115-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_4"
                },
                [5] = {
                    label = "Hat (115-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_5"
                },
                [6] = {
                    label = "Hat (115-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_6"
                },
                [7] = {
                    label = "Hat (115-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_7"
                },
                [8] = {
                    label = "Leopard Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_8"
                },
                [9] = {
                    label = "Brown Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_9"
                },
                [10] = {
                    label = "Tiger Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_10"
                },
                [11] = {
                    label = "Pink Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_11"
                },
                [12] = {
                    label = "Peach Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_12"
                },
                [13] = {
                    label = "Fall Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_13"
                },
                [14] = {
                    label = "Dark Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_14"
                },
                [15] = {
                    label = "Crosshatch Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_15"
                },
                [16] = {
                    label = "Green Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_16"
                },
                [17] = {
                    label = "Gray Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_17"
                },
                [18] = {
                    label = "Aqua Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_18"
                },
                [19] = {
                    label = "Splinter Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_19"
                },
                [20] = {
                    label = "Contrast Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_20"
                },
                [21] = {
                    label = "Cobble Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_21"
                },
                [22] = {
                    label = "Brushstroke Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_22"
                },
                [23] = {
                    label = "Flecktarn Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_23"
                },
                [24] = {
                    label = "Black & Red Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_24"
                },
                [25] = {
                    label = "Zebra Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_25"
                },
                [26] = {
                    label = "Hat (115-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_115_26"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_0"
                },
                [1] = {
                    label = "Moss Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_1"
                },
                [2] = {
                    label = "Brown Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_2"
                },
                [3] = {
                    label = "White Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_3"
                },
                [4] = {
                    label = "Hat (116-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_4"
                },
                [5] = {
                    label = "Hat (116-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_5"
                },
                [6] = {
                    label = "Hat (116-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_6"
                },
                [7] = {
                    label = "Hat (116-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_7"
                },
                [8] = {
                    label = "Leopard Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_8"
                },
                [9] = {
                    label = "Brown Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_9"
                },
                [10] = {
                    label = "Tiger Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_10"
                },
                [11] = {
                    label = "Pink Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_11"
                },
                [12] = {
                    label = "Peach Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_12"
                },
                [13] = {
                    label = "Fall Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_13"
                },
                [14] = {
                    label = "Dark Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_14"
                },
                [15] = {
                    label = "Crosshatch Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_15"
                },
                [16] = {
                    label = "Green Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_16"
                },
                [17] = {
                    label = "Gray Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_17"
                },
                [18] = {
                    label = "Aqua Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_18"
                },
                [19] = {
                    label = "Splinter Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_19"
                },
                [20] = {
                    label = "Contrast Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_20"
                },
                [21] = {
                    label = "Cobble Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_21"
                },
                [22] = {
                    label = "Brushstroke Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_22"
                },
                [23] = {
                    label = "Flecktarn Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_23"
                },
                [24] = {
                    label = "Black & Red Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_24"
                },
                [25] = {
                    label = "Zebra Dual Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_25"
                },
                [26] = {
                    label = "Hat (116-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_116_26"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_0"
                },
                [1] = {
                    label = "Moss Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_1"
                },
                [2] = {
                    label = "Brown Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_2"
                },
                [3] = {
                    label = "White Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_3"
                },
                [4] = {
                    label = "Hat (117-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_4"
                },
                [5] = {
                    label = "Hat (117-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_5"
                },
                [6] = {
                    label = "Hat (117-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_6"
                },
                [7] = {
                    label = "Hat (117-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_7"
                },
                [8] = {
                    label = "Leopard Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_8"
                },
                [9] = {
                    label = "Brown Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_9"
                },
                [10] = {
                    label = "Tiger Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_10"
                },
                [11] = {
                    label = "Pink Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_11"
                },
                [12] = {
                    label = "Peach Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_12"
                },
                [13] = {
                    label = "Fall Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_13"
                },
                [14] = {
                    label = "Dark Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_14"
                },
                [15] = {
                    label = "Crosshatch Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_15"
                },
                [16] = {
                    label = "Green Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_16"
                },
                [17] = {
                    label = "Gray Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_17"
                },
                [18] = {
                    label = "Aqua Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_18"
                },
                [19] = {
                    label = "Splinter Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_19"
                },
                [20] = {
                    label = "Contrast Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_20"
                },
                [21] = {
                    label = "Cobble Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_21"
                },
                [22] = {
                    label = "Brushstroke Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_22"
                },
                [23] = {
                    label = "Flecktarn Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_23"
                },
                [24] = {
                    label = "Black & Red Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_24"
                },
                [25] = {
                    label = "Zebra Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_25"
                },
                [26] = {
                    label = "Hat (117-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_117_26"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_0"
                },
                [1] = {
                    label = "Moss Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_1"
                },
                [2] = {
                    label = "Brown Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_2"
                },
                [3] = {
                    label = "White Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_3"
                },
                [4] = {
                    label = "Hat (118-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_4"
                },
                [5] = {
                    label = "Hat (118-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_5"
                },
                [6] = {
                    label = "Hat (118-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_6"
                },
                [7] = {
                    label = "Hat (118-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_7"
                },
                [8] = {
                    label = "Leopard Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_8"
                },
                [9] = {
                    label = "Brown Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_9"
                },
                [10] = {
                    label = "Tiger Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_10"
                },
                [11] = {
                    label = "Pink Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_11"
                },
                [12] = {
                    label = "Peach Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_12"
                },
                [13] = {
                    label = "Fall Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_13"
                },
                [14] = {
                    label = "Dark Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_14"
                },
                [15] = {
                    label = "Crosshatch Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_15"
                },
                [16] = {
                    label = "Green Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_16"
                },
                [17] = {
                    label = "Gray Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_17"
                },
                [18] = {
                    label = "Aqua Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_18"
                },
                [19] = {
                    label = "Splinter Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_19"
                },
                [20] = {
                    label = "Contrast Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_20"
                },
                [21] = {
                    label = "Cobble Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_21"
                },
                [22] = {
                    label = "Brushstroke Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_22"
                },
                [23] = {
                    label = "Flecktarn Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_23"
                },
                [24] = {
                    label = "Black & Red Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_24"
                },
                [25] = {
                    label = "Zebra Quad Lens",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_25"
                },
                [26] = {
                    label = "Hat (118-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_118_26"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_0"
                },
                [1] = {
                    label = "Charcoal Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_1"
                },
                [2] = {
                    label = "Ash Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_2"
                },
                [3] = {
                    label = "White Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_3"
                },
                [4] = {
                    label = "Red Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_4"
                },
                [5] = {
                    label = "Blue Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_5"
                },
                [6] = {
                    label = "Light Blue Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_6"
                },
                [7] = {
                    label = "Beige Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_7"
                },
                [8] = {
                    label = "Light Woodland Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_8"
                },
                [9] = {
                    label = "Gray Woodland Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_9"
                },
                [10] = {
                    label = "Aqua Camo Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_10"
                },
                [11] = {
                    label = "Tiger Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_11"
                },
                [12] = {
                    label = "Tricolore Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_12"
                },
                [13] = {
                    label = "Blue Striped Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_13"
                },
                [14] = {
                    label = "Rasta Trio Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_14"
                },
                [15] = {
                    label = "Brown Striped Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_15"
                },
                [16] = {
                    label = "Stars & Stripes Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_16"
                },
                [17] = {
                    label = "Rasta Stripes Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_17"
                },
                [18] = {
                    label = "Black & Yellow Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_18"
                },
                [19] = {
                    label = "Blue & Yellow Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_19"
                },
                [20] = {
                    label = "Green Houndstooth Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_20"
                },
                [21] = {
                    label = "Beige Houndstooth Low Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_21"
                },
                [22] = {
                    label = "Hat (119-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_22"
                },
                [23] = {
                    label = "Hat (119-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_23"
                },
                [24] = {
                    label = "Hat (119-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_24"
                },
                [25] = {
                    label = "Hat (119-25)",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_25"
                },
                [26] = {
                    label = "Hat (119-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_119_26"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (120-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_120_0"
                },
                [1] = {
                    label = "Hat (120-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_120_1"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (121-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_121_0"
                },
                [1] = {
                    label = "Hat (121-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_121_1"
                },
                [2] = {
                    label = "Hat (121-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_121_2"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_0"
                },
                [1] = {
                    label = "White Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_1"
                },
                [2] = {
                    label = "Gray Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_2"
                },
                [3] = {
                    label = "Moss Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_3"
                },
                [4] = {
                    label = "Brown Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_4"
                },
                [5] = {
                    label = "Gray Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_5"
                },
                [6] = {
                    label = "Crosshatch Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_6"
                },
                [7] = {
                    label = "Blue Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_7"
                },
                [8] = {
                    label = "Fall Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_8"
                },
                [9] = {
                    label = "Aqua Camo Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_9"
                },
                [10] = {
                    label = "Splinter Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_10"
                },
                [11] = {
                    label = "Gray Woodland Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_11"
                },
                [12] = {
                    label = "Brushstroke Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_12"
                },
                [13] = {
                    label = "Moss Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_13"
                },
                [14] = {
                    label = "MP Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_14"
                },
                [15] = {
                    label = "LSPD Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_15"
                },
                [16] = {
                    label = "Hat (122-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_16"
                },
                [17] = {
                    label = "Hat (122-17)",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_17"
                },
                [18] = {
                    label = "Hat (122-18)",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_18"
                },
                [19] = {
                    label = "Hat (122-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_19"
                },
                [20] = {
                    label = "Hat (122-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_122_20"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_0"
                },
                [1] = {
                    label = "White Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_1"
                },
                [2] = {
                    label = "Gray Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_2"
                },
                [3] = {
                    label = "Moss Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_3"
                },
                [4] = {
                    label = "Brown Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_4"
                },
                [5] = {
                    label = "Gray Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_5"
                },
                [6] = {
                    label = "Crosshatch Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_6"
                },
                [7] = {
                    label = "Blue Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_7"
                },
                [8] = {
                    label = "Fall Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_8"
                },
                [9] = {
                    label = "Aqua Camo Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_9"
                },
                [10] = {
                    label = "Splinter Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_10"
                },
                [11] = {
                    label = "Gray Woodland Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_11"
                },
                [12] = {
                    label = "Brushstroke Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_12"
                },
                [13] = {
                    label = "Moss Digital Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_13"
                },
                [14] = {
                    label = "MP Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_14"
                },
                [15] = {
                    label = "LSPD Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_15"
                },
                [16] = {
                    label = "Hat (123-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_16"
                },
                [17] = {
                    label = "Hat (123-17)",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_17"
                },
                [18] = {
                    label = "Hat (123-18)",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_18"
                },
                [19] = {
                    label = "Hat (123-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_19"
                },
                [20] = {
                    label = "Hat (123-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_123_20"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_0"
                },
                [1] = {
                    label = "Cream Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_1"
                },
                [2] = {
                    label = "Stone Gray Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_2"
                },
                [3] = {
                    label = "Brown Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_3"
                },
                [4] = {
                    label = "Ox Blood Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_4"
                },
                [5] = {
                    label = "Blue Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_5"
                },
                [6] = {
                    label = "Brown Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_6"
                },
                [7] = {
                    label = "Gray Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_7"
                },
                [8] = {
                    label = "Contrast Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_8"
                },
                [9] = {
                    label = "Blue Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_9"
                },
                [10] = {
                    label = "Fall Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_10"
                },
                [11] = {
                    label = "Aqua Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_11"
                },
                [12] = {
                    label = "Light Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_12"
                },
                [13] = {
                    label = "Splinter Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_13"
                },
                [14] = {
                    label = "Gray Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_14"
                },
                [15] = {
                    label = "Moss Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_15"
                },
                [16] = {
                    label = "Crosshatch Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_16"
                },
                [17] = {
                    label = "No Master Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_17"
                },
                [18] = {
                    label = "Police Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_18"
                },
                [19] = {
                    label = "Hat (124-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_19"
                },
                [20] = {
                    label = "Hat (124-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_20"
                },
                [21] = {
                    label = "Hat (124-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_21"
                },
                [22] = {
                    label = "Hat (124-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_22"
                },
                [23] = {
                    label = "Hat (124-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_124_23"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_0"
                },
                [1] = {
                    label = "Cream Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_1"
                },
                [2] = {
                    label = "Stone Gray Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_2"
                },
                [3] = {
                    label = "Brown Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_3"
                },
                [4] = {
                    label = "Ox Blood Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_4"
                },
                [5] = {
                    label = "Blue Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_5"
                },
                [6] = {
                    label = "Brown Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_6"
                },
                [7] = {
                    label = "Gray Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_7"
                },
                [8] = {
                    label = "Contrast Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_8"
                },
                [9] = {
                    label = "Blue Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_9"
                },
                [10] = {
                    label = "Fall Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_10"
                },
                [11] = {
                    label = "Aqua Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_11"
                },
                [12] = {
                    label = "Light Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_12"
                },
                [13] = {
                    label = "Splinter Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_13"
                },
                [14] = {
                    label = "Gray Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_14"
                },
                [15] = {
                    label = "Moss Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_15"
                },
                [16] = {
                    label = "Crosshatch Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_16"
                },
                [17] = {
                    label = "No Master Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_17"
                },
                [18] = {
                    label = "Police Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_18"
                },
                [19] = {
                    label = "Hat (125-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_19"
                },
                [20] = {
                    label = "Hat (125-20)",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_20"
                },
                [21] = {
                    label = "Hat (125-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_21"
                },
                [22] = {
                    label = "Hat (125-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_22"
                },
                [23] = {
                    label = "Hat (125-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_125_23"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (126-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_126_0"
                },
                [1] = {
                    label = "Hat (126-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_126_1"
                },
                [2] = {
                    label = "Hat (126-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_126_2"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (127-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_127_0"
                },
                [1] = {
                    label = "Hat (127-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_127_1"
                },
                [2] = {
                    label = "Hat (127-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_127_2"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (128-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_0"
                },
                [1] = {
                    label = "Hat (128-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_1"
                },
                [2] = {
                    label = "Hat (128-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_2"
                },
                [3] = {
                    label = "Hat (128-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_3"
                },
                [4] = {
                    label = "Hat (128-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_4"
                },
                [5] = {
                    label = "Hat (128-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_5"
                },
                [6] = {
                    label = "Hat (128-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_6"
                },
                [7] = {
                    label = "Hat (128-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_7"
                },
                [8] = {
                    label = "Hat (128-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_8"
                },
                [9] = {
                    label = "Hat (128-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_9"
                },
                [10] = {
                    label = "Hat (128-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_10"
                },
                [11] = {
                    label = "Hat (128-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_11"
                },
                [12] = {
                    label = "Hat (128-12)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_12"
                },
                [13] = {
                    label = "Hat (128-13)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_13"
                },
                [14] = {
                    label = "Hat (128-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_14"
                },
                [15] = {
                    label = "Hat (128-15)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_15"
                },
                [16] = {
                    label = "Hat (128-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_16"
                },
                [17] = {
                    label = "Hat (128-17)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_17"
                },
                [18] = {
                    label = "Hat (128-18)",
                    price = 500,
                    type = "money",
                    image = "female_hat_128_18"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Burger Shot Burgers Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_0"
                },
                [1] = {
                    label = "Burger Shot Fries Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_1"
                },
                [2] = {
                    label = "Burger Shot Logo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_2"
                },
                [3] = {
                    label = "Burger Shot Bullseye Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_3"
                },
                [4] = {
                    label = "Yellow Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_4"
                },
                [5] = {
                    label = "Blue Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_5"
                },
                [6] = {
                    label = "Cluckin' Bell Logos Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_6"
                },
                [7] = {
                    label = "Black Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_7"
                },
                [8] = {
                    label = "Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_8"
                },
                [9] = {
                    label = "Purple Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_9"
                },
                [10] = {
                    label = "Pink Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_10"
                },
                [11] = {
                    label = "White Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_11"
                },
                [12] = {
                    label = "Red Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_12"
                },
                [13] = {
                    label = "Lucky Plucker Red Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_13"
                },
                [14] = {
                    label = "Lucky Plucker White Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_14"
                },
                [15] = {
                    label = "White Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_15"
                },
                [16] = {
                    label = "Black Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_16"
                },
                [17] = {
                    label = "White Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_17"
                },
                [18] = {
                    label = "Green Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_18"
                },
                [19] = {
                    label = "Hat (129-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_129_19"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Burger Shot Burgers Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_0"
                },
                [1] = {
                    label = "Burger Shot Fries Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_1"
                },
                [2] = {
                    label = "Burger Shot Logo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_2"
                },
                [3] = {
                    label = "Burger Shot Bullseye Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_3"
                },
                [4] = {
                    label = "Yellow Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_4"
                },
                [5] = {
                    label = "Blue Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_5"
                },
                [6] = {
                    label = "Cluckin' Bell Logos Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_6"
                },
                [7] = {
                    label = "Black Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_7"
                },
                [8] = {
                    label = "Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_8"
                },
                [9] = {
                    label = "Purple Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_9"
                },
                [10] = {
                    label = "Pink Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_10"
                },
                [11] = {
                    label = "White Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_11"
                },
                [12] = {
                    label = "Red Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_12"
                },
                [13] = {
                    label = "Lucky Plucker Red Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_13"
                },
                [14] = {
                    label = "Lucky Plucker White Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_14"
                },
                [15] = {
                    label = "White Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_15"
                },
                [16] = {
                    label = "Black Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_16"
                },
                [17] = {
                    label = "White Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_17"
                },
                [18] = {
                    label = "Green Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_18"
                },
                [19] = {
                    label = "Hat (130-19)",
                    price = 500,
                    type = "money",
                    image = "female_hat_130_19"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Taco Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_131_0"
                },
                [1] = {
                    label = "Burger Shot Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_131_1"
                },
                [2] = {
                    label = "Cluckin' Bell Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_131_2"
                },
                [3] = {
                    label = "Hotdogs Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_131_3"
                },
                [4] = {
                    label = "Hat (131-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_131_4"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (132-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_0"
                },
                [1] = {
                    label = "Hat (132-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_1"
                },
                [2] = {
                    label = "Hat (132-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_2"
                },
                [3] = {
                    label = "Hat (132-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_3"
                },
                [4] = {
                    label = "Hat (132-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_4"
                },
                [5] = {
                    label = "Hat (132-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_5"
                },
                [6] = {
                    label = "Hat (132-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_6"
                },
                [7] = {
                    label = "Hat (132-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_7"
                },
                [8] = {
                    label = "Hat (132-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_8"
                },
                [9] = {
                    label = "Hat (132-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_9"
                },
                [10] = {
                    label = "Hat (132-10)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_10"
                },
                [11] = {
                    label = "Hat (132-11)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_11"
                },
                [12] = {
                    label = "Hat (132-12)",
                    price = 500,
                    type = "money",
                    image = "female_hat_132_12"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (133-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_133_0"
                },
                [1] = {
                    label = "Hat (133-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_133_1"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_0"
                },
                [1] = {
                    label = "Black The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_1"
                },
                [2] = {
                    label = "White LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_2"
                },
                [3] = {
                    label = "Black LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_3"
                },
                [4] = {
                    label = "Red The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_4"
                },
                [5] = {
                    label = "Orange The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_5"
                },
                [6] = {
                    label = "Blue LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_6"
                },
                [7] = {
                    label = "Green The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_7"
                },
                [8] = {
                    label = "Orange LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_8"
                },
                [9] = {
                    label = "Purple The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_9"
                },
                [10] = {
                    label = "Pink LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_10"
                },
                [11] = {
                    label = "White Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_11"
                },
                [12] = {
                    label = "Black Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_12"
                },
                [13] = {
                    label = "Teal Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_13"
                },
                [14] = {
                    label = "Red Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_14"
                },
                [15] = {
                    label = "Green Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_15"
                },
                [16] = {
                    label = "Black SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_16"
                },
                [17] = {
                    label = "Teal SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_17"
                },
                [18] = {
                    label = "Purple SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_18"
                },
                [19] = {
                    label = "Red SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_19"
                },
                [20] = {
                    label = "White SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_20"
                },
                [21] = {
                    label = "Gray Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_21"
                },
                [22] = {
                    label = "Colors Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_22"
                },
                [23] = {
                    label = "Woodland Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_23"
                },
                [24] = {
                    label = "Hat (134-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_134_24"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_0"
                },
                [1] = {
                    label = "Black The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_1"
                },
                [2] = {
                    label = "White LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_2"
                },
                [3] = {
                    label = "Black LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_3"
                },
                [4] = {
                    label = "Red The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_4"
                },
                [5] = {
                    label = "Orange The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_5"
                },
                [6] = {
                    label = "Blue LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_6"
                },
                [7] = {
                    label = "Green The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_7"
                },
                [8] = {
                    label = "Orange LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_8"
                },
                [9] = {
                    label = "Purple The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_9"
                },
                [10] = {
                    label = "Pink LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_10"
                },
                [11] = {
                    label = "White Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_11"
                },
                [12] = {
                    label = "Black Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_12"
                },
                [13] = {
                    label = "Teal Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_13"
                },
                [14] = {
                    label = "Red Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_14"
                },
                [15] = {
                    label = "Green Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_15"
                },
                [16] = {
                    label = "Black SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_16"
                },
                [17] = {
                    label = "Teal SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_17"
                },
                [18] = {
                    label = "Purple SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_18"
                },
                [19] = {
                    label = "Red SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_19"
                },
                [20] = {
                    label = "White SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_20"
                },
                [21] = {
                    label = "Gray Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_21"
                },
                [22] = {
                    label = "Colors Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_22"
                },
                [23] = {
                    label = "Woodland Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_23"
                },
                [24] = {
                    label = "Hat (135-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_135_24"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Firefighter",
                    price = 500,
                    type = "money",
                    image = "female_hat_136_0"
                },
                [1] = {
                    label = "Orange Firefighter",
                    price = 500,
                    type = "money",
                    image = "female_hat_136_1"
                },
                [2] = {
                    label = "White Firefighter",
                    price = 500,
                    type = "money",
                    image = "female_hat_136_2"
                },
                [3] = {
                    label = "Hat (136-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_136_3"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "female_hat_137_0"
                },
                [1] = {
                    label = "Orange Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "female_hat_137_1"
                },
                [2] = {
                    label = "White Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "female_hat_137_2"
                },
                [3] = {
                    label = "Hat (137-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_137_3"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bugstars Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_138_0"
                },
                [1] = {
                    label = "Prison Authority Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_138_1"
                },
                [2] = {
                    label = "Yung Ancestor Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_138_2"
                },
                [3] = {
                    label = "Hat (138-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_138_3"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bugstars Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_139_0"
                },
                [1] = {
                    label = "Prison Authority Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_139_1"
                },
                [2] = {
                    label = "Yung Ancestor Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_139_2"
                },
                [3] = {
                    label = "Hat (139-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_139_3"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (140-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_140_0"
                },
                [1] = {
                    label = "Hat (140-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_140_1"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_0"
                },
                [1] = {
                    label = "Gray Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_1"
                },
                [2] = {
                    label = "Light Gray Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_2"
                },
                [3] = {
                    label = "Red Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_3"
                },
                [4] = {
                    label = "Teal Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_4"
                },
                [5] = {
                    label = "Smiley Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_5"
                },
                [6] = {
                    label = "Gray Digital Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_6"
                },
                [7] = {
                    label = "Blue Digital Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_7"
                },
                [8] = {
                    label = "Blue Wave Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_8"
                },
                [9] = {
                    label = "Stars & Stripes Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_9"
                },
                [10] = {
                    label = "Toothy Grin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_10"
                },
                [11] = {
                    label = "Wolf Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_11"
                },
                [12] = {
                    label = "Gray Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_12"
                },
                [13] = {
                    label = "Black Skull Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_13"
                },
                [14] = {
                    label = "Blood Cross Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_14"
                },
                [15] = {
                    label = "Brown Skull Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_15"
                },
                [16] = {
                    label = "Green Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_16"
                },
                [17] = {
                    label = "Green Neon Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_17"
                },
                [18] = {
                    label = "Purple Neon Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_18"
                },
                [19] = {
                    label = "Cobble Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_19"
                },
                [20] = {
                    label = "Green Snakeskin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_20"
                },
                [21] = {
                    label = "Purple Snakeskin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_21"
                },
                [22] = {
                    label = "Hat (141-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_22"
                },
                [23] = {
                    label = "Hat (141-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_23"
                },
                [24] = {
                    label = "Hat (141-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_24"
                },
                [25] = {
                    label = "Hat (141-25)",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_25"
                },
                [26] = {
                    label = "Hat (141-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_141_26"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_0"
                },
                [1] = {
                    label = "Gray Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_1"
                },
                [2] = {
                    label = "Light Gray Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_2"
                },
                [3] = {
                    label = "Red Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_3"
                },
                [4] = {
                    label = "Teal Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_4"
                },
                [5] = {
                    label = "Smiley Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_5"
                },
                [6] = {
                    label = "Gray Digital Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_6"
                },
                [7] = {
                    label = "Blue Digital Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_7"
                },
                [8] = {
                    label = "Blue Wave Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_8"
                },
                [9] = {
                    label = "Stars & Stripes Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_9"
                },
                [10] = {
                    label = "Toothy Grin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_10"
                },
                [11] = {
                    label = "Wolf Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_11"
                },
                [12] = {
                    label = "Gray Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_12"
                },
                [13] = {
                    label = "Black Skull Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_13"
                },
                [14] = {
                    label = "Blood Cross Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_14"
                },
                [15] = {
                    label = "Brown Skull Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_15"
                },
                [16] = {
                    label = "Green Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_16"
                },
                [17] = {
                    label = "Green Neon Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_17"
                },
                [18] = {
                    label = "Purple Neon Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_18"
                },
                [19] = {
                    label = "Cobble Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_19"
                },
                [20] = {
                    label = "Green Snakeskin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_20"
                },
                [21] = {
                    label = "Purple Snakeskin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_21"
                },
                [22] = {
                    label = "Hat (142-22)",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_22"
                },
                [23] = {
                    label = "Hat (142-23)",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_23"
                },
                [24] = {
                    label = "Hat (142-24)",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_24"
                },
                [25] = {
                    label = "Hat (142-25)",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_25"
                },
                [26] = {
                    label = "Hat (142-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_142_26"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gruppe Sechs Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_143_0"
                },
                [1] = {
                    label = "Hat (143-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_143_1"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_144_0"
                },
                [1] = {
                    label = "Orange Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_144_1"
                },
                [2] = {
                    label = "White Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_144_2"
                },
                [3] = {
                    label = "Blue Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_144_3"
                },
                [4] = {
                    label = "Hat (144-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_144_4"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_0"
                },
                [1] = {
                    label = "Dark Gray Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_1"
                },
                [2] = {
                    label = "Dusty Violet Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_2"
                },
                [3] = {
                    label = "Light Gray Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_3"
                },
                [4] = {
                    label = "Sage Green Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_4"
                },
                [5] = {
                    label = "Dusty Pink Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_5"
                },
                [6] = {
                    label = "Red Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_6"
                },
                [7] = {
                    label = "Terracotta Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_7"
                },
                [8] = {
                    label = "Cream Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_8"
                },
                [9] = {
                    label = "Ivory Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_9"
                },
                [10] = {
                    label = "Ash Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_10"
                },
                [11] = {
                    label = "Dark Violet Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_11"
                },
                [12] = {
                    label = "Eggshell Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_12"
                },
                [13] = {
                    label = "White Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_13"
                },
                [14] = {
                    label = "Hat (145-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_145_14"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_0"
                },
                [1] = {
                    label = "Sage Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_1"
                },
                [2] = {
                    label = "Beige Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_2"
                },
                [3] = {
                    label = "Stone Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_3"
                },
                [4] = {
                    label = "White Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_4"
                },
                [5] = {
                    label = "Beige Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_5"
                },
                [6] = {
                    label = "Green Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_6"
                },
                [7] = {
                    label = "Desert Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_7"
                },
                [8] = {
                    label = "Hat (146-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_146_8"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_0"
                },
                [1] = {
                    label = "Sage Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_1"
                },
                [2] = {
                    label = "Beige Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_2"
                },
                [3] = {
                    label = "Stone Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_3"
                },
                [4] = {
                    label = "White Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_4"
                },
                [5] = {
                    label = "Beige Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_5"
                },
                [6] = {
                    label = "Green Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_6"
                },
                [7] = {
                    label = "Desert Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_7"
                },
                [8] = {
                    label = "Hat (147-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_147_8"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Captain Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_148_0"
                },
                [1] = {
                    label = "Hat (148-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_148_1"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_0"
                },
                [1] = {
                    label = "Moss Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_1"
                },
                [2] = {
                    label = "Brown Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_2"
                },
                [3] = {
                    label = "White Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_3"
                },
                [4] = {
                    label = "Hat (149-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_4"
                },
                [5] = {
                    label = "Hat (149-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_5"
                },
                [6] = {
                    label = "Hat (149-6)",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_6"
                },
                [7] = {
                    label = "Hat (149-7)",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_7"
                },
                [8] = {
                    label = "Leopard Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_8"
                },
                [9] = {
                    label = "Brown Digital Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_9"
                },
                [10] = {
                    label = "Tiger Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_10"
                },
                [11] = {
                    label = "Pink Pattern Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_11"
                },
                [12] = {
                    label = "Peach Digital Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_12"
                },
                [13] = {
                    label = "Fall Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_13"
                },
                [14] = {
                    label = "Dark Woodland Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_14"
                },
                [15] = {
                    label = "Crosshatch Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_15"
                },
                [16] = {
                    label = "Green Pattern Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_16"
                },
                [17] = {
                    label = "Gray Woodland Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_17"
                },
                [18] = {
                    label = "Aqua Camo Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_18"
                },
                [19] = {
                    label = "Splinter Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_19"
                },
                [20] = {
                    label = "Contrast Camo Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_20"
                },
                [21] = {
                    label = "Cobble Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_21"
                },
                [22] = {
                    label = "Brushstroke Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_22"
                },
                [23] = {
                    label = "Flecktarn Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_23"
                },
                [24] = {
                    label = "Black & Red Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_24"
                },
                [25] = {
                    label = "Zebra Advanced",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_25"
                },
                [26] = {
                    label = "Hat (149-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_149_26"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Enus Yeti Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_0"
                },
                [1] = {
                    label = "720 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_2"
                },
                [3] = {
                    label = "Güffy Double Logo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_3"
                },
                [4] = {
                    label = "Rockstar Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_4"
                },
                [5] = {
                    label = "Civilist White Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_5"
                },
                [6] = {
                    label = "Civilist Black Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_6"
                },
                [7] = {
                    label = "Civilist Orange Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_7"
                },
                [8] = {
                    label = "Hat (150-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_150_8"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Enus Yeti Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_0"
                },
                [1] = {
                    label = "720 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_2"
                },
                [3] = {
                    label = "Güffy Double Logo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_3"
                },
                [4] = {
                    label = "Rockstar Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_4"
                },
                [5] = {
                    label = "Civilist White Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_5"
                },
                [6] = {
                    label = "Civilist Black Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_6"
                },
                [7] = {
                    label = "Civilist Orange Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_7"
                },
                [8] = {
                    label = "Hat (151-8)",
                    price = 500,
                    type = "money",
                    image = "female_hat_151_8"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Frontier Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_152_0"
                },
                [1] = {
                    label = "Hat (152-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_152_1"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Sprunk Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_0"
                },
                [1] = {
                    label = "eCola Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_1"
                },
                [2] = {
                    label = "Broker Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_2"
                },
                [3] = {
                    label = "Light Dinka Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_3"
                },
                [4] = {
                    label = "Dark Dinka Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_4"
                },
                [5] = {
                    label = "White Güffy Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_5"
                },
                [6] = {
                    label = "Black Güffy Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_6"
                },
                [7] = {
                    label = "Annis Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_7"
                },
                [8] = {
                    label = "Hellion Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_8"
                },
                [9] = {
                    label = "Emperor Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_9"
                },
                [10] = {
                    label = "Karin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_10"
                },
                [11] = {
                    label = "Lampadati Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_11"
                },
                [12] = {
                    label = "Omnis Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_12"
                },
                [13] = {
                    label = "Vapid Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_13"
                },
                [14] = {
                    label = "Hat (153-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_153_14"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Sprunk Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_0"
                },
                [1] = {
                    label = "eCola Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_1"
                },
                [2] = {
                    label = "Broker Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_2"
                },
                [3] = {
                    label = "Light Dinka Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_3"
                },
                [4] = {
                    label = "Dark Dinka Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_4"
                },
                [5] = {
                    label = "White Güffy Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_5"
                },
                [6] = {
                    label = "Black Güffy Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_6"
                },
                [7] = {
                    label = "Annis Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_7"
                },
                [8] = {
                    label = "Hellion Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_8"
                },
                [9] = {
                    label = "Emperor Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_9"
                },
                [10] = {
                    label = "Karin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_10"
                },
                [11] = {
                    label = "Lampadati Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_11"
                },
                [12] = {
                    label = "Omnis Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_12"
                },
                [13] = {
                    label = "Vapid Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_13"
                },
                [14] = {
                    label = "Hat (154-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_154_14"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_0"
                },
                [1] = {
                    label = "Yellow Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_1"
                },
                [2] = {
                    label = "Gray Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_2"
                },
                [3] = {
                    label = "Navy Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_3"
                },
                [4] = {
                    label = "Red Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_4"
                },
                [5] = {
                    label = "Beige Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_5"
                },
                [6] = {
                    label = "Salmon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_6"
                },
                [7] = {
                    label = "Orange Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_7"
                },
                [8] = {
                    label = "Chocolate Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_8"
                },
                [9] = {
                    label = "Slate Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_9"
                },
                [10] = {
                    label = "Ice Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_10"
                },
                [11] = {
                    label = "Crimson Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_11"
                },
                [12] = {
                    label = "Green Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_12"
                },
                [13] = {
                    label = "Blue Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_13"
                },
                [14] = {
                    label = "Olive Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_14"
                },
                [15] = {
                    label = "Maroon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_15"
                },
                [16] = {
                    label = "Lemon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_16"
                },
                [17] = {
                    label = "Hot Pink Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_17"
                },
                [18] = {
                    label = "Black Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_18"
                },
                [19] = {
                    label = "Contrast Camo Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_19"
                },
                [20] = {
                    label = "Aqua Camo Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_20"
                },
                [21] = {
                    label = "Brushstroke Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_21"
                },
                [22] = {
                    label = "Brown Digital Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_22"
                },
                [23] = {
                    label = "Gray Woodland Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_23"
                },
                [24] = {
                    label = "Vibrant Heat Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_24"
                },
                [25] = {
                    label = "Navy Prolaps Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_25"
                },
                [26] = {
                    label = "Hat (155-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_155_26"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_0"
                },
                [1] = {
                    label = "Yellow Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_1"
                },
                [2] = {
                    label = "Gray Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_2"
                },
                [3] = {
                    label = "Navy Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_3"
                },
                [4] = {
                    label = "Red Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_4"
                },
                [5] = {
                    label = "Beige Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_5"
                },
                [6] = {
                    label = "Salmon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_6"
                },
                [7] = {
                    label = "Orange Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_7"
                },
                [8] = {
                    label = "Chocolate Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_8"
                },
                [9] = {
                    label = "Slate Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_9"
                },
                [10] = {
                    label = "Ice Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_10"
                },
                [11] = {
                    label = "Crimson Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_11"
                },
                [12] = {
                    label = "Green Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_12"
                },
                [13] = {
                    label = "Blue Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_13"
                },
                [14] = {
                    label = "Olive Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_14"
                },
                [15] = {
                    label = "Maroon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_15"
                },
                [16] = {
                    label = "Lemon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_16"
                },
                [17] = {
                    label = "Hot Pink Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_17"
                },
                [18] = {
                    label = "Black Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_18"
                },
                [19] = {
                    label = "Contrast Camo Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_19"
                },
                [20] = {
                    label = "Aqua Camo Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_20"
                },
                [21] = {
                    label = "Brushstroke Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_21"
                },
                [22] = {
                    label = "Brown Digital Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_22"
                },
                [23] = {
                    label = "Gray Woodland Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_23"
                },
                [24] = {
                    label = "Vibrant Heat Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_24"
                },
                [25] = {
                    label = "Navy Prolaps Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_25"
                },
                [26] = {
                    label = "Hat (156-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_156_26"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_0"
                },
                [1] = {
                    label = "Yellow Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_1"
                },
                [2] = {
                    label = "Gray Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_2"
                },
                [3] = {
                    label = "Navy Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_3"
                },
                [4] = {
                    label = "Red Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_4"
                },
                [5] = {
                    label = "Beige Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_5"
                },
                [6] = {
                    label = "Salmon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_6"
                },
                [7] = {
                    label = "Orange Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_7"
                },
                [8] = {
                    label = "Chocolate Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_8"
                },
                [9] = {
                    label = "Slate Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_9"
                },
                [10] = {
                    label = "Ice Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_10"
                },
                [11] = {
                    label = "Crimson Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_11"
                },
                [12] = {
                    label = "Green Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_12"
                },
                [13] = {
                    label = "Blue Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_13"
                },
                [14] = {
                    label = "Olive Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_14"
                },
                [15] = {
                    label = "Maroon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_15"
                },
                [16] = {
                    label = "Lemon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_16"
                },
                [17] = {
                    label = "Hot Pink Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_17"
                },
                [18] = {
                    label = "Black Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_18"
                },
                [19] = {
                    label = "Contrast Camo Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_19"
                },
                [20] = {
                    label = "Aqua Camo Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_20"
                },
                [21] = {
                    label = "Brushstroke Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_21"
                },
                [22] = {
                    label = "Brown Digital Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_22"
                },
                [23] = {
                    label = "Gray Woodland Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_23"
                },
                [24] = {
                    label = "Vibrant Heat Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_24"
                },
                [25] = {
                    label = "White Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_25"
                },
                [26] = {
                    label = "Hat (157-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_157_26"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Navy Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_158_0"
                },
                [1] = {
                    label = "Green Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_158_1"
                },
                [2] = {
                    label = "Hat (158-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_158_2"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_0"
                },
                [1] = {
                    label = "Yellow Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_1"
                },
                [2] = {
                    label = "Gray Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_2"
                },
                [3] = {
                    label = "Navy Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_3"
                },
                [4] = {
                    label = "Red Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_4"
                },
                [5] = {
                    label = "Beige Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_5"
                },
                [6] = {
                    label = "Salmon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_6"
                },
                [7] = {
                    label = "Orange Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_7"
                },
                [8] = {
                    label = "Chocolate Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_8"
                },
                [9] = {
                    label = "Slate Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_9"
                },
                [10] = {
                    label = "Ice Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_10"
                },
                [11] = {
                    label = "Crimson Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_11"
                },
                [12] = {
                    label = "Green Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_12"
                },
                [13] = {
                    label = "Blue Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_13"
                },
                [14] = {
                    label = "Olive Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_14"
                },
                [15] = {
                    label = "Maroon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_15"
                },
                [16] = {
                    label = "Lemon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_16"
                },
                [17] = {
                    label = "Hot Pink Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_17"
                },
                [18] = {
                    label = "Black Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_18"
                },
                [19] = {
                    label = "Contrast Camo Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_19"
                },
                [20] = {
                    label = "Aqua Camo Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_20"
                },
                [21] = {
                    label = "Brushstroke Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_21"
                },
                [22] = {
                    label = "Brown Digital Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_22"
                },
                [23] = {
                    label = "Gray Woodland Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_23"
                },
                [24] = {
                    label = "Vibrant Heat Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_24"
                },
                [25] = {
                    label = "White Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_25"
                },
                [26] = {
                    label = "Hat (159-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_159_26"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Navy Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_160_0"
                },
                [1] = {
                    label = "Green Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_160_1"
                },
                [2] = {
                    label = "Hat (160-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_160_2"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Broker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_0"
                },
                [1] = {
                    label = "Gray Broker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_1"
                },
                [2] = {
                    label = "Black Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_2"
                },
                [3] = {
                    label = "Yellow Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_3"
                },
                [4] = {
                    label = "Yellow Camo Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_4"
                },
                [5] = {
                    label = "Black VDG Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_5"
                },
                [6] = {
                    label = "Yellow VDG Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_6"
                },
                [7] = {
                    label = "Black Pounders Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_7"
                },
                [8] = {
                    label = "White Pounders Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_8"
                },
                [9] = {
                    label = "Hat (161-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_161_9"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Broker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_0"
                },
                [1] = {
                    label = "Gray Broker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_1"
                },
                [2] = {
                    label = "Black Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_2"
                },
                [3] = {
                    label = "Yellow Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_3"
                },
                [4] = {
                    label = "Yellow Camo Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_4"
                },
                [5] = {
                    label = "Black VDG Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_5"
                },
                [6] = {
                    label = "Yellow VDG Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_6"
                },
                [7] = {
                    label = "Black Pounders Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_7"
                },
                [8] = {
                    label = "White Pounders Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_8"
                },
                [9] = {
                    label = "Hat (162-9)",
                    price = 500,
                    type = "money",
                    image = "female_hat_162_9"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black LD Organics Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_163_0"
                },
                [1] = {
                    label = "Hat (163-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_163_1"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black LD Organics Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_164_0"
                },
                [1] = {
                    label = "Hat (164-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_164_1"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_165_0"
                },
                [1] = {
                    label = "Black Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_165_1"
                },
                [2] = {
                    label = "Hat (165-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_165_2"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_166_0"
                },
                [1] = {
                    label = "Hat (166-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_166_1"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_167_0"
                },
                [1] = {
                    label = "Black Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_167_1"
                },
                [2] = {
                    label = "Hat (167-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_167_2"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Ice Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_0"
                },
                [1] = {
                    label = "Ash Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_1"
                },
                [2] = {
                    label = "Mono Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_2"
                },
                [3] = {
                    label = "Dark Gray Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_3"
                },
                [4] = {
                    label = "Beige Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_4"
                },
                [5] = {
                    label = "Chocolate Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_5"
                },
                [6] = {
                    label = "Burgundy Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_6"
                },
                [7] = {
                    label = "Hot Pink Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_7"
                },
                [8] = {
                    label = "Scarlet Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_8"
                },
                [9] = {
                    label = "Orange Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_9"
                },
                [10] = {
                    label = "Amber Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_10"
                },
                [11] = {
                    label = "Lemon Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_11"
                },
                [12] = {
                    label = "Royal Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_12"
                },
                [13] = {
                    label = "Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_13"
                },
                [14] = {
                    label = "Teal Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_14"
                },
                [15] = {
                    label = "Cyan Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_15"
                },
                [16] = {
                    label = "Light Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_16"
                },
                [17] = {
                    label = "Lilac Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_17"
                },
                [18] = {
                    label = "Dark Green Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_18"
                },
                [19] = {
                    label = "Emerald Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_19"
                },
                [20] = {
                    label = "Moss Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_20"
                },
                [21] = {
                    label = "Lime Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_21"
                },
                [22] = {
                    label = "Peach Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_22"
                },
                [23] = {
                    label = "Lavender Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_23"
                },
                [24] = {
                    label = "Purple Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_24"
                },
                [25] = {
                    label = "Magenta Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_25"
                },
                [26] = {
                    label = "Hat (168-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_168_26"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Yeti Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_0"
                },
                [1] = {
                    label = "Woodland Yeti Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_1"
                },
                [2] = {
                    label = "Green FB Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_2"
                },
                [3] = {
                    label = "Blue FB Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_3"
                },
                [4] = {
                    label = "Gray Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_4"
                },
                [5] = {
                    label = "Green Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_5"
                },
                [6] = {
                    label = "Light Plaid Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_6"
                },
                [7] = {
                    label = "Dark Plaid Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_7"
                },
                [8] = {
                    label = "White Striped Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_8"
                },
                [9] = {
                    label = "Red Striped Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_9"
                },
                [10] = {
                    label = "Brown Crevis Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_10"
                },
                [11] = {
                    label = "Gray Crevis Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_11"
                },
                [12] = {
                    label = "Black Broker Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_12"
                },
                [13] = {
                    label = "Burgundy Broker Flat Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_13"
                },
                [14] = {
                    label = "Hat (169-14)",
                    price = 500,
                    type = "money",
                    image = "female_hat_169_14"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_170_0"
                },
                [1] = {
                    label = "Hat (170-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_170_1"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Strickler Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_171_0"
                },
                [1] = {
                    label = "Hat (171-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_171_1"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_0"
                },
                [1] = {
                    label = "Dark Gray Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_1"
                },
                [2] = {
                    label = "Gray Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_2"
                },
                [3] = {
                    label = "Ice Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_3"
                },
                [4] = {
                    label = "Beige Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_4"
                },
                [5] = {
                    label = "Chocolate Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_5"
                },
                [6] = {
                    label = "Burgundy Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_6"
                },
                [7] = {
                    label = "Hot Pink Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_7"
                },
                [8] = {
                    label = "Scarlet Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_8"
                },
                [9] = {
                    label = "Orange Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_9"
                },
                [10] = {
                    label = "Amber Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_10"
                },
                [11] = {
                    label = "Lemon Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_11"
                },
                [12] = {
                    label = "Royal Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_12"
                },
                [13] = {
                    label = "Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_13"
                },
                [14] = {
                    label = "Teal Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_14"
                },
                [15] = {
                    label = "Cyan Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_15"
                },
                [16] = {
                    label = "Light Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_16"
                },
                [17] = {
                    label = "Lilac Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_17"
                },
                [18] = {
                    label = "Dark Green Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_18"
                },
                [19] = {
                    label = "Emerald Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_19"
                },
                [20] = {
                    label = "Moss Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_20"
                },
                [21] = {
                    label = "Lime Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_21"
                },
                [22] = {
                    label = "Peach Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_22"
                },
                [23] = {
                    label = "Lavender Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_23"
                },
                [24] = {
                    label = "Purple Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_24"
                },
                [25] = {
                    label = "Magenta Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_25"
                },
                [26] = {
                    label = "Hat (172-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_172_26"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_0"
                },
                [1] = {
                    label = "Dark Gray Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_1"
                },
                [2] = {
                    label = "Gray Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_2"
                },
                [3] = {
                    label = "Ice Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_3"
                },
                [4] = {
                    label = "Beige Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_4"
                },
                [5] = {
                    label = "Chocolate Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_5"
                },
                [6] = {
                    label = "Burgundy Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_6"
                },
                [7] = {
                    label = "Hot Pink Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_7"
                },
                [8] = {
                    label = "Scarlet Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_8"
                },
                [9] = {
                    label = "Orange Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_9"
                },
                [10] = {
                    label = "Amber Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_10"
                },
                [11] = {
                    label = "Lemon Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_11"
                },
                [12] = {
                    label = "Royal Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_12"
                },
                [13] = {
                    label = "Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_13"
                },
                [14] = {
                    label = "Teal Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_14"
                },
                [15] = {
                    label = "Cyan Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_15"
                },
                [16] = {
                    label = "Light Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_16"
                },
                [17] = {
                    label = "Lilac Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_17"
                },
                [18] = {
                    label = "Dark Green Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_18"
                },
                [19] = {
                    label = "Emerald Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_19"
                },
                [20] = {
                    label = "Moss Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_20"
                },
                [21] = {
                    label = "Lime Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_21"
                },
                [22] = {
                    label = "Peach Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_22"
                },
                [23] = {
                    label = "Lavender Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_23"
                },
                [24] = {
                    label = "Purple Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_24"
                },
                [25] = {
                    label = "Magenta Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_25"
                },
                [26] = {
                    label = "Hat (173-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_173_26"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_0"
                },
                [1] = {
                    label = "Dark Gray Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_1"
                },
                [2] = {
                    label = "Gray Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_2"
                },
                [3] = {
                    label = "Ice Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_3"
                },
                [4] = {
                    label = "Beige Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_4"
                },
                [5] = {
                    label = "Chocolate Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_5"
                },
                [6] = {
                    label = "Burgundy Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_6"
                },
                [7] = {
                    label = "Hot Pink Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_7"
                },
                [8] = {
                    label = "Scarlet Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_8"
                },
                [9] = {
                    label = "Orange Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_9"
                },
                [10] = {
                    label = "Amber Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_10"
                },
                [11] = {
                    label = "Lemon Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_11"
                },
                [12] = {
                    label = "Royal Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_12"
                },
                [13] = {
                    label = "Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_13"
                },
                [14] = {
                    label = "Teal Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_14"
                },
                [15] = {
                    label = "Cyan Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_15"
                },
                [16] = {
                    label = "Light Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_16"
                },
                [17] = {
                    label = "Lilac Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_17"
                },
                [18] = {
                    label = "Dark Green Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_18"
                },
                [19] = {
                    label = "Emerald Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_19"
                },
                [20] = {
                    label = "Moss Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_20"
                },
                [21] = {
                    label = "Lime Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_21"
                },
                [22] = {
                    label = "Peach Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_22"
                },
                [23] = {
                    label = "Lavender Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_23"
                },
                [24] = {
                    label = "Purple Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_24"
                },
                [25] = {
                    label = "Magenta Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_25"
                },
                [26] = {
                    label = "Hat (174-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_174_26"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (175-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_175_0"
                },
                [1] = {
                    label = "Hat (175-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_175_1"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (176-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_176_0"
                },
                [1] = {
                    label = "Hat (176-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_176_1"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Holly Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_177_0"
                },
                [1] = {
                    label = "Green Reindeer Beer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_177_1"
                },
                [2] = {
                    label = "Hat (177-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_177_2"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Dome",
                    price = 500,
                    type = "money",
                    image = "female_hat_178_0"
                },
                [1] = {
                    label = "Hat (178-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_178_1"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Snakeskin Spiked",
                    price = 500,
                    type = "money",
                    image = "female_hat_179_0"
                },
                [1] = {
                    label = "Hat (179-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_179_1"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_4"
                },
                [5] = {
                    label = "Pink Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_5"
                },
                [6] = {
                    label = "Cyan Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_6"
                },
                [7] = {
                    label = "Brown Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_7"
                },
                [8] = {
                    label = "Neon Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_8"
                },
                [9] = {
                    label = "Camo Roses Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_10"
                },
                [11] = {
                    label = "White Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_13"
                },
                [14] = {
                    label = "Blue Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_14"
                },
                [15] = {
                    label = "Green Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_15"
                },
                [16] = {
                    label = "Light Blue Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_16"
                },
                [17] = {
                    label = "Pink Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_17"
                },
                [18] = {
                    label = "Red Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_18"
                },
                [19] = {
                    label = "White Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_19"
                },
                [20] = {
                    label = "Blue Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_20"
                },
                [21] = {
                    label = "Black Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_21"
                },
                [22] = {
                    label = "Red Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_22"
                },
                [23] = {
                    label = "Taupe Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_23"
                },
                [24] = {
                    label = "Black Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_24"
                },
                [25] = {
                    label = "Green Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_25"
                },
                [26] = {
                    label = "Hat (180-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_180_26"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Neon Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_181_0"
                },
                [1] = {
                    label = "Blue Signs Squash Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_181_1"
                },
                [2] = {
                    label = "White Signs Squash Forwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_181_2"
                },
                [3] = {
                    label = "Hat (181-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_181_3"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_4"
                },
                [5] = {
                    label = "Pink Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_5"
                },
                [6] = {
                    label = "Cyan Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_6"
                },
                [7] = {
                    label = "Brown Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_7"
                },
                [8] = {
                    label = "Neon Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_8"
                },
                [9] = {
                    label = "Camo Roses Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_10"
                },
                [11] = {
                    label = "White Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_13"
                },
                [14] = {
                    label = "Blue Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_14"
                },
                [15] = {
                    label = "Green Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_15"
                },
                [16] = {
                    label = "Light Blue Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_16"
                },
                [17] = {
                    label = "Pink Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_17"
                },
                [18] = {
                    label = "Red Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_18"
                },
                [19] = {
                    label = "White Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_19"
                },
                [20] = {
                    label = "Blue Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_20"
                },
                [21] = {
                    label = "Black Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_21"
                },
                [22] = {
                    label = "Red Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_22"
                },
                [23] = {
                    label = "Taupe Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_23"
                },
                [24] = {
                    label = "Black Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_24"
                },
                [25] = {
                    label = "Green Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_25"
                },
                [26] = {
                    label = "Hat (182-26)",
                    price = 500,
                    type = "money",
                    image = "female_hat_182_26"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Neon Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_183_0"
                },
                [1] = {
                    label = "Blue Signs Squash Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_183_1"
                },
                [2] = {
                    label = "White Signs Squash Backwards",
                    price = 500,
                    type = "money",
                    image = "female_hat_183_2"
                },
                [3] = {
                    label = "Hat (183-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_183_3"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (184-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_184_0"
                },
                [1] = {
                    label = "Hat (184-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_184_1"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (185-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_185_0"
                },
                [1] = {
                    label = "Hat (185-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_185_1"
                },
                [2] = {
                    label = "Hat (185-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_185_2"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Pounders Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_186_0"
                },
                [1] = {
                    label = "Hat (186-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_186_1"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Pounders Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_187_0"
                },
                [1] = {
                    label = "Hat (187-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_187_1"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Alpine Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_188_0"
                },
                [1] = {
                    label = "Hat (188-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_188_1"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Car Meet Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_0"
                },
                [1] = {
                    label = "VIP Charter Jets Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_1"
                },
                [2] = {
                    label = "Cliffford Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_2"
                },
                [3] = {
                    label = "Maisonette Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_3"
                },
                [4] = {
                    label = "Rootin' Tootin' Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_4"
                },
                [5] = {
                    label = "LS Angels Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_5"
                },
                [6] = {
                    label = "IAA Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_6"
                },
                [7] = {
                    label = "Captain Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_7"
                },
                [8] = {
                    label = "PDM Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_8"
                },
                [9] = {
                    label = "Flying Bravo Andreas Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_9"
                },
                [10] = {
                    label = "Green LS Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_10"
                },
                [11] = {
                    label = "Peter Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_11"
                },
                [12] = {
                    label = "Survivalist Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_12"
                },
                [13] = {
                    label = "Grotti Furia Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_13"
                },
                [14] = {
                    label = "Black Eagle Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_14"
                },
                [15] = {
                    label = "Deathmatch Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_15"
                },
                [16] = {
                    label = "Hat (189-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_189_16"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Car Meet Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_0"
                },
                [1] = {
                    label = "VIP Charter Jets Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_1"
                },
                [2] = {
                    label = "Cliffford Logo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_2"
                },
                [3] = {
                    label = "Maisonette Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_3"
                },
                [4] = {
                    label = "Rootin' Tootin' Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_4"
                },
                [5] = {
                    label = "LS Angels Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_5"
                },
                [6] = {
                    label = "IAA Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_6"
                },
                [7] = {
                    label = "Captain Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_7"
                },
                [8] = {
                    label = "PDM Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_8"
                },
                [9] = {
                    label = "Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_9"
                },
                [10] = {
                    label = "Green LS Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_10"
                },
                [11] = {
                    label = "Peter Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_11"
                },
                [12] = {
                    label = "Survivalist Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_12"
                },
                [13] = {
                    label = "Grotti Furia Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_13"
                },
                [14] = {
                    label = "Black Eagle Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_14"
                },
                [15] = {
                    label = "Deathmatch Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_15"
                },
                [16] = {
                    label = "Hat (190-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_190_16"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Vom Feuer Camo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_191_0"
                },
                [1] = {
                    label = "Western MC Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_191_1"
                },
                [2] = {
                    label = "Red & White Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_191_2"
                },
                [3] = {
                    label = "Santo Capra Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_191_3"
                },
                [4] = {
                    label = "Hat (191-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_191_4"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Vom Feuer Camo Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_192_0"
                },
                [1] = {
                    label = "Western MC Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_192_1"
                },
                [2] = {
                    label = "Red & White Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_192_2"
                },
                [3] = {
                    label = "Santo Capra Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_192_3"
                },
                [4] = {
                    label = "Hat (192-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_192_4"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Junk Energy Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_193_0"
                },
                [1] = {
                    label = "Hat (193-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_193_1"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Rockstar Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_194_0"
                },
                [1] = {
                    label = "Hat (194-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_194_1"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Rockstar Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_195_0"
                },
                [1] = {
                    label = "Hat (195-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_195_1"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (196-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_196_0"
                },
                [1] = {
                    label = "Hat (196-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_196_1"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Fireworks Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_197_0"
                },
                [1] = {
                    label = "Stars and Stripes Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_197_1"
                },
                [2] = {
                    label = "Lady Liberty Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_197_2"
                },
                [3] = {
                    label = "Bigness Carnival Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_197_3"
                },
                [4] = {
                    label = "Hat (197-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_197_4"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'prop',
            textures = {
                [0] = {
                    label = "CMYK Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_0"
                },
                [1] = {
                    label = "Sunset Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_1"
                },
                [2] = {
                    label = "Vibrant Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_2"
                },
                [3] = {
                    label = "Cool Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_3"
                },
                [4] = {
                    label = "Bright Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_4"
                },
                [5] = {
                    label = "Cool Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_5"
                },
                [6] = {
                    label = "Red Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_6"
                },
                [7] = {
                    label = "Yellow Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_7"
                },
                [8] = {
                    label = "Orange Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_8"
                },
                [9] = {
                    label = "Blue Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_9"
                },
                [10] = {
                    label = "Bold Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_10"
                },
                [11] = {
                    label = "Vibrant Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_11"
                },
                [12] = {
                    label = "Vivid Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_12"
                },
                [13] = {
                    label = "Neon Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_13"
                },
                [14] = {
                    label = "Warm Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_14"
                },
                [15] = {
                    label = "Wild Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_15"
                },
                [16] = {
                    label = "Hat (198-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_198_16"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'prop',
            textures = {
                [0] = {
                    label = "CMYK Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_0"
                },
                [1] = {
                    label = "Sunset Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_1"
                },
                [2] = {
                    label = "Vibrant Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_2"
                },
                [3] = {
                    label = "Cool Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_3"
                },
                [4] = {
                    label = "Bright Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_4"
                },
                [5] = {
                    label = "Cool Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_5"
                },
                [6] = {
                    label = "Red Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_6"
                },
                [7] = {
                    label = "Yellow Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_7"
                },
                [8] = {
                    label = "Orange Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_8"
                },
                [9] = {
                    label = "Blue Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_9"
                },
                [10] = {
                    label = "Bold Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_10"
                },
                [11] = {
                    label = "Vibrant Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_11"
                },
                [12] = {
                    label = "Vivid Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_12"
                },
                [13] = {
                    label = "Neon Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_13"
                },
                [14] = {
                    label = "Warm Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_14"
                },
                [15] = {
                    label = "Wild Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_15"
                },
                [16] = {
                    label = "Hat (199-16)",
                    price = 500,
                    type = "money",
                    image = "female_hat_199_16"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Los Santos Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_200_0"
                },
                [1] = {
                    label = "Black LS Customs Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_200_1"
                },
                [2] = {
                    label = "Hat (200-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_200_2"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Los Santos Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_201_0"
                },
                [1] = {
                    label = "Black LS Customs Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_201_1"
                },
                [2] = {
                    label = "Hat (201-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_201_2"
                },
            },
        },
        [202] = {
            drawable = 202,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Festive Reindeer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_202_0"
                },
                [1] = {
                    label = "White Festive Reindeer Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_202_1"
                },
                [2] = {
                    label = "Hat (202-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_202_2"
                },
            },
        },
        [203] = {
            drawable = 203,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Green Festive Tree Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_203_0"
                },
                [1] = {
                    label = "Red Festive Tree Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_203_1"
                },
                [2] = {
                    label = "Hat (203-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_203_2"
                },
            },
        },
        [204] = {
            drawable = 204,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (204-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_204_0"
                },
                [1] = {
                    label = "Hat (204-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_204_1"
                },
                [2] = {
                    label = "Hat (204-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_204_2"
                },
                [3] = {
                    label = "Hat (204-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_204_3"
                },
                [4] = {
                    label = "Hat (204-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_204_4"
                },
            },
        },
        [205] = {
            drawable = 205,
            type = 'prop',
            textures = {
                [0] = {
                    label = "1 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_0"
                },
                [1] = {
                    label = "2 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_1"
                },
                [2] = {
                    label = "3 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_2"
                },
                [3] = {
                    label = "4 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_3"
                },
                [4] = {
                    label = "5 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_4"
                },
                [5] = {
                    label = "6 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_5"
                },
                [6] = {
                    label = "7 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_6"
                },
                [7] = {
                    label = "8 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_7"
                },
                [8] = {
                    label = "9 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_8"
                },
                [9] = {
                    label = "10 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_9"
                },
                [10] = {
                    label = "11 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_10"
                },
                [11] = {
                    label = "12 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_11"
                },
                [12] = {
                    label = "13 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_12"
                },
                [13] = {
                    label = "14 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_13"
                },
                [14] = {
                    label = "15 Party Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_14"
                },
                [15] = {
                    label = "Hat (205-15)",
                    price = 500,
                    type = "money",
                    image = "female_hat_205_15"
                },
            },
        },
        [206] = {
            drawable = 206,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Heartbreakers Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_206_0"
                },
                [1] = {
                    label = "Red's Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_206_1"
                },
                [2] = {
                    label = "Hat (206-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_206_2"
                },
            },
        },
        [207] = {
            drawable = 207,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Heartbreakers Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_207_0"
                },
                [1] = {
                    label = "Red's Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_207_1"
                },
                [2] = {
                    label = "Hat (207-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_207_2"
                },
            },
        },
        [208] = {
            drawable = 208,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bronze New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_208_0"
                },
                [1] = {
                    label = "Gold New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_208_1"
                },
                [2] = {
                    label = "Silver New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_208_2"
                },
                [3] = {
                    label = "Hat (208-3)",
                    price = 500,
                    type = "money",
                    image = "female_hat_208_3"
                },
            },
        },
        [209] = {
            drawable = 209,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (209-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_0"
                },
                [1] = {
                    label = "Hat (209-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_1"
                },
                [2] = {
                    label = "Hat (209-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_2"
                },
                [3] = {
                    label = "Strapz Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_3"
                },
                [4] = {
                    label = "Black 420 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_4"
                },
                [5] = {
                    label = "Hat (209-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_209_5"
                },
            },
        },
        [210] = {
            drawable = 210,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (210-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_0"
                },
                [1] = {
                    label = "Hat (210-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_1"
                },
                [2] = {
                    label = "Hat (210-2)",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_2"
                },
                [3] = {
                    label = "Strapz Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_3"
                },
                [4] = {
                    label = "Black 420 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_4"
                },
                [5] = {
                    label = "Hat (210-5)",
                    price = 500,
                    type = "money",
                    image = "female_hat_210_5"
                },
            },
        },
        [211] = {
            drawable = 211,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_211_0"
                },
                [1] = {
                    label = "Hat (211-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_211_1"
                },
            },
        },
        [212] = {
            drawable = 212,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_212_0"
                },
                [1] = {
                    label = "Hat (212-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_212_1"
                },
            },
        },
        [213] = {
            drawable = 213,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (213-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_213_0"
                },
                [1] = {
                    label = "Hat (213-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_213_1"
                },
            },
        },
        [214] = {
            drawable = 214,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (214-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_214_0"
                },
                [1] = {
                    label = "Hat (214-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_214_1"
                },
            },
        },
        [215] = {
            drawable = 215,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Beige Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_215_0"
                },
                [1] = {
                    label = "Cream Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_215_1"
                },
                [2] = {
                    label = "Gray Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_215_2"
                },
                [3] = {
                    label = "Black Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_215_3"
                },
                [4] = {
                    label = "Hat (215-4)",
                    price = 500,
                    type = "money",
                    image = "female_hat_215_4"
                },
            },
        },
        [216] = {
            drawable = 216,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pizza This... Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_216_0"
                },
                [1] = {
                    label = "Hat (216-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_216_1"
                },
            },
        },
        [217] = {
            drawable = 217,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pizza This... Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "female_hat_217_0"
                },
                [1] = {
                    label = "Hat (217-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_217_1"
                },
            },
        },
        [218] = {
            drawable = 218,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Alpine Hat",
                    price = 500,
                    type = "money",
                    image = "female_hat_218_0"
                },
                [1] = {
                    label = "Hat (218-1)",
                    price = 500,
                    type = "money",
                    image = "female_hat_218_1"
                },
            },
        },
        [219] = {
            drawable = 219,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_1"
                },
                [2] = {
                    label = "Black Cimicino Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_2"
                },
                [3] = {
                    label = "White Cimicino Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_3"
                },
                [4] = {
                    label = "Green FB Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_4"
                },
                [5] = {
                    label = "Blue FB Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_5"
                },
                [6] = {
                    label = "Red FB Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_6"
                },
                [7] = {
                    label = "Black Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_7"
                },
                [8] = {
                    label = "White Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_8"
                },
                [9] = {
                    label = "Cyan Leopard Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_9"
                },
                [10] = {
                    label = "Krapea Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_10"
                },
                [11] = {
                    label = "Black LC Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_11"
                },
                [12] = {
                    label = "White LC Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_12"
                },
                [13] = {
                    label = "Purple Panic Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_13"
                },
                [14] = {
                    label = "Yellow Panic Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_14"
                },
                [15] = {
                    label = "Black SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_15"
                },
                [16] = {
                    label = "Blue SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_16"
                },
                [17] = {
                    label = "Pink SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_17"
                },
                [18] = {
                    label = "Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_18"
                },
                [19] = {
                    label = "Gray Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_19"
                },
                [20] = {
                    label = "Pink Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_20"
                },
                [21] = {
                    label = "Hat (219-21)",
                    price = 500,
                    type = "money",
                    image = "female_hat_219_21"
                },
            },
        },
        [220] = {
            drawable = 220,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (220-0)",
                    price = 500,
                    type = "money",
                    image = "female_hat_220_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_0"
                },
                [1] = {
                    label = "Hat (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_1"
                },
                [2] = {
                    label = "Hat (0-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_2"
                },
                [3] = {
                    label = "Hat (0-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_3"
                },
                [4] = {
                    label = "Hat (0-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_4"
                },
                [5] = {
                    label = "Hat (0-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_5"
                },
                [6] = {
                    label = "Hat (0-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_6"
                },
                [7] = {
                    label = "Hat (0-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_7"
                },
                [8] = {
                    label = "Hat (0-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_0_8"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_1_0"
                },
                [1] = {
                    label = "Hat (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_1_1"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_0"
                },
                [1] = {
                    label = "Hat (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_1"
                },
                [2] = {
                    label = "Hat (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_2"
                },
                [3] = {
                    label = "Hat (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_3"
                },
                [4] = {
                    label = "Hat (2-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_4"
                },
                [5] = {
                    label = "Hat (2-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_5"
                },
                [6] = {
                    label = "Hat (2-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_6"
                },
                [7] = {
                    label = "Hat (2-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_7"
                },
                [8] = {
                    label = "Hat (2-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_2_8"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_0"
                },
                [1] = {
                    label = "Hat (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_1"
                },
                [2] = {
                    label = "Hat (3-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_2"
                },
                [3] = {
                    label = "Hat (3-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_3"
                },
                [4] = {
                    label = "Hat (3-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_4"
                },
                [5] = {
                    label = "Hat (3-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_5"
                },
                [6] = {
                    label = "Hat (3-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_6"
                },
                [7] = {
                    label = "Hat (3-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_7"
                },
                [8] = {
                    label = "Hat (3-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_3_8"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_0"
                },
                [1] = {
                    label = "Hat (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_1"
                },
                [2] = {
                    label = "Hat (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_2"
                },
                [3] = {
                    label = "Hat (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_3"
                },
                [4] = {
                    label = "Hat (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_4"
                },
                [5] = {
                    label = "Hat (4-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_5"
                },
                [6] = {
                    label = "Hat (4-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_6"
                },
                [7] = {
                    label = "Hat (4-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_7"
                },
                [8] = {
                    label = "Hat (4-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_4_8"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_0"
                },
                [1] = {
                    label = "Hat (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_1"
                },
                [2] = {
                    label = "Hat (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_2"
                },
                [3] = {
                    label = "Hat (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_3"
                },
                [4] = {
                    label = "Hat (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_4"
                },
                [5] = {
                    label = "Hat (5-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_5"
                },
                [6] = {
                    label = "Hat (5-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_6"
                },
                [7] = {
                    label = "Hat (5-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_7"
                },
                [8] = {
                    label = "Hat (5-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_5_8"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_0"
                },
                [1] = {
                    label = "Hat (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_1"
                },
                [2] = {
                    label = "Hat (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_2"
                },
                [3] = {
                    label = "Hat (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_3"
                },
                [4] = {
                    label = "Hat (6-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_4"
                },
                [5] = {
                    label = "Hat (6-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_5"
                },
                [6] = {
                    label = "Hat (6-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_6"
                },
                [7] = {
                    label = "Hat (6-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_7"
                },
                [8] = {
                    label = "Hat (6-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_6_8"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_0"
                },
                [1] = {
                    label = "Hat (7-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_1"
                },
                [2] = {
                    label = "Hat (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_2"
                },
                [3] = {
                    label = "Hat (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_3"
                },
                [4] = {
                    label = "Hat (7-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_4"
                },
                [5] = {
                    label = "Hat (7-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_5"
                },
                [6] = {
                    label = "Hat (7-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_6"
                },
                [7] = {
                    label = "Hat (7-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_7"
                },
                [8] = {
                    label = "Hat (7-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_7_8"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (8-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_0"
                },
                [1] = {
                    label = "Hat (8-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_1"
                },
                [2] = {
                    label = "Hat (8-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_2"
                },
                [3] = {
                    label = "Hat (8-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_3"
                },
                [4] = {
                    label = "Hat (8-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_4"
                },
                [5] = {
                    label = "Hat (8-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_5"
                },
                [6] = {
                    label = "Hat (8-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_6"
                },
                [7] = {
                    label = "Hat (8-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_7"
                },
                [8] = {
                    label = "Hat (8-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_8_8"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (9-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_0"
                },
                [1] = {
                    label = "Hat (9-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_1"
                },
                [2] = {
                    label = "Hat (9-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_2"
                },
                [3] = {
                    label = "Hat (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_3"
                },
                [4] = {
                    label = "Hat (9-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_4"
                },
                [5] = {
                    label = "Hat (9-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_5"
                },
                [6] = {
                    label = "Hat (9-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_6"
                },
                [7] = {
                    label = "Hat (9-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_7"
                },
                [8] = {
                    label = "Hat (9-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_9_8"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (10-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_0"
                },
                [1] = {
                    label = "Hat (10-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_1"
                },
                [2] = {
                    label = "Hat (10-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_2"
                },
                [3] = {
                    label = "Hat (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_3"
                },
                [4] = {
                    label = "Hat (10-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_4"
                },
                [5] = {
                    label = "Hat (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_5"
                },
                [6] = {
                    label = "Hat (10-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_6"
                },
                [7] = {
                    label = "Hat (10-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_7"
                },
                [8] = {
                    label = "Hat (10-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_10_8"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (11-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_0"
                },
                [1] = {
                    label = "Hat (11-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_1"
                },
                [2] = {
                    label = "Hat (11-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_2"
                },
                [3] = {
                    label = "Hat (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_3"
                },
                [4] = {
                    label = "Hat (11-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_4"
                },
                [5] = {
                    label = "Hat (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_5"
                },
                [6] = {
                    label = "Hat (11-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_6"
                },
                [7] = {
                    label = "Hat (11-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_7"
                },
                [8] = {
                    label = "Hat (11-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_11_8"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (12-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_0"
                },
                [1] = {
                    label = "Hat (12-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_1"
                },
                [2] = {
                    label = "Hat (12-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_2"
                },
                [3] = {
                    label = "Hat (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_3"
                },
                [4] = {
                    label = "Hat (12-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_4"
                },
                [5] = {
                    label = "Hat (12-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_5"
                },
                [6] = {
                    label = "Hat (12-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_6"
                },
                [7] = {
                    label = "Hat (12-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_7"
                },
                [8] = {
                    label = "Hat (12-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_12_8"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (13-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_0"
                },
                [1] = {
                    label = "Hat (13-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_1"
                },
                [2] = {
                    label = "Hat (13-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_2"
                },
                [3] = {
                    label = "Hat (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_3"
                },
                [4] = {
                    label = "Hat (13-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_4"
                },
                [5] = {
                    label = "Hat (13-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_5"
                },
                [6] = {
                    label = "Hat (13-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_6"
                },
                [7] = {
                    label = "Hat (13-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_7"
                },
                [8] = {
                    label = "Hat (13-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_13_8"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (14-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_0"
                },
                [1] = {
                    label = "Hat (14-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_1"
                },
                [2] = {
                    label = "Hat (14-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_2"
                },
                [3] = {
                    label = "Hat (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_3"
                },
                [4] = {
                    label = "Hat (14-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_4"
                },
                [5] = {
                    label = "Hat (14-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_5"
                },
                [6] = {
                    label = "Hat (14-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_6"
                },
                [7] = {
                    label = "Hat (14-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_7"
                },
                [8] = {
                    label = "Hat (14-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_14_8"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (15-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_0"
                },
                [1] = {
                    label = "Hat (15-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_1"
                },
                [2] = {
                    label = "Hat (15-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_2"
                },
                [3] = {
                    label = "Hat (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_3"
                },
                [4] = {
                    label = "Hat (15-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_4"
                },
                [5] = {
                    label = "Hat (15-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_5"
                },
                [6] = {
                    label = "Hat (15-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_6"
                },
                [7] = {
                    label = "Hat (15-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_7"
                },
                [8] = {
                    label = "Hat (15-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_15_8"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (16-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_0"
                },
                [1] = {
                    label = "Hat (16-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_1"
                },
                [2] = {
                    label = "Hat (16-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_2"
                },
                [3] = {
                    label = "Hat (16-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_3"
                },
                [4] = {
                    label = "Hat (16-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_4"
                },
                [5] = {
                    label = "Hat (16-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_5"
                },
                [6] = {
                    label = "Hat (16-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_6"
                },
                [7] = {
                    label = "Hat (16-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_7"
                },
                [8] = {
                    label = "Hat (16-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_16_8"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (17-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_0"
                },
                [1] = {
                    label = "Hat (17-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_1"
                },
                [2] = {
                    label = "Hat (17-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_2"
                },
                [3] = {
                    label = "Hat (17-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_3"
                },
                [4] = {
                    label = "Hat (17-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_4"
                },
                [5] = {
                    label = "Hat (17-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_5"
                },
                [6] = {
                    label = "Hat (17-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_6"
                },
                [7] = {
                    label = "Hat (17-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_7"
                },
                [8] = {
                    label = "Hat (17-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_17_8"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (18-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_0"
                },
                [1] = {
                    label = "Hat (18-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_1"
                },
                [2] = {
                    label = "Hat (18-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_2"
                },
                [3] = {
                    label = "Hat (18-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_3"
                },
                [4] = {
                    label = "Hat (18-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_4"
                },
                [5] = {
                    label = "Hat (18-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_5"
                },
                [6] = {
                    label = "Hat (18-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_6"
                },
                [7] = {
                    label = "Hat (18-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_7"
                },
                [8] = {
                    label = "Hat (18-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_18_8"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (19-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_19_0"
                },
                [1] = {
                    label = "Hat (19-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_19_1"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Green Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_0"
                },
                [1] = {
                    label = "Gray Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_1"
                },
                [2] = {
                    label = "Hinterland Urban Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_2"
                },
                [3] = {
                    label = "Red Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_3"
                },
                [4] = {
                    label = "Floral Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_4"
                },
                [5] = {
                    label = "Woodland Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_5"
                },
                [6] = {
                    label = "Hat (20-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_20_6"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_0"
                },
                [1] = {
                    label = "Brown Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_1"
                },
                [2] = {
                    label = "Zorse Gray Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_2"
                },
                [3] = {
                    label = "White Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_3"
                },
                [4] = {
                    label = "Ushero Purple Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_4"
                },
                [5] = {
                    label = "Black Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_5"
                },
                [6] = {
                    label = "Green Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_6"
                },
                [7] = {
                    label = "Blue Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_7"
                },
                [8] = {
                    label = "Hat (21-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_21_8"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Santa Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_22_0"
                },
                [1] = {
                    label = "Green Santa Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_22_1"
                },
                [2] = {
                    label = "Hat (22-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_22_2"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Elf Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_23_0"
                },
                [1] = {
                    label = "Hat (23-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_23_1"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Reindeer Antlers",
                    price = 500,
                    type = "money",
                    image = "male_hat_24_0"
                },
                [1] = {
                    label = "Hat (24-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_24_1"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Navy Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_25_0"
                },
                [1] = {
                    label = "Charcoal Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_25_1"
                },
                [2] = {
                    label = "Brown Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_25_2"
                },
                [3] = {
                    label = "Hat (25-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_25_3"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_0"
                },
                [1] = {
                    label = "Gray Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_1"
                },
                [2] = {
                    label = "Blue Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_2"
                },
                [3] = {
                    label = "Light Gray Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_3"
                },
                [4] = {
                    label = "Olive Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_4"
                },
                [5] = {
                    label = "Purple Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_5"
                },
                [6] = {
                    label = "Lobster Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_6"
                },
                [7] = {
                    label = "Brown Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_7"
                },
                [8] = {
                    label = "Vintage Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_8"
                },
                [9] = {
                    label = "Cream Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_9"
                },
                [10] = {
                    label = "Ash Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_10"
                },
                [11] = {
                    label = "Navy Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_11"
                },
                [12] = {
                    label = "Silver Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_12"
                },
                [13] = {
                    label = "White Bowler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_13"
                },
                [14] = {
                    label = "Hat (26-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_26_14"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_0"
                },
                [1] = {
                    label = "Gray Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_1"
                },
                [2] = {
                    label = "Blue Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_2"
                },
                [3] = {
                    label = "Light Gray Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_3"
                },
                [4] = {
                    label = "Olive Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_4"
                },
                [5] = {
                    label = "Purple Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_5"
                },
                [6] = {
                    label = "Lobster Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_6"
                },
                [7] = {
                    label = "Brown Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_7"
                },
                [8] = {
                    label = "Vintage Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_8"
                },
                [9] = {
                    label = "Cream Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_9"
                },
                [10] = {
                    label = "Ash Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_10"
                },
                [11] = {
                    label = "Navy Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_11"
                },
                [12] = {
                    label = "Silver Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_12"
                },
                [13] = {
                    label = "White Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_13"
                },
                [14] = {
                    label = "Hat (27-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_27_14"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_0"
                },
                [1] = {
                    label = "White Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_1"
                },
                [2] = {
                    label = "Red Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_2"
                },
                [3] = {
                    label = "Lime Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_3"
                },
                [4] = {
                    label = "Purple Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_4"
                },
                [5] = {
                    label = "Yellow Saggy Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_5"
                },
                [6] = {
                    label = "Hat (28-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_28_6"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_0"
                },
                [1] = {
                    label = "Black Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_1"
                },
                [2] = {
                    label = "White Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_2"
                },
                [3] = {
                    label = "Cream Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_3"
                },
                [4] = {
                    label = "Red Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_4"
                },
                [5] = {
                    label = "Black & Red Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_5"
                },
                [6] = {
                    label = "Brown Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_6"
                },
                [7] = {
                    label = "Blue Trilby",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_7"
                },
                [8] = {
                    label = "Hat (29-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_29_8"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_30_0"
                },
                [1] = {
                    label = "Pink Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_30_1"
                },
                [2] = {
                    label = "Hat (30-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_30_2"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_31_0"
                },
                [1] = {
                    label = "Hat (31-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_31_1"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Top Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_32_0"
                },
                [1] = {
                    label = "Hat (32-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_32_1"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Top Foam Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_33_0"
                },
                [1] = {
                    label = "Blue Top Foam Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_33_1"
                },
                [2] = {
                    label = "Hat (33-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_33_2"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Patriotic Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_34_0"
                },
                [1] = {
                    label = "Hat (34-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_34_1"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Crown",
                    price = 500,
                    type = "money",
                    image = "male_hat_35_0"
                },
                [1] = {
                    label = "Hat (35-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_35_1"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "USA Boppers",
                    price = 500,
                    type = "money",
                    image = "male_hat_36_0"
                },
                [1] = {
                    label = "Hat (36-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_36_1"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pisswasser Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_0"
                },
                [1] = {
                    label = "Benedict Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_1"
                },
                [2] = {
                    label = "J Lager Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_2"
                },
                [3] = {
                    label = "Patriot Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_3"
                },
                [4] = {
                    label = "Blarneys Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_4"
                },
                [5] = {
                    label = "Supa Wet Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_5"
                },
                [6] = {
                    label = "Hat (37-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_37_6"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_38_0"
                },
                [1] = {
                    label = "Hat (38-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_38_1"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bulletproof",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_0"
                },
                [1] = {
                    label = "Gray Bulletproof",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_1"
                },
                [2] = {
                    label = "Charcoal Bulletproof",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_2"
                },
                [3] = {
                    label = "Tan Bulletproof",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_3"
                },
                [4] = {
                    label = "Forest Bulletproof",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_4"
                },
                [5] = {
                    label = "Hat (39-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_39_5"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Classic Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_0"
                },
                [1] = {
                    label = "Purple Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_1"
                },
                [2] = {
                    label = "Holly Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_2"
                },
                [3] = {
                    label = "Red Stripy Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_3"
                },
                [4] = {
                    label = "Green Stripy Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_4"
                },
                [5] = {
                    label = "Star Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_5"
                },
                [6] = {
                    label = "Santa Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_6"
                },
                [7] = {
                    label = "Elf Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_7"
                },
                [8] = {
                    label = "Hat (40-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_40_8"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pudding Woolly Knit",
                    price = 500,
                    type = "money",
                    image = "male_hat_41_0"
                },
                [1] = {
                    label = "Hat (41-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_41_1"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cheeky Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "male_hat_42_0"
                },
                [1] = {
                    label = "Naughty Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "male_hat_42_1"
                },
                [2] = {
                    label = "Happy Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "male_hat_42_2"
                },
                [3] = {
                    label = "Silly Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "male_hat_42_3"
                },
                [4] = {
                    label = "Hat (42-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_42_4"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Clan Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "male_hat_43_0"
                },
                [1] = {
                    label = "Highland Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "male_hat_43_1"
                },
                [2] = {
                    label = "Chieftain Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "male_hat_43_2"
                },
                [3] = {
                    label = "Heritage Tartan Bobble",
                    price = 500,
                    type = "money",
                    image = "male_hat_43_3"
                },
                [4] = {
                    label = "Hat (43-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_43_4"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Naughty Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_0"
                },
                [1] = {
                    label = "Black Ho Ho Ho Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_1"
                },
                [2] = {
                    label = "Blue Snowflake Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_2"
                },
                [3] = {
                    label = "Nice Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_3"
                },
                [4] = {
                    label = "Green Ho Ho Ho Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_4"
                },
                [5] = {
                    label = "Red Snowflake Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_5"
                },
                [6] = {
                    label = "Gingerbread Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_6"
                },
                [7] = {
                    label = "Bah Humbug Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_7"
                },
                [8] = {
                    label = "Hat (44-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_44_8"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Naughty Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_0"
                },
                [1] = {
                    label = "Black Ho Ho Ho Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_1"
                },
                [2] = {
                    label = "Blue Snowflake Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_2"
                },
                [3] = {
                    label = "Nice Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_3"
                },
                [4] = {
                    label = "Green Ho Ho Ho Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_4"
                },
                [5] = {
                    label = "Red Snowflake Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_5"
                },
                [6] = {
                    label = "Gingerbread Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_6"
                },
                [7] = {
                    label = "Bah Humbug Flipped Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_7"
                },
                [8] = {
                    label = "Hat (45-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_45_8"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (46-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_46_0"
                },
                [1] = {
                    label = "Hat (46-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_46_1"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_47_0"
                },
                [1] = {
                    label = "Hat (47-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_47_1"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Black Off-road",
                    price = 500,
                    type = "money",
                    image = "male_hat_48_0"
                },
                [1] = {
                    label = "Hat (48-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_48_1"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Black Off-road",
                    price = 500,
                    type = "money",
                    image = "male_hat_49_0"
                },
                [1] = {
                    label = "Hat (49-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy All Black Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_50_0"
                },
                [1] = {
                    label = "Hat (50-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_50_1"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_51_0"
                },
                [1] = {
                    label = "Hat (51-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_51_1"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte All Black Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_52_0"
                },
                [1] = {
                    label = "Hat (52-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_53_0"
                },
                [1] = {
                    label = "Hat (53-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_53_1"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (54-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_54_0"
                },
                [1] = {
                    label = "Hat (54-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_54_1"
                },
                [2] = {
                    label = "Hat (54-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_54_2"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_0"
                },
                [1] = {
                    label = "Charcoal Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_1"
                },
                [2] = {
                    label = "Cream Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_2"
                },
                [3] = {
                    label = "Navy Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_3"
                },
                [4] = {
                    label = "Brown Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_4"
                },
                [5] = {
                    label = "Brown Harsh Souls Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_5"
                },
                [6] = {
                    label = "Orange Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_6"
                },
                [7] = {
                    label = "Blue Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_7"
                },
                [8] = {
                    label = "Stripy Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_8"
                },
                [9] = {
                    label = "Link Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_9"
                },
                [10] = {
                    label = "Diamond Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_10"
                },
                [11] = {
                    label = "Cherry Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_11"
                },
                [12] = {
                    label = "Tan Fruntalot Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_12"
                },
                [13] = {
                    label = "Green Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_13"
                },
                [14] = {
                    label = "Jungle Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_14"
                },
                [15] = {
                    label = "Forest Trickster Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_15"
                },
                [16] = {
                    label = "Coffee Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_16"
                },
                [17] = {
                    label = "Dual Trey Baker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_17"
                },
                [18] = {
                    label = "Gray Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_18"
                },
                [19] = {
                    label = "Cream Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_19"
                },
                [20] = {
                    label = "Red Yeti Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_20"
                },
                [21] = {
                    label = "White Harsh Souls Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_21"
                },
                [22] = {
                    label = "Navy Fruntalot Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_22"
                },
                [23] = {
                    label = "Yellow Sweatbox Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_23"
                },
                [24] = {
                    label = "All Black Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_24"
                },
                [25] = {
                    label = "Black Broker Snapback",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_25"
                },
                [26] = {
                    label = "Hat (55-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_55_26"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Magnetics Script Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_0"
                },
                [1] = {
                    label = "Magnetics Block Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_1"
                },
                [2] = {
                    label = "Low Santos Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_2"
                },
                [3] = {
                    label = "Boars Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_3"
                },
                [4] = {
                    label = "Benny's Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_4"
                },
                [5] = {
                    label = "Westside Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_5"
                },
                [6] = {
                    label = "Eastside Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_6"
                },
                [7] = {
                    label = "Strawberry Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_7"
                },
                [8] = {
                    label = "Black SA Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_8"
                },
                [9] = {
                    label = "Davis Fitted Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_9"
                },
                [10] = {
                    label = "Hat (56-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_56_10"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (57-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_57_0"
                },
                [1] = {
                    label = "Hat (57-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_57_1"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tan Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_58_0"
                },
                [1] = {
                    label = "Khaki Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_58_1"
                },
                [2] = {
                    label = "Black Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_58_2"
                },
                [3] = {
                    label = "Hat (58-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_58_3"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (59-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_0"
                },
                [1] = {
                    label = "Hat (59-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_1"
                },
                [2] = {
                    label = "Hat (59-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_2"
                },
                [3] = {
                    label = "Hat (59-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_3"
                },
                [4] = {
                    label = "Hat (59-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_4"
                },
                [5] = {
                    label = "Hat (59-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_5"
                },
                [6] = {
                    label = "Hat (59-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_6"
                },
                [7] = {
                    label = "Hat (59-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_7"
                },
                [8] = {
                    label = "Hat (59-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_8"
                },
                [9] = {
                    label = "Hat (59-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_9"
                },
                [10] = {
                    label = "Hat (59-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_59_10"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (60-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_0"
                },
                [1] = {
                    label = "Hat (60-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_1"
                },
                [2] = {
                    label = "Hat (60-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_2"
                },
                [3] = {
                    label = "Hat (60-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_3"
                },
                [4] = {
                    label = "Hat (60-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_4"
                },
                [5] = {
                    label = "Hat (60-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_5"
                },
                [6] = {
                    label = "Hat (60-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_6"
                },
                [7] = {
                    label = "Hat (60-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_7"
                },
                [8] = {
                    label = "Hat (60-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_8"
                },
                [9] = {
                    label = "Hat (60-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_9"
                },
                [10] = {
                    label = "Hat (60-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_60_10"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (61-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_0"
                },
                [1] = {
                    label = "Hat (61-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_1"
                },
                [2] = {
                    label = "Hat (61-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_2"
                },
                [3] = {
                    label = "Hat (61-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_3"
                },
                [4] = {
                    label = "Hat (61-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_4"
                },
                [5] = {
                    label = "Hat (61-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_5"
                },
                [6] = {
                    label = "Hat (61-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_6"
                },
                [7] = {
                    label = "Hat (61-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_7"
                },
                [8] = {
                    label = "Hat (61-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_8"
                },
                [9] = {
                    label = "Hat (61-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_9"
                },
                [10] = {
                    label = "Hat (61-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_61_10"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (62-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_0"
                },
                [1] = {
                    label = "Hat (62-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_1"
                },
                [2] = {
                    label = "Hat (62-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_2"
                },
                [3] = {
                    label = "Hat (62-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_3"
                },
                [4] = {
                    label = "Hat (62-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_4"
                },
                [5] = {
                    label = "Hat (62-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_5"
                },
                [6] = {
                    label = "Hat (62-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_6"
                },
                [7] = {
                    label = "Hat (62-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_7"
                },
                [8] = {
                    label = "Hat (62-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_8"
                },
                [9] = {
                    label = "Hat (62-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_9"
                },
                [10] = {
                    label = "Hat (62-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_62_10"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (63-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_0"
                },
                [1] = {
                    label = "Hat (63-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_1"
                },
                [2] = {
                    label = "Hat (63-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_2"
                },
                [3] = {
                    label = "Hat (63-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_3"
                },
                [4] = {
                    label = "Hat (63-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_4"
                },
                [5] = {
                    label = "Hat (63-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_5"
                },
                [6] = {
                    label = "Hat (63-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_6"
                },
                [7] = {
                    label = "Hat (63-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_7"
                },
                [8] = {
                    label = "Hat (63-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_8"
                },
                [9] = {
                    label = "Hat (63-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_9"
                },
                [10] = {
                    label = "Hat (63-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_63_10"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Check Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_0"
                },
                [1] = {
                    label = "Red Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_1"
                },
                [2] = {
                    label = "Dusk Check Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_2"
                },
                [3] = {
                    label = "Black Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_3"
                },
                [4] = {
                    label = "White Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_4"
                },
                [5] = {
                    label = "Sky Check Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_5"
                },
                [6] = {
                    label = "Chocolate Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_6"
                },
                [7] = {
                    label = "Mustard Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_7"
                },
                [8] = {
                    label = "Crimson Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_8"
                },
                [9] = {
                    label = "Classic Check Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_9"
                },
                [10] = {
                    label = "Beige Check Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_10"
                },
                [11] = {
                    label = "Royal Suit Fedora",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_11"
                },
                [12] = {
                    label = "Hat (64-12)",
                    price = 500,
                    type = "money",
                    image = "male_hat_64_12"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'prop',
            textures = {
                [0] = {
                    label = "SecuroServ Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_65_0"
                },
                [1] = {
                    label = "Hat (65-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_65_1"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'prop',
            textures = {
                [0] = {
                    label = "SecuroServ Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_66_0"
                },
                [1] = {
                    label = "Hat (66-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_66_1"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Shatter Pattern Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_0"
                },
                [1] = {
                    label = "Stars Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_1"
                },
                [2] = {
                    label = "Squared Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_2"
                },
                [3] = {
                    label = "Crimson Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_3"
                },
                [4] = {
                    label = "Skull Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_4"
                },
                [5] = {
                    label = "Ace of Spades Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_5"
                },
                [6] = {
                    label = "Flamejob Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_6"
                },
                [7] = {
                    label = "White Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_7"
                },
                [8] = {
                    label = "Downhill Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_8"
                },
                [9] = {
                    label = "Slalom Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_9"
                },
                [10] = {
                    label = "SA Assault Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_10"
                },
                [11] = {
                    label = "Vibe Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_11"
                },
                [12] = {
                    label = "Burst Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_12"
                },
                [13] = {
                    label = "Tri Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_13"
                },
                [14] = {
                    label = "Sprunk Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_14"
                },
                [15] = {
                    label = "Skeleton Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_15"
                },
                [16] = {
                    label = "Death Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_16"
                },
                [17] = {
                    label = "Cobble Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_17"
                },
                [18] = {
                    label = "Cubist Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_18"
                },
                [19] = {
                    label = "Digital Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_19"
                },
                [20] = {
                    label = "Snakeskin Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_20"
                },
                [21] = {
                    label = "Boost Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_21"
                },
                [22] = {
                    label = "Tropic Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_22"
                },
                [23] = {
                    label = "Atomic Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_23"
                },
                [24] = {
                    label = "Hat (67-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_67_24"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy All Black Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_68_0"
                },
                [1] = {
                    label = "Hat (68-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_68_1"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glossy Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_69_0"
                },
                [1] = {
                    label = "Hat (69-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_69_1"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte All Black Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_70_0"
                },
                [1] = {
                    label = "Hat (70-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_70_1"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Matte Mirrored Biker",
                    price = 500,
                    type = "money",
                    image = "male_hat_71_0"
                },
                [1] = {
                    label = "Hat (71-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_71_1"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (72-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_0"
                },
                [1] = {
                    label = "Hat (72-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_1"
                },
                [2] = {
                    label = "Hat (72-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_2"
                },
                [3] = {
                    label = "Hat (72-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_3"
                },
                [4] = {
                    label = "Hat (72-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_4"
                },
                [5] = {
                    label = "Hat (72-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_5"
                },
                [6] = {
                    label = "Hat (72-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_6"
                },
                [7] = {
                    label = "Hat (72-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_7"
                },
                [8] = {
                    label = "Hat (72-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_8"
                },
                [9] = {
                    label = "Hat (72-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_9"
                },
                [10] = {
                    label = "Hat (72-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_72_10"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_0"
                },
                [1] = {
                    label = "Gray Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_1"
                },
                [2] = {
                    label = "Orange Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_2"
                },
                [3] = {
                    label = "Pale Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_3"
                },
                [4] = {
                    label = "Hat (73-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_4"
                },
                [5] = {
                    label = "Hat (73-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_5"
                },
                [6] = {
                    label = "Hat (73-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_6"
                },
                [7] = {
                    label = "Hat (73-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_7"
                },
                [8] = {
                    label = "White Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_8"
                },
                [9] = {
                    label = "Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_9"
                },
                [10] = {
                    label = "Red Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_10"
                },
                [11] = {
                    label = "Black Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_11"
                },
                [12] = {
                    label = "Pink Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_12"
                },
                [13] = {
                    label = "Hat (73-13)",
                    price = 500,
                    type = "money",
                    image = "male_hat_73_13"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_0"
                },
                [1] = {
                    label = "Gray Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_1"
                },
                [2] = {
                    label = "Orange Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_2"
                },
                [3] = {
                    label = "Pale Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_3"
                },
                [4] = {
                    label = "Hat (74-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_4"
                },
                [5] = {
                    label = "Hat (74-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_5"
                },
                [6] = {
                    label = "Hat (74-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_6"
                },
                [7] = {
                    label = "Hat (74-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_7"
                },
                [8] = {
                    label = "White Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_8"
                },
                [9] = {
                    label = "Blue Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_9"
                },
                [10] = {
                    label = "Red Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_10"
                },
                [11] = {
                    label = "Black Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_11"
                },
                [12] = {
                    label = "Pink Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_12"
                },
                [13] = {
                    label = "Hat (74-13)",
                    price = 500,
                    type = "money",
                    image = "male_hat_74_13"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (75-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_0"
                },
                [1] = {
                    label = "Hat (75-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_1"
                },
                [2] = {
                    label = "Hat (75-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_2"
                },
                [3] = {
                    label = "Hat (75-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_3"
                },
                [4] = {
                    label = "Swirl Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_4"
                },
                [5] = {
                    label = "Red Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_5"
                },
                [6] = {
                    label = "Brown Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_6"
                },
                [7] = {
                    label = "White Flag Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_7"
                },
                [8] = {
                    label = "Blue Stars Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_8"
                },
                [9] = {
                    label = "Black Slash Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_9"
                },
                [10] = {
                    label = "White Stars Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_10"
                },
                [11] = {
                    label = "Blue Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_11"
                },
                [12] = {
                    label = "Red Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_12"
                },
                [13] = {
                    label = "Blue Chain Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_13"
                },
                [14] = {
                    label = "Black Stripes Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_14"
                },
                [15] = {
                    label = "Black Jag Mod Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_15"
                },
                [16] = {
                    label = "Hat (75-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_75_16"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Atomic Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_0"
                },
                [1] = {
                    label = "Auto Exotic Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_1"
                },
                [2] = {
                    label = "Chepalle Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_2"
                },
                [3] = {
                    label = "Cunning Stunts Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_3"
                },
                [4] = {
                    label = "Flash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_4"
                },
                [5] = {
                    label = "Fukaru Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_5"
                },
                [6] = {
                    label = "Globe Oil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_6"
                },
                [7] = {
                    label = "Grotti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_7"
                },
                [8] = {
                    label = "Imponte Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_8"
                },
                [9] = {
                    label = "Lampadati Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_9"
                },
                [10] = {
                    label = "LTD Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_10"
                },
                [11] = {
                    label = "Nagasaki Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_11"
                },
                [12] = {
                    label = "Nagasaki Moto Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_12"
                },
                [13] = {
                    label = "Patriot Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_13"
                },
                [14] = {
                    label = "Rebel Radio Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_14"
                },
                [15] = {
                    label = "Redwood Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_15"
                },
                [16] = {
                    label = "Scooter Brothers Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_16"
                },
                [17] = {
                    label = "The Mount Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_17"
                },
                [18] = {
                    label = "Total Ride Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_18"
                },
                [19] = {
                    label = "Vapid Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_19"
                },
                [20] = {
                    label = "Xero Gas Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_20"
                },
                [21] = {
                    label = "Hat (76-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_76_21"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Atomic Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_0"
                },
                [1] = {
                    label = "Auto Exotic Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_1"
                },
                [2] = {
                    label = "Chepalle Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_2"
                },
                [3] = {
                    label = "Cunning Stunts Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_3"
                },
                [4] = {
                    label = "Flash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_4"
                },
                [5] = {
                    label = "Fukaru Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_5"
                },
                [6] = {
                    label = "Globe Oil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_6"
                },
                [7] = {
                    label = "Grotti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_7"
                },
                [8] = {
                    label = "Imponte Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_8"
                },
                [9] = {
                    label = "Lampadati Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_9"
                },
                [10] = {
                    label = "LTD Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_10"
                },
                [11] = {
                    label = "Nagasaki Racing Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_11"
                },
                [12] = {
                    label = "Nagasaki Moto Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_12"
                },
                [13] = {
                    label = "Patriot Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_13"
                },
                [14] = {
                    label = "Rebel Radio Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_14"
                },
                [15] = {
                    label = "Redwood Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_15"
                },
                [16] = {
                    label = "Scooter Brothers Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_16"
                },
                [17] = {
                    label = "The Mount Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_17"
                },
                [18] = {
                    label = "Total Ride Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_18"
                },
                [19] = {
                    label = "Vapid Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_19"
                },
                [20] = {
                    label = "Xero Gas Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_20"
                },
                [21] = {
                    label = "Hat (77-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_77_21"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_0"
                },
                [1] = {
                    label = "Blue JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_1"
                },
                [2] = {
                    label = "Red JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_2"
                },
                [3] = {
                    label = "Black JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_3"
                },
                [4] = {
                    label = "Pink JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_4"
                },
                [5] = {
                    label = "Hat (78-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_78_5"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_0"
                },
                [1] = {
                    label = "Blue JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_1"
                },
                [2] = {
                    label = "Red JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_2"
                },
                [3] = {
                    label = "Black JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_3"
                },
                [4] = {
                    label = "Pink JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_4"
                },
                [5] = {
                    label = "Hat (79-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_79_5"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_80_0"
                },
                [1] = {
                    label = "Silver JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_80_1"
                },
                [2] = {
                    label = "Gold Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_80_2"
                },
                [3] = {
                    label = "Silver Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_80_3"
                },
                [4] = {
                    label = "Hat (80-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_80_4"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_81_0"
                },
                [1] = {
                    label = "Silver JC Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_81_1"
                },
                [2] = {
                    label = "Gold Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_81_2"
                },
                [3] = {
                    label = "Silver Retro Bubble",
                    price = 500,
                    type = "money",
                    image = "male_hat_81_3"
                },
                [4] = {
                    label = "Hat (81-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_81_4"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Shatter Pattern Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_0"
                },
                [1] = {
                    label = "Stars Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_1"
                },
                [2] = {
                    label = "Squared Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_2"
                },
                [3] = {
                    label = "Crimson Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_3"
                },
                [4] = {
                    label = "Skull Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_4"
                },
                [5] = {
                    label = "Ace of Spades Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_5"
                },
                [6] = {
                    label = "Flamejob Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_6"
                },
                [7] = {
                    label = "White Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_7"
                },
                [8] = {
                    label = "Downhill Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_8"
                },
                [9] = {
                    label = "Slalom Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_9"
                },
                [10] = {
                    label = "SA Assault Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_10"
                },
                [11] = {
                    label = "Vibe Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_11"
                },
                [12] = {
                    label = "Burst Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_12"
                },
                [13] = {
                    label = "Tri Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_13"
                },
                [14] = {
                    label = "Sprunk Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_14"
                },
                [15] = {
                    label = "Skeleton Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_15"
                },
                [16] = {
                    label = "Death Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_16"
                },
                [17] = {
                    label = "Cobble Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_17"
                },
                [18] = {
                    label = "Cubist Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_18"
                },
                [19] = {
                    label = "Digital Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_19"
                },
                [20] = {
                    label = "Snakeskin Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_20"
                },
                [21] = {
                    label = "Boost Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_21"
                },
                [22] = {
                    label = "Tropic Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_22"
                },
                [23] = {
                    label = "Atomic Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_23"
                },
                [24] = {
                    label = "Hat (82-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_82_24"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_0"
                },
                [1] = {
                    label = "Uptown Riders Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_1"
                },
                [2] = {
                    label = "Ride Free Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_2"
                },
                [3] = {
                    label = "Ace of Spades Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_3"
                },
                [4] = {
                    label = "Skull and Snake Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_4"
                },
                [5] = {
                    label = "Ox and Hatchets Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_5"
                },
                [6] = {
                    label = "Stars and Stripes Tied",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_6"
                },
                [7] = {
                    label = "Hat (83-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_83_7"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_0"
                },
                [1] = {
                    label = "Carbon Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_1"
                },
                [2] = {
                    label = "Orange Fiber Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_2"
                },
                [3] = {
                    label = "Star and Stripes Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_3"
                },
                [4] = {
                    label = "Green Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_4"
                },
                [5] = {
                    label = "Feathers Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_5"
                },
                [6] = {
                    label = "Ox and Hatchets Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_6"
                },
                [7] = {
                    label = "Ride Free Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_7"
                },
                [8] = {
                    label = "Ace of Spades Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_8"
                },
                [9] = {
                    label = "Skull and Snake Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_9"
                },
                [10] = {
                    label = "Hat (84-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_84_10"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_85_0"
                },
                [1] = {
                    label = "Hat (85-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_85_1"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Visored Skull Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_86_0"
                },
                [1] = {
                    label = "Hat (86-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_86_1"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Finned Skull Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_87_0"
                },
                [1] = {
                    label = "Hat (87-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_87_1"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Skull Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_88_0"
                },
                [1] = {
                    label = "Hat (88-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_88_1"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_0"
                },
                [1] = {
                    label = "Carbon Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_1"
                },
                [2] = {
                    label = "Orange Fiber Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_2"
                },
                [3] = {
                    label = "Star and Stripes Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_3"
                },
                [4] = {
                    label = "Green Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_4"
                },
                [5] = {
                    label = "Feathers Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_5"
                },
                [6] = {
                    label = "Ox and Hatchets Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_6"
                },
                [7] = {
                    label = "Ride Free Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_7"
                },
                [8] = {
                    label = "Ace of Spades Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_8"
                },
                [9] = {
                    label = "Skull and Snake Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_9"
                },
                [10] = {
                    label = "Hat (89-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_89_10"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chromed Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_90_0"
                },
                [1] = {
                    label = "Hat (90-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_90_1"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Deadline Yellow",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_0"
                },
                [1] = {
                    label = "Deadline Green",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_1"
                },
                [2] = {
                    label = "Deadline Orange",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_2"
                },
                [3] = {
                    label = "Deadline Purple",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_3"
                },
                [4] = {
                    label = "Deadline Pink",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_4"
                },
                [5] = {
                    label = "Deadline Red",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_5"
                },
                [6] = {
                    label = "Deadline Blue",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_6"
                },
                [7] = {
                    label = "Hat (91-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_7"
                },
                [8] = {
                    label = "Hat (91-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_8"
                },
                [9] = {
                    label = "Deadline White",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_9"
                },
                [10] = {
                    label = "Hat (91-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_10"
                },
                [11] = {
                    label = "Hat (91-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_91_11"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Deadline Yellow",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_0"
                },
                [1] = {
                    label = "Deadline Green",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_1"
                },
                [2] = {
                    label = "Deadline Orange",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_2"
                },
                [3] = {
                    label = "Deadline Purple",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_3"
                },
                [4] = {
                    label = "Deadline Pink",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_4"
                },
                [5] = {
                    label = "Deadline Red",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_5"
                },
                [6] = {
                    label = "Deadline Blue",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_6"
                },
                [7] = {
                    label = "Hat (92-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_7"
                },
                [8] = {
                    label = "Hat (92-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_8"
                },
                [9] = {
                    label = "Deadline White",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_9"
                },
                [10] = {
                    label = "Hat (92-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_10"
                },
                [11] = {
                    label = "Hat (92-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_92_11"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Roundel Mod",
                    price = 500,
                    type = "money",
                    image = "male_hat_93_0"
                },
                [1] = {
                    label = "Faggio Mod",
                    price = 500,
                    type = "money",
                    image = "male_hat_93_1"
                },
                [2] = {
                    label = "Green Roundel Mod",
                    price = 500,
                    type = "money",
                    image = "male_hat_93_2"
                },
                [3] = {
                    label = "Green Faggio Mod",
                    price = 500,
                    type = "money",
                    image = "male_hat_93_3"
                },
                [4] = {
                    label = "Hat (93-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_93_4"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_0"
                },
                [1] = {
                    label = "Red Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_1"
                },
                [2] = {
                    label = "Blue Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_2"
                },
                [3] = {
                    label = "Cyan Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_3"
                },
                [4] = {
                    label = "White Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_4"
                },
                [5] = {
                    label = "Ash Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_5"
                },
                [6] = {
                    label = "Navy Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_6"
                },
                [7] = {
                    label = "Dark Red Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_7"
                },
                [8] = {
                    label = "Slate Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_8"
                },
                [9] = {
                    label = "Moss Mod Canvas",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_9"
                },
                [10] = {
                    label = "Hat (94-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_94_10"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cream Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_0"
                },
                [1] = {
                    label = "Red Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_1"
                },
                [2] = {
                    label = "Blue Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_2"
                },
                [3] = {
                    label = "Cyan Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_3"
                },
                [4] = {
                    label = "White Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_4"
                },
                [5] = {
                    label = "Ash Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_5"
                },
                [6] = {
                    label = "Navy Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_6"
                },
                [7] = {
                    label = "Dark Red Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_7"
                },
                [8] = {
                    label = "Slate Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_8"
                },
                [9] = {
                    label = "Moss Mod Pork Pie",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_9"
                },
                [10] = {
                    label = "Hat (95-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_95_10"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_0"
                },
                [1] = {
                    label = "Red Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_1"
                },
                [2] = {
                    label = "Orange Camo Sand Castle Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_2"
                },
                [3] = {
                    label = "Purple Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_3"
                },
                [4] = {
                    label = "Off-White Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_4"
                },
                [5] = {
                    label = "Bold Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_5"
                },
                [6] = {
                    label = "Gray Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_6"
                },
                [7] = {
                    label = "Pale Abstract Bigness Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_7"
                },
                [8] = {
                    label = "Primary Squash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_8"
                },
                [9] = {
                    label = "Spots Squash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_9"
                },
                [10] = {
                    label = "Banana Squash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_10"
                },
                [11] = {
                    label = "Splat Squash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_11"
                },
                [12] = {
                    label = "OJ Squash Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_12"
                },
                [13] = {
                    label = "Multicolor Leaves Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_13"
                },
                [14] = {
                    label = "Red Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_14"
                },
                [15] = {
                    label = "White Painted Güffy Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_15"
                },
                [16] = {
                    label = "Hat (96-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_96_16"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Classic Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_97_0"
                },
                [1] = {
                    label = "Glow Purple Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_97_1"
                },
                [2] = {
                    label = "Glow Holly Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_97_2"
                },
                [3] = {
                    label = "Glow Star Tree",
                    price = 500,
                    type = "money",
                    image = "male_hat_97_3"
                },
                [4] = {
                    label = "Hat (97-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_97_4"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Pudding Woolly Knit",
                    price = 500,
                    type = "money",
                    image = "male_hat_98_0"
                },
                [1] = {
                    label = "Hat (98-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_98_1"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Cheeky Elf Woolly Trail",
                    price = 500,
                    type = "money",
                    image = "male_hat_99_0"
                },
                [1] = {
                    label = "Hat (99-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_99_1"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Elf Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_100_0"
                },
                [1] = {
                    label = "Hat (100-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_100_1"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Reindeer Antlers",
                    price = 500,
                    type = "money",
                    image = "male_hat_101_0"
                },
                [1] = {
                    label = "Hat (101-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_101_1"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (102-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_0"
                },
                [1] = {
                    label = "Hat (102-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_1"
                },
                [2] = {
                    label = "Hat (102-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_2"
                },
                [3] = {
                    label = "Hat (102-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_3"
                },
                [4] = {
                    label = "Hat (102-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_4"
                },
                [5] = {
                    label = "Hat (102-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_5"
                },
                [6] = {
                    label = "Hat (102-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_6"
                },
                [7] = {
                    label = "Hat (102-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_7"
                },
                [8] = {
                    label = "Hat (102-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_8"
                },
                [9] = {
                    label = "Hat (102-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_9"
                },
                [10] = {
                    label = "Hat (102-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_102_10"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_0"
                },
                [1] = {
                    label = "Brown Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_1"
                },
                [2] = {
                    label = "Green Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_2"
                },
                [3] = {
                    label = "Gray Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_3"
                },
                [4] = {
                    label = "Peach Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_4"
                },
                [5] = {
                    label = "Fall Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_5"
                },
                [6] = {
                    label = "Dark Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_6"
                },
                [7] = {
                    label = "Crosshatch Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_7"
                },
                [8] = {
                    label = "Moss Digital Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_8"
                },
                [9] = {
                    label = "Gray Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_9"
                },
                [10] = {
                    label = "Aqua Camo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_10"
                },
                [11] = {
                    label = "Splinter Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_11"
                },
                [12] = {
                    label = "Contrast Camo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_12"
                },
                [13] = {
                    label = "Cobble Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_13"
                },
                [14] = {
                    label = "Peach Camo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_14"
                },
                [15] = {
                    label = "Brushstroke Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_15"
                },
                [16] = {
                    label = "Flecktarn Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_16"
                },
                [17] = {
                    label = "Light Woodland Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_17"
                },
                [18] = {
                    label = "Moss Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_18"
                },
                [19] = {
                    label = "Sand Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_19"
                },
                [20] = {
                    label = "Hat (103-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_103_20"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_0"
                },
                [1] = {
                    label = "Brown Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_1"
                },
                [2] = {
                    label = "Green Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_2"
                },
                [3] = {
                    label = "Gray Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_3"
                },
                [4] = {
                    label = "Peach Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_4"
                },
                [5] = {
                    label = "Fall Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_5"
                },
                [6] = {
                    label = "Dark Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_6"
                },
                [7] = {
                    label = "Crosshatch Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_7"
                },
                [8] = {
                    label = "Moss Digital Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_8"
                },
                [9] = {
                    label = "Gray Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_9"
                },
                [10] = {
                    label = "Aqua Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_10"
                },
                [11] = {
                    label = "Splinter Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_11"
                },
                [12] = {
                    label = "Contrast Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_12"
                },
                [13] = {
                    label = "Cobble Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_13"
                },
                [14] = {
                    label = "Peach Camo Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_14"
                },
                [15] = {
                    label = "Brushstroke Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_15"
                },
                [16] = {
                    label = "Flecktarn Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_16"
                },
                [17] = {
                    label = "Light Woodland Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_17"
                },
                [18] = {
                    label = "Moss Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_18"
                },
                [19] = {
                    label = "Sand Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_19"
                },
                [20] = {
                    label = "Black Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_20"
                },
                [21] = {
                    label = "Slate Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_21"
                },
                [22] = {
                    label = "White Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_22"
                },
                [23] = {
                    label = "Chocolate Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_23"
                },
                [24] = {
                    label = "Olive Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_24"
                },
                [25] = {
                    label = "Light Brown Boonie Down",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_25"
                },
                [26] = {
                    label = "Hat (104-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_104_26"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_0"
                },
                [1] = {
                    label = "Brown Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_1"
                },
                [2] = {
                    label = "Green Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_2"
                },
                [3] = {
                    label = "Gray Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_3"
                },
                [4] = {
                    label = "Peach Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_4"
                },
                [5] = {
                    label = "Fall Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_5"
                },
                [6] = {
                    label = "Dark Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_6"
                },
                [7] = {
                    label = "Crosshatch Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_7"
                },
                [8] = {
                    label = "Moss Digital Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_8"
                },
                [9] = {
                    label = "Gray Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_9"
                },
                [10] = {
                    label = "Aqua Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_10"
                },
                [11] = {
                    label = "Splinter Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_11"
                },
                [12] = {
                    label = "Contrast Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_12"
                },
                [13] = {
                    label = "Cobble Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_13"
                },
                [14] = {
                    label = "Peach Camo Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_14"
                },
                [15] = {
                    label = "Brushstroke Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_15"
                },
                [16] = {
                    label = "Flecktarn Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_16"
                },
                [17] = {
                    label = "Light Woodland Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_17"
                },
                [18] = {
                    label = "Moss Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_18"
                },
                [19] = {
                    label = "Sand Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_19"
                },
                [20] = {
                    label = "Black Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_20"
                },
                [21] = {
                    label = "Slate Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_21"
                },
                [22] = {
                    label = "White Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_22"
                },
                [23] = {
                    label = "Chocolate Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_23"
                },
                [24] = {
                    label = "Olive Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_24"
                },
                [25] = {
                    label = "Light Brown Boonie Up",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_25"
                },
                [26] = {
                    label = "Hat (105-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_105_26"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_0"
                },
                [1] = {
                    label = "Brown Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_1"
                },
                [2] = {
                    label = "Green Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_2"
                },
                [3] = {
                    label = "Gray Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_3"
                },
                [4] = {
                    label = "Peach Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_4"
                },
                [5] = {
                    label = "Fall Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_5"
                },
                [6] = {
                    label = "Dark Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_6"
                },
                [7] = {
                    label = "Crosshatch Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_7"
                },
                [8] = {
                    label = "Moss Digital Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_8"
                },
                [9] = {
                    label = "Gray Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_9"
                },
                [10] = {
                    label = "Aqua Camo Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_10"
                },
                [11] = {
                    label = "Splinter Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_11"
                },
                [12] = {
                    label = "Contrast Camo Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_12"
                },
                [13] = {
                    label = "Cobble Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_13"
                },
                [14] = {
                    label = "Peach Camo Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_14"
                },
                [15] = {
                    label = "Brushstroke Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_15"
                },
                [16] = {
                    label = "Flecktarn Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_16"
                },
                [17] = {
                    label = "Light Woodland Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_17"
                },
                [18] = {
                    label = "Moss Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_18"
                },
                [19] = {
                    label = "Sand Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_19"
                },
                [20] = {
                    label = "Midnight Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_20"
                },
                [21] = {
                    label = "Slate Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_21"
                },
                [22] = {
                    label = "Ice Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_22"
                },
                [23] = {
                    label = "Chocolate Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_23"
                },
                [24] = {
                    label = "Olive Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_24"
                },
                [25] = {
                    label = "Light Brown Beret",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_25"
                },
                [26] = {
                    label = "Hat (106-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_106_26"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_0"
                },
                [1] = {
                    label = "Brown Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_1"
                },
                [2] = {
                    label = "Green Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_2"
                },
                [3] = {
                    label = "Gray Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_3"
                },
                [4] = {
                    label = "Peach Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_4"
                },
                [5] = {
                    label = "Fall Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_5"
                },
                [6] = {
                    label = "Dark Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_6"
                },
                [7] = {
                    label = "Crosshatch Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_7"
                },
                [8] = {
                    label = "Moss Digital Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_8"
                },
                [9] = {
                    label = "Gray Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_9"
                },
                [10] = {
                    label = "Aqua Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_10"
                },
                [11] = {
                    label = "Splinter Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_11"
                },
                [12] = {
                    label = "Contrast Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_12"
                },
                [13] = {
                    label = "Cobble Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_13"
                },
                [14] = {
                    label = "Peach Camo Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_14"
                },
                [15] = {
                    label = "Brushstroke Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_15"
                },
                [16] = {
                    label = "Flecktarn Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_16"
                },
                [17] = {
                    label = "Light Woodland Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_17"
                },
                [18] = {
                    label = "Moss Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_18"
                },
                [19] = {
                    label = "Sand Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_19"
                },
                [20] = {
                    label = "Black Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_20"
                },
                [21] = {
                    label = "Slate Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_21"
                },
                [22] = {
                    label = "White Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_22"
                },
                [23] = {
                    label = "Chocolate Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_23"
                },
                [24] = {
                    label = "Olive Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_24"
                },
                [25] = {
                    label = "Light Brown Utility Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_25"
                },
                [26] = {
                    label = "Hat (107-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_107_26"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_0"
                },
                [1] = {
                    label = "Brown Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_1"
                },
                [2] = {
                    label = "Green Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_2"
                },
                [3] = {
                    label = "Gray Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_3"
                },
                [4] = {
                    label = "Peach Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_4"
                },
                [5] = {
                    label = "Fall Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_5"
                },
                [6] = {
                    label = "Dark Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_6"
                },
                [7] = {
                    label = "Crosshatch Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_7"
                },
                [8] = {
                    label = "Moss Digital Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_8"
                },
                [9] = {
                    label = "Gray Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_9"
                },
                [10] = {
                    label = "Aqua Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_10"
                },
                [11] = {
                    label = "Splinter Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_11"
                },
                [12] = {
                    label = "Contrast Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_12"
                },
                [13] = {
                    label = "Cobble Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_13"
                },
                [14] = {
                    label = "Peach Camo Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_14"
                },
                [15] = {
                    label = "Brushstroke Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_15"
                },
                [16] = {
                    label = "Flecktarn Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_16"
                },
                [17] = {
                    label = "Light Woodland Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_17"
                },
                [18] = {
                    label = "Moss Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_18"
                },
                [19] = {
                    label = "Sand Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_19"
                },
                [20] = {
                    label = "Black Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_20"
                },
                [21] = {
                    label = "Slate Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_21"
                },
                [22] = {
                    label = "White Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_22"
                },
                [23] = {
                    label = "Chocolate Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_23"
                },
                [24] = {
                    label = "Olive Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_24"
                },
                [25] = {
                    label = "Light Brown Beanie Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_25"
                },
                [26] = {
                    label = "Hat (108-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_108_26"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_0"
                },
                [1] = {
                    label = "Black Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_1"
                },
                [2] = {
                    label = "White Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_2"
                },
                [3] = {
                    label = "Black Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_3"
                },
                [4] = {
                    label = "White Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_4"
                },
                [5] = {
                    label = "Black Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_5"
                },
                [6] = {
                    label = "Wine Coil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_6"
                },
                [7] = {
                    label = "Black Coil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_7"
                },
                [8] = {
                    label = "Black Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_8"
                },
                [9] = {
                    label = "Red Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_9"
                },
                [10] = {
                    label = "Warstock Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_10"
                },
                [11] = {
                    label = "Hat (109-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_109_11"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_0"
                },
                [1] = {
                    label = "Black Hawk & Little Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_1"
                },
                [2] = {
                    label = "White Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_2"
                },
                [3] = {
                    label = "Black Shrewsbury Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_3"
                },
                [4] = {
                    label = "White Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_4"
                },
                [5] = {
                    label = "Black Vom Feuer Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_5"
                },
                [6] = {
                    label = "Wine Coil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_6"
                },
                [7] = {
                    label = "Black Coil Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_7"
                },
                [8] = {
                    label = "Black Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_8"
                },
                [9] = {
                    label = "Red Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_9"
                },
                [10] = {
                    label = "Warstock Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_10"
                },
                [11] = {
                    label = "Hat (110-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_110_11"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Orange Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_0"
                },
                [1] = {
                    label = "Green Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_1"
                },
                [2] = {
                    label = "Brown Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_2"
                },
                [3] = {
                    label = "White Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_3"
                },
                [4] = {
                    label = "Hat (111-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_4"
                },
                [5] = {
                    label = "Hat (111-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_5"
                },
                [6] = {
                    label = "Hat (111-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_6"
                },
                [7] = {
                    label = "Hat (111-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_7"
                },
                [8] = {
                    label = "Lime & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_8"
                },
                [9] = {
                    label = "51st Squad Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_9"
                },
                [10] = {
                    label = "Orange & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_10"
                },
                [11] = {
                    label = "Zeus Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_11"
                },
                [12] = {
                    label = "Green & Yellow Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_12"
                },
                [13] = {
                    label = "Blue & Orange Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_13"
                },
                [14] = {
                    label = "DFA Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_14"
                },
                [15] = {
                    label = "Snake Killers Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_15"
                },
                [16] = {
                    label = "Mind Over Matter Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_16"
                },
                [17] = {
                    label = "Red & White Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_17"
                },
                [18] = {
                    label = "Other Side Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_18"
                },
                [19] = {
                    label = "STFU Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_19"
                },
                [20] = {
                    label = "Patriot Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_20"
                },
                [21] = {
                    label = "Zebra Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_21"
                },
                [22] = {
                    label = "Tiger Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_22"
                },
                [23] = {
                    label = "Leopard Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_23"
                },
                [24] = {
                    label = "Shark Mouth Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_24"
                },
                [25] = {
                    label = "Yellow & Black Flight Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_25"
                },
                [26] = {
                    label = "Hat (111-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_111_26"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Woodland Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_0"
                },
                [1] = {
                    label = "Dark Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_1"
                },
                [2] = {
                    label = "Light Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_2"
                },
                [3] = {
                    label = "Flecktarn Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_3"
                },
                [4] = {
                    label = "Black Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_4"
                },
                [5] = {
                    label = "Medic Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_5"
                },
                [6] = {
                    label = "Gray Woodland Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_6"
                },
                [7] = {
                    label = "Tan Digital Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_7"
                },
                [8] = {
                    label = "Aqua Camo Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_8"
                },
                [9] = {
                    label = "Splinter Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_9"
                },
                [10] = {
                    label = "Red Star Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_10"
                },
                [11] = {
                    label = "Brown Digital Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_11"
                },
                [12] = {
                    label = "MP Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_12"
                },
                [13] = {
                    label = "Zebra Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_13"
                },
                [14] = {
                    label = "Leopard Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_14"
                },
                [15] = {
                    label = "Tiger Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_15"
                },
                [16] = {
                    label = "Police Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_16"
                },
                [17] = {
                    label = "Flames Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_17"
                },
                [18] = {
                    label = "Stars & Stripes Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_18"
                },
                [19] = {
                    label = "Patriot Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_19"
                },
                [20] = {
                    label = "Green Stars Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_20"
                },
                [21] = {
                    label = "Peace Combat Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_21"
                },
                [22] = {
                    label = "Hat (112-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_22"
                },
                [23] = {
                    label = "Hat (112-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_23"
                },
                [24] = {
                    label = "Hat (112-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_24"
                },
                [25] = {
                    label = "Hat (112-25)",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_25"
                },
                [26] = {
                    label = "Hat (112-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_112_26"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_0"
                },
                [1] = {
                    label = "Black Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_1"
                },
                [2] = {
                    label = "Blue Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_2"
                },
                [3] = {
                    label = "Navy Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_3"
                },
                [4] = {
                    label = "Aqua Camo Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_4"
                },
                [5] = {
                    label = "White Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_5"
                },
                [6] = {
                    label = "White & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_6"
                },
                [7] = {
                    label = "Gray Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_7"
                },
                [8] = {
                    label = "Green & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_8"
                },
                [9] = {
                    label = "Brown & Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_9"
                },
                [10] = {
                    label = "Light Brown Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_10"
                },
                [11] = {
                    label = "Moss Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_11"
                },
                [12] = {
                    label = "Gray Digital Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_12"
                },
                [13] = {
                    label = "Dark Woodland Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_13"
                },
                [14] = {
                    label = "Red Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_14"
                },
                [15] = {
                    label = "Chocolate Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_15"
                },
                [16] = {
                    label = "Hat (113-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_16"
                },
                [17] = {
                    label = "Hat (113-17)",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_17"
                },
                [18] = {
                    label = "Hat (113-18)",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_18"
                },
                [19] = {
                    label = "Hat (113-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_19"
                },
                [20] = {
                    label = "Hat (113-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_113_20"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White & Gold Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_0"
                },
                [1] = {
                    label = "White & Blue Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_1"
                },
                [2] = {
                    label = "Gray Leopard Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_2"
                },
                [3] = {
                    label = "Navy Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_3"
                },
                [4] = {
                    label = "Blue Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_4"
                },
                [5] = {
                    label = "Teal Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_5"
                },
                [6] = {
                    label = "Aqua Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_6"
                },
                [7] = {
                    label = "Black Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_7"
                },
                [8] = {
                    label = "Chocolate Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_8"
                },
                [9] = {
                    label = "Red Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_9"
                },
                [10] = {
                    label = "Red & Navy Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_10"
                },
                [11] = {
                    label = "Red Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_11"
                },
                [12] = {
                    label = "Brushstroke Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_12"
                },
                [13] = {
                    label = "Moss Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_13"
                },
                [14] = {
                    label = "Brown Digital Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_14"
                },
                [15] = {
                    label = "Beige Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_15"
                },
                [16] = {
                    label = "White Camo Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_16"
                },
                [17] = {
                    label = "Gray Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_17"
                },
                [18] = {
                    label = "Zebra Garrison Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_18"
                },
                [19] = {
                    label = "Hat (114-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_19"
                },
                [20] = {
                    label = "Hat (114-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_20"
                },
                [21] = {
                    label = "Hat (114-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_21"
                },
                [22] = {
                    label = "Hat (114-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_22"
                },
                [23] = {
                    label = "Hat (114-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_114_23"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_0"
                },
                [1] = {
                    label = "Moss Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_1"
                },
                [2] = {
                    label = "Brown Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_2"
                },
                [3] = {
                    label = "White Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_3"
                },
                [4] = {
                    label = "Hat (115-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_4"
                },
                [5] = {
                    label = "Hat (115-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_5"
                },
                [6] = {
                    label = "Hat (115-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_6"
                },
                [7] = {
                    label = "Hat (115-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_7"
                },
                [8] = {
                    label = "Leopard Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_8"
                },
                [9] = {
                    label = "Brown Digital Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_9"
                },
                [10] = {
                    label = "Tiger Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_10"
                },
                [11] = {
                    label = "Pink Pattern Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_11"
                },
                [12] = {
                    label = "Peach Digital Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_12"
                },
                [13] = {
                    label = "Fall Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_13"
                },
                [14] = {
                    label = "Dark Woodland Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_14"
                },
                [15] = {
                    label = "Crosshatch Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_15"
                },
                [16] = {
                    label = "Green Pattern Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_16"
                },
                [17] = {
                    label = "Gray Woodland Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_17"
                },
                [18] = {
                    label = "Aqua Camo Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_18"
                },
                [19] = {
                    label = "Splinter Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_19"
                },
                [20] = {
                    label = "Contrast Camo Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_20"
                },
                [21] = {
                    label = "Cobble Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_21"
                },
                [22] = {
                    label = "Brushstroke Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_22"
                },
                [23] = {
                    label = "Flecktarn Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_23"
                },
                [24] = {
                    label = "Black & Red Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_24"
                },
                [25] = {
                    label = "Zebra Full Face",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_25"
                },
                [26] = {
                    label = "Hat (115-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_115_26"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_0"
                },
                [1] = {
                    label = "Moss Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_1"
                },
                [2] = {
                    label = "Brown Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_2"
                },
                [3] = {
                    label = "White Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_3"
                },
                [4] = {
                    label = "Hat (116-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_4"
                },
                [5] = {
                    label = "Hat (116-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_5"
                },
                [6] = {
                    label = "Hat (116-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_6"
                },
                [7] = {
                    label = "Hat (116-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_7"
                },
                [8] = {
                    label = "Leopard Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_8"
                },
                [9] = {
                    label = "Brown Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_9"
                },
                [10] = {
                    label = "Tiger Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_10"
                },
                [11] = {
                    label = "Pink Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_11"
                },
                [12] = {
                    label = "Peach Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_12"
                },
                [13] = {
                    label = "Fall Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_13"
                },
                [14] = {
                    label = "Dark Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_14"
                },
                [15] = {
                    label = "Crosshatch Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_15"
                },
                [16] = {
                    label = "Green Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_16"
                },
                [17] = {
                    label = "Gray Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_17"
                },
                [18] = {
                    label = "Aqua Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_18"
                },
                [19] = {
                    label = "Splinter Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_19"
                },
                [20] = {
                    label = "Contrast Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_20"
                },
                [21] = {
                    label = "Cobble Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_21"
                },
                [22] = {
                    label = "Brushstroke Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_22"
                },
                [23] = {
                    label = "Flecktarn Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_23"
                },
                [24] = {
                    label = "Black & Red Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_24"
                },
                [25] = {
                    label = "Zebra Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_25"
                },
                [26] = {
                    label = "Hat (116-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_116_26"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_0"
                },
                [1] = {
                    label = "Moss Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_1"
                },
                [2] = {
                    label = "Brown Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_2"
                },
                [3] = {
                    label = "White Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_3"
                },
                [4] = {
                    label = "Hat (117-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_4"
                },
                [5] = {
                    label = "Hat (117-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_5"
                },
                [6] = {
                    label = "Hat (117-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_6"
                },
                [7] = {
                    label = "Hat (117-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_7"
                },
                [8] = {
                    label = "Leopard Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_8"
                },
                [9] = {
                    label = "Brown Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_9"
                },
                [10] = {
                    label = "Tiger Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_10"
                },
                [11] = {
                    label = "Pink Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_11"
                },
                [12] = {
                    label = "Peach Digital Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_12"
                },
                [13] = {
                    label = "Fall Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_13"
                },
                [14] = {
                    label = "Dark Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_14"
                },
                [15] = {
                    label = "Crosshatch Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_15"
                },
                [16] = {
                    label = "Green Pattern Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_16"
                },
                [17] = {
                    label = "Gray Woodland Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_17"
                },
                [18] = {
                    label = "Aqua Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_18"
                },
                [19] = {
                    label = "Splinter Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_19"
                },
                [20] = {
                    label = "Contrast Camo Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_20"
                },
                [21] = {
                    label = "Cobble Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_21"
                },
                [22] = {
                    label = "Brushstroke Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_22"
                },
                [23] = {
                    label = "Flecktarn Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_23"
                },
                [24] = {
                    label = "Black & Red Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_24"
                },
                [25] = {
                    label = "Zebra Dual Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_25"
                },
                [26] = {
                    label = "Hat (117-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_117_26"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_0"
                },
                [1] = {
                    label = "Moss Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_1"
                },
                [2] = {
                    label = "Brown Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_2"
                },
                [3] = {
                    label = "White Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_3"
                },
                [4] = {
                    label = "Hat (118-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_4"
                },
                [5] = {
                    label = "Hat (118-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_5"
                },
                [6] = {
                    label = "Hat (118-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_6"
                },
                [7] = {
                    label = "Hat (118-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_7"
                },
                [8] = {
                    label = "Leopard Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_8"
                },
                [9] = {
                    label = "Brown Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_9"
                },
                [10] = {
                    label = "Tiger Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_10"
                },
                [11] = {
                    label = "Pink Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_11"
                },
                [12] = {
                    label = "Peach Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_12"
                },
                [13] = {
                    label = "Fall Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_13"
                },
                [14] = {
                    label = "Dark Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_14"
                },
                [15] = {
                    label = "Crosshatch Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_15"
                },
                [16] = {
                    label = "Green Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_16"
                },
                [17] = {
                    label = "Gray Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_17"
                },
                [18] = {
                    label = "Aqua Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_18"
                },
                [19] = {
                    label = "Splinter Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_19"
                },
                [20] = {
                    label = "Contrast Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_20"
                },
                [21] = {
                    label = "Cobble Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_21"
                },
                [22] = {
                    label = "Brushstroke Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_22"
                },
                [23] = {
                    label = "Flecktarn Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_23"
                },
                [24] = {
                    label = "Black & Red Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_24"
                },
                [25] = {
                    label = "Zebra Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_25"
                },
                [26] = {
                    label = "Hat (118-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_118_26"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_0"
                },
                [1] = {
                    label = "Moss Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_1"
                },
                [2] = {
                    label = "Brown Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_2"
                },
                [3] = {
                    label = "White Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_3"
                },
                [4] = {
                    label = "Hat (119-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_4"
                },
                [5] = {
                    label = "Hat (119-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_5"
                },
                [6] = {
                    label = "Hat (119-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_6"
                },
                [7] = {
                    label = "Hat (119-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_7"
                },
                [8] = {
                    label = "Leopard Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_8"
                },
                [9] = {
                    label = "Brown Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_9"
                },
                [10] = {
                    label = "Tiger Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_10"
                },
                [11] = {
                    label = "Pink Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_11"
                },
                [12] = {
                    label = "Peach Digital Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_12"
                },
                [13] = {
                    label = "Fall Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_13"
                },
                [14] = {
                    label = "Dark Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_14"
                },
                [15] = {
                    label = "Crosshatch Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_15"
                },
                [16] = {
                    label = "Green Pattern Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_16"
                },
                [17] = {
                    label = "Gray Woodland Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_17"
                },
                [18] = {
                    label = "Aqua Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_18"
                },
                [19] = {
                    label = "Splinter Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_19"
                },
                [20] = {
                    label = "Contrast Camo Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_20"
                },
                [21] = {
                    label = "Cobble Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_21"
                },
                [22] = {
                    label = "Brushstroke Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_22"
                },
                [23] = {
                    label = "Flecktarn Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_23"
                },
                [24] = {
                    label = "Black & Red Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_24"
                },
                [25] = {
                    label = "Zebra Quad Lens",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_25"
                },
                [26] = {
                    label = "Hat (119-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_119_26"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_0"
                },
                [1] = {
                    label = "Charcoal Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_1"
                },
                [2] = {
                    label = "Ash Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_2"
                },
                [3] = {
                    label = "White Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_3"
                },
                [4] = {
                    label = "Red Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_4"
                },
                [5] = {
                    label = "Blue Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_5"
                },
                [6] = {
                    label = "Light Blue Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_6"
                },
                [7] = {
                    label = "Beige Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_7"
                },
                [8] = {
                    label = "Light Woodland Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_8"
                },
                [9] = {
                    label = "Gray Woodland Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_9"
                },
                [10] = {
                    label = "Aqua Camo Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_10"
                },
                [11] = {
                    label = "Tiger Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_11"
                },
                [12] = {
                    label = "Tricolore Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_12"
                },
                [13] = {
                    label = "Blue Striped Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_13"
                },
                [14] = {
                    label = "Rasta Trio Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_14"
                },
                [15] = {
                    label = "Brown Striped Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_15"
                },
                [16] = {
                    label = "Stars & Stripes Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_16"
                },
                [17] = {
                    label = "Rasta Stripes Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_17"
                },
                [18] = {
                    label = "Black & Yellow Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_18"
                },
                [19] = {
                    label = "Blue & Yellow Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_19"
                },
                [20] = {
                    label = "Green Houndstooth Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_20"
                },
                [21] = {
                    label = "Beige Houndstooth Low Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_21"
                },
                [22] = {
                    label = "Hat (120-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_22"
                },
                [23] = {
                    label = "Hat (120-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_23"
                },
                [24] = {
                    label = "Hat (120-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_24"
                },
                [25] = {
                    label = "Hat (120-25)",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_25"
                },
                [26] = {
                    label = "Hat (120-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_120_26"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (121-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_121_0"
                },
                [1] = {
                    label = "Hat (121-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_121_1"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (122-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_122_0"
                },
                [1] = {
                    label = "Hat (122-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_122_1"
                },
                [2] = {
                    label = "Hat (122-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_122_2"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_0"
                },
                [1] = {
                    label = "White Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_1"
                },
                [2] = {
                    label = "Gray Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_2"
                },
                [3] = {
                    label = "Moss Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_3"
                },
                [4] = {
                    label = "Brown Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_4"
                },
                [5] = {
                    label = "Gray Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_5"
                },
                [6] = {
                    label = "Crosshatch Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_6"
                },
                [7] = {
                    label = "Blue Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_7"
                },
                [8] = {
                    label = "Fall Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_8"
                },
                [9] = {
                    label = "Aqua Camo Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_9"
                },
                [10] = {
                    label = "Splinter Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_10"
                },
                [11] = {
                    label = "Gray Woodland Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_11"
                },
                [12] = {
                    label = "Brushstroke Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_12"
                },
                [13] = {
                    label = "Moss Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_13"
                },
                [14] = {
                    label = "MP Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_14"
                },
                [15] = {
                    label = "LSPD Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_15"
                },
                [16] = {
                    label = "Hat (123-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_16"
                },
                [17] = {
                    label = "Hat (123-17)",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_17"
                },
                [18] = {
                    label = "Hat (123-18)",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_18"
                },
                [19] = {
                    label = "Hat (123-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_19"
                },
                [20] = {
                    label = "Hat (123-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_123_20"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_0"
                },
                [1] = {
                    label = "White Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_1"
                },
                [2] = {
                    label = "Gray Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_2"
                },
                [3] = {
                    label = "Moss Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_3"
                },
                [4] = {
                    label = "Brown Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_4"
                },
                [5] = {
                    label = "Gray Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_5"
                },
                [6] = {
                    label = "Crosshatch Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_6"
                },
                [7] = {
                    label = "Blue Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_7"
                },
                [8] = {
                    label = "Fall Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_8"
                },
                [9] = {
                    label = "Aqua Camo Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_9"
                },
                [10] = {
                    label = "Splinter Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_10"
                },
                [11] = {
                    label = "Gray Woodland Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_11"
                },
                [12] = {
                    label = "Brushstroke Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_12"
                },
                [13] = {
                    label = "Moss Digital Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_13"
                },
                [14] = {
                    label = "MP Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_14"
                },
                [15] = {
                    label = "LSPD Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_15"
                },
                [16] = {
                    label = "Hat (124-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_16"
                },
                [17] = {
                    label = "Hat (124-17)",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_17"
                },
                [18] = {
                    label = "Hat (124-18)",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_18"
                },
                [19] = {
                    label = "Hat (124-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_19"
                },
                [20] = {
                    label = "Hat (124-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_124_20"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_0"
                },
                [1] = {
                    label = "Cream Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_1"
                },
                [2] = {
                    label = "Stone Gray Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_2"
                },
                [3] = {
                    label = "Brown Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_3"
                },
                [4] = {
                    label = "Ox Blood Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_4"
                },
                [5] = {
                    label = "Blue Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_5"
                },
                [6] = {
                    label = "Brown Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_6"
                },
                [7] = {
                    label = "Gray Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_7"
                },
                [8] = {
                    label = "Contrast Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_8"
                },
                [9] = {
                    label = "Blue Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_9"
                },
                [10] = {
                    label = "Fall Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_10"
                },
                [11] = {
                    label = "Aqua Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_11"
                },
                [12] = {
                    label = "Light Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_12"
                },
                [13] = {
                    label = "Splinter Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_13"
                },
                [14] = {
                    label = "Gray Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_14"
                },
                [15] = {
                    label = "Moss Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_15"
                },
                [16] = {
                    label = "Crosshatch Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_16"
                },
                [17] = {
                    label = "No Master Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_17"
                },
                [18] = {
                    label = "Police Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_18"
                },
                [19] = {
                    label = "Hat (125-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_19"
                },
                [20] = {
                    label = "Hat (125-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_20"
                },
                [21] = {
                    label = "Hat (125-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_21"
                },
                [22] = {
                    label = "Hat (125-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_22"
                },
                [23] = {
                    label = "Hat (125-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_125_23"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_0"
                },
                [1] = {
                    label = "Cream Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_1"
                },
                [2] = {
                    label = "Stone Gray Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_2"
                },
                [3] = {
                    label = "Brown Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_3"
                },
                [4] = {
                    label = "Ox Blood Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_4"
                },
                [5] = {
                    label = "Blue Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_5"
                },
                [6] = {
                    label = "Brown Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_6"
                },
                [7] = {
                    label = "Gray Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_7"
                },
                [8] = {
                    label = "Contrast Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_8"
                },
                [9] = {
                    label = "Blue Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_9"
                },
                [10] = {
                    label = "Fall Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_10"
                },
                [11] = {
                    label = "Aqua Camo Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_11"
                },
                [12] = {
                    label = "Light Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_12"
                },
                [13] = {
                    label = "Splinter Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_13"
                },
                [14] = {
                    label = "Gray Woodland Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_14"
                },
                [15] = {
                    label = "Moss Digital Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_15"
                },
                [16] = {
                    label = "Crosshatch Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_16"
                },
                [17] = {
                    label = "No Master Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_17"
                },
                [18] = {
                    label = "Police Shielded Riot",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_18"
                },
                [19] = {
                    label = "Hat (126-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_19"
                },
                [20] = {
                    label = "Hat (126-20)",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_20"
                },
                [21] = {
                    label = "Hat (126-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_21"
                },
                [22] = {
                    label = "Hat (126-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_22"
                },
                [23] = {
                    label = "Hat (126-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_126_23"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (127-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_127_0"
                },
                [1] = {
                    label = "Hat (127-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_127_1"
                },
                [2] = {
                    label = "Hat (127-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_127_2"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (128-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_128_0"
                },
                [1] = {
                    label = "Hat (128-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_128_1"
                },
                [2] = {
                    label = "Hat (128-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_128_2"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (129-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_0"
                },
                [1] = {
                    label = "Hat (129-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_1"
                },
                [2] = {
                    label = "Hat (129-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_2"
                },
                [3] = {
                    label = "Hat (129-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_3"
                },
                [4] = {
                    label = "Hat (129-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_4"
                },
                [5] = {
                    label = "Hat (129-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_5"
                },
                [6] = {
                    label = "Hat (129-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_6"
                },
                [7] = {
                    label = "Hat (129-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_7"
                },
                [8] = {
                    label = "Hat (129-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_8"
                },
                [9] = {
                    label = "Hat (129-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_9"
                },
                [10] = {
                    label = "Hat (129-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_10"
                },
                [11] = {
                    label = "Hat (129-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_11"
                },
                [12] = {
                    label = "Hat (129-12)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_12"
                },
                [13] = {
                    label = "Hat (129-13)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_13"
                },
                [14] = {
                    label = "Hat (129-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_14"
                },
                [15] = {
                    label = "Hat (129-15)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_15"
                },
                [16] = {
                    label = "Hat (129-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_16"
                },
                [17] = {
                    label = "Hat (129-17)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_17"
                },
                [18] = {
                    label = "Hat (129-18)",
                    price = 500,
                    type = "money",
                    image = "male_hat_129_18"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Burger Shot Burgers Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_0"
                },
                [1] = {
                    label = "Burger Shot Fries Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_1"
                },
                [2] = {
                    label = "Burger Shot Logo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_2"
                },
                [3] = {
                    label = "Burger Shot Bullseye Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_3"
                },
                [4] = {
                    label = "Yellow Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_4"
                },
                [5] = {
                    label = "Blue Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_5"
                },
                [6] = {
                    label = "Cluckin' Bell Logos Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_6"
                },
                [7] = {
                    label = "Black Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_7"
                },
                [8] = {
                    label = "Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_8"
                },
                [9] = {
                    label = "Purple Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_9"
                },
                [10] = {
                    label = "Pink Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_10"
                },
                [11] = {
                    label = "White Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_11"
                },
                [12] = {
                    label = "Red Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_12"
                },
                [13] = {
                    label = "Lucky Plucker Red Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_13"
                },
                [14] = {
                    label = "Lucky Plucker White Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_14"
                },
                [15] = {
                    label = "White Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_15"
                },
                [16] = {
                    label = "Black Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_16"
                },
                [17] = {
                    label = "White Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_17"
                },
                [18] = {
                    label = "Green Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_18"
                },
                [19] = {
                    label = "Hat (130-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_130_19"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Burger Shot Burgers Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_0"
                },
                [1] = {
                    label = "Burger Shot Fries Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_1"
                },
                [2] = {
                    label = "Burger Shot Logo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_2"
                },
                [3] = {
                    label = "Burger Shot Bullseye Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_3"
                },
                [4] = {
                    label = "Yellow Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_4"
                },
                [5] = {
                    label = "Blue Cluckin' Bell Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_5"
                },
                [6] = {
                    label = "Cluckin' Bell Logos Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_6"
                },
                [7] = {
                    label = "Black Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_7"
                },
                [8] = {
                    label = "Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_8"
                },
                [9] = {
                    label = "Purple Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_9"
                },
                [10] = {
                    label = "Pink Hotdogs Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_10"
                },
                [11] = {
                    label = "White Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_11"
                },
                [12] = {
                    label = "Red Lucky Plucker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_12"
                },
                [13] = {
                    label = "Lucky Plucker Red Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_13"
                },
                [14] = {
                    label = "Lucky Plucker White Pattern Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_14"
                },
                [15] = {
                    label = "White Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_15"
                },
                [16] = {
                    label = "Black Pisswasser Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_16"
                },
                [17] = {
                    label = "White Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_17"
                },
                [18] = {
                    label = "Green Taco Bomb Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_18"
                },
                [19] = {
                    label = "Hat (131-19)",
                    price = 500,
                    type = "money",
                    image = "male_hat_131_19"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Taco Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_132_0"
                },
                [1] = {
                    label = "Burger Shot Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_132_1"
                },
                [2] = {
                    label = "Cluckin' Bell Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_132_2"
                },
                [3] = {
                    label = "Hotdogs Canvas Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_132_3"
                },
                [4] = {
                    label = "Hat (132-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_132_4"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (133-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_0"
                },
                [1] = {
                    label = "Hat (133-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_1"
                },
                [2] = {
                    label = "Hat (133-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_2"
                },
                [3] = {
                    label = "Hat (133-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_3"
                },
                [4] = {
                    label = "Hat (133-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_4"
                },
                [5] = {
                    label = "Hat (133-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_5"
                },
                [6] = {
                    label = "Hat (133-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_6"
                },
                [7] = {
                    label = "Hat (133-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_7"
                },
                [8] = {
                    label = "Hat (133-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_8"
                },
                [9] = {
                    label = "Hat (133-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_9"
                },
                [10] = {
                    label = "Hat (133-10)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_10"
                },
                [11] = {
                    label = "Hat (133-11)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_11"
                },
                [12] = {
                    label = "Hat (133-12)",
                    price = 500,
                    type = "money",
                    image = "male_hat_133_12"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (134-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_134_0"
                },
                [1] = {
                    label = "Hat (134-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_134_1"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_0"
                },
                [1] = {
                    label = "Black The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_1"
                },
                [2] = {
                    label = "White LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_2"
                },
                [3] = {
                    label = "Black LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_3"
                },
                [4] = {
                    label = "Red The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_4"
                },
                [5] = {
                    label = "Orange The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_5"
                },
                [6] = {
                    label = "Blue LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_6"
                },
                [7] = {
                    label = "Green The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_7"
                },
                [8] = {
                    label = "Orange LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_8"
                },
                [9] = {
                    label = "Purple The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_9"
                },
                [10] = {
                    label = "Pink LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_10"
                },
                [11] = {
                    label = "White Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_11"
                },
                [12] = {
                    label = "Black Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_12"
                },
                [13] = {
                    label = "Teal Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_13"
                },
                [14] = {
                    label = "Red Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_14"
                },
                [15] = {
                    label = "Green Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_15"
                },
                [16] = {
                    label = "Black SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_16"
                },
                [17] = {
                    label = "Teal SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_17"
                },
                [18] = {
                    label = "Purple SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_18"
                },
                [19] = {
                    label = "Red SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_19"
                },
                [20] = {
                    label = "White SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_20"
                },
                [21] = {
                    label = "Gray Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_21"
                },
                [22] = {
                    label = "Colors Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_22"
                },
                [23] = {
                    label = "Woodland Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_23"
                },
                [24] = {
                    label = "Hat (135-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_135_24"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_0"
                },
                [1] = {
                    label = "Black The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_1"
                },
                [2] = {
                    label = "White LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_2"
                },
                [3] = {
                    label = "Black LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_3"
                },
                [4] = {
                    label = "Red The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_4"
                },
                [5] = {
                    label = "Orange The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_5"
                },
                [6] = {
                    label = "Blue LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_6"
                },
                [7] = {
                    label = "Green The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_7"
                },
                [8] = {
                    label = "Orange LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_8"
                },
                [9] = {
                    label = "Purple The Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_9"
                },
                [10] = {
                    label = "Pink LS Diamond Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_10"
                },
                [11] = {
                    label = "White Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_11"
                },
                [12] = {
                    label = "Black Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_12"
                },
                [13] = {
                    label = "Teal Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_13"
                },
                [14] = {
                    label = "Red Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_14"
                },
                [15] = {
                    label = "Green Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_15"
                },
                [16] = {
                    label = "Black SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_16"
                },
                [17] = {
                    label = "Teal SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_17"
                },
                [18] = {
                    label = "Purple SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_18"
                },
                [19] = {
                    label = "Red SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_19"
                },
                [20] = {
                    label = "White SC Broker Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_20"
                },
                [21] = {
                    label = "Gray Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_21"
                },
                [22] = {
                    label = "Colors Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_22"
                },
                [23] = {
                    label = "Woodland Yeti Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_23"
                },
                [24] = {
                    label = "Hat (136-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_136_24"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Firefighter",
                    price = 500,
                    type = "money",
                    image = "male_hat_137_0"
                },
                [1] = {
                    label = "Orange Firefighter",
                    price = 500,
                    type = "money",
                    image = "male_hat_137_1"
                },
                [2] = {
                    label = "White Firefighter",
                    price = 500,
                    type = "money",
                    image = "male_hat_137_2"
                },
                [3] = {
                    label = "Hat (137-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_137_3"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "male_hat_138_0"
                },
                [1] = {
                    label = "Orange Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "male_hat_138_1"
                },
                [2] = {
                    label = "White Firefighter & Goggles",
                    price = 500,
                    type = "money",
                    image = "male_hat_138_2"
                },
                [3] = {
                    label = "Hat (138-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_138_3"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bugstars Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_139_0"
                },
                [1] = {
                    label = "Prison Authority Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_139_1"
                },
                [2] = {
                    label = "Yung Ancestor Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_139_2"
                },
                [3] = {
                    label = "Hat (139-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_139_3"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bugstars Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_140_0"
                },
                [1] = {
                    label = "Prison Authority Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_140_1"
                },
                [2] = {
                    label = "Yung Ancestor Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_140_2"
                },
                [3] = {
                    label = "Hat (140-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_140_3"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (141-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_141_0"
                },
                [1] = {
                    label = "Hat (141-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_141_1"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_0"
                },
                [1] = {
                    label = "Gray Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_1"
                },
                [2] = {
                    label = "Light Gray Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_2"
                },
                [3] = {
                    label = "Red Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_3"
                },
                [4] = {
                    label = "Teal Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_4"
                },
                [5] = {
                    label = "Smiley Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_5"
                },
                [6] = {
                    label = "Gray Digital Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_6"
                },
                [7] = {
                    label = "Blue Digital Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_7"
                },
                [8] = {
                    label = "Blue Wave Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_8"
                },
                [9] = {
                    label = "Stars & Stripes Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_9"
                },
                [10] = {
                    label = "Toothy Grin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_10"
                },
                [11] = {
                    label = "Wolf Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_11"
                },
                [12] = {
                    label = "Gray Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_12"
                },
                [13] = {
                    label = "Black Skull Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_13"
                },
                [14] = {
                    label = "Blood Cross Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_14"
                },
                [15] = {
                    label = "Brown Skull Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_15"
                },
                [16] = {
                    label = "Green Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_16"
                },
                [17] = {
                    label = "Green Neon Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_17"
                },
                [18] = {
                    label = "Purple Neon Camo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_18"
                },
                [19] = {
                    label = "Cobble Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_19"
                },
                [20] = {
                    label = "Green Snakeskin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_20"
                },
                [21] = {
                    label = "Purple Snakeskin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_21"
                },
                [22] = {
                    label = "Hat (142-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_22"
                },
                [23] = {
                    label = "Hat (142-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_23"
                },
                [24] = {
                    label = "Hat (142-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_24"
                },
                [25] = {
                    label = "Hat (142-25)",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_25"
                },
                [26] = {
                    label = "Hat (142-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_142_26"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_0"
                },
                [1] = {
                    label = "Gray Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_1"
                },
                [2] = {
                    label = "Light Gray Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_2"
                },
                [3] = {
                    label = "Red Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_3"
                },
                [4] = {
                    label = "Teal Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_4"
                },
                [5] = {
                    label = "Smiley Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_5"
                },
                [6] = {
                    label = "Gray Digital Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_6"
                },
                [7] = {
                    label = "Blue Digital Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_7"
                },
                [8] = {
                    label = "Blue Wave Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_8"
                },
                [9] = {
                    label = "Stars & Stripes Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_9"
                },
                [10] = {
                    label = "Toothy Grin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_10"
                },
                [11] = {
                    label = "Wolf Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_11"
                },
                [12] = {
                    label = "Gray Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_12"
                },
                [13] = {
                    label = "Black Skull Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_13"
                },
                [14] = {
                    label = "Blood Cross Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_14"
                },
                [15] = {
                    label = "Brown Skull Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_15"
                },
                [16] = {
                    label = "Green Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_16"
                },
                [17] = {
                    label = "Green Neon Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_17"
                },
                [18] = {
                    label = "Purple Neon Camo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_18"
                },
                [19] = {
                    label = "Cobble Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_19"
                },
                [20] = {
                    label = "Green Snakeskin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_20"
                },
                [21] = {
                    label = "Purple Snakeskin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_21"
                },
                [22] = {
                    label = "Hat (143-22)",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_22"
                },
                [23] = {
                    label = "Hat (143-23)",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_23"
                },
                [24] = {
                    label = "Hat (143-24)",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_24"
                },
                [25] = {
                    label = "Hat (143-25)",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_25"
                },
                [26] = {
                    label = "Hat (143-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_143_26"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gruppe Sechs Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_144_0"
                },
                [1] = {
                    label = "Hat (144-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_144_1"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_145_0"
                },
                [1] = {
                    label = "Orange Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_145_1"
                },
                [2] = {
                    label = "White Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_145_2"
                },
                [3] = {
                    label = "Blue Construction Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_145_3"
                },
                [4] = {
                    label = "Hat (145-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_145_4"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_0"
                },
                [1] = {
                    label = "Dark Gray Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_1"
                },
                [2] = {
                    label = "Dusty Violet Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_2"
                },
                [3] = {
                    label = "Light Gray Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_3"
                },
                [4] = {
                    label = "Sage Green Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_4"
                },
                [5] = {
                    label = "Dusty Pink Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_5"
                },
                [6] = {
                    label = "Red Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_6"
                },
                [7] = {
                    label = "Terracotta Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_7"
                },
                [8] = {
                    label = "Cream Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_8"
                },
                [9] = {
                    label = "Ivory Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_9"
                },
                [10] = {
                    label = "Ash Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_10"
                },
                [11] = {
                    label = "Dark Violet Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_11"
                },
                [12] = {
                    label = "Eggshell Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_12"
                },
                [13] = {
                    label = "White Undertaker Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_13"
                },
                [14] = {
                    label = "Hat (146-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_146_14"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_0"
                },
                [1] = {
                    label = "Sage Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_1"
                },
                [2] = {
                    label = "Beige Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_2"
                },
                [3] = {
                    label = "Stone Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_3"
                },
                [4] = {
                    label = "White Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_4"
                },
                [5] = {
                    label = "Beige Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_5"
                },
                [6] = {
                    label = "Green Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_6"
                },
                [7] = {
                    label = "Desert Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_7"
                },
                [8] = {
                    label = "Hat (147-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_147_8"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_0"
                },
                [1] = {
                    label = "Sage Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_1"
                },
                [2] = {
                    label = "Beige Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_2"
                },
                [3] = {
                    label = "Stone Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_3"
                },
                [4] = {
                    label = "White Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_4"
                },
                [5] = {
                    label = "Beige Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_5"
                },
                [6] = {
                    label = "Green Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_6"
                },
                [7] = {
                    label = "Desert Digital Scope Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_7"
                },
                [8] = {
                    label = "Hat (148-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_148_8"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Captain Peaked Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_149_0"
                },
                [1] = {
                    label = "Hat (149-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_149_1"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_0"
                },
                [1] = {
                    label = "Moss Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_1"
                },
                [2] = {
                    label = "Brown Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_2"
                },
                [3] = {
                    label = "White Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_3"
                },
                [4] = {
                    label = "Hat (150-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_4"
                },
                [5] = {
                    label = "Hat (150-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_5"
                },
                [6] = {
                    label = "Hat (150-6)",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_6"
                },
                [7] = {
                    label = "Hat (150-7)",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_7"
                },
                [8] = {
                    label = "Leopard Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_8"
                },
                [9] = {
                    label = "Brown Digital Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_9"
                },
                [10] = {
                    label = "Tiger Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_10"
                },
                [11] = {
                    label = "Pink Pattern Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_11"
                },
                [12] = {
                    label = "Peach Digital Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_12"
                },
                [13] = {
                    label = "Fall Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_13"
                },
                [14] = {
                    label = "Dark Woodland Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_14"
                },
                [15] = {
                    label = "Crosshatch Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_15"
                },
                [16] = {
                    label = "Green Pattern Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_16"
                },
                [17] = {
                    label = "Gray Woodland Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_17"
                },
                [18] = {
                    label = "Aqua Camo Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_18"
                },
                [19] = {
                    label = "Splinter Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_19"
                },
                [20] = {
                    label = "Contrast Camo Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_20"
                },
                [21] = {
                    label = "Cobble Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_21"
                },
                [22] = {
                    label = "Brushstroke Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_22"
                },
                [23] = {
                    label = "Flecktarn Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_23"
                },
                [24] = {
                    label = "Black & Red Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_24"
                },
                [25] = {
                    label = "Zebra Advanced",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_25"
                },
                [26] = {
                    label = "Hat (150-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_150_26"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Enus Yeti Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_0"
                },
                [1] = {
                    label = "720 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_2"
                },
                [3] = {
                    label = "Güffy Double Logo Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_3"
                },
                [4] = {
                    label = "Rockstar Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_4"
                },
                [5] = {
                    label = "Civilist White Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_5"
                },
                [6] = {
                    label = "Civilist Black Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_6"
                },
                [7] = {
                    label = "Civilist Orange Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_7"
                },
                [8] = {
                    label = "Hat (151-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_151_8"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Enus Yeti Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_0"
                },
                [1] = {
                    label = "720 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_2"
                },
                [3] = {
                    label = "Güffy Double Logo Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_3"
                },
                [4] = {
                    label = "Rockstar Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_4"
                },
                [5] = {
                    label = "Civilist White Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_5"
                },
                [6] = {
                    label = "Civilist Black Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_6"
                },
                [7] = {
                    label = "Civilist Orange Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_7"
                },
                [8] = {
                    label = "Hat (152-8)",
                    price = 500,
                    type = "money",
                    image = "male_hat_152_8"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Frontier Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_153_0"
                },
                [1] = {
                    label = "Hat (153-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_153_1"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Sprunk Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_0"
                },
                [1] = {
                    label = "eCola Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_1"
                },
                [2] = {
                    label = "Broker Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_2"
                },
                [3] = {
                    label = "Light Dinka Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_3"
                },
                [4] = {
                    label = "Dark Dinka Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_4"
                },
                [5] = {
                    label = "White Güffy Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_5"
                },
                [6] = {
                    label = "Black Güffy Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_6"
                },
                [7] = {
                    label = "Annis Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_7"
                },
                [8] = {
                    label = "Hellion Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_8"
                },
                [9] = {
                    label = "Emperor Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_9"
                },
                [10] = {
                    label = "Karin Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_10"
                },
                [11] = {
                    label = "Lampadati Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_11"
                },
                [12] = {
                    label = "Omnis Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_12"
                },
                [13] = {
                    label = "Vapid Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_13"
                },
                [14] = {
                    label = "Hat (154-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_154_14"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Sprunk Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_0"
                },
                [1] = {
                    label = "eCola Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_1"
                },
                [2] = {
                    label = "Broker Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_2"
                },
                [3] = {
                    label = "Light Dinka Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_3"
                },
                [4] = {
                    label = "Dark Dinka Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_4"
                },
                [5] = {
                    label = "White Güffy Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_5"
                },
                [6] = {
                    label = "Black Güffy Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_6"
                },
                [7] = {
                    label = "Annis Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_7"
                },
                [8] = {
                    label = "Hellion Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_8"
                },
                [9] = {
                    label = "Emperor Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_9"
                },
                [10] = {
                    label = "Karin Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_10"
                },
                [11] = {
                    label = "Lampadati Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_11"
                },
                [12] = {
                    label = "Omnis Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_12"
                },
                [13] = {
                    label = "Vapid Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_13"
                },
                [14] = {
                    label = "Hat (155-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_155_14"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_0"
                },
                [1] = {
                    label = "Yellow Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_1"
                },
                [2] = {
                    label = "Gray Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_2"
                },
                [3] = {
                    label = "Navy Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_3"
                },
                [4] = {
                    label = "Red Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_4"
                },
                [5] = {
                    label = "Beige Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_5"
                },
                [6] = {
                    label = "Salmon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_6"
                },
                [7] = {
                    label = "Orange Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_7"
                },
                [8] = {
                    label = "Chocolate Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_8"
                },
                [9] = {
                    label = "Slate Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_9"
                },
                [10] = {
                    label = "Ice Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_10"
                },
                [11] = {
                    label = "Crimson Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_11"
                },
                [12] = {
                    label = "Green Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_12"
                },
                [13] = {
                    label = "Blue Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_13"
                },
                [14] = {
                    label = "Olive Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_14"
                },
                [15] = {
                    label = "Maroon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_15"
                },
                [16] = {
                    label = "Lemon Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_16"
                },
                [17] = {
                    label = "Hot Pink Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_17"
                },
                [18] = {
                    label = "Black Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_18"
                },
                [19] = {
                    label = "Contrast Camo Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_19"
                },
                [20] = {
                    label = "Aqua Camo Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_20"
                },
                [21] = {
                    label = "Brushstroke Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_21"
                },
                [22] = {
                    label = "Brown Digital Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_22"
                },
                [23] = {
                    label = "Gray Woodland Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_23"
                },
                [24] = {
                    label = "Vibrant Heat Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_24"
                },
                [25] = {
                    label = "Navy Prolaps Curved Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_25"
                },
                [26] = {
                    label = "Hat (156-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_156_26"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_0"
                },
                [1] = {
                    label = "Yellow Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_1"
                },
                [2] = {
                    label = "Gray Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_2"
                },
                [3] = {
                    label = "Navy Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_3"
                },
                [4] = {
                    label = "Red Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_4"
                },
                [5] = {
                    label = "Beige Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_5"
                },
                [6] = {
                    label = "Salmon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_6"
                },
                [7] = {
                    label = "Orange Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_7"
                },
                [8] = {
                    label = "Chocolate Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_8"
                },
                [9] = {
                    label = "Slate Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_9"
                },
                [10] = {
                    label = "Ice Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_10"
                },
                [11] = {
                    label = "Crimson Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_11"
                },
                [12] = {
                    label = "Green Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_12"
                },
                [13] = {
                    label = "Blue Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_13"
                },
                [14] = {
                    label = "Olive Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_14"
                },
                [15] = {
                    label = "Maroon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_15"
                },
                [16] = {
                    label = "Lemon Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_16"
                },
                [17] = {
                    label = "Hot Pink Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_17"
                },
                [18] = {
                    label = "Black Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_18"
                },
                [19] = {
                    label = "Contrast Camo Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_19"
                },
                [20] = {
                    label = "Aqua Camo Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_20"
                },
                [21] = {
                    label = "Brushstroke Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_21"
                },
                [22] = {
                    label = "Brown Digital Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_22"
                },
                [23] = {
                    label = "Gray Woodland Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_23"
                },
                [24] = {
                    label = "Vibrant Heat Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_24"
                },
                [25] = {
                    label = "Navy Prolaps Curved Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_25"
                },
                [26] = {
                    label = "Hat (157-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_157_26"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_0"
                },
                [1] = {
                    label = "Yellow Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_1"
                },
                [2] = {
                    label = "Gray Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_2"
                },
                [3] = {
                    label = "Navy Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_3"
                },
                [4] = {
                    label = "Red Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_4"
                },
                [5] = {
                    label = "Beige Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_5"
                },
                [6] = {
                    label = "Salmon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_6"
                },
                [7] = {
                    label = "Orange Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_7"
                },
                [8] = {
                    label = "Chocolate Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_8"
                },
                [9] = {
                    label = "Slate Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_9"
                },
                [10] = {
                    label = "Ice Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_10"
                },
                [11] = {
                    label = "Crimson Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_11"
                },
                [12] = {
                    label = "Green Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_12"
                },
                [13] = {
                    label = "Blue Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_13"
                },
                [14] = {
                    label = "Olive Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_14"
                },
                [15] = {
                    label = "Maroon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_15"
                },
                [16] = {
                    label = "Lemon Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_16"
                },
                [17] = {
                    label = "Hot Pink Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_17"
                },
                [18] = {
                    label = "Black Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_18"
                },
                [19] = {
                    label = "Contrast Camo Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_19"
                },
                [20] = {
                    label = "Aqua Camo Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_20"
                },
                [21] = {
                    label = "Brushstroke Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_21"
                },
                [22] = {
                    label = "Brown Digital Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_22"
                },
                [23] = {
                    label = "Gray Woodland Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_23"
                },
                [24] = {
                    label = "Vibrant Heat Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_24"
                },
                [25] = {
                    label = "White Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_25"
                },
                [26] = {
                    label = "Hat (158-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_158_26"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Navy Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_159_0"
                },
                [1] = {
                    label = "Green Prolaps Flat Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_159_1"
                },
                [2] = {
                    label = "Hat (159-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_159_2"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_0"
                },
                [1] = {
                    label = "Yellow Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_1"
                },
                [2] = {
                    label = "Gray Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_2"
                },
                [3] = {
                    label = "Navy Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_3"
                },
                [4] = {
                    label = "Red Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_4"
                },
                [5] = {
                    label = "Beige Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_5"
                },
                [6] = {
                    label = "Salmon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_6"
                },
                [7] = {
                    label = "Orange Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_7"
                },
                [8] = {
                    label = "Chocolate Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_8"
                },
                [9] = {
                    label = "Slate Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_9"
                },
                [10] = {
                    label = "Ice Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_10"
                },
                [11] = {
                    label = "Crimson Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_11"
                },
                [12] = {
                    label = "Green Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_12"
                },
                [13] = {
                    label = "Blue Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_13"
                },
                [14] = {
                    label = "Olive Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_14"
                },
                [15] = {
                    label = "Maroon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_15"
                },
                [16] = {
                    label = "Lemon Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_16"
                },
                [17] = {
                    label = "Hot Pink Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_17"
                },
                [18] = {
                    label = "Black Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_18"
                },
                [19] = {
                    label = "Contrast Camo Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_19"
                },
                [20] = {
                    label = "Aqua Camo Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_20"
                },
                [21] = {
                    label = "Brushstroke Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_21"
                },
                [22] = {
                    label = "Brown Digital Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_22"
                },
                [23] = {
                    label = "Gray Woodland Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_23"
                },
                [24] = {
                    label = "Vibrant Heat Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_24"
                },
                [25] = {
                    label = "White Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_25"
                },
                [26] = {
                    label = "Hat (160-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_160_26"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Navy Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_161_0"
                },
                [1] = {
                    label = "Green Prolaps Flat Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_161_1"
                },
                [2] = {
                    label = "Hat (161-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_161_2"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Broker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_0"
                },
                [1] = {
                    label = "Gray Broker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_1"
                },
                [2] = {
                    label = "Black Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_2"
                },
                [3] = {
                    label = "Yellow Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_3"
                },
                [4] = {
                    label = "Yellow Camo Trickster Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_4"
                },
                [5] = {
                    label = "Black VDG Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_5"
                },
                [6] = {
                    label = "Yellow VDG Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_6"
                },
                [7] = {
                    label = "Black Pounders Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_7"
                },
                [8] = {
                    label = "White Pounders Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_8"
                },
                [9] = {
                    label = "Hat (162-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_162_9"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Broker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_0"
                },
                [1] = {
                    label = "Gray Broker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_1"
                },
                [2] = {
                    label = "Black Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_2"
                },
                [3] = {
                    label = "Yellow Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_3"
                },
                [4] = {
                    label = "Yellow Camo Trickster Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_4"
                },
                [5] = {
                    label = "Black VDG Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_5"
                },
                [6] = {
                    label = "Yellow VDG Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_6"
                },
                [7] = {
                    label = "Black Pounders Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_7"
                },
                [8] = {
                    label = "White Pounders Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_8"
                },
                [9] = {
                    label = "Hat (163-9)",
                    price = 500,
                    type = "money",
                    image = "male_hat_163_9"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black LD Organics Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_164_0"
                },
                [1] = {
                    label = "Hat (164-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_164_1"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black LD Organics Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_165_0"
                },
                [1] = {
                    label = "Hat (165-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_165_1"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_166_0"
                },
                [1] = {
                    label = "Black Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_166_1"
                },
                [2] = {
                    label = "Hat (166-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_166_2"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Believe Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_167_0"
                },
                [1] = {
                    label = "Hat (167-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_167_1"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_168_0"
                },
                [1] = {
                    label = "Black Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_168_1"
                },
                [2] = {
                    label = "Hat (168-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_168_2"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Ice Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_0"
                },
                [1] = {
                    label = "Ash Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_1"
                },
                [2] = {
                    label = "Mono Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_2"
                },
                [3] = {
                    label = "Dark Gray Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_3"
                },
                [4] = {
                    label = "Beige Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_4"
                },
                [5] = {
                    label = "Chocolate Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_5"
                },
                [6] = {
                    label = "Burgundy Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_6"
                },
                [7] = {
                    label = "Hot Pink Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_7"
                },
                [8] = {
                    label = "Scarlet Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_8"
                },
                [9] = {
                    label = "Orange Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_9"
                },
                [10] = {
                    label = "Amber Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_10"
                },
                [11] = {
                    label = "Lemon Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_11"
                },
                [12] = {
                    label = "Royal Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_12"
                },
                [13] = {
                    label = "Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_13"
                },
                [14] = {
                    label = "Teal Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_14"
                },
                [15] = {
                    label = "Cyan Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_15"
                },
                [16] = {
                    label = "Light Blue Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_16"
                },
                [17] = {
                    label = "Lilac Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_17"
                },
                [18] = {
                    label = "Dark Green Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_18"
                },
                [19] = {
                    label = "Emerald Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_19"
                },
                [20] = {
                    label = "Moss Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_20"
                },
                [21] = {
                    label = "Lime Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_21"
                },
                [22] = {
                    label = "Peach Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_22"
                },
                [23] = {
                    label = "Lavender Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_23"
                },
                [24] = {
                    label = "Purple Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_24"
                },
                [25] = {
                    label = "Magenta Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_25"
                },
                [26] = {
                    label = "Hat (169-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_169_26"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Yeti Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_0"
                },
                [1] = {
                    label = "Woodland Yeti Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_1"
                },
                [2] = {
                    label = "Green FB Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_2"
                },
                [3] = {
                    label = "Blue FB Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_3"
                },
                [4] = {
                    label = "Gray Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_4"
                },
                [5] = {
                    label = "Green Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_5"
                },
                [6] = {
                    label = "Light Plaid Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_6"
                },
                [7] = {
                    label = "Dark Plaid Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_7"
                },
                [8] = {
                    label = "White Striped Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_8"
                },
                [9] = {
                    label = "Red Striped Lézard Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_9"
                },
                [10] = {
                    label = "Brown Crevis Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_10"
                },
                [11] = {
                    label = "Gray Crevis Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_11"
                },
                [12] = {
                    label = "Black Broker Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_12"
                },
                [13] = {
                    label = "Burgundy Broker Flat Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_13"
                },
                [14] = {
                    label = "Hat (170-14)",
                    price = 500,
                    type = "money",
                    image = "male_hat_170_14"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Glow Believe Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_171_0"
                },
                [1] = {
                    label = "Hat (171-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_171_1"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Strickler Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_172_0"
                },
                [1] = {
                    label = "Hat (172-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_172_1"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_0"
                },
                [1] = {
                    label = "Dark Gray Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_1"
                },
                [2] = {
                    label = "Gray Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_2"
                },
                [3] = {
                    label = "Ice Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_3"
                },
                [4] = {
                    label = "Beige Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_4"
                },
                [5] = {
                    label = "Chocolate Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_5"
                },
                [6] = {
                    label = "Burgundy Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_6"
                },
                [7] = {
                    label = "Hot Pink Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_7"
                },
                [8] = {
                    label = "Scarlet Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_8"
                },
                [9] = {
                    label = "Orange Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_9"
                },
                [10] = {
                    label = "Amber Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_10"
                },
                [11] = {
                    label = "Lemon Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_11"
                },
                [12] = {
                    label = "Royal Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_12"
                },
                [13] = {
                    label = "Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_13"
                },
                [14] = {
                    label = "Teal Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_14"
                },
                [15] = {
                    label = "Cyan Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_15"
                },
                [16] = {
                    label = "Light Blue Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_16"
                },
                [17] = {
                    label = "Lilac Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_17"
                },
                [18] = {
                    label = "Dark Green Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_18"
                },
                [19] = {
                    label = "Emerald Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_19"
                },
                [20] = {
                    label = "Moss Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_20"
                },
                [21] = {
                    label = "Lime Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_21"
                },
                [22] = {
                    label = "Peach Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_22"
                },
                [23] = {
                    label = "Lavender Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_23"
                },
                [24] = {
                    label = "Purple Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_24"
                },
                [25] = {
                    label = "Magenta Trucker Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_25"
                },
                [26] = {
                    label = "Hat (173-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_173_26"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_0"
                },
                [1] = {
                    label = "Dark Gray Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_1"
                },
                [2] = {
                    label = "Gray Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_2"
                },
                [3] = {
                    label = "Ice Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_3"
                },
                [4] = {
                    label = "Beige Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_4"
                },
                [5] = {
                    label = "Chocolate Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_5"
                },
                [6] = {
                    label = "Burgundy Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_6"
                },
                [7] = {
                    label = "Hot Pink Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_7"
                },
                [8] = {
                    label = "Scarlet Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_8"
                },
                [9] = {
                    label = "Orange Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_9"
                },
                [10] = {
                    label = "Amber Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_10"
                },
                [11] = {
                    label = "Lemon Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_11"
                },
                [12] = {
                    label = "Royal Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_12"
                },
                [13] = {
                    label = "Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_13"
                },
                [14] = {
                    label = "Teal Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_14"
                },
                [15] = {
                    label = "Cyan Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_15"
                },
                [16] = {
                    label = "Light Blue Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_16"
                },
                [17] = {
                    label = "Lilac Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_17"
                },
                [18] = {
                    label = "Dark Green Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_18"
                },
                [19] = {
                    label = "Emerald Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_19"
                },
                [20] = {
                    label = "Moss Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_20"
                },
                [21] = {
                    label = "Lime Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_21"
                },
                [22] = {
                    label = "Peach Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_22"
                },
                [23] = {
                    label = "Lavender Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_23"
                },
                [24] = {
                    label = "Purple Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_24"
                },
                [25] = {
                    label = "Magenta Trucker Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_25"
                },
                [26] = {
                    label = "Hat (174-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_174_26"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_0"
                },
                [1] = {
                    label = "Dark Gray Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_1"
                },
                [2] = {
                    label = "Gray Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_2"
                },
                [3] = {
                    label = "Ice Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_3"
                },
                [4] = {
                    label = "Beige Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_4"
                },
                [5] = {
                    label = "Chocolate Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_5"
                },
                [6] = {
                    label = "Burgundy Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_6"
                },
                [7] = {
                    label = "Hot Pink Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_7"
                },
                [8] = {
                    label = "Scarlet Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_8"
                },
                [9] = {
                    label = "Orange Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_9"
                },
                [10] = {
                    label = "Amber Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_10"
                },
                [11] = {
                    label = "Lemon Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_11"
                },
                [12] = {
                    label = "Royal Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_12"
                },
                [13] = {
                    label = "Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_13"
                },
                [14] = {
                    label = "Teal Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_14"
                },
                [15] = {
                    label = "Cyan Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_15"
                },
                [16] = {
                    label = "Light Blue Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_16"
                },
                [17] = {
                    label = "Lilac Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_17"
                },
                [18] = {
                    label = "Dark Green Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_18"
                },
                [19] = {
                    label = "Emerald Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_19"
                },
                [20] = {
                    label = "Moss Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_20"
                },
                [21] = {
                    label = "Lime Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_21"
                },
                [22] = {
                    label = "Peach Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_22"
                },
                [23] = {
                    label = "Lavender Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_23"
                },
                [24] = {
                    label = "Purple Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_24"
                },
                [25] = {
                    label = "Magenta Wool Beanie",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_25"
                },
                [26] = {
                    label = "Hat (175-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_175_26"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (176-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_176_0"
                },
                [1] = {
                    label = "Hat (176-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_176_1"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (177-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_177_0"
                },
                [1] = {
                    label = "Hat (177-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_177_1"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Yellow Holly Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_178_0"
                },
                [1] = {
                    label = "Green Reindeer Beer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_178_1"
                },
                [2] = {
                    label = "Hat (178-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_178_2"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Dome",
                    price = 500,
                    type = "money",
                    image = "male_hat_179_0"
                },
                [1] = {
                    label = "Hat (179-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_179_1"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Purple Snakeskin Spiked",
                    price = 500,
                    type = "money",
                    image = "male_hat_180_0"
                },
                [1] = {
                    label = "Hat (180-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_180_1"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_4"
                },
                [5] = {
                    label = "Pink Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_5"
                },
                [6] = {
                    label = "Cyan Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_6"
                },
                [7] = {
                    label = "Brown Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_7"
                },
                [8] = {
                    label = "Neon Script Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_8"
                },
                [9] = {
                    label = "Camo Roses Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_10"
                },
                [11] = {
                    label = "White Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_13"
                },
                [14] = {
                    label = "Blue Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_14"
                },
                [15] = {
                    label = "Green Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_15"
                },
                [16] = {
                    label = "Light Blue Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_16"
                },
                [17] = {
                    label = "Pink Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_17"
                },
                [18] = {
                    label = "Red Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_18"
                },
                [19] = {
                    label = "White Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_19"
                },
                [20] = {
                    label = "Blue Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_20"
                },
                [21] = {
                    label = "Black Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_21"
                },
                [22] = {
                    label = "Red Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_22"
                },
                [23] = {
                    label = "Taupe Bones Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_23"
                },
                [24] = {
                    label = "Black Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_24"
                },
                [25] = {
                    label = "Green Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_25"
                },
                [26] = {
                    label = "Hat (181-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_181_26"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Neon Sloped Slab Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_182_0"
                },
                [1] = {
                    label = "Blue Signs Squash Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_182_1"
                },
                [2] = {
                    label = "White Signs Squash Forwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_182_2"
                },
                [3] = {
                    label = "Hat (182-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_182_3"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_4"
                },
                [5] = {
                    label = "Pink Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_5"
                },
                [6] = {
                    label = "Cyan Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_6"
                },
                [7] = {
                    label = "Brown Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_7"
                },
                [8] = {
                    label = "Neon Script Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_8"
                },
                [9] = {
                    label = "Camo Roses Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_10"
                },
                [11] = {
                    label = "White Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_13"
                },
                [14] = {
                    label = "Blue Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_14"
                },
                [15] = {
                    label = "Green Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_15"
                },
                [16] = {
                    label = "Light Blue Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_16"
                },
                [17] = {
                    label = "Pink Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_17"
                },
                [18] = {
                    label = "Red Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_18"
                },
                [19] = {
                    label = "White Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_19"
                },
                [20] = {
                    label = "Blue Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_20"
                },
                [21] = {
                    label = "Black Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_21"
                },
                [22] = {
                    label = "Red Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_22"
                },
                [23] = {
                    label = "Taupe Bones Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_23"
                },
                [24] = {
                    label = "Black Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_24"
                },
                [25] = {
                    label = "Green Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_25"
                },
                [26] = {
                    label = "Hat (183-26)",
                    price = 500,
                    type = "money",
                    image = "male_hat_183_26"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Neon Sloped Slab Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_184_0"
                },
                [1] = {
                    label = "Blue Signs Squash Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_184_1"
                },
                [2] = {
                    label = "White Signs Squash Backwards",
                    price = 500,
                    type = "money",
                    image = "male_hat_184_2"
                },
                [3] = {
                    label = "Hat (184-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_184_3"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (185-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_185_0"
                },
                [1] = {
                    label = "Hat (185-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_185_1"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (186-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_186_0"
                },
                [1] = {
                    label = "Hat (186-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_186_1"
                },
                [2] = {
                    label = "Hat (186-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_186_2"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Pounders Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_187_0"
                },
                [1] = {
                    label = "Hat (187-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_187_1"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Pounders Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_188_0"
                },
                [1] = {
                    label = "Hat (188-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_188_1"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Alpine Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_189_0"
                },
                [1] = {
                    label = "Hat (189-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_189_1"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Car Meet Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_0"
                },
                [1] = {
                    label = "VIP Charter Jets Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_1"
                },
                [2] = {
                    label = "Cliffford Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_2"
                },
                [3] = {
                    label = "Maisonette Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_3"
                },
                [4] = {
                    label = "Rootin' Tootin' Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_4"
                },
                [5] = {
                    label = "LS Angels Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_5"
                },
                [6] = {
                    label = "IAA Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_6"
                },
                [7] = {
                    label = "Captain Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_7"
                },
                [8] = {
                    label = "PDM Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_8"
                },
                [9] = {
                    label = "Flying Bravo Andreas Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_9"
                },
                [10] = {
                    label = "Green LS Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_10"
                },
                [11] = {
                    label = "Peter Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_11"
                },
                [12] = {
                    label = "Survivalist Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_12"
                },
                [13] = {
                    label = "Grotti Furia Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_13"
                },
                [14] = {
                    label = "Black Eagle Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_14"
                },
                [15] = {
                    label = "Deathmatch Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_15"
                },
                [16] = {
                    label = "Hat (190-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_190_16"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'prop',
            textures = {
                [0] = {
                    label = "LS Car Meet Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_0"
                },
                [1] = {
                    label = "VIP Charter Jets Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_1"
                },
                [2] = {
                    label = "Cliffford Logo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_2"
                },
                [3] = {
                    label = "Maisonette Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_3"
                },
                [4] = {
                    label = "Rootin' Tootin' Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_4"
                },
                [5] = {
                    label = "LS Angels Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_5"
                },
                [6] = {
                    label = "IAA Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_6"
                },
                [7] = {
                    label = "Captain Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_7"
                },
                [8] = {
                    label = "PDM Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_8"
                },
                [9] = {
                    label = "Flying Bravo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_9"
                },
                [10] = {
                    label = "Green LS Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_10"
                },
                [11] = {
                    label = "Peter Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_11"
                },
                [12] = {
                    label = "Survivalist Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_12"
                },
                [13] = {
                    label = "Grotti Furia Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_13"
                },
                [14] = {
                    label = "Black Eagle Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_14"
                },
                [15] = {
                    label = "Deathmatch Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_15"
                },
                [16] = {
                    label = "Hat (191-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_191_16"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Vom Feuer Camo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_192_0"
                },
                [1] = {
                    label = "Western MC Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_192_1"
                },
                [2] = {
                    label = "Red & White Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_192_2"
                },
                [3] = {
                    label = "Santo Capra Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_192_3"
                },
                [4] = {
                    label = "Hat (192-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_192_4"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Vom Feuer Camo Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_193_0"
                },
                [1] = {
                    label = "Western MC Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_193_1"
                },
                [2] = {
                    label = "Red & White Ammu-Nation Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_193_2"
                },
                [3] = {
                    label = "Santo Capra Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_193_3"
                },
                [4] = {
                    label = "Hat (193-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_193_4"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Junk Energy Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_194_0"
                },
                [1] = {
                    label = "Hat (194-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_194_1"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Rockstar Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_195_0"
                },
                [1] = {
                    label = "Hat (195-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_195_1"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Rockstar Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_196_0"
                },
                [1] = {
                    label = "Hat (196-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_196_1"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (197-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_197_0"
                },
                [1] = {
                    label = "Hat (197-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_197_1"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Fireworks Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_198_0"
                },
                [1] = {
                    label = "Stars and Stripes Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_198_1"
                },
                [2] = {
                    label = "Lady Liberty Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_198_2"
                },
                [3] = {
                    label = "Bigness Carnival Bucket Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_198_3"
                },
                [4] = {
                    label = "Hat (198-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_198_4"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'prop',
            textures = {
                [0] = {
                    label = "CMYK Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_0"
                },
                [1] = {
                    label = "Sunset Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_1"
                },
                [2] = {
                    label = "Vibrant Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_2"
                },
                [3] = {
                    label = "Cool Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_3"
                },
                [4] = {
                    label = "Bright Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_4"
                },
                [5] = {
                    label = "Cool Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_5"
                },
                [6] = {
                    label = "Red Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_6"
                },
                [7] = {
                    label = "Yellow Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_7"
                },
                [8] = {
                    label = "Orange Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_8"
                },
                [9] = {
                    label = "Blue Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_9"
                },
                [10] = {
                    label = "Bold Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_10"
                },
                [11] = {
                    label = "Vibrant Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_11"
                },
                [12] = {
                    label = "Vivid Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_12"
                },
                [13] = {
                    label = "Neon Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_13"
                },
                [14] = {
                    label = "Warm Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_14"
                },
                [15] = {
                    label = "Wild Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_15"
                },
                [16] = {
                    label = "Hat (199-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_199_16"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'prop',
            textures = {
                [0] = {
                    label = "CMYK Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_0"
                },
                [1] = {
                    label = "Sunset Glitch HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_1"
                },
                [2] = {
                    label = "Vibrant Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_2"
                },
                [3] = {
                    label = "Cool Pixel HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_3"
                },
                [4] = {
                    label = "Bright Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_4"
                },
                [5] = {
                    label = "Cool Noise HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_5"
                },
                [6] = {
                    label = "Red Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_6"
                },
                [7] = {
                    label = "Yellow Geo HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_7"
                },
                [8] = {
                    label = "Orange Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_8"
                },
                [9] = {
                    label = "Blue Trip HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_9"
                },
                [10] = {
                    label = "Bold Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_10"
                },
                [11] = {
                    label = "Vibrant Shock HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_11"
                },
                [12] = {
                    label = "Vivid Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_12"
                },
                [13] = {
                    label = "Neon Torn HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_13"
                },
                [14] = {
                    label = "Warm Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_14"
                },
                [15] = {
                    label = "Wild Warped HSW Helmet",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_15"
                },
                [16] = {
                    label = "Hat (200-16)",
                    price = 500,
                    type = "money",
                    image = "male_hat_200_16"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Los Santos Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_201_0"
                },
                [1] = {
                    label = "Black LS Customs Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_201_1"
                },
                [2] = {
                    label = "Hat (201-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_201_2"
                },
            },
        },
        [202] = {
            drawable = 202,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Los Santos Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_202_0"
                },
                [1] = {
                    label = "Black LS Customs Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_202_1"
                },
                [2] = {
                    label = "Hat (202-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_202_2"
                },
            },
        },
        [203] = {
            drawable = 203,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Festive Reindeer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_203_0"
                },
                [1] = {
                    label = "White Festive Reindeer Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_203_1"
                },
                [2] = {
                    label = "Hat (203-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_203_2"
                },
            },
        },
        [204] = {
            drawable = 204,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Green Festive Tree Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_204_0"
                },
                [1] = {
                    label = "Red Festive Tree Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_204_1"
                },
                [2] = {
                    label = "Hat (204-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_204_2"
                },
            },
        },
        [205] = {
            drawable = 205,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (205-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_205_0"
                },
                [1] = {
                    label = "Hat (205-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_205_1"
                },
                [2] = {
                    label = "Hat (205-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_205_2"
                },
                [3] = {
                    label = "Hat (205-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_205_3"
                },
                [4] = {
                    label = "Hat (205-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_205_4"
                },
            },
        },
        [206] = {
            drawable = 206,
            type = 'prop',
            textures = {
                [0] = {
                    label = "1 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_0"
                },
                [1] = {
                    label = "2 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_1"
                },
                [2] = {
                    label = "3 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_2"
                },
                [3] = {
                    label = "4 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_3"
                },
                [4] = {
                    label = "5 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_4"
                },
                [5] = {
                    label = "6 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_5"
                },
                [6] = {
                    label = "7 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_6"
                },
                [7] = {
                    label = "8 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_7"
                },
                [8] = {
                    label = "9 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_8"
                },
                [9] = {
                    label = "10 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_9"
                },
                [10] = {
                    label = "11 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_10"
                },
                [11] = {
                    label = "12 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_11"
                },
                [12] = {
                    label = "13 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_12"
                },
                [13] = {
                    label = "14 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_13"
                },
                [14] = {
                    label = "15 Party Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_14"
                },
                [15] = {
                    label = "Hat (206-15)",
                    price = 500,
                    type = "money",
                    image = "male_hat_206_15"
                },
            },
        },
        [207] = {
            drawable = 207,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Heartbreakers Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_207_0"
                },
                [1] = {
                    label = "Red's Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_207_1"
                },
                [2] = {
                    label = "Hat (207-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_207_2"
                },
            },
        },
        [208] = {
            drawable = 208,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Heartbreakers Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_208_0"
                },
                [1] = {
                    label = "Red's Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_208_1"
                },
                [2] = {
                    label = "Hat (208-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_208_2"
                },
            },
        },
        [209] = {
            drawable = 209,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Bronze New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_209_0"
                },
                [1] = {
                    label = "Gold New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_209_1"
                },
                [2] = {
                    label = "Silver New Year's Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_209_2"
                },
                [3] = {
                    label = "Hat (209-3)",
                    price = 500,
                    type = "money",
                    image = "male_hat_209_3"
                },
            },
        },
        [210] = {
            drawable = 210,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (210-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_0"
                },
                [1] = {
                    label = "Hat (210-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_1"
                },
                [2] = {
                    label = "Hat (210-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_2"
                },
                [3] = {
                    label = "Strapz Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_3"
                },
                [4] = {
                    label = "Black 420 Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_4"
                },
                [5] = {
                    label = "Hat (210-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_210_5"
                },
            },
        },
        [211] = {
            drawable = 211,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (211-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_0"
                },
                [1] = {
                    label = "Hat (211-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_1"
                },
                [2] = {
                    label = "Hat (211-2)",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_2"
                },
                [3] = {
                    label = "Strapz Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_3"
                },
                [4] = {
                    label = "Black 420 Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_4"
                },
                [5] = {
                    label = "Hat (211-5)",
                    price = 500,
                    type = "money",
                    image = "male_hat_211_5"
                },
            },
        },
        [212] = {
            drawable = 212,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_212_0"
                },
                [1] = {
                    label = "Hat (212-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_212_1"
                },
            },
        },
        [213] = {
            drawable = 213,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_213_0"
                },
                [1] = {
                    label = "Hat (213-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_213_1"
                },
            },
        },
        [214] = {
            drawable = 214,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (214-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_214_0"
                },
                [1] = {
                    label = "Hat (214-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_214_1"
                },
            },
        },
        [215] = {
            drawable = 215,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (215-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_215_0"
                },
                [1] = {
                    label = "Hat (215-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_215_1"
                },
            },
        },
        [216] = {
            drawable = 216,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Beige Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_216_0"
                },
                [1] = {
                    label = "Cream Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_216_1"
                },
                [2] = {
                    label = "Gray Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_216_2"
                },
                [3] = {
                    label = "Black Straw Sun Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_216_3"
                },
                [4] = {
                    label = "Hat (216-4)",
                    price = 500,
                    type = "money",
                    image = "male_hat_216_4"
                },
            },
        },
        [217] = {
            drawable = 217,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pizza This... Forwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_217_0"
                },
                [1] = {
                    label = "Hat (217-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_217_1"
                },
            },
        },
        [218] = {
            drawable = 218,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pizza This... Backwards Cap",
                    price = 500,
                    type = "money",
                    image = "male_hat_218_0"
                },
                [1] = {
                    label = "Hat (218-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_218_1"
                },
            },
        },
        [219] = {
            drawable = 219,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Brown Alpine Hat",
                    price = 500,
                    type = "money",
                    image = "male_hat_219_0"
                },
                [1] = {
                    label = "Hat (219-1)",
                    price = 500,
                    type = "money",
                    image = "male_hat_219_1"
                },
            },
        },
        [220] = {
            drawable = 220,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Zebra Bigness Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_1"
                },
                [2] = {
                    label = "Black Cimicino Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_2"
                },
                [3] = {
                    label = "White Cimicino Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_3"
                },
                [4] = {
                    label = "Green FB Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_4"
                },
                [5] = {
                    label = "Blue FB Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_5"
                },
                [6] = {
                    label = "Red FB Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_6"
                },
                [7] = {
                    label = "Black Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_7"
                },
                [8] = {
                    label = "White Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_8"
                },
                [9] = {
                    label = "Cyan Leopard Güffy Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_9"
                },
                [10] = {
                    label = "Krapea Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_10"
                },
                [11] = {
                    label = "Black LC Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_11"
                },
                [12] = {
                    label = "White LC Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_12"
                },
                [13] = {
                    label = "Purple Panic Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_13"
                },
                [14] = {
                    label = "Yellow Panic Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_14"
                },
                [15] = {
                    label = "Black SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_15"
                },
                [16] = {
                    label = "Blue SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_16"
                },
                [17] = {
                    label = "Pink SC Coin Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_17"
                },
                [18] = {
                    label = "Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_18"
                },
                [19] = {
                    label = "Gray Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_19"
                },
                [20] = {
                    label = "Pink Camo Yeti Bucket",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_20"
                },
                [21] = {
                    label = "Hat (220-21)",
                    price = 500,
                    type = "money",
                    image = "male_hat_220_21"
                },
            },
        },
        [221] = {
            drawable = 221,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Hat (221-0)",
                    price = 500,
                    type = "money",
                    image = "male_hat_221_0"
                },
            },
        },
    },
}
