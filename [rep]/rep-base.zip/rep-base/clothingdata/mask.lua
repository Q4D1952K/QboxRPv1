mask = {

    female = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_0_0"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_1_0"
                },
                [1] = {
                    label = "Mask (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_1_1"
                },
                [2] = {
                    label = "Mask (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_1_2"
                },
                [3] = {
                    label = "Mask (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_1_3"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_2_0"
                },
                [1] = {
                    label = "Mask (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_2_1"
                },
                [2] = {
                    label = "Mask (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_2_2"
                },
                [3] = {
                    label = "Mask (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_2_3"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_3_0"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_4_0"
                },
                [1] = {
                    label = "Mask (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_4_1"
                },
                [2] = {
                    label = "Mask (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_4_2"
                },
                [3] = {
                    label = "Mask (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_4_3"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_5_0"
                },
                [1] = {
                    label = "Mask (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_5_1"
                },
                [2] = {
                    label = "Mask (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_5_2"
                },
                [3] = {
                    label = "Mask (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_5_3"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_6_0"
                },
                [1] = {
                    label = "Mask (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_6_1"
                },
                [2] = {
                    label = "Mask (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_6_2"
                },
                [3] = {
                    label = "Mask (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_6_3"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_7_0"
                },
                [1] = {
                    label = "Mask (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_7_1"
                },
                [2] = {
                    label = "Mask (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_7_2"
                },
                [3] = {
                    label = "Mask (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_7_3"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_8_0"
                },
                [1] = {
                    label = "Black Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_8_1"
                },
                [2] = {
                    label = "Latino Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_8_2"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Reindeer Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_9_0"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Snowman Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_10_0"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mysterious",
                    price = 500,
                    type = "money",
                    image = "female_mask_11_0"
                },
                [1] = {
                    label = "Red Mysterious",
                    price = 500,
                    type = "money",
                    image = "female_mask_11_1"
                },
                [2] = {
                    label = "Black Mysterious",
                    price = 500,
                    type = "money",
                    image = "female_mask_11_2"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bronze Masquerade",
                    price = 500,
                    type = "money",
                    image = "female_mask_12_0"
                },
                [1] = {
                    label = "Silver Masquerade",
                    price = 500,
                    type = "money",
                    image = "female_mask_12_1"
                },
                [2] = {
                    label = "Black & Gold Masquerade",
                    price = 500,
                    type = "money",
                    image = "female_mask_12_2"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cupid",
                    price = 500,
                    type = "money",
                    image = "female_mask_13_0"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bullet Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_0"
                },
                [1] = {
                    label = "Vinewood Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_1"
                },
                [2] = {
                    label = "Tourist Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_2"
                },
                [3] = {
                    label = "Hound Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_3"
                },
                [4] = {
                    label = "Wolf Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_4"
                },
                [5] = {
                    label = "Beast Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_5"
                },
                [6] = {
                    label = "Bear Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_6"
                },
                [7] = {
                    label = "Dust Devils Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_7"
                },
                [8] = {
                    label = "Striped Rampage Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_8"
                },
                [9] = {
                    label = "Royal Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_9"
                },
                [10] = {
                    label = "Fashion Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_10"
                },
                [11] = {
                    label = "Vile Zombie Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_11"
                },
                [12] = {
                    label = "Rotten Zombie Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_12"
                },
                [13] = {
                    label = "Flame Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_13"
                },
                [14] = {
                    label = "Nightmare Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_14"
                },
                [15] = {
                    label = "Electric Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_15_0"
                },
                [1] = {
                    label = "Stitched Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_15_1"
                },
                [2] = {
                    label = "Pale Stitched Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_15_2"
                },
                [3] = {
                    label = "Crossed Rampage Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_15_3"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Metal Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_0"
                },
                [1] = {
                    label = "Circuit Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_1"
                },
                [2] = {
                    label = "Molten Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_2"
                },
                [3] = {
                    label = "Neon Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_3"
                },
                [4] = {
                    label = "Carbon Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_4"
                },
                [5] = {
                    label = "Deadeye Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_5"
                },
                [6] = {
                    label = "Stone Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_6"
                },
                [7] = {
                    label = "Lightning Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_7"
                },
                [8] = {
                    label = "Wooden Warrior",
                    price = 500,
                    type = "money",
                    image = "female_mask_16_8"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Cat",
                    price = 500,
                    type = "money",
                    image = "female_mask_17_0"
                },
                [1] = {
                    label = "Tabby Cat",
                    price = 500,
                    type = "money",
                    image = "female_mask_17_1"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Fox",
                    price = 500,
                    type = "money",
                    image = "female_mask_18_0"
                },
                [1] = {
                    label = "Brown Fox",
                    price = 500,
                    type = "money",
                    image = "female_mask_18_1"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Owl",
                    price = 500,
                    type = "money",
                    image = "female_mask_19_0"
                },
                [1] = {
                    label = "White Owl",
                    price = 500,
                    type = "money",
                    image = "female_mask_19_1"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Racoon",
                    price = 500,
                    type = "money",
                    image = "female_mask_20_0"
                },
                [1] = {
                    label = "Black Racoon",
                    price = 500,
                    type = "money",
                    image = "female_mask_20_1"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Bear",
                    price = 500,
                    type = "money",
                    image = "female_mask_21_0"
                },
                [1] = {
                    label = "Grey Bear",
                    price = 500,
                    type = "money",
                    image = "female_mask_21_1"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Bison",
                    price = 500,
                    type = "money",
                    image = "female_mask_22_0"
                },
                [1] = {
                    label = "Golden Bison",
                    price = 500,
                    type = "money",
                    image = "female_mask_22_1"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bull",
                    price = 500,
                    type = "money",
                    image = "female_mask_23_0"
                },
                [1] = {
                    label = "Brown Bull",
                    price = 500,
                    type = "money",
                    image = "female_mask_23_1"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Eagle",
                    price = 500,
                    type = "money",
                    image = "female_mask_24_0"
                },
                [1] = {
                    label = "White Eagle",
                    price = 500,
                    type = "money",
                    image = "female_mask_24_1"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Vulture",
                    price = 500,
                    type = "money",
                    image = "female_mask_25_0"
                },
                [1] = {
                    label = "Black Vulture",
                    price = 500,
                    type = "money",
                    image = "female_mask_25_1"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grey Wolf",
                    price = 500,
                    type = "money",
                    image = "female_mask_26_0"
                },
                [1] = {
                    label = "Black Wolf",
                    price = 500,
                    type = "money",
                    image = "female_mask_26_1"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_27_0"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_28_0"
                },
                [1] = {
                    label = "Gray Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_28_1"
                },
                [2] = {
                    label = "Charcoal Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_28_2"
                },
                [3] = {
                    label = "Tan Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_28_3"
                },
                [4] = {
                    label = "Forest Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_28_4"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skeletal",
                    price = 500,
                    type = "money",
                    image = "female_mask_29_0"
                },
                [1] = {
                    label = "Gray Skeletal",
                    price = 500,
                    type = "money",
                    image = "female_mask_29_1"
                },
                [2] = {
                    label = "Charcoal Skeletal",
                    price = 500,
                    type = "money",
                    image = "female_mask_29_2"
                },
                [3] = {
                    label = "Tan Skeletal",
                    price = 500,
                    type = "money",
                    image = "female_mask_29_3"
                },
                [4] = {
                    label = "Green Skeletal",
                    price = 500,
                    type = "money",
                    image = "female_mask_29_4"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Please Stop Me Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_30_0"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Penguin",
                    price = 500,
                    type = "money",
                    image = "female_mask_31_0"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stocking",
                    price = 500,
                    type = "money",
                    image = "female_mask_32_0"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_34_0"
                },
                [1] = {
                    label = "Black Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_34_1"
                },
                [2] = {
                    label = "Latino Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_34_2"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_35_0"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Rebreather",
                    price = 500,
                    type = "money",
                    image = "female_mask_36_0"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Scruffy Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_37_0"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_38_0"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Infected",
                    price = 500,
                    type = "money",
                    image = "female_mask_39_0"
                },
                [1] = {
                    label = "Brown Infected",
                    price = 500,
                    type = "money",
                    image = "female_mask_39_1"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mummy",
                    price = 500,
                    type = "money",
                    image = "female_mask_40_0"
                },
                [1] = {
                    label = "Green Mummy",
                    price = 500,
                    type = "money",
                    image = "female_mask_40_1"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Vampyr",
                    price = 500,
                    type = "money",
                    image = "female_mask_41_0"
                },
                [1] = {
                    label = "Blue Vampyr",
                    price = 500,
                    type = "money",
                    image = "female_mask_41_1"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Frank",
                    price = 500,
                    type = "money",
                    image = "female_mask_42_0"
                },
                [1] = {
                    label = "Gray Frank",
                    price = 500,
                    type = "money",
                    image = "female_mask_42_1"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Impotent Rage",
                    price = 500,
                    type = "money",
                    image = "female_mask_43_0"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Princess Robot Bubblegum",
                    price = 500,
                    type = "money",
                    image = "female_mask_44_0"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Moorehead",
                    price = 500,
                    type = "money",
                    image = "female_mask_45_0"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chemical Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_46_0"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Crime Scene Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_47_0"
                },
                [1] = {
                    label = "Black Arrow Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_47_1"
                },
                [2] = {
                    label = "Hazard Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_47_2"
                },
                [3] = {
                    label = "Red Arrow Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_47_3"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Gray Duct Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_48_0"
                },
                [1] = {
                    label = "Dark Gray Duct Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_48_1"
                },
                [2] = {
                    label = "White Duct Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_48_2"
                },
                [3] = {
                    label = "Electrical Duct Tape",
                    price = 500,
                    type = "money",
                    image = "female_mask_48_3"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Up-n-Atom Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_0"
                },
                [1] = {
                    label = "Manic Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_1"
                },
                [2] = {
                    label = "Sad Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_2"
                },
                [3] = {
                    label = "Happy Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_3"
                },
                [4] = {
                    label = "Fat Cat Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_4"
                },
                [5] = {
                    label = "Mouth Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_5"
                },
                [6] = {
                    label = "Shy Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_6"
                },
                [7] = {
                    label = "Burger Shot Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_7"
                },
                [8] = {
                    label = "Kill Me Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_8"
                },
                [9] = {
                    label = "Diabolic Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_9"
                },
                [10] = {
                    label = "Cop Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_10"
                },
                [11] = {
                    label = "Monster Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_11"
                },
                [12] = {
                    label = "Fury Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_12"
                },
                [13] = {
                    label = "Zigzag Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_13"
                },
                [14] = {
                    label = "Skull Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_14"
                },
                [15] = {
                    label = "Dog Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_15"
                },
                [16] = {
                    label = "Pink Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_16"
                },
                [17] = {
                    label = "Alien Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_17"
                },
                [18] = {
                    label = "Help Me Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_18"
                },
                [19] = {
                    label = "Puzzle Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_19"
                },
                [20] = {
                    label = "The Bird Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_20"
                },
                [21] = {
                    label = "Dapper Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_21"
                },
                [22] = {
                    label = "Sticker Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_22"
                },
                [23] = {
                    label = "Modernist Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_23"
                },
                [24] = {
                    label = "Love Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_24"
                },
                [25] = {
                    label = "Blackout Paper Bag",
                    price = 500,
                    type = "money",
                    image = "female_mask_49_25"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_0"
                },
                [1] = {
                    label = "The Don Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_1"
                },
                [2] = {
                    label = "Pink Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_2"
                },
                [3] = {
                    label = "Clown Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_3"
                },
                [4] = {
                    label = "Black Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_4"
                },
                [5] = {
                    label = "Brown Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_5"
                },
                [6] = {
                    label = "Mannequin Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_6"
                },
                [7] = {
                    label = "Doll Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_7"
                },
                [8] = {
                    label = "Puppet Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_8"
                },
                [9] = {
                    label = "Mime Plastic Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_50_9"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_0"
                },
                [1] = {
                    label = "Skull Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_1"
                },
                [2] = {
                    label = "Urban Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_2"
                },
                [3] = {
                    label = "Desert Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_3"
                },
                [4] = {
                    label = "Forest Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_4"
                },
                [5] = {
                    label = "Green Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_5"
                },
                [6] = {
                    label = "Purple Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_6"
                },
                [7] = {
                    label = "Paisley Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_7"
                },
                [8] = {
                    label = "Yellow Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_8"
                },
                [9] = {
                    label = "Electric Skull Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_51_9"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_0"
                },
                [1] = {
                    label = "Gray Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_1"
                },
                [2] = {
                    label = "White Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_2"
                },
                [3] = {
                    label = "Green Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_3"
                },
                [4] = {
                    label = "Khaki Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_4"
                },
                [5] = {
                    label = "Charcoal Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_5"
                },
                [6] = {
                    label = "Forest Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_6"
                },
                [7] = {
                    label = "Urban Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_7"
                },
                [8] = {
                    label = "Blue Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_8"
                },
                [9] = {
                    label = "Yellow Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_9"
                },
                [10] = {
                    label = "Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_52_10"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_0"
                },
                [1] = {
                    label = "Gray Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_1"
                },
                [2] = {
                    label = "White Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_2"
                },
                [3] = {
                    label = "Green Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_3"
                },
                [4] = {
                    label = "Khaki Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_4"
                },
                [5] = {
                    label = "Charcoal Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_5"
                },
                [6] = {
                    label = "Forest Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_6"
                },
                [7] = {
                    label = "Urban Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_7"
                },
                [8] = {
                    label = "Skull Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_53_8"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_0"
                },
                [1] = {
                    label = "White T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_1"
                },
                [2] = {
                    label = "Tan T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_2"
                },
                [3] = {
                    label = "Benders T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_3"
                },
                [4] = {
                    label = "Justice T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_4"
                },
                [5] = {
                    label = "Woodland T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_5"
                },
                [6] = {
                    label = "Stripy T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_6"
                },
                [7] = {
                    label = "Love Fist T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_7"
                },
                [8] = {
                    label = "TPI T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_8"
                },
                [9] = {
                    label = "Pink Camo T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_9"
                },
                [10] = {
                    label = "LSPD T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_54_10"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Toggle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_55_0"
                },
                [1] = {
                    label = "Khaki Toggle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_55_1"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_0"
                },
                [1] = {
                    label = "Black Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_1"
                },
                [2] = {
                    label = "Skull Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_2"
                },
                [3] = {
                    label = "Khaki Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_3"
                },
                [4] = {
                    label = "Bloody Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_4"
                },
                [5] = {
                    label = "Woodland Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_5"
                },
                [6] = {
                    label = "Red Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_6"
                },
                [7] = {
                    label = "Outback Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_7"
                },
                [8] = {
                    label = "Split Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_56_8"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_0"
                },
                [1] = {
                    label = "Army Green Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_1"
                },
                [2] = {
                    label = "Copper Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_2"
                },
                [3] = {
                    label = "Gray Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_3"
                },
                [4] = {
                    label = "Brown Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_4"
                },
                [5] = {
                    label = "Rainbow Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_5"
                },
                [6] = {
                    label = "Woodland Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_6"
                },
                [7] = {
                    label = "Dirty Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_7"
                },
                [8] = {
                    label = "Pink Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_8"
                },
                [9] = {
                    label = "Flying Bravo FB Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_9"
                },
                [10] = {
                    label = "Flying Bravo Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_10"
                },
                [11] = {
                    label = "Princess Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_11"
                },
                [12] = {
                    label = "Didier Sachs Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_12"
                },
                [13] = {
                    label = "Perseus Band Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_13"
                },
                [14] = {
                    label = "Perseus Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_14"
                },
                [15] = {
                    label = "Sessanta Nove Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_15"
                },
                [16] = {
                    label = "White Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_16"
                },
                [17] = {
                    label = "Blue Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_17"
                },
                [18] = {
                    label = "Red Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_18"
                },
                [19] = {
                    label = "Green Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_19"
                },
                [20] = {
                    label = "Orange Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_20"
                },
                [21] = {
                    label = "Purple Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_57_21"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bandit Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_0"
                },
                [1] = {
                    label = "Nature Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_1"
                },
                [2] = {
                    label = "Neon Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_2"
                },
                [3] = {
                    label = "Pink Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_3"
                },
                [4] = {
                    label = "Orange Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_4"
                },
                [5] = {
                    label = "Impotent Rage Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_5"
                },
                [6] = {
                    label = "Pogo Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_6"
                },
                [7] = {
                    label = "Blue Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_7"
                },
                [8] = {
                    label = "Black Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_8"
                },
                [9] = {
                    label = "Pink Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_58_9"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (59-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_59_0"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Evil Pumpkin",
                    price = 500,
                    type = "money",
                    image = "female_mask_60_0"
                },
                [1] = {
                    label = "Rotten Pumpkin",
                    price = 500,
                    type = "money",
                    image = "female_mask_60_1"
                },
                [2] = {
                    label = "Nasty Watermelon",
                    price = 500,
                    type = "money",
                    image = "female_mask_60_2"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Creepy Butler",
                    price = 500,
                    type = "money",
                    image = "female_mask_61_0"
                },
                [1] = {
                    label = "Dead Butler",
                    price = 500,
                    type = "money",
                    image = "female_mask_61_1"
                },
                [2] = {
                    label = "Rotten Butler",
                    price = 500,
                    type = "money",
                    image = "female_mask_61_2"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "female_mask_62_0"
                },
                [1] = {
                    label = "Bloody Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "female_mask_62_1"
                },
                [2] = {
                    label = "Black Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "female_mask_62_2"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_63_0"
                },
                [1] = {
                    label = "Green Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_63_1"
                },
                [2] = {
                    label = "Gray Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_63_2"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skull Burst",
                    price = 500,
                    type = "money",
                    image = "female_mask_64_0"
                },
                [1] = {
                    label = "Red Skull Burst",
                    price = 500,
                    type = "money",
                    image = "female_mask_64_1"
                },
                [2] = {
                    label = "Cream Skull Burst",
                    price = 500,
                    type = "money",
                    image = "female_mask_64_2"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "female_mask_65_0"
                },
                [1] = {
                    label = "Dark Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "female_mask_65_1"
                },
                [2] = {
                    label = "Gray Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "female_mask_65_2"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "female_mask_66_0"
                },
                [1] = {
                    label = "Red Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "female_mask_66_1"
                },
                [2] = {
                    label = "Purple Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "female_mask_66_2"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dirty Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "female_mask_67_0"
                },
                [1] = {
                    label = "Rotten Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "female_mask_67_1"
                },
                [2] = {
                    label = "Scabby Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "female_mask_67_2"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_68_0"
                },
                [1] = {
                    label = "Orange Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_68_1"
                },
                [2] = {
                    label = "Black Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_68_2"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "female_mask_69_0"
                },
                [1] = {
                    label = "Bloody Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "female_mask_69_1"
                },
                [2] = {
                    label = "Black Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "female_mask_69_2"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "female_mask_70_0"
                },
                [1] = {
                    label = "Green Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "female_mask_70_1"
                },
                [2] = {
                    label = "Red Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "female_mask_70_2"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "female_mask_71_0"
                },
                [1] = {
                    label = "Gray Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "female_mask_71_1"
                },
                [2] = {
                    label = "White Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "female_mask_71_2"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_72_0"
                },
                [1] = {
                    label = "Orange Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_72_1"
                },
                [2] = {
                    label = "Black Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "female_mask_72_2"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (73-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_73_0"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Manic Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_74_0"
                },
                [1] = {
                    label = "Mad Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_74_1"
                },
                [2] = {
                    label = "Angry Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_74_2"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_75_0"
                },
                [1] = {
                    label = "Blue Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_75_1"
                },
                [2] = {
                    label = "Brown Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "female_mask_75_2"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bruised Bad Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_76_0"
                },
                [1] = {
                    label = "Grumpy Bad Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_76_1"
                },
                [2] = {
                    label = "Filthy Bad Santa",
                    price = 500,
                    type = "money",
                    image = "female_mask_76_2"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_0"
                },
                [1] = {
                    label = "Dark Green Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_1"
                },
                [2] = {
                    label = "Black Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_2"
                },
                [3] = {
                    label = "White Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_3"
                },
                [4] = {
                    label = "Red Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_4"
                },
                [5] = {
                    label = "Purple Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "female_mask_77_5"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Pudding",
                    price = 500,
                    type = "money",
                    image = "female_mask_78_0"
                },
                [1] = {
                    label = "Light Pudding",
                    price = 500,
                    type = "money",
                    image = "female_mask_78_1"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_79_0"
                },
                [1] = {
                    label = "Blond Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_79_1"
                },
                [2] = {
                    label = "Silver Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_79_2"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black LS Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_80_0"
                },
                [1] = {
                    label = "Red LS Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_80_1"
                },
                [2] = {
                    label = "White LS Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_80_2"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Visor Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_81_0"
                },
                [1] = {
                    label = "LS Visor Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_81_1"
                },
                [2] = {
                    label = "Brown Visor Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_81_2"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_82_0"
                },
                [1] = {
                    label = "Patriot Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_82_1"
                },
                [2] = {
                    label = "Blue Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_82_2"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Festive Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_83_0"
                },
                [1] = {
                    label = "Brown Festive Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_83_1"
                },
                [2] = {
                    label = "Blond Festive Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_83_2"
                },
                [3] = {
                    label = "Silver Festive Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_83_3"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Abominable Snowman",
                    price = 500,
                    type = "money",
                    image = "female_mask_84_0"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Raw Turkey",
                    price = 500,
                    type = "money",
                    image = "female_mask_85_0"
                },
                [1] = {
                    label = "Cooked Turkey",
                    price = 500,
                    type = "money",
                    image = "female_mask_85_1"
                },
                [2] = {
                    label = "Burnt Turkey",
                    price = 500,
                    type = "money",
                    image = "female_mask_85_2"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wasted Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_86_0"
                },
                [1] = {
                    label = "Smashed Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_86_1"
                },
                [2] = {
                    label = "High Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_86_2"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Rebel Bad Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_87_0"
                },
                [1] = {
                    label = "Gangsta Bad Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_87_1"
                },
                [2] = {
                    label = "Badass Bad Elf",
                    price = 500,
                    type = "money",
                    image = "female_mask_87_2"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_88_0"
                },
                [1] = {
                    label = "Black Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_88_1"
                },
                [2] = {
                    label = "Latino Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "female_mask_88_2"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_89_0"
                },
                [1] = {
                    label = "Gray Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_89_1"
                },
                [2] = {
                    label = "Charcoal Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_89_2"
                },
                [3] = {
                    label = "Tan Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_89_3"
                },
                [4] = {
                    label = "Forest Combat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_89_4"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ox Blood Dome Filter",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_0"
                },
                [1] = {
                    label = "Chocolate Dome Filter",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_1"
                },
                [2] = {
                    label = "Black Dome Filter",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_2"
                },
                [3] = {
                    label = "Tan Dome Filter",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_3"
                },
                [4] = {
                    label = "Ox Blood Dome Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_4"
                },
                [5] = {
                    label = "Chocolate Dome Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_5"
                },
                [6] = {
                    label = "Black Dome Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_6"
                },
                [7] = {
                    label = "Tan Dome Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_90_7"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (91-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_0"
                },
                [1] = {
                    label = "Mask (91-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_1"
                },
                [2] = {
                    label = "Mask (91-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_2"
                },
                [3] = {
                    label = "Mask (91-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_3"
                },
                [4] = {
                    label = "Mask (91-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_4"
                },
                [5] = {
                    label = "Mask (91-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_5"
                },
                [6] = {
                    label = "Mask (91-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_6"
                },
                [7] = {
                    label = "Mask (91-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_7"
                },
                [8] = {
                    label = "Mask (91-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_8"
                },
                [9] = {
                    label = "Mask (91-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_9"
                },
                [10] = {
                    label = "Mask (91-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_91_10"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Amphibian Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_0"
                },
                [1] = {
                    label = "Alien Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_1"
                },
                [2] = {
                    label = "Reptilian Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_2"
                },
                [3] = {
                    label = "Otherworldly Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_3"
                },
                [4] = {
                    label = "Deity Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_4"
                },
                [5] = {
                    label = "Infernal Sea Beast",
                    price = 500,
                    type = "money",
                    image = "female_mask_92_5"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Striped Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_0"
                },
                [1] = {
                    label = "Gray Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_1"
                },
                [2] = {
                    label = "Tropical Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_2"
                },
                [3] = {
                    label = "Earth Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_3"
                },
                [4] = {
                    label = "Rainforest Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_4"
                },
                [5] = {
                    label = "Danger Dino",
                    price = 500,
                    type = "money",
                    image = "female_mask_93_5"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_0"
                },
                [1] = {
                    label = "Blue Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_1"
                },
                [2] = {
                    label = "White Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_2"
                },
                [3] = {
                    label = "Black Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_3"
                },
                [4] = {
                    label = "Gold Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_4"
                },
                [5] = {
                    label = "Green Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_94_5"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_0"
                },
                [1] = {
                    label = "Blue Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_1"
                },
                [2] = {
                    label = "Green Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_2"
                },
                [3] = {
                    label = "Orange Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_3"
                },
                [4] = {
                    label = "Scavenger Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_4"
                },
                [5] = {
                    label = "Neon Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_5"
                },
                [6] = {
                    label = "Franken Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_6"
                },
                [7] = {
                    label = "Sinister Clown",
                    price = 500,
                    type = "money",
                    image = "female_mask_95_7"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silverback Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "female_mask_96_0"
                },
                [1] = {
                    label = "Orangutan Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "female_mask_96_1"
                },
                [2] = {
                    label = "Gray Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "female_mask_96_2"
                },
                [3] = {
                    label = "Albino Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "female_mask_96_3"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chestnut Horse",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_0"
                },
                [1] = {
                    label = "Black Horse",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_1"
                },
                [2] = {
                    label = "Gray Horse",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_2"
                },
                [3] = {
                    label = "Brown Horse",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_3"
                },
                [4] = {
                    label = "Pinto Horse",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_4"
                },
                [5] = {
                    label = "Zebra",
                    price = 500,
                    type = "money",
                    image = "female_mask_97_5"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Unicorn",
                    price = 500,
                    type = "money",
                    image = "female_mask_98_0"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_0"
                },
                [1] = {
                    label = "Silver Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_1"
                },
                [2] = {
                    label = "Blue Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_2"
                },
                [3] = {
                    label = "Teal Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_3"
                },
                [4] = {
                    label = "White Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_4"
                },
                [5] = {
                    label = "Black Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_99_5"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Moe Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_0"
                },
                [1] = {
                    label = "Black Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_1"
                },
                [2] = {
                    label = "Gray Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_2"
                },
                [3] = {
                    label = "Brown Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_3"
                },
                [4] = {
                    label = "Josephine Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_4"
                },
                [5] = {
                    label = "Black and Tan Pug",
                    price = 500,
                    type = "money",
                    image = "female_mask_100_5"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_0"
                },
                [1] = {
                    label = "Blue Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_1"
                },
                [2] = {
                    label = "Magenta Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_2"
                },
                [3] = {
                    label = "Yellow Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_3"
                },
                [4] = {
                    label = "Fall Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_4"
                },
                [5] = {
                    label = "Gray Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_5"
                },
                [6] = {
                    label = "Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_6"
                },
                [7] = {
                    label = "Gray Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_7"
                },
                [8] = {
                    label = "Geo Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_8"
                },
                [9] = {
                    label = "Black Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_9"
                },
                [10] = {
                    label = "Zebra Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_10"
                },
                [11] = {
                    label = "Bold Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_11"
                },
                [12] = {
                    label = "Pale Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_12"
                },
                [13] = {
                    label = "Gray Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_13"
                },
                [14] = {
                    label = "Gray Leopard Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_14"
                },
                [15] = {
                    label = "Blue Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_101_15"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (102-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_102_0"
                },
                [1] = {
                    label = "Mask (102-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_102_1"
                },
                [2] = {
                    label = "Mask (102-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_102_2"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_0"
                },
                [1] = {
                    label = "Brown Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_1"
                },
                [2] = {
                    label = "Green Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_2"
                },
                [3] = {
                    label = "Gray Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_3"
                },
                [4] = {
                    label = "Peach Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_4"
                },
                [5] = {
                    label = "Fall Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_5"
                },
                [6] = {
                    label = "Dark Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_6"
                },
                [7] = {
                    label = "Crosshatch Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_7"
                },
                [8] = {
                    label = "Moss Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_8"
                },
                [9] = {
                    label = "Gray Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_9"
                },
                [10] = {
                    label = "Aqua Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_10"
                },
                [11] = {
                    label = "Splinter Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_11"
                },
                [12] = {
                    label = "Contrast Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_12"
                },
                [13] = {
                    label = "Cobble Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_13"
                },
                [14] = {
                    label = "Peach Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_14"
                },
                [15] = {
                    label = "Brushstroke Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_15"
                },
                [16] = {
                    label = "Flecktarn Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_16"
                },
                [17] = {
                    label = "Light Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_17"
                },
                [18] = {
                    label = "Moss Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_18"
                },
                [19] = {
                    label = "Sand Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_19"
                },
                [20] = {
                    label = "Black Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_20"
                },
                [21] = {
                    label = "Slate Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_21"
                },
                [22] = {
                    label = "Stone Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_22"
                },
                [23] = {
                    label = "Green Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_23"
                },
                [24] = {
                    label = "Woodland Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_24"
                },
                [25] = {
                    label = "Moss Camo Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "female_mask_103_25"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_0"
                },
                [1] = {
                    label = "Brown Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_1"
                },
                [2] = {
                    label = "Green Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_2"
                },
                [3] = {
                    label = "Gray Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_3"
                },
                [4] = {
                    label = "Peach Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_4"
                },
                [5] = {
                    label = "Fall Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_5"
                },
                [6] = {
                    label = "Dark Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_6"
                },
                [7] = {
                    label = "Crosshatch Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_7"
                },
                [8] = {
                    label = "Moss Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_8"
                },
                [9] = {
                    label = "Gray Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_9"
                },
                [10] = {
                    label = "Aqua Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_10"
                },
                [11] = {
                    label = "Splinter Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_11"
                },
                [12] = {
                    label = "Contrast Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_12"
                },
                [13] = {
                    label = "Cobble Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_13"
                },
                [14] = {
                    label = "Peach Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_14"
                },
                [15] = {
                    label = "Brushstroke Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_15"
                },
                [16] = {
                    label = "Flecktarn Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_16"
                },
                [17] = {
                    label = "Light Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_17"
                },
                [18] = {
                    label = "Moss Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_18"
                },
                [19] = {
                    label = "Sand Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_19"
                },
                [20] = {
                    label = "Mask (104-20)",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_20"
                },
                [21] = {
                    label = "Mask (104-21)",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_21"
                },
                [22] = {
                    label = "Mask (104-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_22"
                },
                [23] = {
                    label = "Mask (104-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_23"
                },
                [24] = {
                    label = "Olive Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_24"
                },
                [25] = {
                    label = "Skull Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_104_25"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Obsidian Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_0"
                },
                [1] = {
                    label = "Weathered Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_1"
                },
                [2] = {
                    label = "Sandstone Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_2"
                },
                [3] = {
                    label = "White Painted Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_3"
                },
                [4] = {
                    label = "Gold Painted Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_4"
                },
                [5] = {
                    label = "Red Painted Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_5"
                },
                [6] = {
                    label = "Black Painted Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_6"
                },
                [7] = {
                    label = "Black Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_7"
                },
                [8] = {
                    label = "Brown Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_8"
                },
                [9] = {
                    label = "Yellow Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_9"
                },
                [10] = {
                    label = "Plum Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_10"
                },
                [11] = {
                    label = "Grayscale Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_11"
                },
                [12] = {
                    label = "Black and Yellow Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_12"
                },
                [13] = {
                    label = "Orange Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_13"
                },
                [14] = {
                    label = "Gold Stone Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_14"
                },
                [15] = {
                    label = "Stone Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_15"
                },
                [16] = {
                    label = "Gray Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_16"
                },
                [17] = {
                    label = "Black and Gold Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_17"
                },
                [18] = {
                    label = "Gray and Orange Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_18"
                },
                [19] = {
                    label = "White Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_19"
                },
                [20] = {
                    label = "Gray and Gold Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_20"
                },
                [21] = {
                    label = "Stone Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_21"
                },
                [22] = {
                    label = "Sea Green Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_22"
                },
                [23] = {
                    label = "Purple Oni",
                    price = 500,
                    type = "money",
                    image = "female_mask_105_23"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_0"
                },
                [1] = {
                    label = "Brown Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_1"
                },
                [2] = {
                    label = "Green Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_2"
                },
                [3] = {
                    label = "Gray Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_3"
                },
                [4] = {
                    label = "Peach Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_4"
                },
                [5] = {
                    label = "Fall Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_5"
                },
                [6] = {
                    label = "Dark Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_6"
                },
                [7] = {
                    label = "Crosshatch Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_7"
                },
                [8] = {
                    label = "Moss Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_8"
                },
                [9] = {
                    label = "Gray Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_9"
                },
                [10] = {
                    label = "Aqua Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_10"
                },
                [11] = {
                    label = "Splinter Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_11"
                },
                [12] = {
                    label = "Contrast Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_12"
                },
                [13] = {
                    label = "Cobble Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_13"
                },
                [14] = {
                    label = "Peach Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_14"
                },
                [15] = {
                    label = "Brushstroke Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_15"
                },
                [16] = {
                    label = "Flecktarn Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_16"
                },
                [17] = {
                    label = "Light Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_17"
                },
                [18] = {
                    label = "Moss Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_18"
                },
                [19] = {
                    label = "Sand Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_19"
                },
                [20] = {
                    label = "Mask (106-20)",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_20"
                },
                [21] = {
                    label = "Mask (106-21)",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_21"
                },
                [22] = {
                    label = "Mask (106-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_22"
                },
                [23] = {
                    label = "Mask (106-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_23"
                },
                [24] = {
                    label = "Red Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_24"
                },
                [25] = {
                    label = "White Snake Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_106_25"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_0"
                },
                [1] = {
                    label = "Brown Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_1"
                },
                [2] = {
                    label = "Green Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_2"
                },
                [3] = {
                    label = "Gray Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_3"
                },
                [4] = {
                    label = "Peach Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_4"
                },
                [5] = {
                    label = "Fall Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_5"
                },
                [6] = {
                    label = "Dark Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_6"
                },
                [7] = {
                    label = "Crosshatch Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_7"
                },
                [8] = {
                    label = "Moss Digital Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_8"
                },
                [9] = {
                    label = "Gray Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_9"
                },
                [10] = {
                    label = "Aqua Camo Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_10"
                },
                [11] = {
                    label = "Splinter Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_11"
                },
                [12] = {
                    label = "Contrast Camo Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_12"
                },
                [13] = {
                    label = "Cobble Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_13"
                },
                [14] = {
                    label = "Peach Camo Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_14"
                },
                [15] = {
                    label = "Brushstroke Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_15"
                },
                [16] = {
                    label = "Flecktarn Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_16"
                },
                [17] = {
                    label = "Light Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_17"
                },
                [18] = {
                    label = "Moss Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_18"
                },
                [19] = {
                    label = "Sand Vent",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_19"
                },
                [20] = {
                    label = "Mask (107-20)",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_20"
                },
                [21] = {
                    label = "Mask (107-21)",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_21"
                },
                [22] = {
                    label = "Mask (107-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_22"
                },
                [23] = {
                    label = "Mask (107-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_107_23"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Clean Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_0"
                },
                [1] = {
                    label = "Weathered Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_1"
                },
                [2] = {
                    label = "Aged Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_2"
                },
                [3] = {
                    label = "Venom Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_3"
                },
                [4] = {
                    label = "Fresh Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_4"
                },
                [5] = {
                    label = "Fleshy Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_5"
                },
                [6] = {
                    label = "Moss Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_6"
                },
                [7] = {
                    label = "Sand Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_7"
                },
                [8] = {
                    label = "Inked Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_8"
                },
                [9] = {
                    label = "Stained Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_9"
                },
                [10] = {
                    label = "Tan Leather Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_10"
                },
                [11] = {
                    label = "Chocolate Leather Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_11"
                },
                [12] = {
                    label = "Orange Open-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_12"
                },
                [13] = {
                    label = "Possessed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_13"
                },
                [14] = {
                    label = "Wide-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_14"
                },
                [15] = {
                    label = "Tattooed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_15"
                },
                [16] = {
                    label = "Blue Painted Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_16"
                },
                [17] = {
                    label = "Pink Painted Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_17"
                },
                [18] = {
                    label = "Green Painted Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_18"
                },
                [19] = {
                    label = "Mustard Painted Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_19"
                },
                [20] = {
                    label = "Orange Swirl-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_20"
                },
                [21] = {
                    label = "Leather Solar-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_21"
                },
                [22] = {
                    label = "Terracotta Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_22"
                },
                [23] = {
                    label = "Striped Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_108_23"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (109-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_0"
                },
                [1] = {
                    label = "Mask (109-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_1"
                },
                [2] = {
                    label = "Mask (109-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_2"
                },
                [3] = {
                    label = "Mask (109-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_3"
                },
                [4] = {
                    label = "Black Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_4"
                },
                [5] = {
                    label = "Tan Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_5"
                },
                [6] = {
                    label = "Green Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_6"
                },
                [7] = {
                    label = "Olive Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_7"
                },
                [8] = {
                    label = "Light Woodland Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_8"
                },
                [9] = {
                    label = "Aqua Camo Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_9"
                },
                [10] = {
                    label = "Splinter Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_10"
                },
                [11] = {
                    label = "Brown Digital Flight Cap",
                    price = 500,
                    type = "money",
                    image = "female_mask_109_11"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_0"
                },
                [1] = {
                    label = "Blue Digital Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_1"
                },
                [2] = {
                    label = "Brown Digital Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_2"
                },
                [3] = {
                    label = "Green Digital Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_3"
                },
                [4] = {
                    label = "Fall Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_4"
                },
                [5] = {
                    label = "Dark Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_5"
                },
                [6] = {
                    label = "Crosshatch Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_6"
                },
                [7] = {
                    label = "Gray Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_7"
                },
                [8] = {
                    label = "Aqua Camo Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_8"
                },
                [9] = {
                    label = "Splinter Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_9"
                },
                [10] = {
                    label = "Contrast Camo Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_10"
                },
                [11] = {
                    label = "Cobble Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_11"
                },
                [12] = {
                    label = "Peach Camo Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_12"
                },
                [13] = {
                    label = "Brushstroke Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_13"
                },
                [14] = {
                    label = "Flecktarn Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_14"
                },
                [15] = {
                    label = "Light Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_15"
                },
                [16] = {
                    label = "Blue Striped Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_16"
                },
                [17] = {
                    label = "Moss Striped Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_17"
                },
                [18] = {
                    label = "Orange Striped Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_18"
                },
                [19] = {
                    label = "Yellow Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_19"
                },
                [20] = {
                    label = "Zebra Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_20"
                },
                [21] = {
                    label = "White Robo",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_21"
                },
                [22] = {
                    label = "Mask (110-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_22"
                },
                [23] = {
                    label = "Mask (110-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_23"
                },
                [24] = {
                    label = "Mask (110-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_24"
                },
                [25] = {
                    label = "Mask (110-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_110_25"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (111-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_0"
                },
                [1] = {
                    label = "Mask (111-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_1"
                },
                [2] = {
                    label = "Mask (111-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_2"
                },
                [3] = {
                    label = "Mask (111-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_3"
                },
                [4] = {
                    label = "Blue Blagueurs Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_4"
                },
                [5] = {
                    label = "Red Blagueurs Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_5"
                },
                [6] = {
                    label = "Bold Abstract Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_6"
                },
                [7] = {
                    label = "Geometric Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_7"
                },
                [8] = {
                    label = "Splinter Bigness Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_8"
                },
                [9] = {
                    label = "Red Bigness Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_9"
                },
                [10] = {
                    label = "Green Leaves Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_10"
                },
                [11] = {
                    label = "Blue Leaves Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_11"
                },
                [12] = {
                    label = "Red Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_12"
                },
                [13] = {
                    label = "Black Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_13"
                },
                [14] = {
                    label = "Skulls Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_14"
                },
                [15] = {
                    label = "White Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_15"
                },
                [16] = {
                    label = "Orange Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_16"
                },
                [17] = {
                    label = "Black Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_17"
                },
                [18] = {
                    label = "Off-White Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_18"
                },
                [19] = {
                    label = "Stars & Stripes Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_19"
                },
                [20] = {
                    label = "Painted Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_20"
                },
                [21] = {
                    label = "Fractal Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_21"
                },
                [22] = {
                    label = "Contrast Camo Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_22"
                },
                [23] = {
                    label = "Zebra Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_23"
                },
                [24] = {
                    label = "Dark Pattern Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_24"
                },
                [25] = {
                    label = "Bright Pattern Face Bandana",
                    price = 500,
                    type = "money",
                    image = "female_mask_111_25"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_0"
                },
                [1] = {
                    label = "Blue Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_1"
                },
                [2] = {
                    label = "Brown Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_2"
                },
                [3] = {
                    label = "Green Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_3"
                },
                [4] = {
                    label = "Fall Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_4"
                },
                [5] = {
                    label = "Dark Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_5"
                },
                [6] = {
                    label = "Crosshatch Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_6"
                },
                [7] = {
                    label = "Gray Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_7"
                },
                [8] = {
                    label = "Aqua Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_8"
                },
                [9] = {
                    label = "Splinter Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_9"
                },
                [10] = {
                    label = "Contrast Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_10"
                },
                [11] = {
                    label = "Cobble Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_11"
                },
                [12] = {
                    label = "Peach Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_12"
                },
                [13] = {
                    label = "Brushstroke Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_13"
                },
                [14] = {
                    label = "Flecktarn Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_14"
                },
                [15] = {
                    label = "Light Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_15"
                },
                [16] = {
                    label = "Blue Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_16"
                },
                [17] = {
                    label = "Moss Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_17"
                },
                [18] = {
                    label = "Orange Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_18"
                },
                [19] = {
                    label = "Yellow Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_19"
                },
                [20] = {
                    label = "Zebra Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_20"
                },
                [21] = {
                    label = "White Mandible",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_21"
                },
                [22] = {
                    label = "Mask (112-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_22"
                },
                [23] = {
                    label = "Mask (112-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_23"
                },
                [24] = {
                    label = "Mask (112-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_24"
                },
                [25] = {
                    label = "Mask (112-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_112_25"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skate Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_0"
                },
                [1] = {
                    label = "Multicolor Leaves Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_1"
                },
                [2] = {
                    label = "Lime Xero Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_2"
                },
                [3] = {
                    label = "Tropical Xero Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_3"
                },
                [4] = {
                    label = "Red Stripe Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_4"
                },
                [5] = {
                    label = "Gray Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_5"
                },
                [6] = {
                    label = "Orange & Red Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_6"
                },
                [7] = {
                    label = "Vibrant Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_7"
                },
                [8] = {
                    label = "Blue Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_8"
                },
                [9] = {
                    label = "Mustard Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_9"
                },
                [10] = {
                    label = "Stars & Stripes Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_10"
                },
                [11] = {
                    label = "Black Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_11"
                },
                [12] = {
                    label = "White Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_12"
                },
                [13] = {
                    label = "Mask (113-13)",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_13"
                },
                [14] = {
                    label = "Mask (113-14)",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_14"
                },
                [15] = {
                    label = "Mask (113-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_15"
                },
                [16] = {
                    label = "Mask (113-16)",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_16"
                },
                [17] = {
                    label = "SA Republic Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_17"
                },
                [18] = {
                    label = "Black Stars & Stripes Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_18"
                },
                [19] = {
                    label = "Black & Red Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_19"
                },
                [20] = {
                    label = "Bold Abstract Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_20"
                },
                [21] = {
                    label = "Camo Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_113_21"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_0"
                },
                [1] = {
                    label = "Teal Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_1"
                },
                [2] = {
                    label = "Green Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_2"
                },
                [3] = {
                    label = "Yellow Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_3"
                },
                [4] = {
                    label = "Turquoise Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_4"
                },
                [5] = {
                    label = "Brown Digital Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_5"
                },
                [6] = {
                    label = "Yellow Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_6"
                },
                [7] = {
                    label = "Dark Red Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_7"
                },
                [8] = {
                    label = "Peach Digital Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_8"
                },
                [9] = {
                    label = "Fall Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_9"
                },
                [10] = {
                    label = "Dark Woodland Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_10"
                },
                [11] = {
                    label = "Orange Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_11"
                },
                [12] = {
                    label = "Red Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_12"
                },
                [13] = {
                    label = "Gray Woodland Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_13"
                },
                [14] = {
                    label = "Blue Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_14"
                },
                [15] = {
                    label = "Splinter Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_15"
                },
                [16] = {
                    label = "Purple Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_16"
                },
                [17] = {
                    label = "Jolly Roger Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_17"
                },
                [18] = {
                    label = "Peach Camo Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_18"
                },
                [19] = {
                    label = "Brushstroke Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_19"
                },
                [20] = {
                    label = "Flecktarn Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_20"
                },
                [21] = {
                    label = "Weapon Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_21"
                },
                [22] = {
                    label = "Mask (114-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_22"
                },
                [23] = {
                    label = "Mask (114-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_23"
                },
                [24] = {
                    label = "Mask (114-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_24"
                },
                [25] = {
                    label = "Mask (114-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_114_25"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_0"
                },
                [1] = {
                    label = "Teal Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_1"
                },
                [2] = {
                    label = "Green Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_2"
                },
                [3] = {
                    label = "Yellow Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_3"
                },
                [4] = {
                    label = "Turquoise Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_4"
                },
                [5] = {
                    label = "Brown Digital Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_5"
                },
                [6] = {
                    label = "Red Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_6"
                },
                [7] = {
                    label = "Jolly Roger Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_7"
                },
                [8] = {
                    label = "Peach Digital Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_8"
                },
                [9] = {
                    label = "Fall Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_9"
                },
                [10] = {
                    label = "Dark Woodland Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_10"
                },
                [11] = {
                    label = "Weapon Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_11"
                },
                [12] = {
                    label = "Blue Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_12"
                },
                [13] = {
                    label = "Gray Woodland Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_13"
                },
                [14] = {
                    label = "Dark Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_14"
                },
                [15] = {
                    label = "Splinter Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_15"
                },
                [16] = {
                    label = "Dark Red Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_16"
                },
                [17] = {
                    label = "Orange Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_17"
                },
                [18] = {
                    label = "Peach Camo Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_18"
                },
                [19] = {
                    label = "Brushstroke Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_19"
                },
                [20] = {
                    label = "Flecktarn Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_20"
                },
                [21] = {
                    label = "Purple Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_21"
                },
                [22] = {
                    label = "Mask (115-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_22"
                },
                [23] = {
                    label = "Mask (115-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_23"
                },
                [24] = {
                    label = "Mask (115-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_24"
                },
                [25] = {
                    label = "Mask (115-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_115_25"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_0"
                },
                [1] = {
                    label = "Teal Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_1"
                },
                [2] = {
                    label = "Green Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_2"
                },
                [3] = {
                    label = "Yellow Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_3"
                },
                [4] = {
                    label = "Turquoise Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_4"
                },
                [5] = {
                    label = "Brown Digital Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_5"
                },
                [6] = {
                    label = "Dark Red Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_6"
                },
                [7] = {
                    label = "Orange Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_7"
                },
                [8] = {
                    label = "Peach Digital Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_8"
                },
                [9] = {
                    label = "Fall Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_9"
                },
                [10] = {
                    label = "Dark Woodland Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_10"
                },
                [11] = {
                    label = "Blue Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_11"
                },
                [12] = {
                    label = "Purple Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_12"
                },
                [13] = {
                    label = "Gray Woodland Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_13"
                },
                [14] = {
                    label = "Yellow Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_14"
                },
                [15] = {
                    label = "Splinter Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_15"
                },
                [16] = {
                    label = "Red Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_16"
                },
                [17] = {
                    label = "Weapon Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_17"
                },
                [18] = {
                    label = "Peach Camo Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_18"
                },
                [19] = {
                    label = "Brushstroke Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_19"
                },
                [20] = {
                    label = "Flecktarn Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_20"
                },
                [21] = {
                    label = "Jolly Roger Snood",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_21"
                },
                [22] = {
                    label = "Mask (116-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_22"
                },
                [23] = {
                    label = "Mask (116-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_23"
                },
                [24] = {
                    label = "Mask (116-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_24"
                },
                [25] = {
                    label = "Mask (116-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_116_25"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bright Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_0"
                },
                [1] = {
                    label = "Dark Red Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_1"
                },
                [2] = {
                    label = "Green & Beige Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_2"
                },
                [3] = {
                    label = "Sunrise Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_3"
                },
                [4] = {
                    label = "Gray Digital Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_4"
                },
                [5] = {
                    label = "Gray Woodland Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_5"
                },
                [6] = {
                    label = "Brown Digital Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_6"
                },
                [7] = {
                    label = "Red Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_7"
                },
                [8] = {
                    label = "Skull Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_8"
                },
                [9] = {
                    label = "Wine Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_9"
                },
                [10] = {
                    label = "Bright Green Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_10"
                },
                [11] = {
                    label = "Aqua Camo Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_11"
                },
                [12] = {
                    label = "Primary Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_12"
                },
                [13] = {
                    label = "Black & Red Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_13"
                },
                [14] = {
                    label = "Green Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_14"
                },
                [15] = {
                    label = "Tiger Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_15"
                },
                [16] = {
                    label = "Leopard Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_16"
                },
                [17] = {
                    label = "Dark Pattern Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_17"
                },
                [18] = {
                    label = "Stars & Stripes Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_18"
                },
                [19] = {
                    label = "Blue Luchador Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_19"
                },
                [20] = {
                    label = "Green Luchador Knit",
                    price = 500,
                    type = "money",
                    image = "female_mask_117_20"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (118-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_0"
                },
                [1] = {
                    label = "Mask (118-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_1"
                },
                [2] = {
                    label = "Mask (118-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_2"
                },
                [3] = {
                    label = "Mask (118-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_3"
                },
                [4] = {
                    label = "Magenta Leopard T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_4"
                },
                [5] = {
                    label = "Navy Painted T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_5"
                },
                [6] = {
                    label = "Multicolor Leaves T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_6"
                },
                [7] = {
                    label = "Gray Digital T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_7"
                },
                [8] = {
                    label = "Aqua Camo T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_8"
                },
                [9] = {
                    label = "Red Camo T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_9"
                },
                [10] = {
                    label = "Camo Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_10"
                },
                [11] = {
                    label = "Black Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_11"
                },
                [12] = {
                    label = "Red Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_12"
                },
                [13] = {
                    label = "Gray Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_13"
                },
                [14] = {
                    label = "Primary T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_14"
                },
                [15] = {
                    label = "OJ Squash T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_15"
                },
                [16] = {
                    label = "Green & Pink T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_16"
                },
                [17] = {
                    label = "Stars & Stripes T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_17"
                },
                [18] = {
                    label = "Black Stars & Stripes T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_18"
                },
                [19] = {
                    label = "SA Republic T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_19"
                },
                [20] = {
                    label = "Aqua Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_20"
                },
                [21] = {
                    label = "Far Out Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_21"
                },
                [22] = {
                    label = "Pink Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_22"
                },
                [23] = {
                    label = "Orange Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_23"
                },
                [24] = {
                    label = "Green Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_24"
                },
                [25] = {
                    label = "Pink Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "female_mask_118_25"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_0"
                },
                [1] = {
                    label = "Ash Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_1"
                },
                [2] = {
                    label = "Charcoal Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_2"
                },
                [3] = {
                    label = "Chocolate Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_3"
                },
                [4] = {
                    label = "Blue Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_4"
                },
                [5] = {
                    label = "Hessian Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_5"
                },
                [6] = {
                    label = "Dark Red Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_6"
                },
                [7] = {
                    label = "Mask (119-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_7"
                },
                [8] = {
                    label = "Mask (119-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_8"
                },
                [9] = {
                    label = "Mask (119-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_9"
                },
                [10] = {
                    label = "Mask (119-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_10"
                },
                [11] = {
                    label = "Bright Green Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_11"
                },
                [12] = {
                    label = "Beige Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_12"
                },
                [13] = {
                    label = "Rasta Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_13"
                },
                [14] = {
                    label = "Triplet Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_14"
                },
                [15] = {
                    label = "Orange Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_15"
                },
                [16] = {
                    label = "Magenta Leopard Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_16"
                },
                [17] = {
                    label = "Vibrant Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_17"
                },
                [18] = {
                    label = "Skate Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_18"
                },
                [19] = {
                    label = "Pink Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_19"
                },
                [20] = {
                    label = "Aqua Camo Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_20"
                },
                [21] = {
                    label = "Gray Digital Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_21"
                },
                [22] = {
                    label = "Gray Woodland Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_22"
                },
                [23] = {
                    label = "Pretty Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_23"
                },
                [24] = {
                    label = "Dark Neon Scruffy",
                    price = 500,
                    type = "money",
                    image = "female_mask_119_24"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (120-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_120_0"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (121-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_121_0"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (122-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_122_0"
                },
                [1] = {
                    label = "Mask (122-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_122_1"
                },
                [2] = {
                    label = "Mask (122-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_122_2"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (123-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_0"
                },
                [1] = {
                    label = "Mask (123-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_1"
                },
                [2] = {
                    label = "Mask (123-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_2"
                },
                [3] = {
                    label = "Mask (123-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_3"
                },
                [4] = {
                    label = "Mask (123-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_4"
                },
                [5] = {
                    label = "Mask (123-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_5"
                },
                [6] = {
                    label = "Mask (123-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_6"
                },
                [7] = {
                    label = "Mask (123-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_7"
                },
                [8] = {
                    label = "Mask (123-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_8"
                },
                [9] = {
                    label = "Mask (123-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_9"
                },
                [10] = {
                    label = "Mask (123-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_10"
                },
                [11] = {
                    label = "Mask (123-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_123_11"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Manic Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_0"
                },
                [1] = {
                    label = "Manic Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_1"
                },
                [2] = {
                    label = "Manic Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_2"
                },
                [3] = {
                    label = "Amused Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_3"
                },
                [4] = {
                    label = "Amused Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_4"
                },
                [5] = {
                    label = "Amused Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_5"
                },
                [6] = {
                    label = "Furious Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_6"
                },
                [7] = {
                    label = "Furious Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_7"
                },
                [8] = {
                    label = "Furious Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_8"
                },
                [9] = {
                    label = "Pleased Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_9"
                },
                [10] = {
                    label = "Pleased Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_10"
                },
                [11] = {
                    label = "Pleased Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_11"
                },
                [12] = {
                    label = "Peaceful Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_12"
                },
                [13] = {
                    label = "Peaceful Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_13"
                },
                [14] = {
                    label = "Peaceful Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_14"
                },
                [15] = {
                    label = "Transcendent Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_15"
                },
                [16] = {
                    label = "Transcendent Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_16"
                },
                [17] = {
                    label = "Transcendent Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_17"
                },
                [18] = {
                    label = "Tribal Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_18"
                },
                [19] = {
                    label = "Tribal Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_19"
                },
                [20] = {
                    label = "Tribal Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_20"
                },
                [21] = {
                    label = "Iwazaru Luminous",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_21"
                },
                [22] = {
                    label = "Iwazaru Electric",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_22"
                },
                [23] = {
                    label = "Iwazaru Neon",
                    price = 500,
                    type = "money",
                    image = "female_mask_124_23"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_0"
                },
                [1] = {
                    label = "Gray Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_1"
                },
                [2] = {
                    label = "White Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_2"
                },
                [3] = {
                    label = "Sand Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_3"
                },
                [4] = {
                    label = "Mask (125-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_4"
                },
                [5] = {
                    label = "Mask (125-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_5"
                },
                [6] = {
                    label = "Mask (125-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_6"
                },
                [7] = {
                    label = "Mask (125-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_7"
                },
                [8] = {
                    label = "Sand Goggled Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_8"
                },
                [9] = {
                    label = "Red Goggled Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_9"
                },
                [10] = {
                    label = "Black Carbon Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_10"
                },
                [11] = {
                    label = "Sand Carbon Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_11"
                },
                [12] = {
                    label = "Cranial Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_12"
                },
                [13] = {
                    label = "Flecktarn Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_13"
                },
                [14] = {
                    label = "Splinter Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_14"
                },
                [15] = {
                    label = "Red & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_15"
                },
                [16] = {
                    label = "Blue & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_16"
                },
                [17] = {
                    label = "Yellow & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_17"
                },
                [18] = {
                    label = "Orange & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_18"
                },
                [19] = {
                    label = "White & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_19"
                },
                [20] = {
                    label = "Red Stripe Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_20"
                },
                [21] = {
                    label = "Black Stripe Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_21"
                },
                [22] = {
                    label = "Off White & Red Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_22"
                },
                [23] = {
                    label = "Red Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_23"
                },
                [24] = {
                    label = "Brown Digital Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_24"
                },
                [25] = {
                    label = "Fall Ballistic",
                    price = 500,
                    type = "money",
                    image = "female_mask_125_25"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_0"
                },
                [1] = {
                    label = "Carbon Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_1"
                },
                [2] = {
                    label = "Scale Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_2"
                },
                [3] = {
                    label = "Tan Digital Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_3"
                },
                [4] = {
                    label = "Aqua Camo Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_4"
                },
                [5] = {
                    label = "Splinter Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_5"
                },
                [6] = {
                    label = "Mono Splinter Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_6"
                },
                [7] = {
                    label = "Gray Woodland Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_7"
                },
                [8] = {
                    label = "Dark Woodland Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_8"
                },
                [9] = {
                    label = "Electric Skull Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_9"
                },
                [10] = {
                    label = "LSPD Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_10"
                },
                [11] = {
                    label = "Ornate Skull Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_11"
                },
                [12] = {
                    label = "Striped Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_12"
                },
                [13] = {
                    label = "Opera Spec Ops",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_13"
                },
                [14] = {
                    label = "Mask (126-14)",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_14"
                },
                [15] = {
                    label = "Mask (126-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_15"
                },
                [16] = {
                    label = "Mask (126-16)",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_16"
                },
                [17] = {
                    label = "Mask (126-17)",
                    price = 500,
                    type = "money",
                    image = "female_mask_126_17"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Festive Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_127_0"
                },
                [1] = {
                    label = "Merry Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_127_1"
                },
                [2] = {
                    label = "Jovial Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_127_2"
                },
                [3] = {
                    label = "Mirthful Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_127_3"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_0"
                },
                [1] = {
                    label = "Aqua Camo False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_1"
                },
                [2] = {
                    label = "Headline False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_2"
                },
                [3] = {
                    label = "Splinter False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_3"
                },
                [4] = {
                    label = "Brown Digital False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_4"
                },
                [5] = {
                    label = "Striped Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_5"
                },
                [6] = {
                    label = "Cobble Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_6"
                },
                [7] = {
                    label = "Rising Sun False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_7"
                },
                [8] = {
                    label = "Opera False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_8"
                },
                [9] = {
                    label = "Stars & Stripes False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_9"
                },
                [10] = {
                    label = "Green Pattern False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_10"
                },
                [11] = {
                    label = "Gothic False Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_11"
                },
                [12] = {
                    label = "Mask (128-12)",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_12"
                },
                [13] = {
                    label = "Mask (128-13)",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_13"
                },
                [14] = {
                    label = "Mask (128-14)",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_14"
                },
                [15] = {
                    label = "Mask (128-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_128_15"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_0"
                },
                [1] = {
                    label = "Carbon Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_1"
                },
                [2] = {
                    label = "Tan Digital Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_2"
                },
                [3] = {
                    label = "Aqua Camo Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_3"
                },
                [4] = {
                    label = "Splinter Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_4"
                },
                [5] = {
                    label = "Gray Splinter Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_5"
                },
                [6] = {
                    label = "Gray Striped Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_6"
                },
                [7] = {
                    label = "Moss Striped Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_7"
                },
                [8] = {
                    label = "Peach Camo Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_8"
                },
                [9] = {
                    label = "Woodland Digital Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_9"
                },
                [10] = {
                    label = "Skull Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_10"
                },
                [11] = {
                    label = "White Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_11"
                },
                [12] = {
                    label = "Yellow Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_12"
                },
                [13] = {
                    label = "Orange Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_13"
                },
                [14] = {
                    label = "Mask (129-14)",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_14"
                },
                [15] = {
                    label = "Mask (129-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_15"
                },
                [16] = {
                    label = "Mask (129-16)",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_16"
                },
                [17] = {
                    label = "Mask (129-17)",
                    price = 500,
                    type = "money",
                    image = "female_mask_129_17"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_0"
                },
                [1] = {
                    label = "Flecktarn Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_1"
                },
                [2] = {
                    label = "Gray Digital Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_2"
                },
                [3] = {
                    label = "Aqua Camo Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_3"
                },
                [4] = {
                    label = "Splinter Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_4"
                },
                [5] = {
                    label = "Gray Splinter Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_5"
                },
                [6] = {
                    label = "Tiger Striped Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_6"
                },
                [7] = {
                    label = "Moss Striped Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_7"
                },
                [8] = {
                    label = "Green Digital Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_8"
                },
                [9] = {
                    label = "Brushstroke Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_9"
                },
                [10] = {
                    label = "Gray Woodland Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_10"
                },
                [11] = {
                    label = "Cobble Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_11"
                },
                [12] = {
                    label = "Contrast Camo Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_12"
                },
                [13] = {
                    label = "Viper Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_13"
                },
                [14] = {
                    label = "Crosshatch Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_14"
                },
                [15] = {
                    label = "Mask (130-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_15"
                },
                [16] = {
                    label = "Mask (130-16)",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_16"
                },
                [17] = {
                    label = "Mask (130-17)",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_17"
                },
                [18] = {
                    label = "Mask (130-18)",
                    price = 500,
                    type = "money",
                    image = "female_mask_130_18"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Hideous Krampus",
                    price = 500,
                    type = "money",
                    image = "female_mask_131_0"
                },
                [1] = {
                    label = "Fearsome Krampus",
                    price = 500,
                    type = "money",
                    image = "female_mask_131_1"
                },
                [2] = {
                    label = "Odious Krampus",
                    price = 500,
                    type = "money",
                    image = "female_mask_131_2"
                },
                [3] = {
                    label = "Heinous Krampus",
                    price = 500,
                    type = "money",
                    image = "female_mask_131_3"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_0"
                },
                [1] = {
                    label = "White Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_1"
                },
                [2] = {
                    label = "Gray Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_2"
                },
                [3] = {
                    label = "Blue Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_3"
                },
                [4] = {
                    label = "Tan Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_4"
                },
                [5] = {
                    label = "Moss Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_5"
                },
                [6] = {
                    label = "Brown Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_6"
                },
                [7] = {
                    label = "Aqua Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_7"
                },
                [8] = {
                    label = "Gray Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_8"
                },
                [9] = {
                    label = "White Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_9"
                },
                [10] = {
                    label = "Green Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_10"
                },
                [11] = {
                    label = "Splinter Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_11"
                },
                [12] = {
                    label = "Dazzle Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_12"
                },
                [13] = {
                    label = "Brown Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_13"
                },
                [14] = {
                    label = "Woodland Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_14"
                },
                [15] = {
                    label = "Gray Woodland Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_15"
                },
                [16] = {
                    label = "Crosshatch Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_16"
                },
                [17] = {
                    label = "Contrast Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_17"
                },
                [18] = {
                    label = "Cobble Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_18"
                },
                [19] = {
                    label = "Moss Striped Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_19"
                },
                [20] = {
                    label = "White Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_20"
                },
                [21] = {
                    label = "Skull Night Vision",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_21"
                },
                [22] = {
                    label = "Mask (132-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_22"
                },
                [23] = {
                    label = "Mask (132-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_23"
                },
                [24] = {
                    label = "Mask (132-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_24"
                },
                [25] = {
                    label = "Mask (132-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_132_25"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_0"
                },
                [1] = {
                    label = "Blue Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_1"
                },
                [2] = {
                    label = "Light Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_2"
                },
                [3] = {
                    label = "Purple Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_3"
                },
                [4] = {
                    label = "Dark Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_4"
                },
                [5] = {
                    label = "Light Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_5"
                },
                [6] = {
                    label = "Purple Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_6"
                },
                [7] = {
                    label = "Woodland Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_7"
                },
                [8] = {
                    label = "Abstract Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_8"
                },
                [9] = {
                    label = "Geometric Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_9"
                },
                [10] = {
                    label = "Blue Digital Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_10"
                },
                [11] = {
                    label = "Gray Digital Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_11"
                },
                [12] = {
                    label = "Zebra Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_12"
                },
                [13] = {
                    label = "Harlequin Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_13"
                },
                [14] = {
                    label = "Wild Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_14"
                },
                [15] = {
                    label = "Fall Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_15"
                },
                [16] = {
                    label = "Orange Fall Hockey",
                    price = 500,
                    type = "money",
                    image = "female_mask_133_16"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (134-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_0"
                },
                [1] = {
                    label = "Mask (134-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_1"
                },
                [2] = {
                    label = "Mask (134-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_2"
                },
                [3] = {
                    label = "Mask (134-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_3"
                },
                [4] = {
                    label = "Mask (134-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_4"
                },
                [5] = {
                    label = "Mask (134-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_5"
                },
                [6] = {
                    label = "Mask (134-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_6"
                },
                [7] = {
                    label = "Mask (134-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_7"
                },
                [8] = {
                    label = "Mask (134-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_8"
                },
                [9] = {
                    label = "Mask (134-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_9"
                },
                [10] = {
                    label = "Mask (134-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_10"
                },
                [11] = {
                    label = "Mask (134-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_11"
                },
                [12] = {
                    label = "Mask (134-12)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_12"
                },
                [13] = {
                    label = "Mask (134-13)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_13"
                },
                [14] = {
                    label = "Mask (134-14)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_14"
                },
                [15] = {
                    label = "Mask (134-15)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_15"
                },
                [16] = {
                    label = "Mask (134-16)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_16"
                },
                [17] = {
                    label = "Mask (134-17)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_17"
                },
                [18] = {
                    label = "Mask (134-18)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_18"
                },
                [19] = {
                    label = "Mask (134-19)",
                    price = 500,
                    type = "money",
                    image = "female_mask_134_19"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (135-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_0"
                },
                [1] = {
                    label = "Mask (135-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_1"
                },
                [2] = {
                    label = "Mask (135-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_2"
                },
                [3] = {
                    label = "Mask (135-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_3"
                },
                [4] = {
                    label = "Mask (135-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_4"
                },
                [5] = {
                    label = "Mask (135-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_5"
                },
                [6] = {
                    label = "Mask (135-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_6"
                },
                [7] = {
                    label = "Mask (135-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_7"
                },
                [8] = {
                    label = "Mask (135-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_8"
                },
                [9] = {
                    label = "Mask (135-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_9"
                },
                [10] = {
                    label = "Mask (135-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_10"
                },
                [11] = {
                    label = "Mask (135-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_11"
                },
                [12] = {
                    label = "Mask (135-12)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_12"
                },
                [13] = {
                    label = "Mask (135-13)",
                    price = 500,
                    type = "money",
                    image = "female_mask_135_13"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Brown Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_0"
                },
                [1] = {
                    label = "White Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_1"
                },
                [2] = {
                    label = "Black Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_2"
                },
                [3] = {
                    label = "Red Cross Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_3"
                },
                [4] = {
                    label = "Green Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_4"
                },
                [5] = {
                    label = "Blue Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_5"
                },
                [6] = {
                    label = "Beige Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_6"
                },
                [7] = {
                    label = "Crosshatch Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_7"
                },
                [8] = {
                    label = "Splinter Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_8"
                },
                [9] = {
                    label = "Red Feather Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_9"
                },
                [10] = {
                    label = "Black & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_10"
                },
                [11] = {
                    label = "Ash Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_11"
                },
                [12] = {
                    label = "Black & Yellow Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_12"
                },
                [13] = {
                    label = "Red & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_13"
                },
                [14] = {
                    label = "Brown & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_14"
                },
                [15] = {
                    label = "Brown & Yellow Death Bird",
                    price = 500,
                    type = "money",
                    image = "female_mask_136_15"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_0"
                },
                [1] = {
                    label = "Brown Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_1"
                },
                [2] = {
                    label = "Purple Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_2"
                },
                [3] = {
                    label = "Red Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_3"
                },
                [4] = {
                    label = "Black Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_4"
                },
                [5] = {
                    label = "Stars Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_5"
                },
                [6] = {
                    label = "Brown Camo Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_6"
                },
                [7] = {
                    label = "Green Camo Stalker",
                    price = 500,
                    type = "money",
                    image = "female_mask_137_7"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_0"
                },
                [1] = {
                    label = "Chocolate Brown Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_1"
                },
                [2] = {
                    label = "Brown Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_2"
                },
                [3] = {
                    label = "Red Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_3"
                },
                [4] = {
                    label = "Beige Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_4"
                },
                [5] = {
                    label = "Bright Orange Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_5"
                },
                [6] = {
                    label = "Blue Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_6"
                },
                [7] = {
                    label = "Gray Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_7"
                },
                [8] = {
                    label = "Green Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_8"
                },
                [9] = {
                    label = "Brown Camo Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_9"
                },
                [10] = {
                    label = "Red & Gray Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_10"
                },
                [11] = {
                    label = "Orange & Gray Raider",
                    price = 500,
                    type = "money",
                    image = "female_mask_138_11"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (139-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_0"
                },
                [1] = {
                    label = "Mask (139-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_1"
                },
                [2] = {
                    label = "Mask (139-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_2"
                },
                [3] = {
                    label = "Mask (139-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_3"
                },
                [4] = {
                    label = "Mask (139-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_4"
                },
                [5] = {
                    label = "Mask (139-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_5"
                },
                [6] = {
                    label = "Mask (139-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_6"
                },
                [7] = {
                    label = "Mask (139-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_7"
                },
                [8] = {
                    label = "Mask (139-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_8"
                },
                [9] = {
                    label = "Mask (139-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_9"
                },
                [10] = {
                    label = "Mask (139-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_10"
                },
                [11] = {
                    label = "Mask (139-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_139_11"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (140-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_0"
                },
                [1] = {
                    label = "Mask (140-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_1"
                },
                [2] = {
                    label = "Mask (140-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_2"
                },
                [3] = {
                    label = "Mask (140-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_3"
                },
                [4] = {
                    label = "Mask (140-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_4"
                },
                [5] = {
                    label = "Mask (140-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_5"
                },
                [6] = {
                    label = "Mask (140-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_6"
                },
                [7] = {
                    label = "Mask (140-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_7"
                },
                [8] = {
                    label = "Mask (140-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_8"
                },
                [9] = {
                    label = "Mask (140-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_9"
                },
                [10] = {
                    label = "Mask (140-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_10"
                },
                [11] = {
                    label = "Mask (140-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_140_11"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (141-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_0"
                },
                [1] = {
                    label = "Mask (141-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_1"
                },
                [2] = {
                    label = "Mask (141-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_2"
                },
                [3] = {
                    label = "Mask (141-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_3"
                },
                [4] = {
                    label = "Mask (141-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_4"
                },
                [5] = {
                    label = "Mask (141-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_5"
                },
                [6] = {
                    label = "Mask (141-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_6"
                },
                [7] = {
                    label = "Mask (141-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_7"
                },
                [8] = {
                    label = "Mask (141-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_8"
                },
                [9] = {
                    label = "Mask (141-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_9"
                },
                [10] = {
                    label = "Mask (141-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_10"
                },
                [11] = {
                    label = "Mask (141-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_141_11"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Brown Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_0"
                },
                [1] = {
                    label = "Radioactive Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_1"
                },
                [2] = {
                    label = "Bolt Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_2"
                },
                [3] = {
                    label = "Branded Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_3"
                },
                [4] = {
                    label = "Crossbones Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_4"
                },
                [5] = {
                    label = "Red Stripe Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_5"
                },
                [6] = {
                    label = "Yellow Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_6"
                },
                [7] = {
                    label = "Eight-ball Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_7"
                },
                [8] = {
                    label = "Black Arrow Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_8"
                },
                [9] = {
                    label = "Shooting Stars Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_9"
                },
                [10] = {
                    label = "Beige Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_10"
                },
                [11] = {
                    label = "Black Marauder",
                    price = 500,
                    type = "money",
                    image = "female_mask_142_11"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Paco the Taco Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_143_0"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Burger Shot Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_144_0"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_145_0"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_0"
                },
                [1] = {
                    label = "White Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_1"
                },
                [2] = {
                    label = "Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_2"
                },
                [3] = {
                    label = "Red Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_3"
                },
                [4] = {
                    label = "Green Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_4"
                },
                [5] = {
                    label = "Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_5"
                },
                [6] = {
                    label = "Pink Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_6"
                },
                [7] = {
                    label = "Orange Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_7"
                },
                [8] = {
                    label = "Purple Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_8"
                },
                [9] = {
                    label = "Gray & Red Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_9"
                },
                [10] = {
                    label = "Black & Green Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_10"
                },
                [11] = {
                    label = "Beige & Orange Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_11"
                },
                [12] = {
                    label = "Orange & Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_12"
                },
                [13] = {
                    label = "White & Blue Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_13"
                },
                [14] = {
                    label = "Purple & Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_14"
                },
                [15] = {
                    label = "Red & Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_15"
                },
                [16] = {
                    label = "Green & Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "female_mask_146_16"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (147-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_147_0"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Impotent Rage Eye Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_148_0"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Strawberry Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_149_0"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Lemon Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_150_0"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grapes Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_151_0"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pineapple Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cherries Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_153_0"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Lucky Seven Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_154_0"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Joker",
                    price = 500,
                    type = "money",
                    image = "female_mask_155_0"
                },
                [1] = {
                    label = "Red Joker",
                    price = 500,
                    type = "money",
                    image = "female_mask_155_1"
                },
                [2] = {
                    label = "Green Joker",
                    price = 500,
                    type = "money",
                    image = "female_mask_155_2"
                },
                [3] = {
                    label = "Purple Joker",
                    price = 500,
                    type = "money",
                    image = "female_mask_155_3"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "King of Hearts",
                    price = 500,
                    type = "money",
                    image = "female_mask_156_0"
                },
                [1] = {
                    label = "King of Clubs",
                    price = 500,
                    type = "money",
                    image = "female_mask_156_1"
                },
                [2] = {
                    label = "King of Diamonds",
                    price = 500,
                    type = "money",
                    image = "female_mask_156_2"
                },
                [3] = {
                    label = "King of Spades",
                    price = 500,
                    type = "money",
                    image = "female_mask_156_3"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "Queen of Spades",
                    price = 500,
                    type = "money",
                    image = "female_mask_157_0"
                },
                [1] = {
                    label = "Queen of Hearts",
                    price = 500,
                    type = "money",
                    image = "female_mask_157_1"
                },
                [2] = {
                    label = "Queen of Diamonds",
                    price = 500,
                    type = "money",
                    image = "female_mask_157_2"
                },
                [3] = {
                    label = "Queen of Clubs",
                    price = 500,
                    type = "money",
                    image = "female_mask_157_3"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Jack of Spades",
                    price = 500,
                    type = "money",
                    image = "female_mask_158_0"
                },
                [1] = {
                    label = "Jack of Hearts",
                    price = 500,
                    type = "money",
                    image = "female_mask_158_1"
                },
                [2] = {
                    label = "Jack of Clubs",
                    price = 500,
                    type = "money",
                    image = "female_mask_158_2"
                },
                [3] = {
                    label = "Jack of Diamonds",
                    price = 500,
                    type = "money",
                    image = "female_mask_158_3"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ace of Spades",
                    price = 500,
                    type = "money",
                    image = "female_mask_159_0"
                },
                [1] = {
                    label = "Ace of Hearts",
                    price = 500,
                    type = "money",
                    image = "female_mask_159_1"
                },
                [2] = {
                    label = "Ace of Clubs",
                    price = 500,
                    type = "money",
                    image = "female_mask_159_2"
                },
                [3] = {
                    label = "Ace of Diamonds",
                    price = 500,
                    type = "money",
                    image = "female_mask_159_3"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Baby Smile",
                    price = 500,
                    type = "money",
                    image = "female_mask_160_0"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fig",
                    price = 500,
                    type = "money",
                    image = "female_mask_161_0"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'component',
            textures = {
                [0] = {
                    label = "Piggly",
                    price = 500,
                    type = "money",
                    image = "female_mask_162_0"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ape",
                    price = 500,
                    type = "money",
                    image = "female_mask_163_0"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grinner",
                    price = 500,
                    type = "money",
                    image = "female_mask_164_0"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fluffy Rabbit",
                    price = 500,
                    type = "money",
                    image = "female_mask_165_0"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (166-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_166_0"
                },
                [1] = {
                    label = "Mask (166-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_166_1"
                },
                [2] = {
                    label = "Mask (166-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_166_2"
                },
                [3] = {
                    label = "Mask (166-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_166_3"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'component',
            textures = {
                [0] = {
                    label = "Sniper",
                    price = 500,
                    type = "money",
                    image = "female_mask_167_0"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fleshless",
                    price = 500,
                    type = "money",
                    image = "female_mask_168_0"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_0"
                },
                [1] = {
                    label = "Gray Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_1"
                },
                [2] = {
                    label = "Light Gray Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_2"
                },
                [3] = {
                    label = "Red Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_3"
                },
                [4] = {
                    label = "Teal Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_4"
                },
                [5] = {
                    label = "Smiley Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_5"
                },
                [6] = {
                    label = "Gray Digital Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_6"
                },
                [7] = {
                    label = "Blue Digital Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_7"
                },
                [8] = {
                    label = "Blue Wave Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_8"
                },
                [9] = {
                    label = "Stars & Stripes Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_9"
                },
                [10] = {
                    label = "Toothy Grin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_10"
                },
                [11] = {
                    label = "Wolf Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_11"
                },
                [12] = {
                    label = "Gray Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_12"
                },
                [13] = {
                    label = "Black Skull Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_13"
                },
                [14] = {
                    label = "Blood Cross Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_14"
                },
                [15] = {
                    label = "Brown Skull Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_15"
                },
                [16] = {
                    label = "Green Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_16"
                },
                [17] = {
                    label = "Green Neon Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_17"
                },
                [18] = {
                    label = "Purple Neon Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_18"
                },
                [19] = {
                    label = "Cobble Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_19"
                },
                [20] = {
                    label = "Green Snakeskin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_20"
                },
                [21] = {
                    label = "Purple Snakeskin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_21"
                },
                [22] = {
                    label = "Mask (169-22)",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_22"
                },
                [23] = {
                    label = "Mask (169-23)",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_23"
                },
                [24] = {
                    label = "Mask (169-24)",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_24"
                },
                [25] = {
                    label = "Mask (169-25)",
                    price = 500,
                    type = "money",
                    image = "female_mask_169_25"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'component',
            textures = {
                [0] = {
                    label = "Voyeur",
                    price = 500,
                    type = "money",
                    image = "female_mask_170_0"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Fox",
                    price = 500,
                    type = "money",
                    image = "female_mask_171_0"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Ginger & White Cat",
                    price = 500,
                    type = "money",
                    image = "female_mask_172_0"
                },
                [1] = {
                    label = "Geo Gray & White Cat",
                    price = 500,
                    type = "money",
                    image = "female_mask_172_1"
                },
                [2] = {
                    label = "Geo Black & White Cat",
                    price = 500,
                    type = "money",
                    image = "female_mask_172_2"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Pig",
                    price = 500,
                    type = "money",
                    image = "female_mask_173_0"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray & Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_0"
                },
                [1] = {
                    label = "Ash & White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_1"
                },
                [2] = {
                    label = "Gray & White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_2"
                },
                [3] = {
                    label = "Worn Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_3"
                },
                [4] = {
                    label = "Worn Yellow Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_4"
                },
                [5] = {
                    label = "Worn Green Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_5"
                },
                [6] = {
                    label = "Black Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_6"
                },
                [7] = {
                    label = "Red Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_7"
                },
                [8] = {
                    label = "Yellow Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_8"
                },
                [9] = {
                    label = "Pale Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_9"
                },
                [10] = {
                    label = "Red Lip Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_10"
                },
                [11] = {
                    label = "Smoke Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_11"
                },
                [12] = {
                    label = "Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_12"
                },
                [13] = {
                    label = "Cyan Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_13"
                },
                [14] = {
                    label = "Dark Pink Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_14"
                },
                [15] = {
                    label = "Green Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_15"
                },
                [16] = {
                    label = "Peach Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_16"
                },
                [17] = {
                    label = "Purple Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_17"
                },
                [18] = {
                    label = "Light Pink Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_18"
                },
                [19] = {
                    label = "Terracotta Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_19"
                },
                [20] = {
                    label = "Dusty Blue Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_20"
                },
                [21] = {
                    label = "Gray Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_21"
                },
                [22] = {
                    label = "Putty Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_22"
                },
                [23] = {
                    label = "White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_23"
                },
                [24] = {
                    label = "Stone Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_174_24"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Visor Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_175_0"
                },
                [1] = {
                    label = "Green Visor Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_175_1"
                },
                [2] = {
                    label = "Orange Mask Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_175_2"
                },
                [3] = {
                    label = "Gold Mask Respirator",
                    price = 500,
                    type = "money",
                    image = "female_mask_175_3"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Gold Dog",
                    price = 500,
                    type = "money",
                    image = "female_mask_176_0"
                },
                [1] = {
                    label = "Geo White Dog",
                    price = 500,
                    type = "money",
                    image = "female_mask_176_1"
                },
                [2] = {
                    label = "Geo Brown Dog",
                    price = 500,
                    type = "money",
                    image = "female_mask_176_2"
                },
                [3] = {
                    label = "Geo Gray Dog",
                    price = 500,
                    type = "money",
                    image = "female_mask_176_3"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cerberus",
                    price = 500,
                    type = "money",
                    image = "female_mask_177_0"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray & Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_0"
                },
                [1] = {
                    label = "Ash & White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_1"
                },
                [2] = {
                    label = "Gray & White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_2"
                },
                [3] = {
                    label = "Worn Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_3"
                },
                [4] = {
                    label = "Worn Yellow Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_4"
                },
                [5] = {
                    label = "Worn Green Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_5"
                },
                [6] = {
                    label = "Black Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_6"
                },
                [7] = {
                    label = "Red Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_7"
                },
                [8] = {
                    label = "Yellow Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_8"
                },
                [9] = {
                    label = "Pale Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_9"
                },
                [10] = {
                    label = "Red Lip Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_10"
                },
                [11] = {
                    label = "Smoke Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_11"
                },
                [12] = {
                    label = "Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_12"
                },
                [13] = {
                    label = "Cyan Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_13"
                },
                [14] = {
                    label = "Dark Pink Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_14"
                },
                [15] = {
                    label = "Green Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_15"
                },
                [16] = {
                    label = "Peach Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_16"
                },
                [17] = {
                    label = "Purple Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_17"
                },
                [18] = {
                    label = "Light Pink Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_18"
                },
                [19] = {
                    label = "Terracotta Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_19"
                },
                [20] = {
                    label = "Dusty Blue Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_20"
                },
                [21] = {
                    label = "Gray Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_21"
                },
                [22] = {
                    label = "Putty Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_22"
                },
                [23] = {
                    label = "White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_23"
                },
                [24] = {
                    label = "Stone Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "female_mask_178_24"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grin",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_0"
                },
                [1] = {
                    label = "Cry",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_1"
                },
                [2] = {
                    label = "Laugh",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_2"
                },
                [3] = {
                    label = "Grimace",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_3"
                },
                [4] = {
                    label = "In Love",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_4"
                },
                [5] = {
                    label = "Blow Kiss",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_5"
                },
                [6] = {
                    label = "Gasp",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_6"
                },
                [7] = {
                    label = "Wink",
                    price = 500,
                    type = "money",
                    image = "female_mask_179_7"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (180-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_0"
                },
                [1] = {
                    label = "Mask (180-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_1"
                },
                [2] = {
                    label = "Mask (180-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_2"
                },
                [3] = {
                    label = "Mask (180-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_3"
                },
                [4] = {
                    label = "Mask (180-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_4"
                },
                [5] = {
                    label = "Mask (180-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_5"
                },
                [6] = {
                    label = "Mask (180-6)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_6"
                },
                [7] = {
                    label = "Mask (180-7)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_7"
                },
                [8] = {
                    label = "Mask (180-8)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_8"
                },
                [9] = {
                    label = "Mask (180-9)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_9"
                },
                [10] = {
                    label = "Mask (180-10)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_10"
                },
                [11] = {
                    label = "Mask (180-11)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_11"
                },
                [12] = {
                    label = "Mask (180-12)",
                    price = 500,
                    type = "money",
                    image = "female_mask_180_12"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_181_0"
                },
                [1] = {
                    label = "Brown Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_181_1"
                },
                [2] = {
                    label = "Moss Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_181_2"
                },
                [3] = {
                    label = "Swamp Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_181_3"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_182_0"
                },
                [1] = {
                    label = "Brown Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_182_1"
                },
                [2] = {
                    label = "Tan Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_182_2"
                },
                [3] = {
                    label = "Gray Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_182_3"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black & Green Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_0"
                },
                [1] = {
                    label = "Black & Orange Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_1"
                },
                [2] = {
                    label = "Black & Blue Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_2"
                },
                [3] = {
                    label = "Black & Pink Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_3"
                },
                [4] = {
                    label = "Green Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_4"
                },
                [5] = {
                    label = "Orange Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_5"
                },
                [6] = {
                    label = "Blue Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_6"
                },
                [7] = {
                    label = "Pink Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_7"
                },
                [8] = {
                    label = "Green T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_8"
                },
                [9] = {
                    label = "Orange T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_9"
                },
                [10] = {
                    label = "Blue T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_10"
                },
                [11] = {
                    label = "Pink T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_11"
                },
                [12] = {
                    label = "Green Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_12"
                },
                [13] = {
                    label = "Orange Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_13"
                },
                [14] = {
                    label = "Blue Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_14"
                },
                [15] = {
                    label = "Pink Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_183_15"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_184_0"
                },
                [1] = {
                    label = "Gray Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_184_1"
                },
                [2] = {
                    label = "Stone Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_184_2"
                },
                [3] = {
                    label = "Smoke Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_184_3"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_0"
                },
                [1] = {
                    label = "White Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_1"
                },
                [2] = {
                    label = "Ash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_2"
                },
                [3] = {
                    label = "Red Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_3"
                },
                [4] = {
                    label = "Dark Red Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_4"
                },
                [5] = {
                    label = "Cream Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_5"
                },
                [6] = {
                    label = "Green Digital Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_6"
                },
                [7] = {
                    label = "Brown Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_7"
                },
                [8] = {
                    label = "Gray Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_8"
                },
                [9] = {
                    label = "Desert Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_9"
                },
                [10] = {
                    label = "Forest Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_10"
                },
                [11] = {
                    label = "Blue Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_11"
                },
                [12] = {
                    label = "Rock Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_12"
                },
                [13] = {
                    label = "Grass Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_13"
                },
                [14] = {
                    label = "Field Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_14"
                },
                [15] = {
                    label = "Rust Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_15"
                },
                [16] = {
                    label = "Blue Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_16"
                },
                [17] = {
                    label = "Yellow Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_17"
                },
                [18] = {
                    label = "Green Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_18"
                },
                [19] = {
                    label = "Pink Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_19"
                },
                [20] = {
                    label = "Moss Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_20"
                },
                [21] = {
                    label = "Green Splash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_21"
                },
                [22] = {
                    label = "Purple Splash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_22"
                },
                [23] = {
                    label = "Green Shard Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_23"
                },
                [24] = {
                    label = "Violet Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_24"
                },
                [25] = {
                    label = "Pink Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_185_25"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Logo Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_0"
                },
                [1] = {
                    label = "Yellow Bigness Logo Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_1"
                },
                [2] = {
                    label = "Yellow VDG Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_2"
                },
                [3] = {
                    label = "Gray VDG Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_3"
                },
                [4] = {
                    label = "Yellow Pattern Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_4"
                },
                [5] = {
                    label = "Black Pattern Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_5"
                },
                [6] = {
                    label = "Yellow Trickster Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_6"
                },
                [7] = {
                    label = "Black Trickster Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_7"
                },
                [8] = {
                    label = "Yellow Camo Face",
                    price = 500,
                    type = "money",
                    image = "female_mask_186_8"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Botanical Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_0"
                },
                [1] = {
                    label = "Black Botanical Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_1"
                },
                [2] = {
                    label = "Blue Blossom Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_2"
                },
                [3] = {
                    label = "Black Blossom Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_3"
                },
                [4] = {
                    label = "Blue Blooming Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_4"
                },
                [5] = {
                    label = "Orange Blooming Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_5"
                },
                [6] = {
                    label = "Green Floral Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_6"
                },
                [7] = {
                    label = "Cream Floral Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_7"
                },
                [8] = {
                    label = "Aqua Palms Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_8"
                },
                [9] = {
                    label = "Yellow Palms Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_9"
                },
                [10] = {
                    label = "Flamingo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_10"
                },
                [11] = {
                    label = "Blue Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_11"
                },
                [12] = {
                    label = "Green Painted Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_12"
                },
                [13] = {
                    label = "Navy Painted Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_13"
                },
                [14] = {
                    label = "Blue Ocean Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_14"
                },
                [15] = {
                    label = "Orange Ocean Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_15"
                },
                [16] = {
                    label = "Blue Butterfly Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_16"
                },
                [17] = {
                    label = "Orange Butterfly Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_17"
                },
                [18] = {
                    label = "Red Volcanic Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_18"
                },
                [19] = {
                    label = "Pink Volcanic Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_19"
                },
                [20] = {
                    label = "Cream Fish Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_20"
                },
                [21] = {
                    label = "Magenta Fish Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_21"
                },
                [22] = {
                    label = "Cream Tiger Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_22"
                },
                [23] = {
                    label = "Pink Tiger Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_23"
                },
                [24] = {
                    label = "Mauve Flowers Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_24"
                },
                [25] = {
                    label = "Blue Flowers Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_187_25"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Grotesque Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_0"
                },
                [1] = {
                    label = "Blue Grotesque Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_1"
                },
                [2] = {
                    label = "Red Flames Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_2"
                },
                [3] = {
                    label = "Blue Flames Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_3"
                },
                [4] = {
                    label = "Island Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_4"
                },
                [5] = {
                    label = "Palm Print Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_5"
                },
                [6] = {
                    label = "Green Grin Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_6"
                },
                [7] = {
                    label = "Red Grin Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_7"
                },
                [8] = {
                    label = "Yellow Grin Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_8"
                },
                [9] = {
                    label = "Red Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_9"
                },
                [10] = {
                    label = "White Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_10"
                },
                [11] = {
                    label = "Black Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "female_mask_188_11"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_0"
                },
                [1] = {
                    label = "Navy Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_1"
                },
                [2] = {
                    label = "Cherry Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_2"
                },
                [3] = {
                    label = "Orange Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_3"
                },
                [4] = {
                    label = "Purple Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_4"
                },
                [5] = {
                    label = "Dark Blue Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_5"
                },
                [6] = {
                    label = "Lavender Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_6"
                },
                [7] = {
                    label = "Yellow Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_7"
                },
                [8] = {
                    label = "Pink Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_8"
                },
                [9] = {
                    label = "Neon Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_9"
                },
                [10] = {
                    label = "Vibrant Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_10"
                },
                [11] = {
                    label = "Pink Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_11"
                },
                [12] = {
                    label = "Blue Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_12"
                },
                [13] = {
                    label = "Neon Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_13"
                },
                [14] = {
                    label = "Vibrant Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_14"
                },
                [15] = {
                    label = "Pink Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_15"
                },
                [16] = {
                    label = "Orange Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_16"
                },
                [17] = {
                    label = "Dark X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_17"
                },
                [18] = {
                    label = "Bright X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_18"
                },
                [19] = {
                    label = "Purple X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_189_19"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (190-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_190_0"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'component',
            textures = {
                [0] = {
                    label = "Clean Horned Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_191_0"
                },
                [1] = {
                    label = "Dark Horned Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_191_1"
                },
                [2] = {
                    label = "Aged Horned Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_191_2"
                },
                [3] = {
                    label = "Weathered Horned Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_191_3"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "female_mask_192_0"
                },
                [1] = {
                    label = "Red Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "female_mask_192_1"
                },
                [2] = {
                    label = "White Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "female_mask_192_2"
                },
                [3] = {
                    label = "Yellow Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "female_mask_192_3"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'component',
            textures = {
                [0] = {
                    label = "Plain Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_193_0"
                },
                [1] = {
                    label = "Fleshy Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_193_1"
                },
                [2] = {
                    label = "Mossy Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_193_2"
                },
                [3] = {
                    label = "Dark Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "female_mask_193_3"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bearsy",
                    price = 500,
                    type = "money",
                    image = "female_mask_194_0"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (195-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_195_0"
                },
                [1] = {
                    label = "Mask (195-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_195_1"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Goldfish",
                    price = 500,
                    type = "money",
                    image = "female_mask_196_0"
                },
                [1] = {
                    label = "Purple Goldfish",
                    price = 500,
                    type = "money",
                    image = "female_mask_196_1"
                },
                [2] = {
                    label = "Bronze Goldfish",
                    price = 500,
                    type = "money",
                    image = "female_mask_196_2"
                },
                [3] = {
                    label = "Clownfish",
                    price = 500,
                    type = "money",
                    image = "female_mask_196_3"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'component',
            textures = {
                [0] = {
                    label = "Juvenile Gull",
                    price = 500,
                    type = "money",
                    image = "female_mask_197_0"
                },
                [1] = {
                    label = "Sooty Gull",
                    price = 500,
                    type = "money",
                    image = "female_mask_197_1"
                },
                [2] = {
                    label = "Black-headed Gull",
                    price = 500,
                    type = "money",
                    image = "female_mask_197_2"
                },
                [3] = {
                    label = "Herring Gull",
                    price = 500,
                    type = "money",
                    image = "female_mask_197_3"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Sea Lion",
                    price = 500,
                    type = "money",
                    image = "female_mask_198_0"
                },
                [1] = {
                    label = "Dark Sea Lion",
                    price = 500,
                    type = "money",
                    image = "female_mask_198_1"
                },
                [2] = {
                    label = "Spotted Sea Lion",
                    price = 500,
                    type = "money",
                    image = "female_mask_198_2"
                },
                [3] = {
                    label = "Gray Sea Lion",
                    price = 500,
                    type = "money",
                    image = "female_mask_198_3"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'component',
            textures = {
                [0] = {
                    label = "Famine",
                    price = 500,
                    type = "money",
                    image = "female_mask_199_0"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "female_mask_200_0"
                },
                [1] = {
                    label = "Dark Green Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "female_mask_200_1"
                },
                [2] = {
                    label = "Light Green Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "female_mask_200_2"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (201-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_201_0"
                },
            },
        },
        [202] = {
            drawable = 202,
            type = 'component',
            textures = {
                [0] = {
                    label = "War",
                    price = 500,
                    type = "money",
                    image = "female_mask_202_0"
                },
            },
        },
        [203] = {
            drawable = 203,
            type = 'component',
            textures = {
                [0] = {
                    label = "Death",
                    price = 500,
                    type = "money",
                    image = "female_mask_203_0"
                },
            },
        },
        [204] = {
            drawable = 204,
            type = 'component',
            textures = {
                [0] = {
                    label = "Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "female_mask_204_0"
                },
                [1] = {
                    label = "Gray Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "female_mask_204_1"
                },
                [2] = {
                    label = "Gold Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "female_mask_204_2"
                },
                [3] = {
                    label = "Ornate Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "female_mask_204_3"
                },
            },
        },
        [205] = {
            drawable = 205,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "female_mask_205_0"
                },
                [1] = {
                    label = "Green Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "female_mask_205_1"
                },
                [2] = {
                    label = "Weathered Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "female_mask_205_2"
                },
            },
        },
        [206] = {
            drawable = 206,
            type = 'component',
            textures = {
                [0] = {
                    label = "Horror Pumpkin",
                    price = 500,
                    type = "money",
                    image = "female_mask_206_0"
                },
            },
        },
        [207] = {
            drawable = 207,
            type = 'component',
            textures = {
                [0] = {
                    label = "Conquest",
                    price = 500,
                    type = "money",
                    image = "female_mask_207_0"
                },
            },
        },
        [208] = {
            drawable = 208,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "female_mask_208_0"
                },
                [1] = {
                    label = "Brown Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "female_mask_208_1"
                },
                [2] = {
                    label = "Gray Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "female_mask_208_2"
                },
            },
        },
        [209] = {
            drawable = 209,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_0"
                },
                [1] = {
                    label = "Gray Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_1"
                },
                [2] = {
                    label = "White Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_2"
                },
                [3] = {
                    label = "Green Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_3"
                },
                [4] = {
                    label = "Orange Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_4"
                },
                [5] = {
                    label = "Purple Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_5"
                },
                [6] = {
                    label = "Pink Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_6"
                },
                [7] = {
                    label = "Red Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_7"
                },
                [8] = {
                    label = "Blue Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_8"
                },
                [9] = {
                    label = "Yellow Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_9"
                },
                [10] = {
                    label = "Green Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_10"
                },
                [11] = {
                    label = "Pink Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_11"
                },
                [12] = {
                    label = "Orange & Gray Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_12"
                },
                [13] = {
                    label = "Red Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_13"
                },
                [14] = {
                    label = "Camo Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_14"
                },
                [15] = {
                    label = "Aqua Camo Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_15"
                },
                [16] = {
                    label = "Brown Digital Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_16"
                },
                [17] = {
                    label = "Gold Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_17"
                },
                [18] = {
                    label = "Orange & Cream Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_18"
                },
                [19] = {
                    label = "Green & Yellow Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_19"
                },
                [20] = {
                    label = "Pink Floral Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_20"
                },
                [21] = {
                    label = "Black & Green Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_21"
                },
                [22] = {
                    label = "White & Red Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_22"
                },
                [23] = {
                    label = "Carbon Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_23"
                },
                [24] = {
                    label = "Carbon Teal Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_24"
                },
                [25] = {
                    label = "Black & White Tech Demon",
                    price = 500,
                    type = "money",
                    image = "female_mask_209_25"
                },
            },
        },
        [210] = {
            drawable = 210,
            type = 'component',
            textures = {
                [0] = {
                    label = "Traditional Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "female_mask_210_0"
                },
                [1] = {
                    label = "Twilight Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "female_mask_210_1"
                },
                [2] = {
                    label = "Noh Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "female_mask_210_2"
                },
            },
        },
        [211] = {
            drawable = 211,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (211-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_211_0"
                },
            },
        },
        [212] = {
            drawable = 212,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_0"
                },
                [1] = {
                    label = "White Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_1"
                },
                [2] = {
                    label = "Purple Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_2"
                },
                [3] = {
                    label = "Black Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_3"
                },
                [4] = {
                    label = "Blue Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_4"
                },
                [5] = {
                    label = "Red Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_5"
                },
                [6] = {
                    label = "White Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_6"
                },
                [7] = {
                    label = "Black Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_7"
                },
                [8] = {
                    label = "Teal Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_8"
                },
                [9] = {
                    label = "Magenta Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_9"
                },
                [10] = {
                    label = "Green Flames Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_10"
                },
                [11] = {
                    label = "Orange Flames Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_11"
                },
                [12] = {
                    label = "Pink Flames Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_12"
                },
                [13] = {
                    label = "Purple Flames Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_13"
                },
                [14] = {
                    label = "Red Flames Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_14"
                },
                [15] = {
                    label = "Blue Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_15"
                },
                [16] = {
                    label = "White Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_16"
                },
                [17] = {
                    label = "Green Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_17"
                },
                [18] = {
                    label = "Orange Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_18"
                },
                [19] = {
                    label = "Purple Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_19"
                },
                [20] = {
                    label = "Pink Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_20"
                },
                [21] = {
                    label = "Gray Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_21"
                },
                [22] = {
                    label = "Aqua Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_22"
                },
                [23] = {
                    label = "Contrast Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_23"
                },
                [24] = {
                    label = "Gray Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_24"
                },
                [25] = {
                    label = "Aqua Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_212_25"
                },
            },
        },
        [213] = {
            drawable = 213,
            type = 'component',
            textures = {
                [0] = {
                    label = "Contrast Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_213_0"
                },
                [1] = {
                    label = "Gray Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_213_1"
                },
                [2] = {
                    label = "Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_213_2"
                },
                [3] = {
                    label = "Pink Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "female_mask_213_3"
                },
            },
        },
        [214] = {
            drawable = 214,
            type = 'component',
            textures = {
                [0] = {
                    label = "The Gooch",
                    price = 500,
                    type = "money",
                    image = "female_mask_214_0"
                },
            },
        },
        [215] = {
            drawable = 215,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (215-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_215_0"
                },
                [1] = {
                    label = "Mask (215-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_215_1"
                },
            },
        },
        [216] = {
            drawable = 216,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (216-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_216_0"
                },
            },
        },
        [217] = {
            drawable = 217,
            type = 'component',
            textures = {
                [0] = {
                    label = "Scarlet Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_217_0"
                },
                [1] = {
                    label = "Amber Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_217_1"
                },
                [2] = {
                    label = "Green Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_217_2"
                },
            },
        },
        [218] = {
            drawable = 218,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_218_0"
                },
                [1] = {
                    label = "Blue Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_218_1"
                },
                [2] = {
                    label = "Brown Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_218_2"
                },
            },
        },
        [219] = {
            drawable = 219,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_219_0"
                },
                [1] = {
                    label = "Yellow Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_219_1"
                },
                [2] = {
                    label = "Orange Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_219_2"
                },
            },
        },
        [220] = {
            drawable = 220,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_220_0"
                },
                [1] = {
                    label = "Brown Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_220_1"
                },
                [2] = {
                    label = "Teal Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_220_2"
                },
            },
        },
        [221] = {
            drawable = 221,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_221_0"
                },
                [1] = {
                    label = "White Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_221_1"
                },
                [2] = {
                    label = "Brown Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_221_2"
                },
            },
        },
        [222] = {
            drawable = 222,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (222-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_222_0"
                },
            },
        },
        [223] = {
            drawable = 223,
            type = 'component',
            textures = {
                [0] = {
                    label = "Golden Balaclava",
                    price = 500,
                    type = "money",
                    image = "female_mask_223_0"
                },
            },
        },
        [224] = {
            drawable = 224,
            type = 'component',
            textures = {
                [0] = {
                    label = "Turkey Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_224_0"
                },
            },
        },
        [225] = {
            drawable = 225,
            type = 'component',
            textures = {
                [0] = {
                    label = "Luchadora's Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_225_0"
                },
            },
        },
        [226] = {
            drawable = 226,
            type = 'component',
            textures = {
                [0] = {
                    label = "Royal Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_226_0"
                },
                [1] = {
                    label = "Maritime Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_226_1"
                },
                [2] = {
                    label = "Romance Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_226_2"
                },
                [3] = {
                    label = "Floral Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_226_3"
                },
            },
        },
        [227] = {
            drawable = 227,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (227-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_227_0"
                },
            },
        },
        [228] = {
            drawable = 228,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (228-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_228_0"
                },
            },
        },
        [229] = {
            drawable = 229,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cinco de Mayo Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_229_0"
                },
            },
        },
        [230] = {
            drawable = 230,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wooden Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_230_0"
                },
                [1] = {
                    label = "Contrast Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_230_1"
                },
                [2] = {
                    label = "Regal Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_230_2"
                },
                [3] = {
                    label = "Midnight Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_230_3"
                },
            },
        },
        [231] = {
            drawable = 231,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (231-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_231_0"
                },
                [1] = {
                    label = "Mask (231-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_231_1"
                },
                [2] = {
                    label = "Mask (231-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_231_2"
                },
                [3] = {
                    label = "Mask (231-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_231_3"
                },
            },
        },
        [232] = {
            drawable = 232,
            type = 'component',
            textures = {
                [0] = {
                    label = "LS Customs Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_232_0"
                },
            },
        },
        [233] = {
            drawable = 233,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (233-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_0"
                },
                [1] = {
                    label = "Mask (233-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_1"
                },
                [2] = {
                    label = "Mask (233-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_2"
                },
                [3] = {
                    label = "Mask (233-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_3"
                },
                [4] = {
                    label = "Mask (233-4)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_4"
                },
                [5] = {
                    label = "Mask (233-5)",
                    price = 500,
                    type = "money",
                    image = "female_mask_233_5"
                },
            },
        },
        [234] = {
            drawable = 234,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (234-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_234_0"
                },
                [1] = {
                    label = "Mask (234-1)",
                    price = 500,
                    type = "money",
                    image = "female_mask_234_1"
                },
                [2] = {
                    label = "Mask (234-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_234_2"
                },
                [3] = {
                    label = "Mask (234-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_234_3"
                },
            },
        },
        [235] = {
            drawable = 235,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (235-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_235_0"
                },
                [1] = {
                    label = "Strapz Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_235_1"
                },
                [2] = {
                    label = "Mask (235-2)",
                    price = 500,
                    type = "money",
                    image = "female_mask_235_2"
                },
                [3] = {
                    label = "Mask (235-3)",
                    price = 500,
                    type = "money",
                    image = "female_mask_235_3"
                },
            },
        },
        [236] = {
            drawable = 236,
            type = 'component',
            textures = {
                [0] = {
                    label = "Carnival Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_236_0"
                },
            },
        },
        [237] = {
            drawable = 237,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (237-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_237_0"
                },
            },
        },
        [238] = {
            drawable = 238,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (238-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_238_0"
                },
            },
        },
        [239] = {
            drawable = 239,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_239_0"
                },
                [1] = {
                    label = "Red Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_239_1"
                },
                [2] = {
                    label = "Tan Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_239_2"
                },
            },
        },
        [240] = {
            drawable = 240,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_240_0"
                },
                [1] = {
                    label = "Gray Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_240_1"
                },
                [2] = {
                    label = "Brown Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_240_2"
                },
            },
        },
        [241] = {
            drawable = 241,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_241_0"
                },
                [1] = {
                    label = "Red Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_241_1"
                },
                [2] = {
                    label = "Blue Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_241_2"
                },
            },
        },
        [242] = {
            drawable = 242,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_242_0"
                },
                [1] = {
                    label = "Green Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_242_1"
                },
                [2] = {
                    label = "Orange Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "female_mask_242_2"
                },
            },
        },
        [243] = {
            drawable = 243,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (243-0)",
                    price = 500,
                    type = "money",
                    image = "female_mask_243_0"
                },
            },
        },
        [244] = {
            drawable = 244,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ride or Die Gaiter",
                    price = 500,
                    type = "money",
                    image = "female_mask_244_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_0_0"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_1_0"
                },
                [1] = {
                    label = "Mask (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_1_1"
                },
                [2] = {
                    label = "Mask (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_1_2"
                },
                [3] = {
                    label = "Mask (1-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_1_3"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_2_0"
                },
                [1] = {
                    label = "Mask (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_2_1"
                },
                [2] = {
                    label = "Mask (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_2_2"
                },
                [3] = {
                    label = "Mask (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_2_3"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_3_0"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_4_0"
                },
                [1] = {
                    label = "Mask (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_4_1"
                },
                [2] = {
                    label = "Mask (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_4_2"
                },
                [3] = {
                    label = "Mask (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_4_3"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_5_0"
                },
                [1] = {
                    label = "Mask (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_5_1"
                },
                [2] = {
                    label = "Mask (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_5_2"
                },
                [3] = {
                    label = "Mask (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_5_3"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_6_0"
                },
                [1] = {
                    label = "Mask (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_6_1"
                },
                [2] = {
                    label = "Mask (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_6_2"
                },
                [3] = {
                    label = "Mask (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_6_3"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_7_0"
                },
                [1] = {
                    label = "Mask (7-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_7_1"
                },
                [2] = {
                    label = "Mask (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_7_2"
                },
                [3] = {
                    label = "Mask (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_7_3"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_8_0"
                },
                [1] = {
                    label = "Black Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_8_1"
                },
                [2] = {
                    label = "Latino Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_8_2"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Reindeer Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_9_0"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Snowman Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_10_0"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mysterious",
                    price = 500,
                    type = "money",
                    image = "male_mask_11_0"
                },
                [1] = {
                    label = "Red Mysterious",
                    price = 500,
                    type = "money",
                    image = "male_mask_11_1"
                },
                [2] = {
                    label = "Black Mysterious",
                    price = 500,
                    type = "money",
                    image = "male_mask_11_2"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bronze Masquerade",
                    price = 500,
                    type = "money",
                    image = "male_mask_12_0"
                },
                [1] = {
                    label = "Silver Masquerade",
                    price = 500,
                    type = "money",
                    image = "male_mask_12_1"
                },
                [2] = {
                    label = "Black & Gold Masquerade",
                    price = 500,
                    type = "money",
                    image = "male_mask_12_2"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cupid",
                    price = 500,
                    type = "money",
                    image = "male_mask_13_0"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bullet Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_0"
                },
                [1] = {
                    label = "Vinewood Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_1"
                },
                [2] = {
                    label = "Tourist Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_2"
                },
                [3] = {
                    label = "Hound Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_3"
                },
                [4] = {
                    label = "Wolf Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_4"
                },
                [5] = {
                    label = "Beast Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_5"
                },
                [6] = {
                    label = "Bear Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_6"
                },
                [7] = {
                    label = "Dust Devils Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_7"
                },
                [8] = {
                    label = "Striped Rampage Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_8"
                },
                [9] = {
                    label = "Royal Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_9"
                },
                [10] = {
                    label = "Fashion Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_10"
                },
                [11] = {
                    label = "Vile Zombie Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_11"
                },
                [12] = {
                    label = "Rotten Zombie Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_12"
                },
                [13] = {
                    label = "Flame Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_13"
                },
                [14] = {
                    label = "Nightmare Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_14"
                },
                [15] = {
                    label = "Electric Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_15_0"
                },
                [1] = {
                    label = "Stitched Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_15_1"
                },
                [2] = {
                    label = "Pale Stitched Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_15_2"
                },
                [3] = {
                    label = "Crossed Rampage Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_15_3"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Metal Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_0"
                },
                [1] = {
                    label = "Circuit Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_1"
                },
                [2] = {
                    label = "Molten Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_2"
                },
                [3] = {
                    label = "Neon Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_3"
                },
                [4] = {
                    label = "Carbon Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_4"
                },
                [5] = {
                    label = "Deadeye Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_5"
                },
                [6] = {
                    label = "Stone Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_6"
                },
                [7] = {
                    label = "Lightning Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_7"
                },
                [8] = {
                    label = "Wooden Warrior",
                    price = 500,
                    type = "money",
                    image = "male_mask_16_8"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Cat",
                    price = 500,
                    type = "money",
                    image = "male_mask_17_0"
                },
                [1] = {
                    label = "Tabby Cat",
                    price = 500,
                    type = "money",
                    image = "male_mask_17_1"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Fox",
                    price = 500,
                    type = "money",
                    image = "male_mask_18_0"
                },
                [1] = {
                    label = "Brown Fox",
                    price = 500,
                    type = "money",
                    image = "male_mask_18_1"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Owl",
                    price = 500,
                    type = "money",
                    image = "male_mask_19_0"
                },
                [1] = {
                    label = "White Owl",
                    price = 500,
                    type = "money",
                    image = "male_mask_19_1"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Racoon",
                    price = 500,
                    type = "money",
                    image = "male_mask_20_0"
                },
                [1] = {
                    label = "Black Racoon",
                    price = 500,
                    type = "money",
                    image = "male_mask_20_1"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Bear",
                    price = 500,
                    type = "money",
                    image = "male_mask_21_0"
                },
                [1] = {
                    label = "Grey Bear",
                    price = 500,
                    type = "money",
                    image = "male_mask_21_1"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Bison",
                    price = 500,
                    type = "money",
                    image = "male_mask_22_0"
                },
                [1] = {
                    label = "Golden Bison",
                    price = 500,
                    type = "money",
                    image = "male_mask_22_1"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bull",
                    price = 500,
                    type = "money",
                    image = "male_mask_23_0"
                },
                [1] = {
                    label = "Brown Bull",
                    price = 500,
                    type = "money",
                    image = "male_mask_23_1"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Eagle",
                    price = 500,
                    type = "money",
                    image = "male_mask_24_0"
                },
                [1] = {
                    label = "White Eagle",
                    price = 500,
                    type = "money",
                    image = "male_mask_24_1"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Vulture",
                    price = 500,
                    type = "money",
                    image = "male_mask_25_0"
                },
                [1] = {
                    label = "Black Vulture",
                    price = 500,
                    type = "money",
                    image = "male_mask_25_1"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grey Wolf",
                    price = 500,
                    type = "money",
                    image = "male_mask_26_0"
                },
                [1] = {
                    label = "Black Wolf",
                    price = 500,
                    type = "money",
                    image = "male_mask_26_1"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_27_0"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_28_0"
                },
                [1] = {
                    label = "Gray Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_28_1"
                },
                [2] = {
                    label = "Charcoal Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_28_2"
                },
                [3] = {
                    label = "Tan Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_28_3"
                },
                [4] = {
                    label = "Forest Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_28_4"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skeletal",
                    price = 500,
                    type = "money",
                    image = "male_mask_29_0"
                },
                [1] = {
                    label = "Gray Skeletal",
                    price = 500,
                    type = "money",
                    image = "male_mask_29_1"
                },
                [2] = {
                    label = "Charcoal Skeletal",
                    price = 500,
                    type = "money",
                    image = "male_mask_29_2"
                },
                [3] = {
                    label = "Tan Skeletal",
                    price = 500,
                    type = "money",
                    image = "male_mask_29_3"
                },
                [4] = {
                    label = "Green Skeletal",
                    price = 500,
                    type = "money",
                    image = "male_mask_29_4"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Please Stop Me Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_30_0"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Penguin",
                    price = 500,
                    type = "money",
                    image = "male_mask_31_0"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Stocking",
                    price = 500,
                    type = "money",
                    image = "male_mask_32_0"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_34_0"
                },
                [1] = {
                    label = "Black Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_34_1"
                },
                [2] = {
                    label = "Latino Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_34_2"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_35_0"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Rebreather",
                    price = 500,
                    type = "money",
                    image = "male_mask_36_0"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Scruffy Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_37_0"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_38_0"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Infected",
                    price = 500,
                    type = "money",
                    image = "male_mask_39_0"
                },
                [1] = {
                    label = "Brown Infected",
                    price = 500,
                    type = "money",
                    image = "male_mask_39_1"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mummy",
                    price = 500,
                    type = "money",
                    image = "male_mask_40_0"
                },
                [1] = {
                    label = "Green Mummy",
                    price = 500,
                    type = "money",
                    image = "male_mask_40_1"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Vampyr",
                    price = 500,
                    type = "money",
                    image = "male_mask_41_0"
                },
                [1] = {
                    label = "Blue Vampyr",
                    price = 500,
                    type = "money",
                    image = "male_mask_41_1"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Frank",
                    price = 500,
                    type = "money",
                    image = "male_mask_42_0"
                },
                [1] = {
                    label = "Gray Frank",
                    price = 500,
                    type = "money",
                    image = "male_mask_42_1"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Impotent Rage",
                    price = 500,
                    type = "money",
                    image = "male_mask_43_0"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Princess Robot Bubblegum",
                    price = 500,
                    type = "money",
                    image = "male_mask_44_0"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Moorehead",
                    price = 500,
                    type = "money",
                    image = "male_mask_45_0"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chemical Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_46_0"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Crime Scene Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_47_0"
                },
                [1] = {
                    label = "Black Arrow Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_47_1"
                },
                [2] = {
                    label = "Hazard Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_47_2"
                },
                [3] = {
                    label = "Red Arrow Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_47_3"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Gray Duct Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_48_0"
                },
                [1] = {
                    label = "Dark Gray Duct Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_48_1"
                },
                [2] = {
                    label = "White Duct Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_48_2"
                },
                [3] = {
                    label = "Electrical Duct Tape",
                    price = 500,
                    type = "money",
                    image = "male_mask_48_3"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Up-n-Atom Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_0"
                },
                [1] = {
                    label = "Manic Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_1"
                },
                [2] = {
                    label = "Sad Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_2"
                },
                [3] = {
                    label = "Happy Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_3"
                },
                [4] = {
                    label = "Fat Cat Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_4"
                },
                [5] = {
                    label = "Mouth Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_5"
                },
                [6] = {
                    label = "Shy Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_6"
                },
                [7] = {
                    label = "Burger Shot Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_7"
                },
                [8] = {
                    label = "Kill Me Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_8"
                },
                [9] = {
                    label = "Diabolic Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_9"
                },
                [10] = {
                    label = "Cop Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_10"
                },
                [11] = {
                    label = "Monster Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_11"
                },
                [12] = {
                    label = "Fury Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_12"
                },
                [13] = {
                    label = "Zigzag Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_13"
                },
                [14] = {
                    label = "Skull Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_14"
                },
                [15] = {
                    label = "Dog Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_15"
                },
                [16] = {
                    label = "Pink Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_16"
                },
                [17] = {
                    label = "Alien Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_17"
                },
                [18] = {
                    label = "Help Me Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_18"
                },
                [19] = {
                    label = "Puzzle Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_19"
                },
                [20] = {
                    label = "The Bird Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_20"
                },
                [21] = {
                    label = "Dapper Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_21"
                },
                [22] = {
                    label = "Sticker Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_22"
                },
                [23] = {
                    label = "Modernist Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_23"
                },
                [24] = {
                    label = "Love Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_24"
                },
                [25] = {
                    label = "Blackout Paper Bag",
                    price = 500,
                    type = "money",
                    image = "male_mask_49_25"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_0"
                },
                [1] = {
                    label = "The Don Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_1"
                },
                [2] = {
                    label = "Pink Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_2"
                },
                [3] = {
                    label = "Clown Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_3"
                },
                [4] = {
                    label = "Black Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_4"
                },
                [5] = {
                    label = "Brown Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_5"
                },
                [6] = {
                    label = "Mannequin Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_6"
                },
                [7] = {
                    label = "Doll Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_7"
                },
                [8] = {
                    label = "Puppet Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_8"
                },
                [9] = {
                    label = "Mime Plastic Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_50_9"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_0"
                },
                [1] = {
                    label = "Skull Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_1"
                },
                [2] = {
                    label = "Urban Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_2"
                },
                [3] = {
                    label = "Desert Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_3"
                },
                [4] = {
                    label = "Forest Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_4"
                },
                [5] = {
                    label = "Green Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_5"
                },
                [6] = {
                    label = "Purple Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_6"
                },
                [7] = {
                    label = "Paisley Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_7"
                },
                [8] = {
                    label = "Yellow Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_8"
                },
                [9] = {
                    label = "Electric Skull Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_51_9"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_0"
                },
                [1] = {
                    label = "Gray Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_1"
                },
                [2] = {
                    label = "White Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_2"
                },
                [3] = {
                    label = "Green Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_3"
                },
                [4] = {
                    label = "Khaki Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_4"
                },
                [5] = {
                    label = "Charcoal Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_5"
                },
                [6] = {
                    label = "Forest Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_6"
                },
                [7] = {
                    label = "Urban Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_7"
                },
                [8] = {
                    label = "Blue Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_8"
                },
                [9] = {
                    label = "Yellow Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_9"
                },
                [10] = {
                    label = "Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_52_10"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_0"
                },
                [1] = {
                    label = "Gray Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_1"
                },
                [2] = {
                    label = "White Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_2"
                },
                [3] = {
                    label = "Green Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_3"
                },
                [4] = {
                    label = "Khaki Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_4"
                },
                [5] = {
                    label = "Charcoal Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_5"
                },
                [6] = {
                    label = "Forest Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_6"
                },
                [7] = {
                    label = "Urban Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_7"
                },
                [8] = {
                    label = "Skull Hooded Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_53_8"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_0"
                },
                [1] = {
                    label = "White T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_1"
                },
                [2] = {
                    label = "Tan T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_2"
                },
                [3] = {
                    label = "Benders T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_3"
                },
                [4] = {
                    label = "Justice T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_4"
                },
                [5] = {
                    label = "Woodland T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_5"
                },
                [6] = {
                    label = "Stripy T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_6"
                },
                [7] = {
                    label = "Love Fist T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_7"
                },
                [8] = {
                    label = "TPI T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_8"
                },
                [9] = {
                    label = "Pink Camo T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_9"
                },
                [10] = {
                    label = "LSPD T-Shirt Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_54_10"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Toggle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_55_0"
                },
                [1] = {
                    label = "Khaki Toggle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_55_1"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_0"
                },
                [1] = {
                    label = "Black Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_1"
                },
                [2] = {
                    label = "Skull Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_2"
                },
                [3] = {
                    label = "Khaki Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_3"
                },
                [4] = {
                    label = "Bloody Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_4"
                },
                [5] = {
                    label = "Woodland Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_5"
                },
                [6] = {
                    label = "Red Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_6"
                },
                [7] = {
                    label = "Outback Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_7"
                },
                [8] = {
                    label = "Split Loose Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_56_8"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_0"
                },
                [1] = {
                    label = "Army Green Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_1"
                },
                [2] = {
                    label = "Copper Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_2"
                },
                [3] = {
                    label = "Gray Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_3"
                },
                [4] = {
                    label = "Brown Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_4"
                },
                [5] = {
                    label = "Rainbow Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_5"
                },
                [6] = {
                    label = "Woodland Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_6"
                },
                [7] = {
                    label = "Dirty Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_7"
                },
                [8] = {
                    label = "Pink Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_8"
                },
                [9] = {
                    label = "Flying Bravo FB Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_9"
                },
                [10] = {
                    label = "Flying Bravo Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_10"
                },
                [11] = {
                    label = "Princess Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_11"
                },
                [12] = {
                    label = "Didier Sachs Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_12"
                },
                [13] = {
                    label = "Perseus Band Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_13"
                },
                [14] = {
                    label = "Perseus Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_14"
                },
                [15] = {
                    label = "Sessanta Nove Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_15"
                },
                [16] = {
                    label = "White Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_16"
                },
                [17] = {
                    label = "Blue Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_17"
                },
                [18] = {
                    label = "Red Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_18"
                },
                [19] = {
                    label = "Green Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_19"
                },
                [20] = {
                    label = "Orange Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_20"
                },
                [21] = {
                    label = "Purple Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_57_21"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bandit Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_0"
                },
                [1] = {
                    label = "Nature Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_1"
                },
                [2] = {
                    label = "Neon Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_2"
                },
                [3] = {
                    label = "Pink Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_3"
                },
                [4] = {
                    label = "Orange Camo Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_4"
                },
                [5] = {
                    label = "Impotent Rage Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_5"
                },
                [6] = {
                    label = "Pogo Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_6"
                },
                [7] = {
                    label = "Blue Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_7"
                },
                [8] = {
                    label = "Black Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_8"
                },
                [9] = {
                    label = "Pink Stripe Knit Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_58_9"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (59-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_59_0"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Evil Pumpkin",
                    price = 500,
                    type = "money",
                    image = "male_mask_60_0"
                },
                [1] = {
                    label = "Rotten Pumpkin",
                    price = 500,
                    type = "money",
                    image = "male_mask_60_1"
                },
                [2] = {
                    label = "Nasty Watermelon",
                    price = 500,
                    type = "money",
                    image = "male_mask_60_2"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Creepy Butler",
                    price = 500,
                    type = "money",
                    image = "male_mask_61_0"
                },
                [1] = {
                    label = "Dead Butler",
                    price = 500,
                    type = "money",
                    image = "male_mask_61_1"
                },
                [2] = {
                    label = "Rotten Butler",
                    price = 500,
                    type = "money",
                    image = "male_mask_61_2"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "male_mask_62_0"
                },
                [1] = {
                    label = "Bloody Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "male_mask_62_1"
                },
                [2] = {
                    label = "Black Scalded Psycho",
                    price = 500,
                    type = "money",
                    image = "male_mask_62_2"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_63_0"
                },
                [1] = {
                    label = "Green Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_63_1"
                },
                [2] = {
                    label = "Gray Flayed Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_63_2"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Skull Burst",
                    price = 500,
                    type = "money",
                    image = "male_mask_64_0"
                },
                [1] = {
                    label = "Red Skull Burst",
                    price = 500,
                    type = "money",
                    image = "male_mask_64_1"
                },
                [2] = {
                    label = "Cream Skull Burst",
                    price = 500,
                    type = "money",
                    image = "male_mask_64_2"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "male_mask_65_0"
                },
                [1] = {
                    label = "Dark Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "male_mask_65_1"
                },
                [2] = {
                    label = "Gray Lycanthrope",
                    price = 500,
                    type = "money",
                    image = "male_mask_65_2"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "male_mask_66_0"
                },
                [1] = {
                    label = "Red Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "male_mask_66_1"
                },
                [2] = {
                    label = "Purple Toxic Insect",
                    price = 500,
                    type = "money",
                    image = "male_mask_66_2"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dirty Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "male_mask_67_0"
                },
                [1] = {
                    label = "Rotten Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "male_mask_67_1"
                },
                [2] = {
                    label = "Scabby Sewer Creature",
                    price = 500,
                    type = "money",
                    image = "male_mask_67_2"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_68_0"
                },
                [1] = {
                    label = "Orange Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_68_1"
                },
                [2] = {
                    label = "Black Classic Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_68_2"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "male_mask_69_0"
                },
                [1] = {
                    label = "Bloody Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "male_mask_69_1"
                },
                [2] = {
                    label = "Black Sack Slasher",
                    price = 500,
                    type = "money",
                    image = "male_mask_69_2"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "male_mask_70_0"
                },
                [1] = {
                    label = "Green Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "male_mask_70_1"
                },
                [2] = {
                    label = "Red Hypnotic Alien",
                    price = 500,
                    type = "money",
                    image = "male_mask_70_2"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "male_mask_71_0"
                },
                [1] = {
                    label = "Gray Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "male_mask_71_1"
                },
                [2] = {
                    label = "White Haggard Witch",
                    price = 500,
                    type = "money",
                    image = "male_mask_71_2"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_72_0"
                },
                [1] = {
                    label = "Orange Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_72_1"
                },
                [2] = {
                    label = "Black Bearded Lucifer",
                    price = 500,
                    type = "money",
                    image = "male_mask_72_2"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (73-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_73_0"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Manic Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_74_0"
                },
                [1] = {
                    label = "Mad Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_74_1"
                },
                [2] = {
                    label = "Angry Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_74_2"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pink Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_75_0"
                },
                [1] = {
                    label = "Blue Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_75_1"
                },
                [2] = {
                    label = "Brown Crazy Gingerbread",
                    price = 500,
                    type = "money",
                    image = "male_mask_75_2"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bruised Bad Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_76_0"
                },
                [1] = {
                    label = "Grumpy Bad Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_76_1"
                },
                [2] = {
                    label = "Filthy Bad Santa",
                    price = 500,
                    type = "money",
                    image = "male_mask_76_2"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_0"
                },
                [1] = {
                    label = "Dark Green Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_1"
                },
                [2] = {
                    label = "Black Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_2"
                },
                [3] = {
                    label = "White Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_3"
                },
                [4] = {
                    label = "Red Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_4"
                },
                [5] = {
                    label = "Purple Festive Luchador",
                    price = 500,
                    type = "money",
                    image = "male_mask_77_5"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Pudding",
                    price = 500,
                    type = "money",
                    image = "male_mask_78_0"
                },
                [1] = {
                    label = "Light Pudding",
                    price = 500,
                    type = "money",
                    image = "male_mask_78_1"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_79_0"
                },
                [1] = {
                    label = "Blond Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_79_1"
                },
                [2] = {
                    label = "Silver Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_79_2"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black LS Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_80_0"
                },
                [1] = {
                    label = "Red LS Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_80_1"
                },
                [2] = {
                    label = "White LS Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_80_2"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Visor Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_81_0"
                },
                [1] = {
                    label = "LS Visor Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_81_1"
                },
                [2] = {
                    label = "Brown Visor Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_81_2"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_82_0"
                },
                [1] = {
                    label = "Patriot Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_82_1"
                },
                [2] = {
                    label = "Blue Sweatband Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_82_2"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Festive Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_83_0"
                },
                [1] = {
                    label = "Brown Festive Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_83_1"
                },
                [2] = {
                    label = "Blond Festive Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_83_2"
                },
                [3] = {
                    label = "Silver Festive Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_83_3"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Abominable Snowman",
                    price = 500,
                    type = "money",
                    image = "male_mask_84_0"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Raw Turkey",
                    price = 500,
                    type = "money",
                    image = "male_mask_85_0"
                },
                [1] = {
                    label = "Cooked Turkey",
                    price = 500,
                    type = "money",
                    image = "male_mask_85_1"
                },
                [2] = {
                    label = "Burnt Turkey",
                    price = 500,
                    type = "money",
                    image = "male_mask_85_2"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wasted Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_86_0"
                },
                [1] = {
                    label = "Smashed Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_86_1"
                },
                [2] = {
                    label = "High Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_86_2"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Rebel Bad Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_87_0"
                },
                [1] = {
                    label = "Gangsta Bad Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_87_1"
                },
                [2] = {
                    label = "Badass Bad Elf",
                    price = 500,
                    type = "money",
                    image = "male_mask_87_2"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_88_0"
                },
                [1] = {
                    label = "Black Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_88_1"
                },
                [2] = {
                    label = "Latino Mrs Claus",
                    price = 500,
                    type = "money",
                    image = "male_mask_88_2"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_89_0"
                },
                [1] = {
                    label = "Gray Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_89_1"
                },
                [2] = {
                    label = "Charcoal Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_89_2"
                },
                [3] = {
                    label = "Tan Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_89_3"
                },
                [4] = {
                    label = "Forest Combat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_89_4"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ox Blood Dome Filter",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_0"
                },
                [1] = {
                    label = "Chocolate Dome Filter",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_1"
                },
                [2] = {
                    label = "Black Dome Filter",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_2"
                },
                [3] = {
                    label = "Tan Dome Filter",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_3"
                },
                [4] = {
                    label = "Ox Blood Dome Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_4"
                },
                [5] = {
                    label = "Chocolate Dome Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_5"
                },
                [6] = {
                    label = "Black Dome Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_6"
                },
                [7] = {
                    label = "Tan Dome Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_90_7"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (91-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_0"
                },
                [1] = {
                    label = "Mask (91-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_1"
                },
                [2] = {
                    label = "Mask (91-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_2"
                },
                [3] = {
                    label = "Mask (91-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_3"
                },
                [4] = {
                    label = "Mask (91-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_4"
                },
                [5] = {
                    label = "Mask (91-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_5"
                },
                [6] = {
                    label = "Mask (91-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_6"
                },
                [7] = {
                    label = "Mask (91-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_7"
                },
                [8] = {
                    label = "Mask (91-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_8"
                },
                [9] = {
                    label = "Mask (91-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_9"
                },
                [10] = {
                    label = "Mask (91-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_91_10"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Amphibian Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_0"
                },
                [1] = {
                    label = "Alien Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_1"
                },
                [2] = {
                    label = "Reptilian Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_2"
                },
                [3] = {
                    label = "Otherworldly Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_3"
                },
                [4] = {
                    label = "Deity Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_4"
                },
                [5] = {
                    label = "Infernal Sea Beast",
                    price = 500,
                    type = "money",
                    image = "male_mask_92_5"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Striped Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_0"
                },
                [1] = {
                    label = "Gray Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_1"
                },
                [2] = {
                    label = "Tropical Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_2"
                },
                [3] = {
                    label = "Earth Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_3"
                },
                [4] = {
                    label = "Rainforest Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_4"
                },
                [5] = {
                    label = "Danger Dino",
                    price = 500,
                    type = "money",
                    image = "male_mask_93_5"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_0"
                },
                [1] = {
                    label = "Blue Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_1"
                },
                [2] = {
                    label = "White Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_2"
                },
                [3] = {
                    label = "Black Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_3"
                },
                [4] = {
                    label = "Gold Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_4"
                },
                [5] = {
                    label = "Green Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_94_5"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_0"
                },
                [1] = {
                    label = "Blue Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_1"
                },
                [2] = {
                    label = "Green Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_2"
                },
                [3] = {
                    label = "Orange Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_3"
                },
                [4] = {
                    label = "Scavenger Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_4"
                },
                [5] = {
                    label = "Neon Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_5"
                },
                [6] = {
                    label = "Franken Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_6"
                },
                [7] = {
                    label = "Sinister Clown",
                    price = 500,
                    type = "money",
                    image = "male_mask_95_7"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Silverback Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "male_mask_96_0"
                },
                [1] = {
                    label = "Orangutan Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "male_mask_96_1"
                },
                [2] = {
                    label = "Gray Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "male_mask_96_2"
                },
                [3] = {
                    label = "Albino Crazed Ape",
                    price = 500,
                    type = "money",
                    image = "male_mask_96_3"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chestnut Horse",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_0"
                },
                [1] = {
                    label = "Black Horse",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_1"
                },
                [2] = {
                    label = "Gray Horse",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_2"
                },
                [3] = {
                    label = "Brown Horse",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_3"
                },
                [4] = {
                    label = "Pinto Horse",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_4"
                },
                [5] = {
                    label = "Zebra",
                    price = 500,
                    type = "money",
                    image = "male_mask_97_5"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Unicorn",
                    price = 500,
                    type = "money",
                    image = "male_mask_98_0"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_0"
                },
                [1] = {
                    label = "Silver Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_1"
                },
                [2] = {
                    label = "Blue Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_2"
                },
                [3] = {
                    label = "Teal Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_3"
                },
                [4] = {
                    label = "White Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_4"
                },
                [5] = {
                    label = "Black Ornate Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_99_5"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Moe Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_0"
                },
                [1] = {
                    label = "Black Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_1"
                },
                [2] = {
                    label = "Gray Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_2"
                },
                [3] = {
                    label = "Brown Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_3"
                },
                [4] = {
                    label = "Josephine Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_4"
                },
                [5] = {
                    label = "Black and Tan Pug",
                    price = 500,
                    type = "money",
                    image = "male_mask_100_5"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_0"
                },
                [1] = {
                    label = "Blue Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_1"
                },
                [2] = {
                    label = "Magenta Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_2"
                },
                [3] = {
                    label = "Yellow Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_3"
                },
                [4] = {
                    label = "Fall Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_4"
                },
                [5] = {
                    label = "Gray Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_5"
                },
                [6] = {
                    label = "Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_6"
                },
                [7] = {
                    label = "Gray Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_7"
                },
                [8] = {
                    label = "Geo Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_8"
                },
                [9] = {
                    label = "Black Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_9"
                },
                [10] = {
                    label = "Zebra Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_10"
                },
                [11] = {
                    label = "Bold Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_11"
                },
                [12] = {
                    label = "Pale Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_12"
                },
                [13] = {
                    label = "Gray Abstract Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_13"
                },
                [14] = {
                    label = "Gray Leopard Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_14"
                },
                [15] = {
                    label = "Blue Camo Bigness Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_101_15"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (102-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_102_0"
                },
                [1] = {
                    label = "Mask (102-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_102_1"
                },
                [2] = {
                    label = "Mask (102-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_102_2"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_0"
                },
                [1] = {
                    label = "Brown Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_1"
                },
                [2] = {
                    label = "Green Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_2"
                },
                [3] = {
                    label = "Gray Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_3"
                },
                [4] = {
                    label = "Peach Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_4"
                },
                [5] = {
                    label = "Fall Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_5"
                },
                [6] = {
                    label = "Dark Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_6"
                },
                [7] = {
                    label = "Crosshatch Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_7"
                },
                [8] = {
                    label = "Moss Digital Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_8"
                },
                [9] = {
                    label = "Gray Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_9"
                },
                [10] = {
                    label = "Aqua Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_10"
                },
                [11] = {
                    label = "Splinter Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_11"
                },
                [12] = {
                    label = "Contrast Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_12"
                },
                [13] = {
                    label = "Cobble Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_13"
                },
                [14] = {
                    label = "Peach Camo Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_14"
                },
                [15] = {
                    label = "Brushstroke Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_15"
                },
                [16] = {
                    label = "Flecktarn Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_16"
                },
                [17] = {
                    label = "Light Woodland Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_17"
                },
                [18] = {
                    label = "Moss Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_18"
                },
                [19] = {
                    label = "Sand Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_19"
                },
                [20] = {
                    label = "Black Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_20"
                },
                [21] = {
                    label = "Slate Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_21"
                },
                [22] = {
                    label = "Stone Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_22"
                },
                [23] = {
                    label = "Green Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_23"
                },
                [24] = {
                    label = "Woodland Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_24"
                },
                [25] = {
                    label = "Moss Camo Putrefied Zombie",
                    price = 500,
                    type = "money",
                    image = "male_mask_103_25"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_0"
                },
                [1] = {
                    label = "Brown Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_1"
                },
                [2] = {
                    label = "Green Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_2"
                },
                [3] = {
                    label = "Gray Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_3"
                },
                [4] = {
                    label = "Peach Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_4"
                },
                [5] = {
                    label = "Fall Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_5"
                },
                [6] = {
                    label = "Dark Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_6"
                },
                [7] = {
                    label = "Crosshatch Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_7"
                },
                [8] = {
                    label = "Moss Digital Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_8"
                },
                [9] = {
                    label = "Gray Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_9"
                },
                [10] = {
                    label = "Aqua Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_10"
                },
                [11] = {
                    label = "Splinter Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_11"
                },
                [12] = {
                    label = "Contrast Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_12"
                },
                [13] = {
                    label = "Cobble Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_13"
                },
                [14] = {
                    label = "Peach Camo Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_14"
                },
                [15] = {
                    label = "Brushstroke Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_15"
                },
                [16] = {
                    label = "Flecktarn Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_16"
                },
                [17] = {
                    label = "Light Woodland Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_17"
                },
                [18] = {
                    label = "Moss Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_18"
                },
                [19] = {
                    label = "Sand Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_19"
                },
                [20] = {
                    label = "Mask (104-20)",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_20"
                },
                [21] = {
                    label = "Mask (104-21)",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_21"
                },
                [22] = {
                    label = "Mask (104-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_22"
                },
                [23] = {
                    label = "Mask (104-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_23"
                },
                [24] = {
                    label = "Olive Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_24"
                },
                [25] = {
                    label = "Skull Tactical Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_104_25"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Obsidian Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_0"
                },
                [1] = {
                    label = "Weathered Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_1"
                },
                [2] = {
                    label = "Sandstone Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_2"
                },
                [3] = {
                    label = "White Painted Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_3"
                },
                [4] = {
                    label = "Gold Painted Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_4"
                },
                [5] = {
                    label = "Red Painted Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_5"
                },
                [6] = {
                    label = "Black Painted Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_6"
                },
                [7] = {
                    label = "Black Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_7"
                },
                [8] = {
                    label = "Brown Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_8"
                },
                [9] = {
                    label = "Yellow Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_9"
                },
                [10] = {
                    label = "Plum Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_10"
                },
                [11] = {
                    label = "Grayscale Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_11"
                },
                [12] = {
                    label = "Black and Yellow Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_12"
                },
                [13] = {
                    label = "Orange Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_13"
                },
                [14] = {
                    label = "Gold Stone Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_14"
                },
                [15] = {
                    label = "Stone Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_15"
                },
                [16] = {
                    label = "Gray Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_16"
                },
                [17] = {
                    label = "Black and Gold Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_17"
                },
                [18] = {
                    label = "Gray and Orange Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_18"
                },
                [19] = {
                    label = "White Possessed Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_19"
                },
                [20] = {
                    label = "Gray and Gold Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_20"
                },
                [21] = {
                    label = "Stone Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_21"
                },
                [22] = {
                    label = "Sea Green Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_22"
                },
                [23] = {
                    label = "Purple Oni",
                    price = 500,
                    type = "money",
                    image = "male_mask_105_23"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_0"
                },
                [1] = {
                    label = "Brown Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_1"
                },
                [2] = {
                    label = "Green Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_2"
                },
                [3] = {
                    label = "Gray Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_3"
                },
                [4] = {
                    label = "Peach Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_4"
                },
                [5] = {
                    label = "Fall Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_5"
                },
                [6] = {
                    label = "Dark Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_6"
                },
                [7] = {
                    label = "Crosshatch Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_7"
                },
                [8] = {
                    label = "Moss Digital Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_8"
                },
                [9] = {
                    label = "Gray Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_9"
                },
                [10] = {
                    label = "Aqua Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_10"
                },
                [11] = {
                    label = "Splinter Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_11"
                },
                [12] = {
                    label = "Contrast Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_12"
                },
                [13] = {
                    label = "Cobble Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_13"
                },
                [14] = {
                    label = "Peach Camo Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_14"
                },
                [15] = {
                    label = "Brushstroke Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_15"
                },
                [16] = {
                    label = "Flecktarn Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_16"
                },
                [17] = {
                    label = "Light Woodland Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_17"
                },
                [18] = {
                    label = "Moss Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_18"
                },
                [19] = {
                    label = "Sand Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_19"
                },
                [20] = {
                    label = "Mask (106-20)",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_20"
                },
                [21] = {
                    label = "Mask (106-21)",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_21"
                },
                [22] = {
                    label = "Mask (106-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_22"
                },
                [23] = {
                    label = "Mask (106-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_23"
                },
                [24] = {
                    label = "Red Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_24"
                },
                [25] = {
                    label = "White Snake Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_106_25"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_0"
                },
                [1] = {
                    label = "Brown Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_1"
                },
                [2] = {
                    label = "Green Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_2"
                },
                [3] = {
                    label = "Gray Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_3"
                },
                [4] = {
                    label = "Peach Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_4"
                },
                [5] = {
                    label = "Fall Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_5"
                },
                [6] = {
                    label = "Dark Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_6"
                },
                [7] = {
                    label = "Crosshatch Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_7"
                },
                [8] = {
                    label = "Moss Digital Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_8"
                },
                [9] = {
                    label = "Gray Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_9"
                },
                [10] = {
                    label = "Aqua Camo Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_10"
                },
                [11] = {
                    label = "Splinter Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_11"
                },
                [12] = {
                    label = "Contrast Camo Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_12"
                },
                [13] = {
                    label = "Cobble Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_13"
                },
                [14] = {
                    label = "Peach Camo Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_14"
                },
                [15] = {
                    label = "Brushstroke Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_15"
                },
                [16] = {
                    label = "Flecktarn Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_16"
                },
                [17] = {
                    label = "Light Woodland Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_17"
                },
                [18] = {
                    label = "Moss Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_18"
                },
                [19] = {
                    label = "Sand Vent",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_19"
                },
                [20] = {
                    label = "Mask (107-20)",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_20"
                },
                [21] = {
                    label = "Mask (107-21)",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_21"
                },
                [22] = {
                    label = "Mask (107-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_22"
                },
                [23] = {
                    label = "Mask (107-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_107_23"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Clean Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_0"
                },
                [1] = {
                    label = "Weathered Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_1"
                },
                [2] = {
                    label = "Aged Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_2"
                },
                [3] = {
                    label = "Venom Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_3"
                },
                [4] = {
                    label = "Fresh Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_4"
                },
                [5] = {
                    label = "Fleshy Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_5"
                },
                [6] = {
                    label = "Moss Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_6"
                },
                [7] = {
                    label = "Sand Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_7"
                },
                [8] = {
                    label = "Inked Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_8"
                },
                [9] = {
                    label = "Stained Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_9"
                },
                [10] = {
                    label = "Tan Leather Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_10"
                },
                [11] = {
                    label = "Chocolate Leather Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_11"
                },
                [12] = {
                    label = "Orange Open-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_12"
                },
                [13] = {
                    label = "Possessed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_13"
                },
                [14] = {
                    label = "Wide-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_14"
                },
                [15] = {
                    label = "Tattooed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_15"
                },
                [16] = {
                    label = "Blue Painted Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_16"
                },
                [17] = {
                    label = "Pink Painted Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_17"
                },
                [18] = {
                    label = "Green Painted Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_18"
                },
                [19] = {
                    label = "Mustard Painted Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_19"
                },
                [20] = {
                    label = "Orange Swirl-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_20"
                },
                [21] = {
                    label = "Leather Solar-Eyed Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_21"
                },
                [22] = {
                    label = "Terracotta Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_22"
                },
                [23] = {
                    label = "Striped Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_108_23"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (109-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_0"
                },
                [1] = {
                    label = "Mask (109-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_1"
                },
                [2] = {
                    label = "Mask (109-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_2"
                },
                [3] = {
                    label = "Mask (109-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_3"
                },
                [4] = {
                    label = "Black Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_4"
                },
                [5] = {
                    label = "Tan Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_5"
                },
                [6] = {
                    label = "Green Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_6"
                },
                [7] = {
                    label = "Olive Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_7"
                },
                [8] = {
                    label = "Light Woodland Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_8"
                },
                [9] = {
                    label = "Aqua Camo Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_9"
                },
                [10] = {
                    label = "Splinter Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_10"
                },
                [11] = {
                    label = "Brown Digital Flight Cap",
                    price = 500,
                    type = "money",
                    image = "male_mask_109_11"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_0"
                },
                [1] = {
                    label = "Blue Digital Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_1"
                },
                [2] = {
                    label = "Brown Digital Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_2"
                },
                [3] = {
                    label = "Green Digital Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_3"
                },
                [4] = {
                    label = "Fall Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_4"
                },
                [5] = {
                    label = "Dark Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_5"
                },
                [6] = {
                    label = "Crosshatch Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_6"
                },
                [7] = {
                    label = "Gray Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_7"
                },
                [8] = {
                    label = "Aqua Camo Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_8"
                },
                [9] = {
                    label = "Splinter Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_9"
                },
                [10] = {
                    label = "Contrast Camo Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_10"
                },
                [11] = {
                    label = "Cobble Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_11"
                },
                [12] = {
                    label = "Peach Camo Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_12"
                },
                [13] = {
                    label = "Brushstroke Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_13"
                },
                [14] = {
                    label = "Flecktarn Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_14"
                },
                [15] = {
                    label = "Light Woodland Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_15"
                },
                [16] = {
                    label = "Blue Striped Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_16"
                },
                [17] = {
                    label = "Moss Striped Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_17"
                },
                [18] = {
                    label = "Orange Striped Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_18"
                },
                [19] = {
                    label = "Yellow Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_19"
                },
                [20] = {
                    label = "Zebra Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_20"
                },
                [21] = {
                    label = "White Robo",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_21"
                },
                [22] = {
                    label = "Mask (110-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_22"
                },
                [23] = {
                    label = "Mask (110-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_23"
                },
                [24] = {
                    label = "Mask (110-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_24"
                },
                [25] = {
                    label = "Mask (110-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_110_25"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (111-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_0"
                },
                [1] = {
                    label = "Mask (111-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_1"
                },
                [2] = {
                    label = "Mask (111-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_2"
                },
                [3] = {
                    label = "Mask (111-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_3"
                },
                [4] = {
                    label = "Blue Blagueurs Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_4"
                },
                [5] = {
                    label = "Red Blagueurs Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_5"
                },
                [6] = {
                    label = "Bold Abstract Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_6"
                },
                [7] = {
                    label = "Geometric Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_7"
                },
                [8] = {
                    label = "Splinter Bigness Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_8"
                },
                [9] = {
                    label = "Red Bigness Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_9"
                },
                [10] = {
                    label = "Green Leaves Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_10"
                },
                [11] = {
                    label = "Blue Leaves Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_11"
                },
                [12] = {
                    label = "Red Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_12"
                },
                [13] = {
                    label = "Black Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_13"
                },
                [14] = {
                    label = "Skulls Manor Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_14"
                },
                [15] = {
                    label = "White Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_15"
                },
                [16] = {
                    label = "Orange Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_16"
                },
                [17] = {
                    label = "Black Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_17"
                },
                [18] = {
                    label = "Off-White Broker Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_18"
                },
                [19] = {
                    label = "Stars & Stripes Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_19"
                },
                [20] = {
                    label = "Painted Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_20"
                },
                [21] = {
                    label = "Fractal Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_21"
                },
                [22] = {
                    label = "Contrast Camo Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_22"
                },
                [23] = {
                    label = "Zebra Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_23"
                },
                [24] = {
                    label = "Dark Pattern Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_24"
                },
                [25] = {
                    label = "Bright Pattern Face Bandana",
                    price = 500,
                    type = "money",
                    image = "male_mask_111_25"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_0"
                },
                [1] = {
                    label = "Blue Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_1"
                },
                [2] = {
                    label = "Brown Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_2"
                },
                [3] = {
                    label = "Green Digital Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_3"
                },
                [4] = {
                    label = "Fall Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_4"
                },
                [5] = {
                    label = "Dark Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_5"
                },
                [6] = {
                    label = "Crosshatch Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_6"
                },
                [7] = {
                    label = "Gray Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_7"
                },
                [8] = {
                    label = "Aqua Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_8"
                },
                [9] = {
                    label = "Splinter Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_9"
                },
                [10] = {
                    label = "Contrast Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_10"
                },
                [11] = {
                    label = "Cobble Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_11"
                },
                [12] = {
                    label = "Peach Camo Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_12"
                },
                [13] = {
                    label = "Brushstroke Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_13"
                },
                [14] = {
                    label = "Flecktarn Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_14"
                },
                [15] = {
                    label = "Light Woodland Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_15"
                },
                [16] = {
                    label = "Blue Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_16"
                },
                [17] = {
                    label = "Moss Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_17"
                },
                [18] = {
                    label = "Orange Striped Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_18"
                },
                [19] = {
                    label = "Yellow Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_19"
                },
                [20] = {
                    label = "Zebra Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_20"
                },
                [21] = {
                    label = "White Mandible",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_21"
                },
                [22] = {
                    label = "Mask (112-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_22"
                },
                [23] = {
                    label = "Mask (112-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_23"
                },
                [24] = {
                    label = "Mask (112-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_24"
                },
                [25] = {
                    label = "Mask (112-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_112_25"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skate Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_0"
                },
                [1] = {
                    label = "Multicolor Leaves Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_1"
                },
                [2] = {
                    label = "Lime Xero Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_2"
                },
                [3] = {
                    label = "Tropical Xero Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_3"
                },
                [4] = {
                    label = "Red Stripe Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_4"
                },
                [5] = {
                    label = "Gray Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_5"
                },
                [6] = {
                    label = "Orange & Red Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_6"
                },
                [7] = {
                    label = "Vibrant Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_7"
                },
                [8] = {
                    label = "Blue Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_8"
                },
                [9] = {
                    label = "Mustard Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_9"
                },
                [10] = {
                    label = "Stars & Stripes Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_10"
                },
                [11] = {
                    label = "Black Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_11"
                },
                [12] = {
                    label = "White Skull Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_12"
                },
                [13] = {
                    label = "Mask (113-13)",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_13"
                },
                [14] = {
                    label = "Mask (113-14)",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_14"
                },
                [15] = {
                    label = "Mask (113-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_15"
                },
                [16] = {
                    label = "Mask (113-16)",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_16"
                },
                [17] = {
                    label = "SA Republic Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_17"
                },
                [18] = {
                    label = "Black Stars & Stripes Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_18"
                },
                [19] = {
                    label = "Black & Red Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_19"
                },
                [20] = {
                    label = "Bold Abstract Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_20"
                },
                [21] = {
                    label = "Camo Bigness Tight Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_113_21"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_0"
                },
                [1] = {
                    label = "Teal Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_1"
                },
                [2] = {
                    label = "Green Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_2"
                },
                [3] = {
                    label = "Yellow Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_3"
                },
                [4] = {
                    label = "Turquoise Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_4"
                },
                [5] = {
                    label = "Brown Digital Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_5"
                },
                [6] = {
                    label = "Yellow Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_6"
                },
                [7] = {
                    label = "Dark Red Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_7"
                },
                [8] = {
                    label = "Peach Digital Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_8"
                },
                [9] = {
                    label = "Fall Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_9"
                },
                [10] = {
                    label = "Dark Woodland Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_10"
                },
                [11] = {
                    label = "Orange Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_11"
                },
                [12] = {
                    label = "Red Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_12"
                },
                [13] = {
                    label = "Gray Woodland Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_13"
                },
                [14] = {
                    label = "Blue Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_14"
                },
                [15] = {
                    label = "Splinter Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_15"
                },
                [16] = {
                    label = "Purple Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_16"
                },
                [17] = {
                    label = "Jolly Roger Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_17"
                },
                [18] = {
                    label = "Peach Camo Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_18"
                },
                [19] = {
                    label = "Brushstroke Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_19"
                },
                [20] = {
                    label = "Flecktarn Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_20"
                },
                [21] = {
                    label = "Weapon Pattern Loose",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_21"
                },
                [22] = {
                    label = "Mask (114-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_22"
                },
                [23] = {
                    label = "Mask (114-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_23"
                },
                [24] = {
                    label = "Mask (114-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_24"
                },
                [25] = {
                    label = "Mask (114-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_114_25"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_0"
                },
                [1] = {
                    label = "Teal Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_1"
                },
                [2] = {
                    label = "Green Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_2"
                },
                [3] = {
                    label = "Yellow Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_3"
                },
                [4] = {
                    label = "Turquoise Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_4"
                },
                [5] = {
                    label = "Brown Digital Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_5"
                },
                [6] = {
                    label = "Red Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_6"
                },
                [7] = {
                    label = "Jolly Roger Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_7"
                },
                [8] = {
                    label = "Peach Digital Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_8"
                },
                [9] = {
                    label = "Fall Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_9"
                },
                [10] = {
                    label = "Dark Woodland Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_10"
                },
                [11] = {
                    label = "Weapon Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_11"
                },
                [12] = {
                    label = "Blue Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_12"
                },
                [13] = {
                    label = "Gray Woodland Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_13"
                },
                [14] = {
                    label = "Dark Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_14"
                },
                [15] = {
                    label = "Splinter Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_15"
                },
                [16] = {
                    label = "Dark Red Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_16"
                },
                [17] = {
                    label = "Orange Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_17"
                },
                [18] = {
                    label = "Peach Camo Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_18"
                },
                [19] = {
                    label = "Brushstroke Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_19"
                },
                [20] = {
                    label = "Flecktarn Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_20"
                },
                [21] = {
                    label = "Purple Pattern Wrapped",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_21"
                },
                [22] = {
                    label = "Mask (115-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_22"
                },
                [23] = {
                    label = "Mask (115-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_23"
                },
                [24] = {
                    label = "Mask (115-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_24"
                },
                [25] = {
                    label = "Mask (115-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_115_25"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_0"
                },
                [1] = {
                    label = "Teal Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_1"
                },
                [2] = {
                    label = "Green Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_2"
                },
                [3] = {
                    label = "Yellow Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_3"
                },
                [4] = {
                    label = "Turquoise Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_4"
                },
                [5] = {
                    label = "Brown Digital Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_5"
                },
                [6] = {
                    label = "Dark Red Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_6"
                },
                [7] = {
                    label = "Orange Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_7"
                },
                [8] = {
                    label = "Peach Digital Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_8"
                },
                [9] = {
                    label = "Fall Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_9"
                },
                [10] = {
                    label = "Dark Woodland Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_10"
                },
                [11] = {
                    label = "Blue Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_11"
                },
                [12] = {
                    label = "Purple Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_12"
                },
                [13] = {
                    label = "Gray Woodland Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_13"
                },
                [14] = {
                    label = "Yellow Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_14"
                },
                [15] = {
                    label = "Splinter Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_15"
                },
                [16] = {
                    label = "Red Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_16"
                },
                [17] = {
                    label = "Weapon Pattern Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_17"
                },
                [18] = {
                    label = "Peach Camo Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_18"
                },
                [19] = {
                    label = "Brushstroke Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_19"
                },
                [20] = {
                    label = "Flecktarn Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_20"
                },
                [21] = {
                    label = "Jolly Roger Snood",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_21"
                },
                [22] = {
                    label = "Mask (116-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_22"
                },
                [23] = {
                    label = "Mask (116-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_23"
                },
                [24] = {
                    label = "Mask (116-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_24"
                },
                [25] = {
                    label = "Mask (116-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_116_25"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bright Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_0"
                },
                [1] = {
                    label = "Dark Red Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_1"
                },
                [2] = {
                    label = "Green & Beige Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_2"
                },
                [3] = {
                    label = "Sunrise Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_3"
                },
                [4] = {
                    label = "Gray Digital Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_4"
                },
                [5] = {
                    label = "Gray Woodland Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_5"
                },
                [6] = {
                    label = "Brown Digital Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_6"
                },
                [7] = {
                    label = "Red Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_7"
                },
                [8] = {
                    label = "Skull Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_8"
                },
                [9] = {
                    label = "Wine Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_9"
                },
                [10] = {
                    label = "Bright Green Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_10"
                },
                [11] = {
                    label = "Aqua Camo Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_11"
                },
                [12] = {
                    label = "Primary Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_12"
                },
                [13] = {
                    label = "Black & Red Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_13"
                },
                [14] = {
                    label = "Green Stripe Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_14"
                },
                [15] = {
                    label = "Tiger Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_15"
                },
                [16] = {
                    label = "Leopard Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_16"
                },
                [17] = {
                    label = "Dark Pattern Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_17"
                },
                [18] = {
                    label = "Stars & Stripes Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_18"
                },
                [19] = {
                    label = "Blue Luchador Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_19"
                },
                [20] = {
                    label = "Green Luchador Knit",
                    price = 500,
                    type = "money",
                    image = "male_mask_117_20"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (118-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_0"
                },
                [1] = {
                    label = "Mask (118-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_1"
                },
                [2] = {
                    label = "Mask (118-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_2"
                },
                [3] = {
                    label = "Mask (118-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_3"
                },
                [4] = {
                    label = "Magenta Leopard T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_4"
                },
                [5] = {
                    label = "Navy Painted T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_5"
                },
                [6] = {
                    label = "Multicolor Leaves T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_6"
                },
                [7] = {
                    label = "Gray Digital T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_7"
                },
                [8] = {
                    label = "Aqua Camo T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_8"
                },
                [9] = {
                    label = "Red Camo T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_9"
                },
                [10] = {
                    label = "Camo Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_10"
                },
                [11] = {
                    label = "Black Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_11"
                },
                [12] = {
                    label = "Red Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_12"
                },
                [13] = {
                    label = "Gray Bigness T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_13"
                },
                [14] = {
                    label = "Primary T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_14"
                },
                [15] = {
                    label = "OJ Squash T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_15"
                },
                [16] = {
                    label = "Green & Pink T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_16"
                },
                [17] = {
                    label = "Stars & Stripes T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_17"
                },
                [18] = {
                    label = "Black Stars & Stripes T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_18"
                },
                [19] = {
                    label = "SA Republic T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_19"
                },
                [20] = {
                    label = "Aqua Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_20"
                },
                [21] = {
                    label = "Far Out Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_21"
                },
                [22] = {
                    label = "Pink Tie Dye T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_22"
                },
                [23] = {
                    label = "Orange Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_23"
                },
                [24] = {
                    label = "Green Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_24"
                },
                [25] = {
                    label = "Pink Pattern T-Shirt",
                    price = 500,
                    type = "money",
                    image = "male_mask_118_25"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_0"
                },
                [1] = {
                    label = "Ash Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_1"
                },
                [2] = {
                    label = "Charcoal Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_2"
                },
                [3] = {
                    label = "Chocolate Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_3"
                },
                [4] = {
                    label = "Blue Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_4"
                },
                [5] = {
                    label = "Hessian Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_5"
                },
                [6] = {
                    label = "Dark Red Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_6"
                },
                [7] = {
                    label = "Mask (119-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_7"
                },
                [8] = {
                    label = "Mask (119-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_8"
                },
                [9] = {
                    label = "Mask (119-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_9"
                },
                [10] = {
                    label = "Mask (119-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_10"
                },
                [11] = {
                    label = "Bright Green Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_11"
                },
                [12] = {
                    label = "Beige Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_12"
                },
                [13] = {
                    label = "Rasta Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_13"
                },
                [14] = {
                    label = "Triplet Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_14"
                },
                [15] = {
                    label = "Orange Stripe Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_15"
                },
                [16] = {
                    label = "Magenta Leopard Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_16"
                },
                [17] = {
                    label = "Vibrant Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_17"
                },
                [18] = {
                    label = "Skate Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_18"
                },
                [19] = {
                    label = "Pink Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_19"
                },
                [20] = {
                    label = "Aqua Camo Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_20"
                },
                [21] = {
                    label = "Gray Digital Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_21"
                },
                [22] = {
                    label = "Gray Woodland Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_22"
                },
                [23] = {
                    label = "Pretty Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_23"
                },
                [24] = {
                    label = "Dark Neon Scruffy",
                    price = 500,
                    type = "money",
                    image = "male_mask_119_24"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (120-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_120_0"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (121-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_121_0"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (122-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_122_0"
                },
                [1] = {
                    label = "Mask (122-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_122_1"
                },
                [2] = {
                    label = "Mask (122-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_122_2"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (123-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_0"
                },
                [1] = {
                    label = "Mask (123-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_1"
                },
                [2] = {
                    label = "Mask (123-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_2"
                },
                [3] = {
                    label = "Mask (123-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_3"
                },
                [4] = {
                    label = "Mask (123-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_4"
                },
                [5] = {
                    label = "Mask (123-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_5"
                },
                [6] = {
                    label = "Mask (123-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_6"
                },
                [7] = {
                    label = "Mask (123-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_7"
                },
                [8] = {
                    label = "Mask (123-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_8"
                },
                [9] = {
                    label = "Mask (123-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_9"
                },
                [10] = {
                    label = "Mask (123-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_10"
                },
                [11] = {
                    label = "Mask (123-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_123_11"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Manic Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_0"
                },
                [1] = {
                    label = "Manic Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_1"
                },
                [2] = {
                    label = "Manic Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_2"
                },
                [3] = {
                    label = "Amused Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_3"
                },
                [4] = {
                    label = "Amused Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_4"
                },
                [5] = {
                    label = "Amused Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_5"
                },
                [6] = {
                    label = "Furious Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_6"
                },
                [7] = {
                    label = "Furious Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_7"
                },
                [8] = {
                    label = "Furious Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_8"
                },
                [9] = {
                    label = "Pleased Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_9"
                },
                [10] = {
                    label = "Pleased Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_10"
                },
                [11] = {
                    label = "Pleased Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_11"
                },
                [12] = {
                    label = "Peaceful Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_12"
                },
                [13] = {
                    label = "Peaceful Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_13"
                },
                [14] = {
                    label = "Peaceful Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_14"
                },
                [15] = {
                    label = "Transcendent Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_15"
                },
                [16] = {
                    label = "Transcendent Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_16"
                },
                [17] = {
                    label = "Transcendent Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_17"
                },
                [18] = {
                    label = "Tribal Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_18"
                },
                [19] = {
                    label = "Tribal Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_19"
                },
                [20] = {
                    label = "Tribal Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_20"
                },
                [21] = {
                    label = "Iwazaru Luminous",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_21"
                },
                [22] = {
                    label = "Iwazaru Electric",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_22"
                },
                [23] = {
                    label = "Iwazaru Neon",
                    price = 500,
                    type = "money",
                    image = "male_mask_124_23"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_0"
                },
                [1] = {
                    label = "Gray Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_1"
                },
                [2] = {
                    label = "White Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_2"
                },
                [3] = {
                    label = "Sand Mono Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_3"
                },
                [4] = {
                    label = "Mask (125-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_4"
                },
                [5] = {
                    label = "Mask (125-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_5"
                },
                [6] = {
                    label = "Mask (125-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_6"
                },
                [7] = {
                    label = "Mask (125-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_7"
                },
                [8] = {
                    label = "Sand Goggled Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_8"
                },
                [9] = {
                    label = "Red Goggled Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_9"
                },
                [10] = {
                    label = "Black Carbon Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_10"
                },
                [11] = {
                    label = "Sand Carbon Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_11"
                },
                [12] = {
                    label = "Cranial Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_12"
                },
                [13] = {
                    label = "Flecktarn Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_13"
                },
                [14] = {
                    label = "Splinter Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_14"
                },
                [15] = {
                    label = "Red & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_15"
                },
                [16] = {
                    label = "Blue & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_16"
                },
                [17] = {
                    label = "Yellow & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_17"
                },
                [18] = {
                    label = "Orange & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_18"
                },
                [19] = {
                    label = "White & Black Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_19"
                },
                [20] = {
                    label = "Red Stripe Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_20"
                },
                [21] = {
                    label = "Black Stripe Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_21"
                },
                [22] = {
                    label = "Off White & Red Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_22"
                },
                [23] = {
                    label = "Red Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_23"
                },
                [24] = {
                    label = "Brown Digital Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_24"
                },
                [25] = {
                    label = "Fall Ballistic",
                    price = 500,
                    type = "money",
                    image = "male_mask_125_25"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_0"
                },
                [1] = {
                    label = "Carbon Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_1"
                },
                [2] = {
                    label = "Scale Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_2"
                },
                [3] = {
                    label = "Tan Digital Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_3"
                },
                [4] = {
                    label = "Aqua Camo Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_4"
                },
                [5] = {
                    label = "Splinter Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_5"
                },
                [6] = {
                    label = "Mono Splinter Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_6"
                },
                [7] = {
                    label = "Gray Woodland Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_7"
                },
                [8] = {
                    label = "Dark Woodland Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_8"
                },
                [9] = {
                    label = "Electric Skull Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_9"
                },
                [10] = {
                    label = "LSPD Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_10"
                },
                [11] = {
                    label = "Ornate Skull Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_11"
                },
                [12] = {
                    label = "Striped Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_12"
                },
                [13] = {
                    label = "Opera Spec Ops",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_13"
                },
                [14] = {
                    label = "Mask (126-14)",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_14"
                },
                [15] = {
                    label = "Mask (126-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_15"
                },
                [16] = {
                    label = "Mask (126-16)",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_16"
                },
                [17] = {
                    label = "Mask (126-17)",
                    price = 500,
                    type = "money",
                    image = "male_mask_126_17"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Festive Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_127_0"
                },
                [1] = {
                    label = "Merry Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_127_1"
                },
                [2] = {
                    label = "Jovial Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_127_2"
                },
                [3] = {
                    label = "Mirthful Gingerbread Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_127_3"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_0"
                },
                [1] = {
                    label = "Aqua Camo False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_1"
                },
                [2] = {
                    label = "Headline False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_2"
                },
                [3] = {
                    label = "Splinter False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_3"
                },
                [4] = {
                    label = "Brown Digital False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_4"
                },
                [5] = {
                    label = "Striped Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_5"
                },
                [6] = {
                    label = "Cobble Woodland False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_6"
                },
                [7] = {
                    label = "Rising Sun False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_7"
                },
                [8] = {
                    label = "Opera False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_8"
                },
                [9] = {
                    label = "Stars & Stripes False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_9"
                },
                [10] = {
                    label = "Green Pattern False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_10"
                },
                [11] = {
                    label = "Gothic False Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_11"
                },
                [12] = {
                    label = "Mask (128-12)",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_12"
                },
                [13] = {
                    label = "Mask (128-13)",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_13"
                },
                [14] = {
                    label = "Mask (128-14)",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_14"
                },
                [15] = {
                    label = "Mask (128-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_128_15"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_0"
                },
                [1] = {
                    label = "Carbon Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_1"
                },
                [2] = {
                    label = "Tan Digital Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_2"
                },
                [3] = {
                    label = "Aqua Camo Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_3"
                },
                [4] = {
                    label = "Splinter Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_4"
                },
                [5] = {
                    label = "Gray Splinter Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_5"
                },
                [6] = {
                    label = "Gray Striped Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_6"
                },
                [7] = {
                    label = "Moss Striped Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_7"
                },
                [8] = {
                    label = "Peach Camo Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_8"
                },
                [9] = {
                    label = "Woodland Digital Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_9"
                },
                [10] = {
                    label = "Skull Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_10"
                },
                [11] = {
                    label = "White Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_11"
                },
                [12] = {
                    label = "Yellow Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_12"
                },
                [13] = {
                    label = "Orange Industrial Gas Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_13"
                },
                [14] = {
                    label = "Mask (129-14)",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_14"
                },
                [15] = {
                    label = "Mask (129-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_15"
                },
                [16] = {
                    label = "Mask (129-16)",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_16"
                },
                [17] = {
                    label = "Mask (129-17)",
                    price = 500,
                    type = "money",
                    image = "male_mask_129_17"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_0"
                },
                [1] = {
                    label = "Flecktarn Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_1"
                },
                [2] = {
                    label = "Gray Digital Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_2"
                },
                [3] = {
                    label = "Aqua Camo Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_3"
                },
                [4] = {
                    label = "Splinter Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_4"
                },
                [5] = {
                    label = "Gray Splinter Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_5"
                },
                [6] = {
                    label = "Tiger Striped Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_6"
                },
                [7] = {
                    label = "Moss Striped Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_7"
                },
                [8] = {
                    label = "Green Digital Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_8"
                },
                [9] = {
                    label = "Brushstroke Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_9"
                },
                [10] = {
                    label = "Gray Woodland Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_10"
                },
                [11] = {
                    label = "Cobble Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_11"
                },
                [12] = {
                    label = "Contrast Camo Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_12"
                },
                [13] = {
                    label = "Viper Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_13"
                },
                [14] = {
                    label = "Crosshatch Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_14"
                },
                [15] = {
                    label = "Mask (130-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_15"
                },
                [16] = {
                    label = "Mask (130-16)",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_16"
                },
                [17] = {
                    label = "Mask (130-17)",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_17"
                },
                [18] = {
                    label = "Mask (130-18)",
                    price = 500,
                    type = "money",
                    image = "male_mask_130_18"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Hideous Krampus",
                    price = 500,
                    type = "money",
                    image = "male_mask_131_0"
                },
                [1] = {
                    label = "Fearsome Krampus",
                    price = 500,
                    type = "money",
                    image = "male_mask_131_1"
                },
                [2] = {
                    label = "Odious Krampus",
                    price = 500,
                    type = "money",
                    image = "male_mask_131_2"
                },
                [3] = {
                    label = "Heinous Krampus",
                    price = 500,
                    type = "money",
                    image = "male_mask_131_3"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_0"
                },
                [1] = {
                    label = "White Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_1"
                },
                [2] = {
                    label = "Gray Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_2"
                },
                [3] = {
                    label = "Blue Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_3"
                },
                [4] = {
                    label = "Tan Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_4"
                },
                [5] = {
                    label = "Moss Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_5"
                },
                [6] = {
                    label = "Brown Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_6"
                },
                [7] = {
                    label = "Aqua Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_7"
                },
                [8] = {
                    label = "Gray Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_8"
                },
                [9] = {
                    label = "White Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_9"
                },
                [10] = {
                    label = "Green Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_10"
                },
                [11] = {
                    label = "Splinter Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_11"
                },
                [12] = {
                    label = "Dazzle Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_12"
                },
                [13] = {
                    label = "Brown Digital Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_13"
                },
                [14] = {
                    label = "Woodland Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_14"
                },
                [15] = {
                    label = "Gray Woodland Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_15"
                },
                [16] = {
                    label = "Crosshatch Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_16"
                },
                [17] = {
                    label = "Contrast Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_17"
                },
                [18] = {
                    label = "Cobble Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_18"
                },
                [19] = {
                    label = "Moss Striped Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_19"
                },
                [20] = {
                    label = "White Camo Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_20"
                },
                [21] = {
                    label = "Skull Night Vision",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_21"
                },
                [22] = {
                    label = "Mask (132-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_22"
                },
                [23] = {
                    label = "Mask (132-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_23"
                },
                [24] = {
                    label = "Mask (132-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_24"
                },
                [25] = {
                    label = "Mask (132-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_132_25"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_0"
                },
                [1] = {
                    label = "Blue Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_1"
                },
                [2] = {
                    label = "Light Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_2"
                },
                [3] = {
                    label = "Purple Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_3"
                },
                [4] = {
                    label = "Dark Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_4"
                },
                [5] = {
                    label = "Light Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_5"
                },
                [6] = {
                    label = "Purple Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_6"
                },
                [7] = {
                    label = "Woodland Camo Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_7"
                },
                [8] = {
                    label = "Abstract Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_8"
                },
                [9] = {
                    label = "Geometric Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_9"
                },
                [10] = {
                    label = "Blue Digital Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_10"
                },
                [11] = {
                    label = "Gray Digital Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_11"
                },
                [12] = {
                    label = "Zebra Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_12"
                },
                [13] = {
                    label = "Harlequin Bigness SN Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_13"
                },
                [14] = {
                    label = "Wild Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_14"
                },
                [15] = {
                    label = "Fall Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_15"
                },
                [16] = {
                    label = "Orange Fall Hockey",
                    price = 500,
                    type = "money",
                    image = "male_mask_133_16"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (134-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_0"
                },
                [1] = {
                    label = "Mask (134-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_1"
                },
                [2] = {
                    label = "Mask (134-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_2"
                },
                [3] = {
                    label = "Mask (134-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_3"
                },
                [4] = {
                    label = "Mask (134-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_4"
                },
                [5] = {
                    label = "Mask (134-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_5"
                },
                [6] = {
                    label = "Mask (134-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_6"
                },
                [7] = {
                    label = "Mask (134-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_7"
                },
                [8] = {
                    label = "Mask (134-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_8"
                },
                [9] = {
                    label = "Mask (134-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_9"
                },
                [10] = {
                    label = "Mask (134-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_10"
                },
                [11] = {
                    label = "Mask (134-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_11"
                },
                [12] = {
                    label = "Mask (134-12)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_12"
                },
                [13] = {
                    label = "Mask (134-13)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_13"
                },
                [14] = {
                    label = "Mask (134-14)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_14"
                },
                [15] = {
                    label = "Mask (134-15)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_15"
                },
                [16] = {
                    label = "Mask (134-16)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_16"
                },
                [17] = {
                    label = "Mask (134-17)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_17"
                },
                [18] = {
                    label = "Mask (134-18)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_18"
                },
                [19] = {
                    label = "Mask (134-19)",
                    price = 500,
                    type = "money",
                    image = "male_mask_134_19"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (135-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_0"
                },
                [1] = {
                    label = "Mask (135-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_1"
                },
                [2] = {
                    label = "Mask (135-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_2"
                },
                [3] = {
                    label = "Mask (135-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_3"
                },
                [4] = {
                    label = "Mask (135-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_4"
                },
                [5] = {
                    label = "Mask (135-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_5"
                },
                [6] = {
                    label = "Mask (135-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_6"
                },
                [7] = {
                    label = "Mask (135-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_7"
                },
                [8] = {
                    label = "Mask (135-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_8"
                },
                [9] = {
                    label = "Mask (135-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_9"
                },
                [10] = {
                    label = "Mask (135-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_10"
                },
                [11] = {
                    label = "Mask (135-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_11"
                },
                [12] = {
                    label = "Mask (135-12)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_12"
                },
                [13] = {
                    label = "Mask (135-13)",
                    price = 500,
                    type = "money",
                    image = "male_mask_135_13"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Brown Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_0"
                },
                [1] = {
                    label = "White Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_1"
                },
                [2] = {
                    label = "Black Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_2"
                },
                [3] = {
                    label = "Red Cross Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_3"
                },
                [4] = {
                    label = "Green Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_4"
                },
                [5] = {
                    label = "Blue Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_5"
                },
                [6] = {
                    label = "Beige Camo Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_6"
                },
                [7] = {
                    label = "Crosshatch Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_7"
                },
                [8] = {
                    label = "Splinter Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_8"
                },
                [9] = {
                    label = "Red Feather Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_9"
                },
                [10] = {
                    label = "Black & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_10"
                },
                [11] = {
                    label = "Ash Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_11"
                },
                [12] = {
                    label = "Black & Yellow Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_12"
                },
                [13] = {
                    label = "Red & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_13"
                },
                [14] = {
                    label = "Brown & White Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_14"
                },
                [15] = {
                    label = "Brown & Yellow Death Bird",
                    price = 500,
                    type = "money",
                    image = "male_mask_136_15"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_0"
                },
                [1] = {
                    label = "Brown Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_1"
                },
                [2] = {
                    label = "Purple Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_2"
                },
                [3] = {
                    label = "Red Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_3"
                },
                [4] = {
                    label = "Black Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_4"
                },
                [5] = {
                    label = "Stars Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_5"
                },
                [6] = {
                    label = "Brown Camo Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_6"
                },
                [7] = {
                    label = "Green Camo Stalker",
                    price = 500,
                    type = "money",
                    image = "male_mask_137_7"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_0"
                },
                [1] = {
                    label = "Chocolate Brown Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_1"
                },
                [2] = {
                    label = "Brown Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_2"
                },
                [3] = {
                    label = "Red Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_3"
                },
                [4] = {
                    label = "Beige Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_4"
                },
                [5] = {
                    label = "Bright Orange Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_5"
                },
                [6] = {
                    label = "Blue Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_6"
                },
                [7] = {
                    label = "Gray Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_7"
                },
                [8] = {
                    label = "Green Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_8"
                },
                [9] = {
                    label = "Brown Camo Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_9"
                },
                [10] = {
                    label = "Red & Gray Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_10"
                },
                [11] = {
                    label = "Orange & Gray Raider",
                    price = 500,
                    type = "money",
                    image = "male_mask_138_11"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (139-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_0"
                },
                [1] = {
                    label = "Mask (139-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_1"
                },
                [2] = {
                    label = "Mask (139-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_2"
                },
                [3] = {
                    label = "Mask (139-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_3"
                },
                [4] = {
                    label = "Mask (139-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_4"
                },
                [5] = {
                    label = "Mask (139-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_5"
                },
                [6] = {
                    label = "Mask (139-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_6"
                },
                [7] = {
                    label = "Mask (139-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_7"
                },
                [8] = {
                    label = "Mask (139-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_8"
                },
                [9] = {
                    label = "Mask (139-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_9"
                },
                [10] = {
                    label = "Mask (139-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_10"
                },
                [11] = {
                    label = "Mask (139-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_139_11"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (140-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_0"
                },
                [1] = {
                    label = "Mask (140-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_1"
                },
                [2] = {
                    label = "Mask (140-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_2"
                },
                [3] = {
                    label = "Mask (140-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_3"
                },
                [4] = {
                    label = "Mask (140-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_4"
                },
                [5] = {
                    label = "Mask (140-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_5"
                },
                [6] = {
                    label = "Mask (140-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_6"
                },
                [7] = {
                    label = "Mask (140-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_7"
                },
                [8] = {
                    label = "Mask (140-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_8"
                },
                [9] = {
                    label = "Mask (140-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_9"
                },
                [10] = {
                    label = "Mask (140-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_10"
                },
                [11] = {
                    label = "Mask (140-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_140_11"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (141-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_0"
                },
                [1] = {
                    label = "Mask (141-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_1"
                },
                [2] = {
                    label = "Mask (141-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_2"
                },
                [3] = {
                    label = "Mask (141-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_3"
                },
                [4] = {
                    label = "Mask (141-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_4"
                },
                [5] = {
                    label = "Mask (141-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_5"
                },
                [6] = {
                    label = "Mask (141-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_6"
                },
                [7] = {
                    label = "Mask (141-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_7"
                },
                [8] = {
                    label = "Mask (141-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_8"
                },
                [9] = {
                    label = "Mask (141-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_9"
                },
                [10] = {
                    label = "Mask (141-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_10"
                },
                [11] = {
                    label = "Mask (141-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_141_11"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Brown Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_0"
                },
                [1] = {
                    label = "Radioactive Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_1"
                },
                [2] = {
                    label = "Bolt Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_2"
                },
                [3] = {
                    label = "Branded Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_3"
                },
                [4] = {
                    label = "Crossbones Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_4"
                },
                [5] = {
                    label = "Red Stripe Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_5"
                },
                [6] = {
                    label = "Yellow Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_6"
                },
                [7] = {
                    label = "Eight-ball Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_7"
                },
                [8] = {
                    label = "Black Arrow Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_8"
                },
                [9] = {
                    label = "Shooting Stars Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_9"
                },
                [10] = {
                    label = "Beige Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_10"
                },
                [11] = {
                    label = "Black Marauder",
                    price = 500,
                    type = "money",
                    image = "male_mask_142_11"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Paco the Taco Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_143_0"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Burger Shot Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_144_0"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_145_0"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_0"
                },
                [1] = {
                    label = "White Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_1"
                },
                [2] = {
                    label = "Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_2"
                },
                [3] = {
                    label = "Red Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_3"
                },
                [4] = {
                    label = "Green Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_4"
                },
                [5] = {
                    label = "Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_5"
                },
                [6] = {
                    label = "Pink Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_6"
                },
                [7] = {
                    label = "Orange Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_7"
                },
                [8] = {
                    label = "Purple Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_8"
                },
                [9] = {
                    label = "Gray & Red Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_9"
                },
                [10] = {
                    label = "Black & Green Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_10"
                },
                [11] = {
                    label = "Beige & Orange Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_11"
                },
                [12] = {
                    label = "Orange & Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_12"
                },
                [13] = {
                    label = "White & Blue Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_13"
                },
                [14] = {
                    label = "Purple & Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_14"
                },
                [15] = {
                    label = "Red & Black Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_15"
                },
                [16] = {
                    label = "Green & Yellow Optics Headset",
                    price = 500,
                    type = "money",
                    image = "male_mask_146_16"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (147-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_147_0"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Impotent Rage Eye Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_148_0"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Strawberry Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_149_0"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Lemon Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_150_0"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grapes Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_151_0"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pineapple Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cherries Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_153_0"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Lucky Seven Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_154_0"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Joker",
                    price = 500,
                    type = "money",
                    image = "male_mask_155_0"
                },
                [1] = {
                    label = "Red Joker",
                    price = 500,
                    type = "money",
                    image = "male_mask_155_1"
                },
                [2] = {
                    label = "Green Joker",
                    price = 500,
                    type = "money",
                    image = "male_mask_155_2"
                },
                [3] = {
                    label = "Purple Joker",
                    price = 500,
                    type = "money",
                    image = "male_mask_155_3"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "King of Hearts",
                    price = 500,
                    type = "money",
                    image = "male_mask_156_0"
                },
                [1] = {
                    label = "King of Clubs",
                    price = 500,
                    type = "money",
                    image = "male_mask_156_1"
                },
                [2] = {
                    label = "King of Diamonds",
                    price = 500,
                    type = "money",
                    image = "male_mask_156_2"
                },
                [3] = {
                    label = "King of Spades",
                    price = 500,
                    type = "money",
                    image = "male_mask_156_3"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "Queen of Spades",
                    price = 500,
                    type = "money",
                    image = "male_mask_157_0"
                },
                [1] = {
                    label = "Queen of Hearts",
                    price = 500,
                    type = "money",
                    image = "male_mask_157_1"
                },
                [2] = {
                    label = "Queen of Diamonds",
                    price = 500,
                    type = "money",
                    image = "male_mask_157_2"
                },
                [3] = {
                    label = "Queen of Clubs",
                    price = 500,
                    type = "money",
                    image = "male_mask_157_3"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Jack of Spades",
                    price = 500,
                    type = "money",
                    image = "male_mask_158_0"
                },
                [1] = {
                    label = "Jack of Hearts",
                    price = 500,
                    type = "money",
                    image = "male_mask_158_1"
                },
                [2] = {
                    label = "Jack of Clubs",
                    price = 500,
                    type = "money",
                    image = "male_mask_158_2"
                },
                [3] = {
                    label = "Jack of Diamonds",
                    price = 500,
                    type = "money",
                    image = "male_mask_158_3"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ace of Spades",
                    price = 500,
                    type = "money",
                    image = "male_mask_159_0"
                },
                [1] = {
                    label = "Ace of Hearts",
                    price = 500,
                    type = "money",
                    image = "male_mask_159_1"
                },
                [2] = {
                    label = "Ace of Clubs",
                    price = 500,
                    type = "money",
                    image = "male_mask_159_2"
                },
                [3] = {
                    label = "Ace of Diamonds",
                    price = 500,
                    type = "money",
                    image = "male_mask_159_3"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Baby Smile",
                    price = 500,
                    type = "money",
                    image = "male_mask_160_0"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fig",
                    price = 500,
                    type = "money",
                    image = "male_mask_161_0"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'component',
            textures = {
                [0] = {
                    label = "Piggly",
                    price = 500,
                    type = "money",
                    image = "male_mask_162_0"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ape",
                    price = 500,
                    type = "money",
                    image = "male_mask_163_0"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grinner",
                    price = 500,
                    type = "money",
                    image = "male_mask_164_0"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fluffy Rabbit",
                    price = 500,
                    type = "money",
                    image = "male_mask_165_0"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (166-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_166_0"
                },
                [1] = {
                    label = "Mask (166-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_166_1"
                },
                [2] = {
                    label = "Mask (166-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_166_2"
                },
                [3] = {
                    label = "Mask (166-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_166_3"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'component',
            textures = {
                [0] = {
                    label = "Sniper",
                    price = 500,
                    type = "money",
                    image = "male_mask_167_0"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'component',
            textures = {
                [0] = {
                    label = "Fleshless",
                    price = 500,
                    type = "money",
                    image = "male_mask_168_0"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_0"
                },
                [1] = {
                    label = "Gray Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_1"
                },
                [2] = {
                    label = "Light Gray Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_2"
                },
                [3] = {
                    label = "Red Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_3"
                },
                [4] = {
                    label = "Teal Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_4"
                },
                [5] = {
                    label = "Smiley Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_5"
                },
                [6] = {
                    label = "Gray Digital Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_6"
                },
                [7] = {
                    label = "Blue Digital Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_7"
                },
                [8] = {
                    label = "Blue Wave Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_8"
                },
                [9] = {
                    label = "Stars & Stripes Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_9"
                },
                [10] = {
                    label = "Toothy Grin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_10"
                },
                [11] = {
                    label = "Wolf Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_11"
                },
                [12] = {
                    label = "Gray Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_12"
                },
                [13] = {
                    label = "Black Skull Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_13"
                },
                [14] = {
                    label = "Blood Cross Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_14"
                },
                [15] = {
                    label = "Brown Skull Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_15"
                },
                [16] = {
                    label = "Green Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_16"
                },
                [17] = {
                    label = "Green Neon Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_17"
                },
                [18] = {
                    label = "Purple Neon Camo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_18"
                },
                [19] = {
                    label = "Cobble Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_19"
                },
                [20] = {
                    label = "Green Snakeskin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_20"
                },
                [21] = {
                    label = "Purple Snakeskin Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_21"
                },
                [22] = {
                    label = "Mask (169-22)",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_22"
                },
                [23] = {
                    label = "Mask (169-23)",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_23"
                },
                [24] = {
                    label = "Mask (169-24)",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_24"
                },
                [25] = {
                    label = "Mask (169-25)",
                    price = 500,
                    type = "money",
                    image = "male_mask_169_25"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'component',
            textures = {
                [0] = {
                    label = "Voyeur",
                    price = 500,
                    type = "money",
                    image = "male_mask_170_0"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Fox",
                    price = 500,
                    type = "money",
                    image = "male_mask_171_0"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Ginger & White Cat",
                    price = 500,
                    type = "money",
                    image = "male_mask_172_0"
                },
                [1] = {
                    label = "Geo Gray & White Cat",
                    price = 500,
                    type = "money",
                    image = "male_mask_172_1"
                },
                [2] = {
                    label = "Geo Black & White Cat",
                    price = 500,
                    type = "money",
                    image = "male_mask_172_2"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Pig",
                    price = 500,
                    type = "money",
                    image = "male_mask_173_0"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray & Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_0"
                },
                [1] = {
                    label = "Ash & White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_1"
                },
                [2] = {
                    label = "Gray & White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_2"
                },
                [3] = {
                    label = "Worn Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_3"
                },
                [4] = {
                    label = "Worn Yellow Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_4"
                },
                [5] = {
                    label = "Worn Green Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_5"
                },
                [6] = {
                    label = "Black Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_6"
                },
                [7] = {
                    label = "Red Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_7"
                },
                [8] = {
                    label = "Yellow Swirl Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_8"
                },
                [9] = {
                    label = "Pale Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_9"
                },
                [10] = {
                    label = "Red Lip Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_10"
                },
                [11] = {
                    label = "Smoke Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_11"
                },
                [12] = {
                    label = "Red Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_12"
                },
                [13] = {
                    label = "Cyan Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_13"
                },
                [14] = {
                    label = "Dark Pink Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_14"
                },
                [15] = {
                    label = "Green Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_15"
                },
                [16] = {
                    label = "Peach Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_16"
                },
                [17] = {
                    label = "Purple Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_17"
                },
                [18] = {
                    label = "Light Pink Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_18"
                },
                [19] = {
                    label = "Terracotta Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_19"
                },
                [20] = {
                    label = "Dusty Blue Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_20"
                },
                [21] = {
                    label = "Gray Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_21"
                },
                [22] = {
                    label = "Putty Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_22"
                },
                [23] = {
                    label = "White Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_23"
                },
                [24] = {
                    label = "Stone Leather Half Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_174_24"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Visor Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_175_0"
                },
                [1] = {
                    label = "Green Visor Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_175_1"
                },
                [2] = {
                    label = "Orange Mask Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_175_2"
                },
                [3] = {
                    label = "Gold Mask Respirator",
                    price = 500,
                    type = "money",
                    image = "male_mask_175_3"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'component',
            textures = {
                [0] = {
                    label = "Geo Gold Dog",
                    price = 500,
                    type = "money",
                    image = "male_mask_176_0"
                },
                [1] = {
                    label = "Geo White Dog",
                    price = 500,
                    type = "money",
                    image = "male_mask_176_1"
                },
                [2] = {
                    label = "Geo Brown Dog",
                    price = 500,
                    type = "money",
                    image = "male_mask_176_2"
                },
                [3] = {
                    label = "Geo Gray Dog",
                    price = 500,
                    type = "money",
                    image = "male_mask_176_3"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cerberus",
                    price = 500,
                    type = "money",
                    image = "male_mask_177_0"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray & Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_0"
                },
                [1] = {
                    label = "Ash & White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_1"
                },
                [2] = {
                    label = "Gray & White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_2"
                },
                [3] = {
                    label = "Worn Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_3"
                },
                [4] = {
                    label = "Worn Yellow Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_4"
                },
                [5] = {
                    label = "Worn Green Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_5"
                },
                [6] = {
                    label = "Black Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_6"
                },
                [7] = {
                    label = "Red Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_7"
                },
                [8] = {
                    label = "Yellow Swirl Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_8"
                },
                [9] = {
                    label = "Pale Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_9"
                },
                [10] = {
                    label = "Red Lip Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_10"
                },
                [11] = {
                    label = "Smoke Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_11"
                },
                [12] = {
                    label = "Red Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_12"
                },
                [13] = {
                    label = "Cyan Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_13"
                },
                [14] = {
                    label = "Dark Pink Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_14"
                },
                [15] = {
                    label = "Green Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_15"
                },
                [16] = {
                    label = "Peach Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_16"
                },
                [17] = {
                    label = "Purple Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_17"
                },
                [18] = {
                    label = "Light Pink Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_18"
                },
                [19] = {
                    label = "Terracotta Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_19"
                },
                [20] = {
                    label = "Dusty Blue Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_20"
                },
                [21] = {
                    label = "Gray Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_21"
                },
                [22] = {
                    label = "Putty Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_22"
                },
                [23] = {
                    label = "White Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_23"
                },
                [24] = {
                    label = "Stone Leather with NVG",
                    price = 500,
                    type = "money",
                    image = "male_mask_178_24"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'component',
            textures = {
                [0] = {
                    label = "Grin",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_0"
                },
                [1] = {
                    label = "Cry",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_1"
                },
                [2] = {
                    label = "Laugh",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_2"
                },
                [3] = {
                    label = "Grimace",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_3"
                },
                [4] = {
                    label = "In Love",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_4"
                },
                [5] = {
                    label = "Blow Kiss",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_5"
                },
                [6] = {
                    label = "Gasp",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_6"
                },
                [7] = {
                    label = "Wink",
                    price = 500,
                    type = "money",
                    image = "male_mask_179_7"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (180-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_0"
                },
                [1] = {
                    label = "Mask (180-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_1"
                },
                [2] = {
                    label = "Mask (180-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_2"
                },
                [3] = {
                    label = "Mask (180-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_3"
                },
                [4] = {
                    label = "Mask (180-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_4"
                },
                [5] = {
                    label = "Mask (180-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_5"
                },
                [6] = {
                    label = "Mask (180-6)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_6"
                },
                [7] = {
                    label = "Mask (180-7)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_7"
                },
                [8] = {
                    label = "Mask (180-8)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_8"
                },
                [9] = {
                    label = "Mask (180-9)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_9"
                },
                [10] = {
                    label = "Mask (180-10)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_10"
                },
                [11] = {
                    label = "Mask (180-11)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_11"
                },
                [12] = {
                    label = "Mask (180-12)",
                    price = 500,
                    type = "money",
                    image = "male_mask_180_12"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_181_0"
                },
                [1] = {
                    label = "Brown Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_181_1"
                },
                [2] = {
                    label = "Moss Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_181_2"
                },
                [3] = {
                    label = "Swamp Turtle Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_181_3"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_182_0"
                },
                [1] = {
                    label = "Brown Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_182_1"
                },
                [2] = {
                    label = "Tan Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_182_2"
                },
                [3] = {
                    label = "Gray Mouse Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_182_3"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black & Green Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_0"
                },
                [1] = {
                    label = "Black & Orange Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_1"
                },
                [2] = {
                    label = "Black & Blue Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_2"
                },
                [3] = {
                    label = "Black & Pink Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_3"
                },
                [4] = {
                    label = "Green Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_4"
                },
                [5] = {
                    label = "Orange Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_5"
                },
                [6] = {
                    label = "Blue Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_6"
                },
                [7] = {
                    label = "Pink Dot Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_7"
                },
                [8] = {
                    label = "Green T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_8"
                },
                [9] = {
                    label = "Orange T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_9"
                },
                [10] = {
                    label = "Blue T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_10"
                },
                [11] = {
                    label = "Pink T Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_11"
                },
                [12] = {
                    label = "Green Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_12"
                },
                [13] = {
                    label = "Orange Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_13"
                },
                [14] = {
                    label = "Blue Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_14"
                },
                [15] = {
                    label = "Pink Grin Tech Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_183_15"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_184_0"
                },
                [1] = {
                    label = "Gray Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_184_1"
                },
                [2] = {
                    label = "Stone Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_184_2"
                },
                [3] = {
                    label = "Smoke Hyena Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_184_3"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_0"
                },
                [1] = {
                    label = "White Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_1"
                },
                [2] = {
                    label = "Ash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_2"
                },
                [3] = {
                    label = "Red Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_3"
                },
                [4] = {
                    label = "Dark Red Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_4"
                },
                [5] = {
                    label = "Cream Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_5"
                },
                [6] = {
                    label = "Green Digital Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_6"
                },
                [7] = {
                    label = "Brown Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_7"
                },
                [8] = {
                    label = "Gray Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_8"
                },
                [9] = {
                    label = "Desert Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_9"
                },
                [10] = {
                    label = "Forest Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_10"
                },
                [11] = {
                    label = "Blue Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_11"
                },
                [12] = {
                    label = "Rock Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_12"
                },
                [13] = {
                    label = "Grass Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_13"
                },
                [14] = {
                    label = "Field Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_14"
                },
                [15] = {
                    label = "Rust Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_15"
                },
                [16] = {
                    label = "Blue Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_16"
                },
                [17] = {
                    label = "Yellow Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_17"
                },
                [18] = {
                    label = "Green Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_18"
                },
                [19] = {
                    label = "Pink Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_19"
                },
                [20] = {
                    label = "Moss Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_20"
                },
                [21] = {
                    label = "Green Splash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_21"
                },
                [22] = {
                    label = "Purple Splash Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_22"
                },
                [23] = {
                    label = "Green Shard Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_23"
                },
                [24] = {
                    label = "Violet Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_24"
                },
                [25] = {
                    label = "Pink Camo Spec Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_185_25"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Logo Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_0"
                },
                [1] = {
                    label = "Yellow Bigness Logo Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_1"
                },
                [2] = {
                    label = "Yellow VDG Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_2"
                },
                [3] = {
                    label = "Gray VDG Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_3"
                },
                [4] = {
                    label = "Yellow Pattern Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_4"
                },
                [5] = {
                    label = "Black Pattern Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_5"
                },
                [6] = {
                    label = "Yellow Trickster Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_6"
                },
                [7] = {
                    label = "Black Trickster Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_7"
                },
                [8] = {
                    label = "Yellow Camo Face",
                    price = 500,
                    type = "money",
                    image = "male_mask_186_8"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Botanical Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_0"
                },
                [1] = {
                    label = "Black Botanical Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_1"
                },
                [2] = {
                    label = "Blue Blossom Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_2"
                },
                [3] = {
                    label = "Black Blossom Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_3"
                },
                [4] = {
                    label = "Blue Blooming Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_4"
                },
                [5] = {
                    label = "Orange Blooming Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_5"
                },
                [6] = {
                    label = "Green Floral Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_6"
                },
                [7] = {
                    label = "Cream Floral Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_7"
                },
                [8] = {
                    label = "Aqua Palms Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_8"
                },
                [9] = {
                    label = "Yellow Palms Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_9"
                },
                [10] = {
                    label = "Flamingo Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_10"
                },
                [11] = {
                    label = "Blue Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_11"
                },
                [12] = {
                    label = "Green Painted Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_12"
                },
                [13] = {
                    label = "Navy Painted Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_13"
                },
                [14] = {
                    label = "Blue Ocean Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_14"
                },
                [15] = {
                    label = "Orange Ocean Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_15"
                },
                [16] = {
                    label = "Blue Butterfly Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_16"
                },
                [17] = {
                    label = "Orange Butterfly Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_17"
                },
                [18] = {
                    label = "Red Volcanic Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_18"
                },
                [19] = {
                    label = "Pink Volcanic Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_19"
                },
                [20] = {
                    label = "Cream Fish Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_20"
                },
                [21] = {
                    label = "Magenta Fish Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_21"
                },
                [22] = {
                    label = "Cream Tiger Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_22"
                },
                [23] = {
                    label = "Pink Tiger Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_23"
                },
                [24] = {
                    label = "Mauve Flowers Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_24"
                },
                [25] = {
                    label = "Blue Flowers Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_187_25"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Grotesque Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_0"
                },
                [1] = {
                    label = "Blue Grotesque Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_1"
                },
                [2] = {
                    label = "Red Flames Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_2"
                },
                [3] = {
                    label = "Blue Flames Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_3"
                },
                [4] = {
                    label = "Island Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_4"
                },
                [5] = {
                    label = "Palm Print Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_5"
                },
                [6] = {
                    label = "Green Grin Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_6"
                },
                [7] = {
                    label = "Red Grin Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_7"
                },
                [8] = {
                    label = "Yellow Grin Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_8"
                },
                [9] = {
                    label = "Red Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_9"
                },
                [10] = {
                    label = "White Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_10"
                },
                [11] = {
                    label = "Black Tribal Painted",
                    price = 500,
                    type = "money",
                    image = "male_mask_188_11"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_0"
                },
                [1] = {
                    label = "Navy Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_1"
                },
                [2] = {
                    label = "Cherry Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_2"
                },
                [3] = {
                    label = "Orange Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_3"
                },
                [4] = {
                    label = "Purple Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_4"
                },
                [5] = {
                    label = "Dark Blue Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_5"
                },
                [6] = {
                    label = "Lavender Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_6"
                },
                [7] = {
                    label = "Yellow Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_7"
                },
                [8] = {
                    label = "Pink Calavera Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_8"
                },
                [9] = {
                    label = "Neon Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_9"
                },
                [10] = {
                    label = "Vibrant Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_10"
                },
                [11] = {
                    label = "Pink Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_11"
                },
                [12] = {
                    label = "Blue Stitch Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_12"
                },
                [13] = {
                    label = "Neon Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_13"
                },
                [14] = {
                    label = "Vibrant Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_14"
                },
                [15] = {
                    label = "Pink Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_15"
                },
                [16] = {
                    label = "Orange Skull Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_16"
                },
                [17] = {
                    label = "Dark X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_17"
                },
                [18] = {
                    label = "Bright X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_18"
                },
                [19] = {
                    label = "Purple X-Ray Emissive Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_189_19"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'component',
            textures = {
                [0] = {
                    label = "Clean Horned Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_190_0"
                },
                [1] = {
                    label = "Dark Horned Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_190_1"
                },
                [2] = {
                    label = "Aged Horned Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_190_2"
                },
                [3] = {
                    label = "Weathered Horned Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_190_3"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "male_mask_191_0"
                },
                [1] = {
                    label = "Red Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "male_mask_191_1"
                },
                [2] = {
                    label = "White Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "male_mask_191_2"
                },
                [3] = {
                    label = "Yellow Stitched Wire",
                    price = 500,
                    type = "money",
                    image = "male_mask_191_3"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'component',
            textures = {
                [0] = {
                    label = "Plain Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_192_0"
                },
                [1] = {
                    label = "Fleshy Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_192_1"
                },
                [2] = {
                    label = "Mossy Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_192_2"
                },
                [3] = {
                    label = "Dark Spiked Skull",
                    price = 500,
                    type = "money",
                    image = "male_mask_192_3"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bearsy",
                    price = 500,
                    type = "money",
                    image = "male_mask_193_0"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (194-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_194_0"
                },
                [1] = {
                    label = "Mask (194-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_194_1"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Goldfish",
                    price = 500,
                    type = "money",
                    image = "male_mask_195_0"
                },
                [1] = {
                    label = "Purple Goldfish",
                    price = 500,
                    type = "money",
                    image = "male_mask_195_1"
                },
                [2] = {
                    label = "Bronze Goldfish",
                    price = 500,
                    type = "money",
                    image = "male_mask_195_2"
                },
                [3] = {
                    label = "Clownfish",
                    price = 500,
                    type = "money",
                    image = "male_mask_195_3"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'component',
            textures = {
                [0] = {
                    label = "Juvenile Gull",
                    price = 500,
                    type = "money",
                    image = "male_mask_196_0"
                },
                [1] = {
                    label = "Sooty Gull",
                    price = 500,
                    type = "money",
                    image = "male_mask_196_1"
                },
                [2] = {
                    label = "Black-headed Gull",
                    price = 500,
                    type = "money",
                    image = "male_mask_196_2"
                },
                [3] = {
                    label = "Herring Gull",
                    price = 500,
                    type = "money",
                    image = "male_mask_196_3"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Sea Lion",
                    price = 500,
                    type = "money",
                    image = "male_mask_197_0"
                },
                [1] = {
                    label = "Dark Sea Lion",
                    price = 500,
                    type = "money",
                    image = "male_mask_197_1"
                },
                [2] = {
                    label = "Spotted Sea Lion",
                    price = 500,
                    type = "money",
                    image = "male_mask_197_2"
                },
                [3] = {
                    label = "Gray Sea Lion",
                    price = 500,
                    type = "money",
                    image = "male_mask_197_3"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'component',
            textures = {
                [0] = {
                    label = "Famine",
                    price = 500,
                    type = "money",
                    image = "male_mask_198_0"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "male_mask_199_0"
                },
                [1] = {
                    label = "Dark Green Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "male_mask_199_1"
                },
                [2] = {
                    label = "Light Green Vintage Vampire",
                    price = 500,
                    type = "money",
                    image = "male_mask_199_2"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (200-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_200_0"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'component',
            textures = {
                [0] = {
                    label = "War",
                    price = 500,
                    type = "money",
                    image = "male_mask_201_0"
                },
            },
        },
        [202] = {
            drawable = 202,
            type = 'component',
            textures = {
                [0] = {
                    label = "Death",
                    price = 500,
                    type = "money",
                    image = "male_mask_202_0"
                },
            },
        },
        [203] = {
            drawable = 203,
            type = 'component',
            textures = {
                [0] = {
                    label = "Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "male_mask_203_0"
                },
                [1] = {
                    label = "Gray Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "male_mask_203_1"
                },
                [2] = {
                    label = "Gold Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "male_mask_203_2"
                },
                [3] = {
                    label = "Ornate Painted Tiger",
                    price = 500,
                    type = "money",
                    image = "male_mask_203_3"
                },
            },
        },
        [204] = {
            drawable = 204,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pale Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "male_mask_204_0"
                },
                [1] = {
                    label = "Green Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "male_mask_204_1"
                },
                [2] = {
                    label = "Weathered Vintage Mummy",
                    price = 500,
                    type = "money",
                    image = "male_mask_204_2"
                },
            },
        },
        [205] = {
            drawable = 205,
            type = 'component',
            textures = {
                [0] = {
                    label = "Horror Pumpkin",
                    price = 500,
                    type = "money",
                    image = "male_mask_205_0"
                },
            },
        },
        [206] = {
            drawable = 206,
            type = 'component',
            textures = {
                [0] = {
                    label = "Conquest",
                    price = 500,
                    type = "money",
                    image = "male_mask_206_0"
                },
            },
        },
        [207] = {
            drawable = 207,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "male_mask_207_0"
                },
                [1] = {
                    label = "Brown Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "male_mask_207_1"
                },
                [2] = {
                    label = "Gray Vintage Frank",
                    price = 500,
                    type = "money",
                    image = "male_mask_207_2"
                },
            },
        },
        [208] = {
            drawable = 208,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_0"
                },
                [1] = {
                    label = "Gray Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_1"
                },
                [2] = {
                    label = "White Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_2"
                },
                [3] = {
                    label = "Green Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_3"
                },
                [4] = {
                    label = "Orange Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_4"
                },
                [5] = {
                    label = "Purple Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_5"
                },
                [6] = {
                    label = "Pink Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_6"
                },
                [7] = {
                    label = "Red Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_7"
                },
                [8] = {
                    label = "Blue Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_8"
                },
                [9] = {
                    label = "Yellow Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_9"
                },
                [10] = {
                    label = "Green Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_10"
                },
                [11] = {
                    label = "Pink Detail Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_11"
                },
                [12] = {
                    label = "Orange & Gray Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_12"
                },
                [13] = {
                    label = "Red Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_13"
                },
                [14] = {
                    label = "Camo Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_14"
                },
                [15] = {
                    label = "Aqua Camo Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_15"
                },
                [16] = {
                    label = "Brown Digital Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_16"
                },
                [17] = {
                    label = "Gold Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_17"
                },
                [18] = {
                    label = "Orange & Cream Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_18"
                },
                [19] = {
                    label = "Green & Yellow Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_19"
                },
                [20] = {
                    label = "Pink Floral Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_20"
                },
                [21] = {
                    label = "Black & Green Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_21"
                },
                [22] = {
                    label = "White & Red Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_22"
                },
                [23] = {
                    label = "Carbon Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_23"
                },
                [24] = {
                    label = "Carbon Teal Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_24"
                },
                [25] = {
                    label = "Black & White Tech Demon",
                    price = 500,
                    type = "money",
                    image = "male_mask_208_25"
                },
            },
        },
        [209] = {
            drawable = 209,
            type = 'component',
            textures = {
                [0] = {
                    label = "Traditional Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "male_mask_209_0"
                },
                [1] = {
                    label = "Twilight Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "male_mask_209_1"
                },
                [2] = {
                    label = "Noh Painted Rabbit",
                    price = 500,
                    type = "money",
                    image = "male_mask_209_2"
                },
            },
        },
        [210] = {
            drawable = 210,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (210-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_210_0"
                },
            },
        },
        [211] = {
            drawable = 211,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_0"
                },
                [1] = {
                    label = "White Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_1"
                },
                [2] = {
                    label = "Purple Bigness Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_2"
                },
                [3] = {
                    label = "Black Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_3"
                },
                [4] = {
                    label = "Blue Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_4"
                },
                [5] = {
                    label = "Red Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_5"
                },
                [6] = {
                    label = "White Blagueurs Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_6"
                },
                [7] = {
                    label = "Black Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_7"
                },
                [8] = {
                    label = "Teal Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_8"
                },
                [9] = {
                    label = "Magenta Enema Flourish Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_9"
                },
                [10] = {
                    label = "Green Flames Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_10"
                },
                [11] = {
                    label = "Orange Flames Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_11"
                },
                [12] = {
                    label = "Pink Flames Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_12"
                },
                [13] = {
                    label = "Purple Flames Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_13"
                },
                [14] = {
                    label = "Red Flames Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_14"
                },
                [15] = {
                    label = "Blue Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_15"
                },
                [16] = {
                    label = "White Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_16"
                },
                [17] = {
                    label = "Green Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_17"
                },
                [18] = {
                    label = "Orange Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_18"
                },
                [19] = {
                    label = "Purple Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_19"
                },
                [20] = {
                    label = "Pink Lightning Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_20"
                },
                [21] = {
                    label = "Gray Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_21"
                },
                [22] = {
                    label = "Aqua Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_22"
                },
                [23] = {
                    label = "Contrast Camo Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_23"
                },
                [24] = {
                    label = "Gray Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_24"
                },
                [25] = {
                    label = "Aqua Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_211_25"
                },
            },
        },
        [212] = {
            drawable = 212,
            type = 'component',
            textures = {
                [0] = {
                    label = "Contrast Dazzle Sand Castle Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_212_0"
                },
                [1] = {
                    label = "Gray Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_212_1"
                },
                [2] = {
                    label = "Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_212_2"
                },
                [3] = {
                    label = "Pink Camo Yeti Ski",
                    price = 500,
                    type = "money",
                    image = "male_mask_212_3"
                },
            },
        },
        [213] = {
            drawable = 213,
            type = 'component',
            textures = {
                [0] = {
                    label = "The Gooch",
                    price = 500,
                    type = "money",
                    image = "male_mask_213_0"
                },
            },
        },
        [214] = {
            drawable = 214,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (214-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_214_0"
                },
                [1] = {
                    label = "Mask (214-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_214_1"
                },
            },
        },
        [215] = {
            drawable = 215,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (215-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_215_0"
                },
            },
        },
        [216] = {
            drawable = 216,
            type = 'component',
            textures = {
                [0] = {
                    label = "Scarlet Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_216_0"
                },
                [1] = {
                    label = "Amber Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_216_1"
                },
                [2] = {
                    label = "Green Vintage Devil Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_216_2"
                },
            },
        },
        [217] = {
            drawable = 217,
            type = 'component',
            textures = {
                [0] = {
                    label = "Orange Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_217_0"
                },
                [1] = {
                    label = "Blue Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_217_1"
                },
                [2] = {
                    label = "Brown Vintage Werewolf Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_217_2"
                },
            },
        },
        [218] = {
            drawable = 218,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_218_0"
                },
                [1] = {
                    label = "Yellow Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_218_1"
                },
                [2] = {
                    label = "Orange Vintage Witch Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_218_2"
                },
            },
        },
        [219] = {
            drawable = 219,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_219_0"
                },
                [1] = {
                    label = "Brown Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_219_1"
                },
                [2] = {
                    label = "Teal Vintage Zombie Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_219_2"
                },
            },
        },
        [220] = {
            drawable = 220,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_220_0"
                },
                [1] = {
                    label = "White Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_220_1"
                },
                [2] = {
                    label = "Brown Vintage Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_220_2"
                },
            },
        },
        [221] = {
            drawable = 221,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (221-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_221_0"
                },
            },
        },
        [222] = {
            drawable = 222,
            type = 'component',
            textures = {
                [0] = {
                    label = "Golden Balaclava",
                    price = 500,
                    type = "money",
                    image = "male_mask_222_0"
                },
            },
        },
        [223] = {
            drawable = 223,
            type = 'component',
            textures = {
                [0] = {
                    label = "Turkey Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_223_0"
                },
            },
        },
        [224] = {
            drawable = 224,
            type = 'component',
            textures = {
                [0] = {
                    label = "Luchadora's Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_224_0"
                },
            },
        },
        [225] = {
            drawable = 225,
            type = 'component',
            textures = {
                [0] = {
                    label = "Royal Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_225_0"
                },
                [1] = {
                    label = "Maritime Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_225_1"
                },
                [2] = {
                    label = "Romance Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_225_2"
                },
                [3] = {
                    label = "Floral Calaca Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_225_3"
                },
            },
        },
        [226] = {
            drawable = 226,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (226-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_226_0"
                },
            },
        },
        [227] = {
            drawable = 227,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (227-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_227_0"
                },
            },
        },
        [228] = {
            drawable = 228,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cinco de Mayo Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_228_0"
                },
            },
        },
        [229] = {
            drawable = 229,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wooden Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_229_0"
                },
                [1] = {
                    label = "Contrast Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_229_1"
                },
                [2] = {
                    label = "Regal Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_229_2"
                },
                [3] = {
                    label = "Midnight Dragon Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_229_3"
                },
            },
        },
        [230] = {
            drawable = 230,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (230-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_230_0"
                },
                [1] = {
                    label = "Mask (230-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_230_1"
                },
                [2] = {
                    label = "Mask (230-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_230_2"
                },
                [3] = {
                    label = "Mask (230-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_230_3"
                },
            },
        },
        [231] = {
            drawable = 231,
            type = 'component',
            textures = {
                [0] = {
                    label = "LS Customs Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_231_0"
                },
            },
        },
        [232] = {
            drawable = 232,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (232-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_0"
                },
                [1] = {
                    label = "Mask (232-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_1"
                },
                [2] = {
                    label = "Mask (232-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_2"
                },
                [3] = {
                    label = "Mask (232-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_3"
                },
                [4] = {
                    label = "Mask (232-4)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_4"
                },
                [5] = {
                    label = "Mask (232-5)",
                    price = 500,
                    type = "money",
                    image = "male_mask_232_5"
                },
            },
        },
        [233] = {
            drawable = 233,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (233-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_233_0"
                },
                [1] = {
                    label = "Mask (233-1)",
                    price = 500,
                    type = "money",
                    image = "male_mask_233_1"
                },
                [2] = {
                    label = "Mask (233-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_233_2"
                },
                [3] = {
                    label = "Mask (233-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_233_3"
                },
            },
        },
        [234] = {
            drawable = 234,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (234-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_234_0"
                },
                [1] = {
                    label = "Strapz Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_234_1"
                },
                [2] = {
                    label = "Mask (234-2)",
                    price = 500,
                    type = "money",
                    image = "male_mask_234_2"
                },
                [3] = {
                    label = "Mask (234-3)",
                    price = 500,
                    type = "money",
                    image = "male_mask_234_3"
                },
            },
        },
        [235] = {
            drawable = 235,
            type = 'component',
            textures = {
                [0] = {
                    label = "Carnival Neck Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_235_0"
                },
            },
        },
        [236] = {
            drawable = 236,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (236-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_236_0"
                },
            },
        },
        [237] = {
            drawable = 237,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (237-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_237_0"
                },
            },
        },
        [238] = {
            drawable = 238,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_238_0"
                },
                [1] = {
                    label = "Red Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_238_1"
                },
                [2] = {
                    label = "Tan Demon Goat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_238_2"
                },
            },
        },
        [239] = {
            drawable = 239,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_239_0"
                },
                [1] = {
                    label = "Gray Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_239_1"
                },
                [2] = {
                    label = "Brown Creepy Cat Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_239_2"
                },
            },
        },
        [240] = {
            drawable = 240,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_240_0"
                },
                [1] = {
                    label = "Red Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_240_1"
                },
                [2] = {
                    label = "Blue Hooded Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_240_2"
                },
            },
        },
        [241] = {
            drawable = 241,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_241_0"
                },
                [1] = {
                    label = "Green Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_241_1"
                },
                [2] = {
                    label = "Orange Flaming Skull Mask",
                    price = 500,
                    type = "money",
                    image = "male_mask_241_2"
                },
            },
        },
        [242] = {
            drawable = 242,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mask (242-0)",
                    price = 500,
                    type = "money",
                    image = "male_mask_242_0"
                },
            },
        },
        [243] = {
            drawable = 243,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ride or Die Gaiter",
                    price = 500,
                    type = "money",
                    image = "male_mask_243_0"
                },
            },
        },
    },
}
