pants = {
    female = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_0"
                },
                [1] = {
                    label = "Pants (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_1"
                },
                [2] = {
                    label = "Pants (0-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_2"
                },
                [3] = {
                    label = "Pants (0-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_3"
                },
                [4] = {
                    label = "Pants (0-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_4"
                },
                [5] = {
                    label = "Pants (0-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_5"
                },
                [6] = {
                    label = "Pants (0-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_6"
                },
                [7] = {
                    label = "Pants (0-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_7"
                },
                [8] = {
                    label = "Pants (0-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_8"
                },
                [9] = {
                    label = "Pants (0-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_9"
                },
                [10] = {
                    label = "Pants (0-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_10"
                },
                [11] = {
                    label = "Pants (0-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_11"
                },
                [12] = {
                    label = "Pants (0-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_12"
                },
                [13] = {
                    label = "Pants (0-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_13"
                },
                [14] = {
                    label = "Pants (0-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_14"
                },
                [15] = {
                    label = "Pants (0-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_0_15"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_0"
                },
                [1] = {
                    label = "Pants (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_1"
                },
                [2] = {
                    label = "Pants (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_2"
                },
                [3] = {
                    label = "Pants (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_3"
                },
                [4] = {
                    label = "Pants (1-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_4"
                },
                [5] = {
                    label = "Pants (1-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_5"
                },
                [6] = {
                    label = "Pants (1-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_6"
                },
                [7] = {
                    label = "Pants (1-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_7"
                },
                [8] = {
                    label = "Pants (1-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_8"
                },
                [9] = {
                    label = "Pants (1-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_9"
                },
                [10] = {
                    label = "Pants (1-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_10"
                },
                [11] = {
                    label = "Pants (1-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_11"
                },
                [12] = {
                    label = "Pants (1-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_12"
                },
                [13] = {
                    label = "Pants (1-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_13"
                },
                [14] = {
                    label = "Pants (1-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_14"
                },
                [15] = {
                    label = "Pants (1-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_1_15"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_0"
                },
                [1] = {
                    label = "Pants (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_1"
                },
                [2] = {
                    label = "Pants (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_2"
                },
                [3] = {
                    label = "Pants (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_3"
                },
                [4] = {
                    label = "Pants (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_4"
                },
                [5] = {
                    label = "Pants (2-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_5"
                },
                [6] = {
                    label = "Pants (2-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_6"
                },
                [7] = {
                    label = "Pants (2-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_7"
                },
                [8] = {
                    label = "Pants (2-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_8"
                },
                [9] = {
                    label = "Pants (2-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_9"
                },
                [10] = {
                    label = "Pants (2-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_10"
                },
                [11] = {
                    label = "Pants (2-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_11"
                },
                [12] = {
                    label = "Pants (2-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_12"
                },
                [13] = {
                    label = "Pants (2-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_13"
                },
                [14] = {
                    label = "Pants (2-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_14"
                },
                [15] = {
                    label = "Pants (2-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_2_15"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_0"
                },
                [1] = {
                    label = "Pants (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_1"
                },
                [2] = {
                    label = "Pants (3-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_2"
                },
                [3] = {
                    label = "Pants (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_3"
                },
                [4] = {
                    label = "Pants (3-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_4"
                },
                [5] = {
                    label = "Pants (3-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_5"
                },
                [6] = {
                    label = "Pants (3-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_6"
                },
                [7] = {
                    label = "Pants (3-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_7"
                },
                [8] = {
                    label = "Pants (3-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_8"
                },
                [9] = {
                    label = "Pants (3-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_9"
                },
                [10] = {
                    label = "Pants (3-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_10"
                },
                [11] = {
                    label = "Pants (3-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_11"
                },
                [12] = {
                    label = "Pants (3-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_12"
                },
                [13] = {
                    label = "Pants (3-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_13"
                },
                [14] = {
                    label = "Pants (3-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_14"
                },
                [15] = {
                    label = "Pants (3-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_3_15"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_0"
                },
                [1] = {
                    label = "Pants (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_1"
                },
                [2] = {
                    label = "Pants (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_2"
                },
                [3] = {
                    label = "Pants (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_3"
                },
                [4] = {
                    label = "Pants (4-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_4"
                },
                [5] = {
                    label = "Pants (4-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_5"
                },
                [6] = {
                    label = "Pants (4-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_6"
                },
                [7] = {
                    label = "Pants (4-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_7"
                },
                [8] = {
                    label = "Pants (4-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_8"
                },
                [9] = {
                    label = "Pants (4-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_9"
                },
                [10] = {
                    label = "Pants (4-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_10"
                },
                [11] = {
                    label = "Pants (4-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_11"
                },
                [12] = {
                    label = "Pants (4-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_12"
                },
                [13] = {
                    label = "Pants (4-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_13"
                },
                [14] = {
                    label = "Pants (4-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_14"
                },
                [15] = {
                    label = "Pants (4-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_4_15"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_0"
                },
                [1] = {
                    label = "Pants (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_1"
                },
                [2] = {
                    label = "Pants (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_2"
                },
                [3] = {
                    label = "Pants (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_3"
                },
                [4] = {
                    label = "Pants (5-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_4"
                },
                [5] = {
                    label = "Pants (5-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_5"
                },
                [6] = {
                    label = "Pants (5-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_6"
                },
                [7] = {
                    label = "Pants (5-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_7"
                },
                [8] = {
                    label = "Pants (5-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_8"
                },
                [9] = {
                    label = "Pants (5-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_9"
                },
                [10] = {
                    label = "Pants (5-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_10"
                },
                [11] = {
                    label = "Pants (5-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_11"
                },
                [12] = {
                    label = "Pants (5-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_12"
                },
                [13] = {
                    label = "Pants (5-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_13"
                },
                [14] = {
                    label = "Pants (5-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_14"
                },
                [15] = {
                    label = "Pants (5-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_5_15"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_0"
                },
                [1] = {
                    label = "Pants (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_1"
                },
                [2] = {
                    label = "Pants (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_2"
                },
                [3] = {
                    label = "Pants (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_3"
                },
                [4] = {
                    label = "Pants (6-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_4"
                },
                [5] = {
                    label = "Pants (6-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_5"
                },
                [6] = {
                    label = "Pants (6-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_6"
                },
                [7] = {
                    label = "Pants (6-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_7"
                },
                [8] = {
                    label = "Pants (6-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_8"
                },
                [9] = {
                    label = "Pants (6-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_9"
                },
                [10] = {
                    label = "Pants (6-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_10"
                },
                [11] = {
                    label = "Pants (6-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_11"
                },
                [12] = {
                    label = "Pants (6-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_12"
                },
                [13] = {
                    label = "Pants (6-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_13"
                },
                [14] = {
                    label = "Pants (6-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_14"
                },
                [15] = {
                    label = "Pants (6-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_6_15"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_0"
                },
                [1] = {
                    label = "Pants (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_1"
                },
                [2] = {
                    label = "Pants (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_2"
                },
                [3] = {
                    label = "Pants (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_3"
                },
                [4] = {
                    label = "Pants (7-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_4"
                },
                [5] = {
                    label = "Pants (7-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_5"
                },
                [6] = {
                    label = "Pants (7-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_6"
                },
                [7] = {
                    label = "Pants (7-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_7"
                },
                [8] = {
                    label = "Pants (7-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_8"
                },
                [9] = {
                    label = "Pants (7-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_9"
                },
                [10] = {
                    label = "Pants (7-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_10"
                },
                [11] = {
                    label = "Pants (7-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_11"
                },
                [12] = {
                    label = "Pants (7-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_12"
                },
                [13] = {
                    label = "Pants (7-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_13"
                },
                [14] = {
                    label = "Pants (7-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_14"
                },
                [15] = {
                    label = "Pants (7-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_7_15"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (8-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_0"
                },
                [1] = {
                    label = "Pants (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_1"
                },
                [2] = {
                    label = "Pants (8-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_2"
                },
                [3] = {
                    label = "Pants (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_3"
                },
                [4] = {
                    label = "Pants (8-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_4"
                },
                [5] = {
                    label = "Pants (8-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_5"
                },
                [6] = {
                    label = "Pants (8-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_6"
                },
                [7] = {
                    label = "Pants (8-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_7"
                },
                [8] = {
                    label = "Pants (8-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_8"
                },
                [9] = {
                    label = "Pants (8-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_9"
                },
                [10] = {
                    label = "Pants (8-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_10"
                },
                [11] = {
                    label = "Pants (8-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_11"
                },
                [12] = {
                    label = "Pants (8-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_12"
                },
                [13] = {
                    label = "Pants (8-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_13"
                },
                [14] = {
                    label = "Pants (8-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_14"
                },
                [15] = {
                    label = "Pants (8-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_8_15"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (9-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_0"
                },
                [1] = {
                    label = "Pants (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_1"
                },
                [2] = {
                    label = "Pants (9-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_2"
                },
                [3] = {
                    label = "Pants (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_3"
                },
                [4] = {
                    label = "Pants (9-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_4"
                },
                [5] = {
                    label = "Pants (9-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_5"
                },
                [6] = {
                    label = "Pants (9-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_6"
                },
                [7] = {
                    label = "Pants (9-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_7"
                },
                [8] = {
                    label = "Pants (9-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_8"
                },
                [9] = {
                    label = "Pants (9-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_9"
                },
                [10] = {
                    label = "Pants (9-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_10"
                },
                [11] = {
                    label = "Pants (9-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_11"
                },
                [12] = {
                    label = "Pants (9-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_12"
                },
                [13] = {
                    label = "Pants (9-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_13"
                },
                [14] = {
                    label = "Pants (9-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_14"
                },
                [15] = {
                    label = "Pants (9-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_9_15"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (10-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_0"
                },
                [1] = {
                    label = "Pants (10-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_1"
                },
                [2] = {
                    label = "Pants (10-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_2"
                },
                [3] = {
                    label = "Pants (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_3"
                },
                [4] = {
                    label = "Pants (10-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_4"
                },
                [5] = {
                    label = "Pants (10-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_5"
                },
                [6] = {
                    label = "Pants (10-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_6"
                },
                [7] = {
                    label = "Pants (10-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_7"
                },
                [8] = {
                    label = "Pants (10-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_8"
                },
                [9] = {
                    label = "Pants (10-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_9"
                },
                [10] = {
                    label = "Pants (10-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_10"
                },
                [11] = {
                    label = "Pants (10-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_11"
                },
                [12] = {
                    label = "Pants (10-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_12"
                },
                [13] = {
                    label = "Pants (10-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_13"
                },
                [14] = {
                    label = "Pants (10-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_14"
                },
                [15] = {
                    label = "Pants (10-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_10_15"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (11-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_0"
                },
                [1] = {
                    label = "Pants (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_1"
                },
                [2] = {
                    label = "Pants (11-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_2"
                },
                [3] = {
                    label = "Pants (11-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_3"
                },
                [4] = {
                    label = "Pants (11-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_4"
                },
                [5] = {
                    label = "Pants (11-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_5"
                },
                [6] = {
                    label = "Pants (11-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_6"
                },
                [7] = {
                    label = "Pants (11-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_7"
                },
                [8] = {
                    label = "Pants (11-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_8"
                },
                [9] = {
                    label = "Pants (11-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_9"
                },
                [10] = {
                    label = "Pants (11-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_10"
                },
                [11] = {
                    label = "Pants (11-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_11"
                },
                [12] = {
                    label = "Pants (11-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_12"
                },
                [13] = {
                    label = "Pants (11-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_13"
                },
                [14] = {
                    label = "Pants (11-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_14"
                },
                [15] = {
                    label = "Pants (11-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_11_15"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (12-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_0"
                },
                [1] = {
                    label = "Pants (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_1"
                },
                [2] = {
                    label = "Pants (12-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_2"
                },
                [3] = {
                    label = "Pants (12-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_3"
                },
                [4] = {
                    label = "Pants (12-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_4"
                },
                [5] = {
                    label = "Pants (12-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_5"
                },
                [6] = {
                    label = "Pants (12-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_6"
                },
                [7] = {
                    label = "Pants (12-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_7"
                },
                [8] = {
                    label = "Pants (12-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_8"
                },
                [9] = {
                    label = "Pants (12-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_9"
                },
                [10] = {
                    label = "Pants (12-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_10"
                },
                [11] = {
                    label = "Pants (12-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_11"
                },
                [12] = {
                    label = "Pants (12-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_12"
                },
                [13] = {
                    label = "Pants (12-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_13"
                },
                [14] = {
                    label = "Pants (12-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_14"
                },
                [15] = {
                    label = "Pants (12-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_12_15"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (13-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_0"
                },
                [1] = {
                    label = "Pants (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_1"
                },
                [2] = {
                    label = "Pants (13-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_2"
                },
                [3] = {
                    label = "Pants (13-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_3"
                },
                [4] = {
                    label = "Pants (13-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_4"
                },
                [5] = {
                    label = "Pants (13-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_5"
                },
                [6] = {
                    label = "Pants (13-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_6"
                },
                [7] = {
                    label = "Pants (13-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_7"
                },
                [8] = {
                    label = "Pants (13-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_8"
                },
                [9] = {
                    label = "Pants (13-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_9"
                },
                [10] = {
                    label = "Pants (13-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_10"
                },
                [11] = {
                    label = "Pants (13-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_11"
                },
                [12] = {
                    label = "Pants (13-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_12"
                },
                [13] = {
                    label = "Pants (13-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_13"
                },
                [14] = {
                    label = "Pants (13-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_14"
                },
                [15] = {
                    label = "Pants (13-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_13_15"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (14-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_0"
                },
                [1] = {
                    label = "Pants (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_1"
                },
                [2] = {
                    label = "Pants (14-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_2"
                },
                [3] = {
                    label = "Pants (14-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_3"
                },
                [4] = {
                    label = "Pants (14-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_4"
                },
                [5] = {
                    label = "Pants (14-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_5"
                },
                [6] = {
                    label = "Pants (14-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_6"
                },
                [7] = {
                    label = "Pants (14-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_7"
                },
                [8] = {
                    label = "Pants (14-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_8"
                },
                [9] = {
                    label = "Pants (14-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_9"
                },
                [10] = {
                    label = "Pants (14-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_10"
                },
                [11] = {
                    label = "Pants (14-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_11"
                },
                [12] = {
                    label = "Pants (14-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_12"
                },
                [13] = {
                    label = "Pants (14-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_13"
                },
                [14] = {
                    label = "Pants (14-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_14"
                },
                [15] = {
                    label = "Pants (14-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (15-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_0"
                },
                [1] = {
                    label = "Pants (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_1"
                },
                [2] = {
                    label = "Pants (15-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_2"
                },
                [3] = {
                    label = "Pants (15-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_3"
                },
                [4] = {
                    label = "Pants (15-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_4"
                },
                [5] = {
                    label = "Pants (15-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_5"
                },
                [6] = {
                    label = "Pants (15-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_6"
                },
                [7] = {
                    label = "Pants (15-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_7"
                },
                [8] = {
                    label = "Pants (15-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_8"
                },
                [9] = {
                    label = "Pants (15-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_9"
                },
                [10] = {
                    label = "Pants (15-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_10"
                },
                [11] = {
                    label = "Pants (15-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_11"
                },
                [12] = {
                    label = "Pants (15-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_12"
                },
                [13] = {
                    label = "Pants (15-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_13"
                },
                [14] = {
                    label = "Pants (15-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_14"
                },
                [15] = {
                    label = "Pants (15-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_15_15"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_0"
                },
                [1] = {
                    label = "Flying Bravo Sail Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_1"
                },
                [2] = {
                    label = "Light Blue Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_2"
                },
                [3] = {
                    label = "Pink Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_3"
                },
                [4] = {
                    label = "Hawaiian Snow Plaid Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_4"
                },
                [5] = {
                    label = "Red Checked Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_5"
                },
                [6] = {
                    label = "Pale Blue Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_6"
                },
                [7] = {
                    label = "Red Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_7"
                },
                [8] = {
                    label = "Beige Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_8"
                },
                [9] = {
                    label = "White Striped Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_9"
                },
                [10] = {
                    label = "Blue Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_10"
                },
                [11] = {
                    label = "Light Pink Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_16_11"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_0"
                },
                [1] = {
                    label = "Crosses Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_1"
                },
                [2] = {
                    label = "Blue Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_2"
                },
                [3] = {
                    label = "Santo Capra Kitty Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_3"
                },
                [4] = {
                    label = "Red Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_4"
                },
                [5] = {
                    label = "Navy Striped Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_5"
                },
                [6] = {
                    label = "Yeti Camo Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_6"
                },
                [7] = {
                    label = "Harsh Souls Punk Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_7"
                },
                [8] = {
                    label = "Pink Patterned Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_8"
                },
                [9] = {
                    label = "Island Print Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_9"
                },
                [10] = {
                    label = "Floral Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_10"
                },
                [11] = {
                    label = "Orange Striped Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_17_11"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Santa Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_18_0"
                },
                [1] = {
                    label = "Elf Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_18_1"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_19_0"
                },
                [1] = {
                    label = "Red Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_19_1"
                },
                [2] = {
                    label = "Black Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_19_2"
                },
                [3] = {
                    label = "Gray Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_19_3"
                },
                [4] = {
                    label = "Teal Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_19_4"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_20_0"
                },
                [1] = {
                    label = "Red Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_20_1"
                },
                [2] = {
                    label = "Black Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_20_2"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (21-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_21_0"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (22-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_22_0"
                },
                [1] = {
                    label = "Pants (22-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_22_1"
                },
                [2] = {
                    label = "Pants (22-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_22_2"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_0"
                },
                [1] = {
                    label = "Blue Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_1"
                },
                [2] = {
                    label = "Purple Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_2"
                },
                [3] = {
                    label = "Sky Blue Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_3"
                },
                [4] = {
                    label = "Gray Woven Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_4"
                },
                [5] = {
                    label = "Olive Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_5"
                },
                [6] = {
                    label = "Yellow Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_6"
                },
                [7] = {
                    label = "Red Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_7"
                },
                [8] = {
                    label = "Pink Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_8"
                },
                [9] = {
                    label = "Fuchsia Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_9"
                },
                [10] = {
                    label = "Black & Cream Stripe Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_10"
                },
                [11] = {
                    label = "Burgundy Stripe Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_11"
                },
                [12] = {
                    label = "Black & White Stripe Suit",
                    price = 500,
                    type = "money",
                    image = "female_pants_23_12"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Vibrant Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_0"
                },
                [1] = {
                    label = "Blue Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_1"
                },
                [2] = {
                    label = "Houndstooth Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_2"
                },
                [3] = {
                    label = "Gray Panel Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_3"
                },
                [4] = {
                    label = "Olive Panel Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_4"
                },
                [5] = {
                    label = "Sky Blue Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_5"
                },
                [6] = {
                    label = "Floral Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_6"
                },
                [7] = {
                    label = "Black & White Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_7"
                },
                [8] = {
                    label = "Leopard Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_8"
                },
                [9] = {
                    label = "Green Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_9"
                },
                [10] = {
                    label = "Fuchsia Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_10"
                },
                [11] = {
                    label = "Purple Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_11"
                },
                [12] = {
                    label = "Sunrise Pencil",
                    price = 500,
                    type = "money",
                    image = "female_pants_24_12"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Distressed Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_0"
                },
                [1] = {
                    label = "Blue Distressed Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_1"
                },
                [2] = {
                    label = "Blue Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_2"
                },
                [3] = {
                    label = "Black Faded Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_3"
                },
                [4] = {
                    label = "Leopard Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_4"
                },
                [5] = {
                    label = "Snakeskin Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_5"
                },
                [6] = {
                    label = "Black Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_6"
                },
                [7] = {
                    label = "Ash Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_7"
                },
                [8] = {
                    label = "Olive Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_8"
                },
                [9] = {
                    label = "Navy Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_9"
                },
                [10] = {
                    label = "Blue Beaded Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_10"
                },
                [11] = {
                    label = "Lavender Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_11"
                },
                [12] = {
                    label = "Mint Denim Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_25_12"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Leopard Print Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_26_0"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_0"
                },
                [1] = {
                    label = "Gray Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_1"
                },
                [2] = {
                    label = "Yellow Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_2"
                },
                [3] = {
                    label = "Dark Brown Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_3"
                },
                [4] = {
                    label = "Red Accent Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_4"
                },
                [5] = {
                    label = "Skeleton Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_5"
                },
                [6] = {
                    label = "Kreppsohle Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_6"
                },
                [7] = {
                    label = "Striped Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_7"
                },
                [8] = {
                    label = "Tiger Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_8"
                },
                [9] = {
                    label = "Leopard Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_9"
                },
                [10] = {
                    label = "Tropical Sunset Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_10"
                },
                [11] = {
                    label = "Princess RB Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_11"
                },
                [12] = {
                    label = "Bright Patterned Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_12"
                },
                [13] = {
                    label = "Navy Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_13"
                },
                [14] = {
                    label = "Sky Blue Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_14"
                },
                [15] = {
                    label = "Black Barlone Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_27_15"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "Independence Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_28_0"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Flight Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_29_0"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_30_0"
                },
                [1] = {
                    label = "Gray Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_30_1"
                },
                [2] = {
                    label = "Charcoal Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_30_2"
                },
                [3] = {
                    label = "Tan Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_30_3"
                },
                [4] = {
                    label = "Forest Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_30_4"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_31_0"
                },
                [1] = {
                    label = "Stripy Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_31_1"
                },
                [2] = {
                    label = "Winter Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_31_2"
                },
                [3] = {
                    label = "Festive Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_31_3"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Heist Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_32_0"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (34-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_34_0"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (35-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_35_0"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Pencil Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_36_0"
                },
                [1] = {
                    label = "Beige Pencil Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_36_1"
                },
                [2] = {
                    label = "Black Pencil Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_36_2"
                },
                [3] = {
                    label = "Blue Pencil Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_36_3"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_0"
                },
                [1] = {
                    label = "Gray Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_1"
                },
                [2] = {
                    label = "Navy Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_2"
                },
                [3] = {
                    label = "Teal Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_3"
                },
                [4] = {
                    label = "Red Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_4"
                },
                [5] = {
                    label = "White Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_5"
                },
                [6] = {
                    label = "Brown Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_37_6"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (38-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_38_0"
                },
                [1] = {
                    label = "Pants (38-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_38_1"
                },
                [2] = {
                    label = "Pants (38-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_38_2"
                },
                [3] = {
                    label = "Pants (38-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_38_3"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (39-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_39_0"
                },
                [1] = {
                    label = "Pants (39-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_39_1"
                },
                [2] = {
                    label = "Pants (39-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_39_2"
                },
                [3] = {
                    label = "Pants (39-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_39_3"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (40-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_40_0"
                },
                [1] = {
                    label = "Pants (40-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_40_1"
                },
                [2] = {
                    label = "Pants (40-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_40_2"
                },
                [3] = {
                    label = "Pants (40-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_40_3"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_41_0"
                },
                [1] = {
                    label = "Beige Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_41_1"
                },
                [2] = {
                    label = "Black Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_41_2"
                },
                [3] = {
                    label = "Blue Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_41_3"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Flight Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_42_0"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_43_0"
                },
                [1] = {
                    label = "Red Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_43_1"
                },
                [2] = {
                    label = "Brown Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_43_2"
                },
                [3] = {
                    label = "Tan Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_43_3"
                },
                [4] = {
                    label = "Burgundy Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_43_4"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skinny Cuts",
                    price = 500,
                    type = "money",
                    image = "female_pants_44_0"
                },
                [1] = {
                    label = "Red Skinny Cuts",
                    price = 500,
                    type = "money",
                    image = "female_pants_44_1"
                },
                [2] = {
                    label = "Brown Skinny Cuts",
                    price = 500,
                    type = "money",
                    image = "female_pants_44_2"
                },
                [3] = {
                    label = "Tan Skinny Cuts",
                    price = 500,
                    type = "money",
                    image = "female_pants_44_3"
                },
                [4] = {
                    label = "Burgundy Skinny Cuts",
                    price = 500,
                    type = "money",
                    image = "female_pants_44_4"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Khaki Baggy Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_45_0"
                },
                [1] = {
                    label = "Black Baggy Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_45_1"
                },
                [2] = {
                    label = "Cream Baggy Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_45_2"
                },
                [3] = {
                    label = "Gray Baggy Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_45_3"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (46-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_46_0"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (47-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_0"
                },
                [1] = {
                    label = "Pants (47-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_1"
                },
                [2] = {
                    label = "Pants (47-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_2"
                },
                [3] = {
                    label = "Pants (47-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_3"
                },
                [4] = {
                    label = "Pants (47-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_4"
                },
                [5] = {
                    label = "Pants (47-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_5"
                },
                [6] = {
                    label = "Pants (47-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_47_6"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_48_0"
                },
                [1] = {
                    label = "Khaki Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_48_1"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Utility Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_49_0"
                },
                [1] = {
                    label = "Khaki Utility Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_50_0"
                },
                [1] = {
                    label = "Navy Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_50_1"
                },
                [2] = {
                    label = "Blue Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_50_2"
                },
                [3] = {
                    label = "Lilac Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_50_3"
                },
                [4] = {
                    label = "Yellow Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_50_4"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_51_0"
                },
                [1] = {
                    label = "Navy Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_51_1"
                },
                [2] = {
                    label = "Blue Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_51_2"
                },
                [3] = {
                    label = "Lilac Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_51_3"
                },
                [4] = {
                    label = "Yellow Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_51_4"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_52_0"
                },
                [1] = {
                    label = "Blue Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_52_1"
                },
                [2] = {
                    label = "Black Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_52_2"
                },
                [3] = {
                    label = "Green Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_52_3"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Print Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_53_0"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_54_0"
                },
                [1] = {
                    label = "Blue Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_54_1"
                },
                [2] = {
                    label = "Black Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_54_2"
                },
                [3] = {
                    label = "Green Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_54_3"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Print Fitted Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_55_0"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dix Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_0"
                },
                [1] = {
                    label = "Le Chien Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_1"
                },
                [2] = {
                    label = "Sessanta Nove Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_2"
                },
                [3] = {
                    label = "Perseus Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_3"
                },
                [4] = {
                    label = "Blossom Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_4"
                },
                [5] = {
                    label = "Floral Bikini",
                    price = 500,
                    type = "money",
                    image = "female_pants_56_5"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (57-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_0"
                },
                [1] = {
                    label = "Pants (57-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_1"
                },
                [2] = {
                    label = "Pants (57-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_2"
                },
                [3] = {
                    label = "Pants (57-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_3"
                },
                [4] = {
                    label = "Pants (57-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_4"
                },
                [5] = {
                    label = "Pants (57-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_5"
                },
                [6] = {
                    label = "Pants (57-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_6"
                },
                [7] = {
                    label = "Pants (57-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_57_7"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_58_0"
                },
                [1] = {
                    label = "Charcoal Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_58_1"
                },
                [2] = {
                    label = "Navy Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_58_2"
                },
                [3] = {
                    label = "Teal Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_58_3"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (59-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_59_0"
                },
                [1] = {
                    label = "Pants (59-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_59_1"
                },
                [2] = {
                    label = "Pants (59-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_59_2"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (60-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_0"
                },
                [1] = {
                    label = "Pants (60-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_1"
                },
                [2] = {
                    label = "Pants (60-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_2"
                },
                [3] = {
                    label = "Pants (60-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_3"
                },
                [4] = {
                    label = "Pants (60-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_4"
                },
                [5] = {
                    label = "Pants (60-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_5"
                },
                [6] = {
                    label = "Pants (60-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_6"
                },
                [7] = {
                    label = "Pants (60-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_7"
                },
                [8] = {
                    label = "Pants (60-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_8"
                },
                [9] = {
                    label = "Pants (60-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_9"
                },
                [10] = {
                    label = "Pants (60-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_10"
                },
                [11] = {
                    label = "Pants (60-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_11"
                },
                [12] = {
                    label = "Pants (60-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_12"
                },
                [13] = {
                    label = "Pants (60-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_13"
                },
                [14] = {
                    label = "Pants (60-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_14"
                },
                [15] = {
                    label = "Pants (60-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_60_15"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (61-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_0"
                },
                [1] = {
                    label = "Pants (61-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_1"
                },
                [2] = {
                    label = "Pants (61-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_2"
                },
                [3] = {
                    label = "Pants (61-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_3"
                },
                [4] = {
                    label = "Pants (61-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_4"
                },
                [5] = {
                    label = "Pants (61-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_5"
                },
                [6] = {
                    label = "Pants (61-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_6"
                },
                [7] = {
                    label = "Pants (61-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_7"
                },
                [8] = {
                    label = "Pants (61-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_8"
                },
                [9] = {
                    label = "Pants (61-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_61_9"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Nude Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_0"
                },
                [1] = {
                    label = "Lilac Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_1"
                },
                [2] = {
                    label = "Black Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_2"
                },
                [3] = {
                    label = "Blue Dot Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_3"
                },
                [4] = {
                    label = "Crimson Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_4"
                },
                [5] = {
                    label = "White Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_5"
                },
                [6] = {
                    label = "Diva Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_6"
                },
                [7] = {
                    label = "Scarlet Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_7"
                },
                [8] = {
                    label = "Purple Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_8"
                },
                [9] = {
                    label = "Tan Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_9"
                },
                [10] = {
                    label = "Noir Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_10"
                },
                [11] = {
                    label = "Red Silk Lace Pantsies",
                    price = 500,
                    type = "money",
                    image = "female_pants_62_11"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Nude Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_0"
                },
                [1] = {
                    label = "Lilac Plaid Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_1"
                },
                [2] = {
                    label = "Black Plaid Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_2"
                },
                [3] = {
                    label = "Blue Dotted Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_3"
                },
                [4] = {
                    label = "Red Leopard Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_4"
                },
                [5] = {
                    label = "White Heart Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_5"
                },
                [6] = {
                    label = "Black Heart Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_6"
                },
                [7] = {
                    label = "Red Heart Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_7"
                },
                [8] = {
                    label = "Purple Stripe Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_8"
                },
                [9] = {
                    label = "Tan Stripe Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_9"
                },
                [10] = {
                    label = "Black Leopard Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_10"
                },
                [11] = {
                    label = "Red Stripe Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_63_11"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cream Fitted Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_64_0"
                },
                [1] = {
                    label = "Black Fitted Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_64_1"
                },
                [2] = {
                    label = "Khaki Fitted Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_64_2"
                },
                [3] = {
                    label = "Gray Fitted Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_64_3"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black High Waisted",
                    price = 500,
                    type = "money",
                    image = "female_pants_65_0"
                },
                [1] = {
                    label = "White High Waisted",
                    price = 500,
                    type = "money",
                    image = "female_pants_65_1"
                },
                [2] = {
                    label = "Gray High Waisted",
                    price = 500,
                    type = "money",
                    image = "female_pants_65_2"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_0"
                },
                [1] = {
                    label = "Burgundy Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_1"
                },
                [2] = {
                    label = "Tan Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_2"
                },
                [3] = {
                    label = "Royal Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_3"
                },
                [4] = {
                    label = "Red Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_4"
                },
                [5] = {
                    label = "Light Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_5"
                },
                [6] = {
                    label = "Orange Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_6"
                },
                [7] = {
                    label = "Purple Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_7"
                },
                [8] = {
                    label = "Gray Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_8"
                },
                [9] = {
                    label = "Green Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_9"
                },
                [10] = {
                    label = "White Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_66_10"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (67-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_0"
                },
                [1] = {
                    label = "Pants (67-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_1"
                },
                [2] = {
                    label = "Pants (67-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_2"
                },
                [3] = {
                    label = "Pants (67-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_3"
                },
                [4] = {
                    label = "Pants (67-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_4"
                },
                [5] = {
                    label = "Pants (67-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_5"
                },
                [6] = {
                    label = "Pants (67-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_6"
                },
                [7] = {
                    label = "Pants (67-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_7"
                },
                [8] = {
                    label = "Pants (67-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_8"
                },
                [9] = {
                    label = "Pants (67-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_9"
                },
                [10] = {
                    label = "Pants (67-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_10"
                },
                [11] = {
                    label = "Pants (67-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_11"
                },
                [12] = {
                    label = "Pants (67-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_12"
                },
                [13] = {
                    label = "Pants (67-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_67_13"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (68-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_0"
                },
                [1] = {
                    label = "Pants (68-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_1"
                },
                [2] = {
                    label = "Pants (68-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_2"
                },
                [3] = {
                    label = "Pants (68-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_3"
                },
                [4] = {
                    label = "Pants (68-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_4"
                },
                [5] = {
                    label = "Pants (68-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_5"
                },
                [6] = {
                    label = "Pants (68-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_6"
                },
                [7] = {
                    label = "Pants (68-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_7"
                },
                [8] = {
                    label = "Pants (68-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_8"
                },
                [9] = {
                    label = "Pants (68-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_68_9"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (69-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_0"
                },
                [1] = {
                    label = "Pants (69-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_1"
                },
                [2] = {
                    label = "Pants (69-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_2"
                },
                [3] = {
                    label = "Pants (69-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_3"
                },
                [4] = {
                    label = "Pants (69-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_4"
                },
                [5] = {
                    label = "Pants (69-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_5"
                },
                [6] = {
                    label = "Pants (69-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_6"
                },
                [7] = {
                    label = "Pants (69-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_7"
                },
                [8] = {
                    label = "Pants (69-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_8"
                },
                [9] = {
                    label = "Pants (69-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_9"
                },
                [10] = {
                    label = "Pants (69-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_10"
                },
                [11] = {
                    label = "Pants (69-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_69_11"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (70-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_0"
                },
                [1] = {
                    label = "Pants (70-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_1"
                },
                [2] = {
                    label = "Pants (70-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_2"
                },
                [3] = {
                    label = "Pants (70-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_3"
                },
                [4] = {
                    label = "Pants (70-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_4"
                },
                [5] = {
                    label = "Pants (70-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_5"
                },
                [6] = {
                    label = "Pants (70-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_6"
                },
                [7] = {
                    label = "Pants (70-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_7"
                },
                [8] = {
                    label = "Pants (70-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_8"
                },
                [9] = {
                    label = "Pants (70-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_70_9"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_0"
                },
                [1] = {
                    label = "Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_1"
                },
                [2] = {
                    label = "Urban Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_2"
                },
                [3] = {
                    label = "Star Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_3"
                },
                [4] = {
                    label = "Pants (71-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_4"
                },
                [5] = {
                    label = "Pants (71-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_5"
                },
                [6] = {
                    label = "Pants (71-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_6"
                },
                [7] = {
                    label = "Pants (71-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_7"
                },
                [8] = {
                    label = "Lazer Force Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_8"
                },
                [9] = {
                    label = "Impotent Rage Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_9"
                },
                [10] = {
                    label = "Hamburgers Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_10"
                },
                [11] = {
                    label = "Up-n-Atom Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_11"
                },
                [12] = {
                    label = "Barfs Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_12"
                },
                [13] = {
                    label = "Bubblegum Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_13"
                },
                [14] = {
                    label = "Neon Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_14"
                },
                [15] = {
                    label = "Space Ranger Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_15"
                },
                [16] = {
                    label = "Sprunk Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_16"
                },
                [17] = {
                    label = "Ripple Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_71_17"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (72-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_72_0"
                },
                [1] = {
                    label = "Pants (72-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_72_1"
                },
                [2] = {
                    label = "Pants (72-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_72_2"
                },
                [3] = {
                    label = "Pants (72-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_72_3"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dirty Wash Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_0"
                },
                [1] = {
                    label = "Black Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_1"
                },
                [2] = {
                    label = "Deep Blue Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_2"
                },
                [3] = {
                    label = "Stonewash Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_3"
                },
                [4] = {
                    label = "Vintage Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_4"
                },
                [5] = {
                    label = "Hard Washed Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_73_5"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dirty Wash Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_0"
                },
                [1] = {
                    label = "Black Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_1"
                },
                [2] = {
                    label = "Deep Blue Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_2"
                },
                [3] = {
                    label = "Stonewash Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_3"
                },
                [4] = {
                    label = "Vintage Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_4"
                },
                [5] = {
                    label = "Hard Washed Roadworn",
                    price = 500,
                    type = "money",
                    image = "female_pants_74_5"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Plain",
                    price = 500,
                    type = "money",
                    image = "female_pants_75_0"
                },
                [1] = {
                    label = "Mocha Plain",
                    price = 500,
                    type = "money",
                    image = "female_pants_75_1"
                },
                [2] = {
                    label = "Red Plain",
                    price = 500,
                    type = "money",
                    image = "female_pants_75_2"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Quilted",
                    price = 500,
                    type = "money",
                    image = "female_pants_76_0"
                },
                [1] = {
                    label = "Mocha Quilted",
                    price = 500,
                    type = "money",
                    image = "female_pants_76_1"
                },
                [2] = {
                    label = "Red Quilted",
                    price = 500,
                    type = "money",
                    image = "female_pants_76_2"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_77_0"
                },
                [1] = {
                    label = "Mocha Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_77_1"
                },
                [2] = {
                    label = "Red Ribbed",
                    price = 500,
                    type = "money",
                    image = "female_pants_77_2"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Indigo Denims and Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_78_0"
                },
                [1] = {
                    label = "Slate Denims and Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_78_1"
                },
                [2] = {
                    label = "Black Denims and Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_78_2"
                },
                [3] = {
                    label = "Ash Denims and Stockings",
                    price = 500,
                    type = "money",
                    image = "female_pants_78_3"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (79-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_0"
                },
                [1] = {
                    label = "Pants (79-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_1"
                },
                [2] = {
                    label = "Pants (79-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_2"
                },
                [3] = {
                    label = "Pants (79-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_3"
                },
                [4] = {
                    label = "Pants (79-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_4"
                },
                [5] = {
                    label = "Pants (79-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_5"
                },
                [6] = {
                    label = "Pants (79-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_6"
                },
                [7] = {
                    label = "Pants (79-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_7"
                },
                [8] = {
                    label = "Pants (79-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_8"
                },
                [9] = {
                    label = "Pants (79-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_9"
                },
                [10] = {
                    label = "Pants (79-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_79_10"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chocolate Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_0"
                },
                [1] = {
                    label = "Camo Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_1"
                },
                [2] = {
                    label = "Black Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_2"
                },
                [3] = {
                    label = "Blue Camo Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_3"
                },
                [4] = {
                    label = "Light Gray Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_4"
                },
                [5] = {
                    label = "Charcoal Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_5"
                },
                [6] = {
                    label = "Diamond Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_6"
                },
                [7] = {
                    label = "Hatched Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_80_7"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_81_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_81_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_81_2"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chocolate Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_0"
                },
                [1] = {
                    label = "Camo Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_1"
                },
                [2] = {
                    label = "Black Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_2"
                },
                [3] = {
                    label = "Blue Camo Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_3"
                },
                [4] = {
                    label = "Light Gray Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_4"
                },
                [5] = {
                    label = "Charcoal Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_5"
                },
                [6] = {
                    label = "Diamond Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_6"
                },
                [7] = {
                    label = "Hatched Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_82_7"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_83_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_83_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_83_2"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_0"
                },
                [1] = {
                    label = "Slate Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_1"
                },
                [2] = {
                    label = "Classic Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_2"
                },
                [3] = {
                    label = "Charcoal Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_3"
                },
                [4] = {
                    label = "Black Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_4"
                },
                [5] = {
                    label = "Navy Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_5"
                },
                [6] = {
                    label = "Slate Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_6"
                },
                [7] = {
                    label = "Classic Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_7"
                },
                [8] = {
                    label = "Charcoal Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_8"
                },
                [9] = {
                    label = "Black Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "female_pants_84_9"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "female_pants_85_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "female_pants_85_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "female_pants_85_2"
                },
                [3] = {
                    label = "Brown Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "female_pants_85_3"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (86-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_0"
                },
                [1] = {
                    label = "Pants (86-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_1"
                },
                [2] = {
                    label = "Pants (86-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_2"
                },
                [3] = {
                    label = "Pants (86-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_3"
                },
                [4] = {
                    label = "Pants (86-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_4"
                },
                [5] = {
                    label = "Pants (86-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_5"
                },
                [6] = {
                    label = "Pants (86-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_6"
                },
                [7] = {
                    label = "Pants (86-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_7"
                },
                [8] = {
                    label = "Pants (86-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_8"
                },
                [9] = {
                    label = "Pants (86-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_9"
                },
                [10] = {
                    label = "Pants (86-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_86_10"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Neon Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_0"
                },
                [1] = {
                    label = "Pink Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_1"
                },
                [2] = {
                    label = "Brown & Orange Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_2"
                },
                [3] = {
                    label = "Red Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_3"
                },
                [4] = {
                    label = "Orange Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_4"
                },
                [5] = {
                    label = "Gray Sparse Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_5"
                },
                [6] = {
                    label = "Woodland Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_6"
                },
                [7] = {
                    label = "Blue & Green Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_7"
                },
                [8] = {
                    label = "Gray Tigerstripe Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_8"
                },
                [9] = {
                    label = "Pink Tigerstripe Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_9"
                },
                [10] = {
                    label = "Aqua Tigerstripe Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_10"
                },
                [11] = {
                    label = "Neon Sparse Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_11"
                },
                [12] = {
                    label = "Red Sparse Camo Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_12"
                },
                [13] = {
                    label = "Floral Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_13"
                },
                [14] = {
                    label = "Banana Squash Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_14"
                },
                [15] = {
                    label = "Orange Squash Leggings",
                    price = 500,
                    type = "money",
                    image = "female_pants_87_15"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (88-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_88_0"
                },
                [1] = {
                    label = "Pants (88-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_88_1"
                },
                [2] = {
                    label = "Pants (88-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_88_2"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_0"
                },
                [1] = {
                    label = "Brown Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_1"
                },
                [2] = {
                    label = "Green Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_2"
                },
                [3] = {
                    label = "Gray Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_3"
                },
                [4] = {
                    label = "Peach Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_4"
                },
                [5] = {
                    label = "Fall Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_6"
                },
                [7] = {
                    label = "Crosshatch Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_7"
                },
                [8] = {
                    label = "Moss Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_10"
                },
                [11] = {
                    label = "Splinter Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_12"
                },
                [13] = {
                    label = "Cobble Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_13"
                },
                [14] = {
                    label = "Peach Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_14"
                },
                [15] = {
                    label = "Brushstroke Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_15"
                },
                [16] = {
                    label = "Flecktarn Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_16"
                },
                [17] = {
                    label = "Light Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_17"
                },
                [18] = {
                    label = "Moss Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_18"
                },
                [19] = {
                    label = "Sand Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_19"
                },
                [20] = {
                    label = "Pants (89-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_20"
                },
                [21] = {
                    label = "Pants (89-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_21"
                },
                [22] = {
                    label = "Pants (89-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_22"
                },
                [23] = {
                    label = "Pants (89-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_89_23"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_0"
                },
                [1] = {
                    label = "Brown Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_1"
                },
                [2] = {
                    label = "Green Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_2"
                },
                [3] = {
                    label = "Gray Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_3"
                },
                [4] = {
                    label = "Peach Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_4"
                },
                [5] = {
                    label = "Fall Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_6"
                },
                [7] = {
                    label = "Crosshatch Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_7"
                },
                [8] = {
                    label = "Moss Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_10"
                },
                [11] = {
                    label = "Splinter Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_12"
                },
                [13] = {
                    label = "Cobble Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_13"
                },
                [14] = {
                    label = "Peach Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_14"
                },
                [15] = {
                    label = "Brushstroke Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_15"
                },
                [16] = {
                    label = "Flecktarn Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_16"
                },
                [17] = {
                    label = "Light Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_17"
                },
                [18] = {
                    label = "Moss Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_18"
                },
                [19] = {
                    label = "Sand Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_19"
                },
                [20] = {
                    label = "Pants (90-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_20"
                },
                [21] = {
                    label = "Pants (90-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_21"
                },
                [22] = {
                    label = "Pants (90-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_22"
                },
                [23] = {
                    label = "Pants (90-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_90_23"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_0"
                },
                [1] = {
                    label = "Brown Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_1"
                },
                [2] = {
                    label = "Green Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_2"
                },
                [3] = {
                    label = "Gray Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_3"
                },
                [4] = {
                    label = "Peach Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_4"
                },
                [5] = {
                    label = "Fall Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_6"
                },
                [7] = {
                    label = "Crosshatch Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_7"
                },
                [8] = {
                    label = "Moss Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_10"
                },
                [11] = {
                    label = "Splinter Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_12"
                },
                [13] = {
                    label = "Cobble Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_13"
                },
                [14] = {
                    label = "Peach Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_14"
                },
                [15] = {
                    label = "Brushstroke Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_15"
                },
                [16] = {
                    label = "Flecktarn Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_16"
                },
                [17] = {
                    label = "Light Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_17"
                },
                [18] = {
                    label = "Moss Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_18"
                },
                [19] = {
                    label = "Sand Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_19"
                },
                [20] = {
                    label = "Pants (91-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_20"
                },
                [21] = {
                    label = "Pants (91-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_21"
                },
                [22] = {
                    label = "Pants (91-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_22"
                },
                [23] = {
                    label = "Pants (91-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_91_23"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_0"
                },
                [1] = {
                    label = "Brown Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_1"
                },
                [2] = {
                    label = "Green Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_2"
                },
                [3] = {
                    label = "Gray Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_3"
                },
                [4] = {
                    label = "Peach Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_4"
                },
                [5] = {
                    label = "Fall Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_5"
                },
                [6] = {
                    label = "Dark Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_6"
                },
                [7] = {
                    label = "Crosshatch Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_7"
                },
                [8] = {
                    label = "Moss Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_8"
                },
                [9] = {
                    label = "Gray Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_9"
                },
                [10] = {
                    label = "Aqua Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_10"
                },
                [11] = {
                    label = "Splinter Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_11"
                },
                [12] = {
                    label = "Contrast Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_12"
                },
                [13] = {
                    label = "Cobble Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_13"
                },
                [14] = {
                    label = "Peach Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_14"
                },
                [15] = {
                    label = "Brushstroke Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_15"
                },
                [16] = {
                    label = "Flecktarn Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_16"
                },
                [17] = {
                    label = "Light Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_17"
                },
                [18] = {
                    label = "Moss Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_18"
                },
                [19] = {
                    label = "Sand Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_19"
                },
                [20] = {
                    label = "Black Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_20"
                },
                [21] = {
                    label = "Slate Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_21"
                },
                [22] = {
                    label = "White Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_22"
                },
                [23] = {
                    label = "Chocolate Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_23"
                },
                [24] = {
                    label = "Olive Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_24"
                },
                [25] = {
                    label = "Light Brown Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_92_25"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Indigo Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_0"
                },
                [1] = {
                    label = "Faded Indigo Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_1"
                },
                [2] = {
                    label = "Dark Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_2"
                },
                [3] = {
                    label = "Faded Dark Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_3"
                },
                [4] = {
                    label = "Light Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_4"
                },
                [5] = {
                    label = "Faded Light Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_5"
                },
                [6] = {
                    label = "Slate Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_6"
                },
                [7] = {
                    label = "Faded Slate Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_7"
                },
                [8] = {
                    label = "Black Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_8"
                },
                [9] = {
                    label = "Faded Black Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "female_pants_93_9"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (94-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_0"
                },
                [1] = {
                    label = "Pants (94-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_1"
                },
                [2] = {
                    label = "Pants (94-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_2"
                },
                [3] = {
                    label = "Pants (94-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_3"
                },
                [4] = {
                    label = "Pants (94-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_4"
                },
                [5] = {
                    label = "Pants (94-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_5"
                },
                [6] = {
                    label = "Pants (94-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_6"
                },
                [7] = {
                    label = "Pants (94-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_7"
                },
                [8] = {
                    label = "Pants (94-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_8"
                },
                [9] = {
                    label = "Pants (94-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_9"
                },
                [10] = {
                    label = "Pants (94-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_10"
                },
                [11] = {
                    label = "Pants (94-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_11"
                },
                [12] = {
                    label = "Pants (94-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_12"
                },
                [13] = {
                    label = "Pants (94-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_94_13"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (95-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_0"
                },
                [1] = {
                    label = "Pants (95-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_1"
                },
                [2] = {
                    label = "Pants (95-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_2"
                },
                [3] = {
                    label = "Pants (95-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_3"
                },
                [4] = {
                    label = "Pants (95-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_4"
                },
                [5] = {
                    label = "Pants (95-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_5"
                },
                [6] = {
                    label = "Pants (95-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_6"
                },
                [7] = {
                    label = "Pants (95-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_7"
                },
                [8] = {
                    label = "Pants (95-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_8"
                },
                [9] = {
                    label = "Pants (95-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_9"
                },
                [10] = {
                    label = "Pants (95-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_10"
                },
                [11] = {
                    label = "Pants (95-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_11"
                },
                [12] = {
                    label = "Pants (95-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_12"
                },
                [13] = {
                    label = "Pants (95-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_13"
                },
                [14] = {
                    label = "Pants (95-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_14"
                },
                [15] = {
                    label = "Pants (95-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_15"
                },
                [16] = {
                    label = "Pants (95-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_16"
                },
                [17] = {
                    label = "Pants (95-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_17"
                },
                [18] = {
                    label = "Pants (95-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_18"
                },
                [19] = {
                    label = "Pants (95-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_95_19"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (96-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_96_0"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (97-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_0"
                },
                [1] = {
                    label = "Pants (97-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_1"
                },
                [2] = {
                    label = "Pants (97-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_2"
                },
                [3] = {
                    label = "Pants (97-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_3"
                },
                [4] = {
                    label = "Pants (97-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_4"
                },
                [5] = {
                    label = "Pants (97-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_5"
                },
                [6] = {
                    label = "Pants (97-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_6"
                },
                [7] = {
                    label = "Pants (97-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_7"
                },
                [8] = {
                    label = "Pants (97-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_8"
                },
                [9] = {
                    label = "Pants (97-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_9"
                },
                [10] = {
                    label = "Pants (97-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_10"
                },
                [11] = {
                    label = "Pants (97-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_11"
                },
                [12] = {
                    label = "Pants (97-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_12"
                },
                [13] = {
                    label = "Pants (97-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_13"
                },
                [14] = {
                    label = "Pants (97-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_14"
                },
                [15] = {
                    label = "Pants (97-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_15"
                },
                [16] = {
                    label = "Pants (97-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_16"
                },
                [17] = {
                    label = "Pants (97-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_17"
                },
                [18] = {
                    label = "Pants (97-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_18"
                },
                [19] = {
                    label = "Pants (97-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_19"
                },
                [20] = {
                    label = "Pants (97-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_20"
                },
                [21] = {
                    label = "Pants (97-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_21"
                },
                [22] = {
                    label = "Pants (97-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_22"
                },
                [23] = {
                    label = "Pants (97-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_23"
                },
                [24] = {
                    label = "Pants (97-24)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_24"
                },
                [25] = {
                    label = "Pants (97-25)",
                    price = 500,
                    type = "money",
                    image = "female_pants_97_25"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (98-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_0"
                },
                [1] = {
                    label = "Pants (98-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_1"
                },
                [2] = {
                    label = "Pants (98-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_2"
                },
                [3] = {
                    label = "Pants (98-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_3"
                },
                [4] = {
                    label = "Pants (98-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_4"
                },
                [5] = {
                    label = "Pants (98-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_5"
                },
                [6] = {
                    label = "Pants (98-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_6"
                },
                [7] = {
                    label = "Pants (98-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_7"
                },
                [8] = {
                    label = "Pants (98-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_8"
                },
                [9] = {
                    label = "Pants (98-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_9"
                },
                [10] = {
                    label = "Pants (98-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_10"
                },
                [11] = {
                    label = "Pants (98-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_98_11"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (99-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_99_0"
                },
                [1] = {
                    label = "Pants (99-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_99_1"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (100-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_0"
                },
                [1] = {
                    label = "Pants (100-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_1"
                },
                [2] = {
                    label = "Pants (100-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_2"
                },
                [3] = {
                    label = "Pants (100-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_3"
                },
                [4] = {
                    label = "Pants (100-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_4"
                },
                [5] = {
                    label = "Pants (100-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_5"
                },
                [6] = {
                    label = "Pants (100-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_6"
                },
                [7] = {
                    label = "Pants (100-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_7"
                },
                [8] = {
                    label = "Pants (100-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_8"
                },
                [9] = {
                    label = "Pants (100-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_9"
                },
                [10] = {
                    label = "Pants (100-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_10"
                },
                [11] = {
                    label = "Pants (100-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_11"
                },
                [12] = {
                    label = "Pants (100-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_12"
                },
                [13] = {
                    label = "Pants (100-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_13"
                },
                [14] = {
                    label = "Pants (100-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_14"
                },
                [15] = {
                    label = "Pants (100-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_15"
                },
                [16] = {
                    label = "Pants (100-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_16"
                },
                [17] = {
                    label = "Pants (100-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_17"
                },
                [18] = {
                    label = "Pants (100-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_18"
                },
                [19] = {
                    label = "Pants (100-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_19"
                },
                [20] = {
                    label = "Pants (100-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_20"
                },
                [21] = {
                    label = "Pants (100-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_21"
                },
                [22] = {
                    label = "Pants (100-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_22"
                },
                [23] = {
                    label = "Pants (100-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_23"
                },
                [24] = {
                    label = "Pants (100-24)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_24"
                },
                [25] = {
                    label = "Pants (100-25)",
                    price = 500,
                    type = "money",
                    image = "female_pants_100_25"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (101-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_0"
                },
                [1] = {
                    label = "Pants (101-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_1"
                },
                [2] = {
                    label = "Pants (101-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_2"
                },
                [3] = {
                    label = "Pants (101-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_3"
                },
                [4] = {
                    label = "Pants (101-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_4"
                },
                [5] = {
                    label = "Pants (101-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_5"
                },
                [6] = {
                    label = "Pants (101-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_6"
                },
                [7] = {
                    label = "Pants (101-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_7"
                },
                [8] = {
                    label = "Pants (101-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_8"
                },
                [9] = {
                    label = "Pants (101-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_9"
                },
                [10] = {
                    label = "Pants (101-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_10"
                },
                [11] = {
                    label = "Pants (101-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_11"
                },
                [12] = {
                    label = "Pants (101-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_12"
                },
                [13] = {
                    label = "Pants (101-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_13"
                },
                [14] = {
                    label = "Pants (101-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_14"
                },
                [15] = {
                    label = "Pants (101-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_15"
                },
                [16] = {
                    label = "Pants (101-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_16"
                },
                [17] = {
                    label = "Pants (101-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_17"
                },
                [18] = {
                    label = "Pants (101-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_18"
                },
                [19] = {
                    label = "Pants (101-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_19"
                },
                [20] = {
                    label = "Pants (101-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_20"
                },
                [21] = {
                    label = "Pants (101-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_21"
                },
                [22] = {
                    label = "Pants (101-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_22"
                },
                [23] = {
                    label = "Pants (101-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_23"
                },
                [24] = {
                    label = "Pants (101-24)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_24"
                },
                [25] = {
                    label = "Pants (101-25)",
                    price = 500,
                    type = "money",
                    image = "female_pants_101_25"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (102-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_0"
                },
                [1] = {
                    label = "Pants (102-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_1"
                },
                [2] = {
                    label = "Pants (102-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_2"
                },
                [3] = {
                    label = "Pants (102-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_3"
                },
                [4] = {
                    label = "Pants (102-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_4"
                },
                [5] = {
                    label = "Pants (102-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_5"
                },
                [6] = {
                    label = "Pants (102-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_6"
                },
                [7] = {
                    label = "Pants (102-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_7"
                },
                [8] = {
                    label = "Pants (102-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_8"
                },
                [9] = {
                    label = "Pants (102-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_9"
                },
                [10] = {
                    label = "Pants (102-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_10"
                },
                [11] = {
                    label = "Pants (102-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_11"
                },
                [12] = {
                    label = "Pants (102-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_12"
                },
                [13] = {
                    label = "Pants (102-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_13"
                },
                [14] = {
                    label = "Pants (102-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_14"
                },
                [15] = {
                    label = "Pants (102-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_15"
                },
                [16] = {
                    label = "Pants (102-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_16"
                },
                [17] = {
                    label = "Pants (102-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_17"
                },
                [18] = {
                    label = "Pants (102-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_18"
                },
                [19] = {
                    label = "Pants (102-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_19"
                },
                [20] = {
                    label = "Pants (102-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_102_20"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (103-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_0"
                },
                [1] = {
                    label = "Pants (103-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_1"
                },
                [2] = {
                    label = "Pants (103-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_2"
                },
                [3] = {
                    label = "Pants (103-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_3"
                },
                [4] = {
                    label = "Pants (103-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_4"
                },
                [5] = {
                    label = "Pants (103-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_5"
                },
                [6] = {
                    label = "Pants (103-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_103_6"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_0"
                },
                [1] = {
                    label = "White Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_1"
                },
                [2] = {
                    label = "Peach Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_2"
                },
                [3] = {
                    label = "Teal Motif Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_3"
                },
                [4] = {
                    label = "Green Motif Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_4"
                },
                [5] = {
                    label = "Fall Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_5"
                },
                [6] = {
                    label = "Orange Fall Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_6"
                },
                [7] = {
                    label = "Purple Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_7"
                },
                [8] = {
                    label = "White Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_8"
                },
                [9] = {
                    label = "Dark Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_9"
                },
                [10] = {
                    label = "Geometric Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_10"
                },
                [11] = {
                    label = "Abstract Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_11"
                },
                [12] = {
                    label = "Striped Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_12"
                },
                [13] = {
                    label = "Spotted Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_104_13"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (105-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_105_0"
                },
                [1] = {
                    label = "Pants (105-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_105_1"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Rust Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_0"
                },
                [1] = {
                    label = "Gray Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_1"
                },
                [2] = {
                    label = "Yellow Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_2"
                },
                [3] = {
                    label = "White Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_3"
                },
                [4] = {
                    label = "Bright Red Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_4"
                },
                [5] = {
                    label = "Green Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_5"
                },
                [6] = {
                    label = "Caramel Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_6"
                },
                [7] = {
                    label = "Blue Leather Zippers",
                    price = 500,
                    type = "money",
                    image = "female_pants_106_7"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mustard Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_0"
                },
                [1] = {
                    label = "Navy Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_1"
                },
                [2] = {
                    label = "Tan Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_2"
                },
                [3] = {
                    label = "Grayscale Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_3"
                },
                [4] = {
                    label = "Burgundy Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_4"
                },
                [5] = {
                    label = "Criss Cross Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_5"
                },
                [6] = {
                    label = "Neon Painted Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_6"
                },
                [7] = {
                    label = "Navy Painted Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_7"
                },
                [8] = {
                    label = "Sunrise Pattern Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_8"
                },
                [9] = {
                    label = "Azure Pattern Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_9"
                },
                [10] = {
                    label = "Tropical Pattern Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_10"
                },
                [11] = {
                    label = "Green Leaves Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_107_11"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Gradient Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_0"
                },
                [1] = {
                    label = "Blue & Gold Gradient Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_1"
                },
                [2] = {
                    label = "White Snakeskin Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_2"
                },
                [3] = {
                    label = "Gold Snakeskin Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_3"
                },
                [4] = {
                    label = "Leopard Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_4"
                },
                [5] = {
                    label = "Pink Leopard Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_5"
                },
                [6] = {
                    label = "Blue Floral Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_6"
                },
                [7] = {
                    label = "Gold Floral Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_7"
                },
                [8] = {
                    label = "Pink & Gold Gradient Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_8"
                },
                [9] = {
                    label = "Blue & Gray Gradient Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_9"
                },
                [10] = {
                    label = "Pink & Blue Gradient Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_10"
                },
                [11] = {
                    label = "Multicolor Stripes Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_11"
                },
                [12] = {
                    label = "Dark Floral Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_12"
                },
                [13] = {
                    label = "Teal Floral Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_13"
                },
                [14] = {
                    label = "Gold SN Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_14"
                },
                [15] = {
                    label = "White SN Sequin",
                    price = 500,
                    type = "money",
                    image = "female_pants_108_15"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_0"
                },
                [1] = {
                    label = "Gray Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_1"
                },
                [2] = {
                    label = "White Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_2"
                },
                [3] = {
                    label = "Brown Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_3"
                },
                [4] = {
                    label = "Tan Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_4"
                },
                [5] = {
                    label = "Beige Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_5"
                },
                [6] = {
                    label = "Gray Camo Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_6"
                },
                [7] = {
                    label = "Green Camo Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_7"
                },
                [8] = {
                    label = "Dark Woodland Chain Paints",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_8"
                },
                [9] = {
                    label = "Cobble Chain Paints",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_9"
                },
                [10] = {
                    label = "Green Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_10"
                },
                [11] = {
                    label = "Beige Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_11"
                },
                [12] = {
                    label = "Gray Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_12"
                },
                [13] = {
                    label = "Tan Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_13"
                },
                [14] = {
                    label = "Pants (109-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_14"
                },
                [15] = {
                    label = "Pants (109-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_15"
                },
                [16] = {
                    label = "Pants (109-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_16"
                },
                [17] = {
                    label = "Pants (109-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_109_17"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_0"
                },
                [1] = {
                    label = "Gray Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_1"
                },
                [2] = {
                    label = "White Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_2"
                },
                [3] = {
                    label = "Brown Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_3"
                },
                [4] = {
                    label = "Tan Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_4"
                },
                [5] = {
                    label = "Beige Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_5"
                },
                [6] = {
                    label = "Gray Camo Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_6"
                },
                [7] = {
                    label = "Green Camo Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_7"
                },
                [8] = {
                    label = "Dark Woodland Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_8"
                },
                [9] = {
                    label = "Cobble Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_9"
                },
                [10] = {
                    label = "Green Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_10"
                },
                [11] = {
                    label = "Beige Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_11"
                },
                [12] = {
                    label = "Gray Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_12"
                },
                [13] = {
                    label = "Tan Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_13"
                },
                [14] = {
                    label = "Pants (110-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_14"
                },
                [15] = {
                    label = "Pants (110-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_15"
                },
                [16] = {
                    label = "Pants (110-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_16"
                },
                [17] = {
                    label = "Pants (110-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_110_17"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (111-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_111_0"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_0"
                },
                [1] = {
                    label = "Black & Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_1"
                },
                [2] = {
                    label = "White Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_2"
                },
                [3] = {
                    label = "Dark Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_3"
                },
                [4] = {
                    label = "Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_4"
                },
                [5] = {
                    label = "Blue Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_5"
                },
                [6] = {
                    label = "Moss Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_6"
                },
                [7] = {
                    label = "Gray Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_7"
                },
                [8] = {
                    label = "Brown Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_8"
                },
                [9] = {
                    label = "Orange Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_9"
                },
                [10] = {
                    label = "Ash Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_10"
                },
                [11] = {
                    label = "Magenta Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_112_11"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (113-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_0"
                },
                [1] = {
                    label = "Pants (113-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_1"
                },
                [2] = {
                    label = "Pants (113-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_2"
                },
                [3] = {
                    label = "Pants (113-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_3"
                },
                [4] = {
                    label = "Pants (113-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_4"
                },
                [5] = {
                    label = "Pants (113-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_5"
                },
                [6] = {
                    label = "Pants (113-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_6"
                },
                [7] = {
                    label = "Pants (113-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_7"
                },
                [8] = {
                    label = "Pants (113-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_8"
                },
                [9] = {
                    label = "Pants (113-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_9"
                },
                [10] = {
                    label = "Pants (113-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_10"
                },
                [11] = {
                    label = "Pants (113-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_11"
                },
                [12] = {
                    label = "Pants (113-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_12"
                },
                [13] = {
                    label = "Pants (113-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_13"
                },
                [14] = {
                    label = "Pants (113-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_14"
                },
                [15] = {
                    label = "Pants (113-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_15"
                },
                [16] = {
                    label = "Pants (113-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_16"
                },
                [17] = {
                    label = "Pants (113-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_17"
                },
                [18] = {
                    label = "Pants (113-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_18"
                },
                [19] = {
                    label = "Pants (113-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_113_19"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_0"
                },
                [1] = {
                    label = "Black Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_1"
                },
                [2] = {
                    label = "Green Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_2"
                },
                [3] = {
                    label = "Beige Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_3"
                },
                [4] = {
                    label = "Blue Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_4"
                },
                [5] = {
                    label = "Green Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_5"
                },
                [6] = {
                    label = "White Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_6"
                },
                [7] = {
                    label = "Crosshatch Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_7"
                },
                [8] = {
                    label = "Yellow Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_8"
                },
                [9] = {
                    label = "Black & White Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_9"
                },
                [10] = {
                    label = "Red Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_10"
                },
                [11] = {
                    label = "Blue Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_11"
                },
                [12] = {
                    label = "Pants (114-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_12"
                },
                [13] = {
                    label = "Pants (114-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_13"
                },
                [14] = {
                    label = "Pants (114-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_14"
                },
                [15] = {
                    label = "Pants (114-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_114_15"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (115-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_0"
                },
                [1] = {
                    label = "Pants (115-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_1"
                },
                [2] = {
                    label = "Pants (115-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_2"
                },
                [3] = {
                    label = "Pants (115-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_3"
                },
                [4] = {
                    label = "Pants (115-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_4"
                },
                [5] = {
                    label = "Pants (115-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_5"
                },
                [6] = {
                    label = "Pants (115-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_6"
                },
                [7] = {
                    label = "Pants (115-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_7"
                },
                [8] = {
                    label = "Pants (115-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_8"
                },
                [9] = {
                    label = "Pants (115-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_9"
                },
                [10] = {
                    label = "Pants (115-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_10"
                },
                [11] = {
                    label = "Pants (115-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_115_11"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (116-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_0"
                },
                [1] = {
                    label = "Pants (116-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_1"
                },
                [2] = {
                    label = "Pants (116-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_2"
                },
                [3] = {
                    label = "Pants (116-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_3"
                },
                [4] = {
                    label = "Pants (116-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_4"
                },
                [5] = {
                    label = "Pants (116-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_5"
                },
                [6] = {
                    label = "Pants (116-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_6"
                },
                [7] = {
                    label = "Pants (116-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_7"
                },
                [8] = {
                    label = "Pants (116-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_8"
                },
                [9] = {
                    label = "Pants (116-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_9"
                },
                [10] = {
                    label = "Pants (116-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_10"
                },
                [11] = {
                    label = "Pants (116-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_11"
                },
                [12] = {
                    label = "Pants (116-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_12"
                },
                [13] = {
                    label = "Pants (116-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_13"
                },
                [14] = {
                    label = "Pants (116-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_14"
                },
                [15] = {
                    label = "Pants (116-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_15"
                },
                [16] = {
                    label = "Pants (116-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_16"
                },
                [17] = {
                    label = "Pants (116-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_116_17"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (117-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_0"
                },
                [1] = {
                    label = "Pants (117-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_1"
                },
                [2] = {
                    label = "Pants (117-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_2"
                },
                [3] = {
                    label = "Pants (117-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_3"
                },
                [4] = {
                    label = "Pants (117-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_4"
                },
                [5] = {
                    label = "Pants (117-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_5"
                },
                [6] = {
                    label = "Pants (117-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_6"
                },
                [7] = {
                    label = "Pants (117-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_7"
                },
                [8] = {
                    label = "Pants (117-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_8"
                },
                [9] = {
                    label = "Pants (117-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_9"
                },
                [10] = {
                    label = "Pants (117-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_10"
                },
                [11] = {
                    label = "Pants (117-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_117_11"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (118-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_118_0"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (119-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_119_0"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (120-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_120_0"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (121-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_0"
                },
                [1] = {
                    label = "Pants (121-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_1"
                },
                [2] = {
                    label = "Pants (121-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_2"
                },
                [3] = {
                    label = "Pants (121-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_3"
                },
                [4] = {
                    label = "Pants (121-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_4"
                },
                [5] = {
                    label = "Pants (121-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_5"
                },
                [6] = {
                    label = "Pants (121-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_6"
                },
                [7] = {
                    label = "Pants (121-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_7"
                },
                [8] = {
                    label = "Pants (121-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_8"
                },
                [9] = {
                    label = "Pants (121-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_9"
                },
                [10] = {
                    label = "Pants (121-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_10"
                },
                [11] = {
                    label = "Pants (121-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_11"
                },
                [12] = {
                    label = "Pants (121-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_12"
                },
                [13] = {
                    label = "Pants (121-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_121_13"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (122-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_122_0"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_0"
                },
                [1] = {
                    label = "Blue Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_1"
                },
                [2] = {
                    label = "White Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_2"
                },
                [3] = {
                    label = "Black Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_3"
                },
                [4] = {
                    label = "Adorned Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_4"
                },
                [5] = {
                    label = "Snake Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_5"
                },
                [6] = {
                    label = "White SC Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_6"
                },
                [7] = {
                    label = "Black SC Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_7"
                },
                [8] = {
                    label = "Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_8"
                },
                [9] = {
                    label = "Purple Painted Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_9"
                },
                [10] = {
                    label = "Black Painted Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_123_10"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_0"
                },
                [1] = {
                    label = "Teal Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_1"
                },
                [2] = {
                    label = "Blue Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_2"
                },
                [3] = {
                    label = "Blue P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_3"
                },
                [4] = {
                    label = "White P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_4"
                },
                [5] = {
                    label = "Black P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_5"
                },
                [6] = {
                    label = "Black E Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_6"
                },
                [7] = {
                    label = "White Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_7"
                },
                [8] = {
                    label = "Purple Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_8"
                },
                [9] = {
                    label = "Red Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_9"
                },
                [10] = {
                    label = "Teal SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_10"
                },
                [11] = {
                    label = "Blue Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_11"
                },
                [12] = {
                    label = "Black Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_12"
                },
                [13] = {
                    label = "White SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_13"
                },
                [14] = {
                    label = "Black Vinewood Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_14"
                },
                [15] = {
                    label = "Pink Vinewood Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_15"
                },
                [16] = {
                    label = "Gray Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_16"
                },
                [17] = {
                    label = "Green Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_17"
                },
                [18] = {
                    label = "Blue Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_18"
                },
                [19] = {
                    label = "Yellow Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_19"
                },
                [20] = {
                    label = "Gray Blagueurs Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_20"
                },
                [21] = {
                    label = "Gray Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_21"
                },
                [22] = {
                    label = "Blue Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_22"
                },
                [23] = {
                    label = "Orange Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_23"
                },
                [24] = {
                    label = "Pink Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_24"
                },
                [25] = {
                    label = "Black SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_124_25"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (125-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_0"
                },
                [1] = {
                    label = "Pants (125-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_1"
                },
                [2] = {
                    label = "Pants (125-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_2"
                },
                [3] = {
                    label = "Pants (125-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_3"
                },
                [4] = {
                    label = "Pants (125-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_4"
                },
                [5] = {
                    label = "Pants (125-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_5"
                },
                [6] = {
                    label = "Pants (125-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_6"
                },
                [7] = {
                    label = "Pants (125-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_7"
                },
                [8] = {
                    label = "Pants (125-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_8"
                },
                [9] = {
                    label = "Pants (125-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_9"
                },
                [10] = {
                    label = "Pants (125-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_125_10"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (126-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_126_0"
                },
                [1] = {
                    label = "Pants (126-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_126_1"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (127-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_127_0"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Correctional Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_128_0"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Correctional Cargo",
                    price = 500,
                    type = "money",
                    image = "female_pants_129_0"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_0"
                },
                [1] = {
                    label = "Black Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_1"
                },
                [2] = {
                    label = "Dark Gray Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_2"
                },
                [3] = {
                    label = "Beige Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_3"
                },
                [4] = {
                    label = "Cream Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_4"
                },
                [5] = {
                    label = "Forest Green Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_5"
                },
                [6] = {
                    label = "Pants (130-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_6"
                },
                [7] = {
                    label = "Pants (130-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_7"
                },
                [8] = {
                    label = "Pants (130-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_8"
                },
                [9] = {
                    label = "Pants (130-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_9"
                },
                [10] = {
                    label = "Blue Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_10"
                },
                [11] = {
                    label = "Splinter Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_11"
                },
                [12] = {
                    label = "Contrast Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_12"
                },
                [13] = {
                    label = "Green Digital Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_13"
                },
                [14] = {
                    label = "Desert Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_14"
                },
                [15] = {
                    label = "Woodland Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_15"
                },
                [16] = {
                    label = "Forest Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_16"
                },
                [17] = {
                    label = "Blue Digital Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_17"
                },
                [18] = {
                    label = "Cobble Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_18"
                },
                [19] = {
                    label = "Beige Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_130_19"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Gray Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_0"
                },
                [1] = {
                    label = "Black Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_1"
                },
                [2] = {
                    label = "Charcoal Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_2"
                },
                [3] = {
                    label = "Beige Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_3"
                },
                [4] = {
                    label = "White Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_4"
                },
                [5] = {
                    label = "Forest Green Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_5"
                },
                [6] = {
                    label = "Pants (131-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_6"
                },
                [7] = {
                    label = "Pants (131-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_7"
                },
                [8] = {
                    label = "Pants (131-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_8"
                },
                [9] = {
                    label = "Pants (131-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_9"
                },
                [10] = {
                    label = "Blue Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_10"
                },
                [11] = {
                    label = "Splinter Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_11"
                },
                [12] = {
                    label = "Contrast Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_12"
                },
                [13] = {
                    label = "Green Digital Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_13"
                },
                [14] = {
                    label = "Desert Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_14"
                },
                [15] = {
                    label = "Woodland Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_15"
                },
                [16] = {
                    label = "Forest Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_16"
                },
                [17] = {
                    label = "Blue Digital Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_17"
                },
                [18] = {
                    label = "Cobble Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_18"
                },
                [19] = {
                    label = "Beige Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_131_19"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (132-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_132_0"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_0"
                },
                [1] = {
                    label = "Gray Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_1"
                },
                [2] = {
                    label = "Navy Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_2"
                },
                [3] = {
                    label = "White Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_3"
                },
                [4] = {
                    label = "Blue Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_4"
                },
                [5] = {
                    label = "Purple Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_5"
                },
                [6] = {
                    label = "Cyan Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_6"
                },
                [7] = {
                    label = "Patterned Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_7"
                },
                [8] = {
                    label = "Olive Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_8"
                },
                [9] = {
                    label = "Yellow Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_9"
                },
                [10] = {
                    label = "Red Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_10"
                },
                [11] = {
                    label = "Pink Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_11"
                },
                [12] = {
                    label = "Magenta Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_12"
                },
                [13] = {
                    label = "Black & Cream Stripe Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_13"
                },
                [14] = {
                    label = "Dark Red Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_14"
                },
                [15] = {
                    label = "Black & White Stripe Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_15"
                },
                [16] = {
                    label = "Cream Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_16"
                },
                [17] = {
                    label = "Slate Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_17"
                },
                [18] = {
                    label = "Powder Blue Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_18"
                },
                [19] = {
                    label = "Ash Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_19"
                },
                [20] = {
                    label = "Tan Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_20"
                },
                [21] = {
                    label = "Wine Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_21"
                },
                [22] = {
                    label = "Dark Blue Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_22"
                },
                [23] = {
                    label = "Midnight Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_23"
                },
                [24] = {
                    label = "Green Slacks",
                    price = 500,
                    type = "money",
                    image = "female_pants_133_24"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cream Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_0"
                },
                [1] = {
                    label = "Gray Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_1"
                },
                [2] = {
                    label = "Mustard Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_2"
                },
                [3] = {
                    label = "Purple Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_3"
                },
                [4] = {
                    label = "Orange Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_4"
                },
                [5] = {
                    label = "Pink Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_5"
                },
                [6] = {
                    label = "White Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_6"
                },
                [7] = {
                    label = "Cyan Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_7"
                },
                [8] = {
                    label = "Stone Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_8"
                },
                [9] = {
                    label = "Blue Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_9"
                },
                [10] = {
                    label = "Ash Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_10"
                },
                [11] = {
                    label = "Cyan Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_11"
                },
                [12] = {
                    label = "Black Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_12"
                },
                [13] = {
                    label = "Crimson Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_13"
                },
                [14] = {
                    label = "Navy Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_14"
                },
                [15] = {
                    label = "Blue DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_15"
                },
                [16] = {
                    label = "Red DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_16"
                },
                [17] = {
                    label = "Yellow DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_17"
                },
                [18] = {
                    label = "Dark Stone Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_18"
                },
                [19] = {
                    label = "Snow Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_19"
                },
                [20] = {
                    label = "Smoke Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_20"
                },
                [21] = {
                    label = "Pants (134-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_21"
                },
                [22] = {
                    label = "Pants (134-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_22"
                },
                [23] = {
                    label = "Pants (134-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_23"
                },
                [24] = {
                    label = "Pants (134-24)",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_24"
                },
                [25] = {
                    label = "Lemon Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_134_25"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_0"
                },
                [1] = {
                    label = "Black Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_1"
                },
                [2] = {
                    label = "Khaki Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_2"
                },
                [3] = {
                    label = "Dark Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_3"
                },
                [4] = {
                    label = "Light Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_4"
                },
                [5] = {
                    label = "Stone Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_5"
                },
                [6] = {
                    label = "Ash Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_6"
                },
                [7] = {
                    label = "Blue Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_135_7"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_0"
                },
                [1] = {
                    label = "Black Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_1"
                },
                [2] = {
                    label = "Khaki Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_2"
                },
                [3] = {
                    label = "Dark Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_3"
                },
                [4] = {
                    label = "Light Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_4"
                },
                [5] = {
                    label = "Stone Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_5"
                },
                [6] = {
                    label = "Ash Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_6"
                },
                [7] = {
                    label = "Blue Large Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_136_7"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_0"
                },
                [1] = {
                    label = "Gray Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_1"
                },
                [2] = {
                    label = "Dark Gray Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_2"
                },
                [3] = {
                    label = "Tan Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_3"
                },
                [4] = {
                    label = "Navy Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_4"
                },
                [5] = {
                    label = "Brown Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_5"
                },
                [6] = {
                    label = "Charcoal Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_6"
                },
                [7] = {
                    label = "Yellow Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_7"
                },
                [8] = {
                    label = "Silver Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_8"
                },
                [9] = {
                    label = "Baby Blue Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_9"
                },
                [10] = {
                    label = "White Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_10"
                },
                [11] = {
                    label = "Light Gray Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_11"
                },
                [12] = {
                    label = "Green Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_12"
                },
                [13] = {
                    label = "Brown Plaid Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_13"
                },
                [14] = {
                    label = "Red Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_14"
                },
                [15] = {
                    label = "Olive Chino Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_137_15"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bigness Tie-dye Sports Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_138_0"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Prolaps Basketball Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_139_0"
                },
                [1] = {
                    label = "Panic Prolaps Basketball Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_139_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Sports Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_139_2"
                },
                [3] = {
                    label = "Pants (139-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_139_3"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (140-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_140_0"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (141-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_141_0"
                },
                [1] = {
                    label = "Pants (141-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_141_1"
                },
                [2] = {
                    label = "Pants (141-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_141_2"
                },
                [3] = {
                    label = "Pants (141-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_141_3"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (142-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_142_0"
                },
                [1] = {
                    label = "Pants (142-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_142_1"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (143-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_143_0"
                },
                [1] = {
                    label = "Pants (143-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_143_1"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (144-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_0"
                },
                [1] = {
                    label = "Pants (144-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_1"
                },
                [2] = {
                    label = "Pants (144-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_2"
                },
                [3] = {
                    label = "Pants (144-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_3"
                },
                [4] = {
                    label = "Pants (144-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_4"
                },
                [5] = {
                    label = "Pants (144-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_5"
                },
                [6] = {
                    label = "Pants (144-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_6"
                },
                [7] = {
                    label = "Pants (144-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_144_7"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_0"
                },
                [1] = {
                    label = "Black Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_1"
                },
                [2] = {
                    label = "Gray Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_2"
                },
                [3] = {
                    label = "Beige Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_3"
                },
                [4] = {
                    label = "Navy Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_4"
                },
                [5] = {
                    label = "Dark Nut Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_5"
                },
                [6] = {
                    label = "Dark Green Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_6"
                },
                [7] = {
                    label = "Red FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_7"
                },
                [8] = {
                    label = "Green FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_8"
                },
                [9] = {
                    label = "Blue FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_9"
                },
                [10] = {
                    label = "Pink VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_10"
                },
                [11] = {
                    label = "Yellow VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_11"
                },
                [12] = {
                    label = "Blue VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_12"
                },
                [13] = {
                    label = "Black Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_13"
                },
                [14] = {
                    label = "Cyan Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_14"
                },
                [15] = {
                    label = "Yellow Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_15"
                },
                [16] = {
                    label = "Pink Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_16"
                },
                [17] = {
                    label = "Purple Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_17"
                },
                [18] = {
                    label = "Pink Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_18"
                },
                [19] = {
                    label = "Patchwork Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_19"
                },
                [20] = {
                    label = "Blues Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_20"
                },
                [21] = {
                    label = "Squash Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_21"
                },
                [22] = {
                    label = "Hiding Print Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_22"
                },
                [23] = {
                    label = "Never Triangle Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_23"
                },
                [24] = {
                    label = "Life Static Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_24"
                },
                [25] = {
                    label = "Black Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_145_25"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_0"
                },
                [1] = {
                    label = "Red Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_1"
                },
                [2] = {
                    label = "White Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_2"
                },
                [3] = {
                    label = "Smoke Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_3"
                },
                [4] = {
                    label = "Sunrise Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_4"
                },
                [5] = {
                    label = "Sunset Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_5"
                },
                [6] = {
                    label = "Pink Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_6"
                },
                [7] = {
                    label = "Yellow Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_7"
                },
                [8] = {
                    label = "Earth Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_8"
                },
                [9] = {
                    label = "Green Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_9"
                },
                [10] = {
                    label = "Green Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_10"
                },
                [11] = {
                    label = "Pink Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_11"
                },
                [12] = {
                    label = "Blue Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_12"
                },
                [13] = {
                    label = "Black Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_13"
                },
                [14] = {
                    label = "Sea Green Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_14"
                },
                [15] = {
                    label = "Yellow Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_15"
                },
                [16] = {
                    label = "Salmon Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_16"
                },
                [17] = {
                    label = "Orange Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_17"
                },
                [18] = {
                    label = "Blue Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_18"
                },
                [19] = {
                    label = "Chocolate Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_19"
                },
                [20] = {
                    label = "Purple Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_20"
                },
                [21] = {
                    label = "Light Brown Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_21"
                },
                [22] = {
                    label = "Lime Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_22"
                },
                [23] = {
                    label = "Mustard Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_23"
                },
                [24] = {
                    label = "Black Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_24"
                },
                [25] = {
                    label = "White Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_146_25"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Teal Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_147_0"
                },
                [1] = {
                    label = "Red Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_147_1"
                },
                [2] = {
                    label = "Yellow Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_147_2"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_0"
                },
                [1] = {
                    label = "Gray Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_1"
                },
                [2] = {
                    label = "Ash Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_2"
                },
                [3] = {
                    label = "White Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_3"
                },
                [4] = {
                    label = "Beige Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_4"
                },
                [5] = {
                    label = "Navy Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_5"
                },
                [6] = {
                    label = "Dark Nut Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_6"
                },
                [7] = {
                    label = "Green SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_7"
                },
                [8] = {
                    label = "Beige SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_8"
                },
                [9] = {
                    label = "Navy SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_9"
                },
                [10] = {
                    label = "Red SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_10"
                },
                [11] = {
                    label = "Green SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_11"
                },
                [12] = {
                    label = "Beige SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_12"
                },
                [13] = {
                    label = "Navy SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_13"
                },
                [14] = {
                    label = "Red SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_14"
                },
                [15] = {
                    label = "Green FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_15"
                },
                [16] = {
                    label = "Beige FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_16"
                },
                [17] = {
                    label = "Blue FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_17"
                },
                [18] = {
                    label = "White Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_18"
                },
                [19] = {
                    label = "Black Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_19"
                },
                [20] = {
                    label = "Blue Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_20"
                },
                [21] = {
                    label = "Electric Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_21"
                },
                [22] = {
                    label = "Gray Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_22"
                },
                [23] = {
                    label = "Aqua Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_23"
                },
                [24] = {
                    label = "Orange Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_24"
                },
                [25] = {
                    label = "Green Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_148_25"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Peach Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_0"
                },
                [1] = {
                    label = "Black Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_1"
                },
                [2] = {
                    label = "Peach Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_2"
                },
                [3] = {
                    label = "Green Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_3"
                },
                [4] = {
                    label = "Rose Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_4"
                },
                [5] = {
                    label = "Aqua Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_5"
                },
                [6] = {
                    label = "Black Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_6"
                },
                [7] = {
                    label = "Aqua Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_7"
                },
                [8] = {
                    label = "Red Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_8"
                },
                [9] = {
                    label = "Green Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_9"
                },
                [10] = {
                    label = "Peach Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_10"
                },
                [11] = {
                    label = "Black Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_11"
                },
                [12] = {
                    label = "Gray Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_12"
                },
                [13] = {
                    label = "Orange Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_13"
                },
                [14] = {
                    label = "Zest Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_14"
                },
                [15] = {
                    label = "Brown Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_15"
                },
                [16] = {
                    label = "Pastel Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_16"
                },
                [17] = {
                    label = "Charcoal Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_17"
                },
                [18] = {
                    label = "Navy Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_18"
                },
                [19] = {
                    label = "Brown Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_19"
                },
                [20] = {
                    label = "Gray Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_20"
                },
                [21] = {
                    label = "Russet Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_149_21"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_0"
                },
                [1] = {
                    label = "Gray Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_1"
                },
                [2] = {
                    label = "Ash Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_2"
                },
                [3] = {
                    label = "Ice Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_3"
                },
                [4] = {
                    label = "Beige Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_4"
                },
                [5] = {
                    label = "Olive Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_5"
                },
                [6] = {
                    label = "Purple Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_6"
                },
                [7] = {
                    label = "Light VDG Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_7"
                },
                [8] = {
                    label = "Dark VDG Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_8"
                },
                [9] = {
                    label = "Black VDG Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_9"
                },
                [10] = {
                    label = "Gray Nature Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_10"
                },
                [11] = {
                    label = "Yellow Nature Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_11"
                },
                [12] = {
                    label = "Gray Broker Cash Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_12"
                },
                [13] = {
                    label = "Pink Broker Cash Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_13"
                },
                [14] = {
                    label = "Dark Paint G&B Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_14"
                },
                [15] = {
                    label = "Light Paint G&B Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_15"
                },
                [16] = {
                    label = "Gray Barfs Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_16"
                },
                [17] = {
                    label = "Purple Barfs Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_17"
                },
                [18] = {
                    label = "Smoke Broker Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_18"
                },
                [19] = {
                    label = "Green Broker Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_19"
                },
                [20] = {
                    label = "Red Crevis Woodland Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_20"
                },
                [21] = {
                    label = "Tan Crevis Woodland Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_21"
                },
                [22] = {
                    label = "Blue Güffy Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_22"
                },
                [23] = {
                    label = "Pink Güffy Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_23"
                },
                [24] = {
                    label = "Blue Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_24"
                },
                [25] = {
                    label = "Midnight Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "female_pants_150_25"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green UFO Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_151_0"
                },
                [1] = {
                    label = "White UFO Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_151_1"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (152-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_0"
                },
                [1] = {
                    label = "Gray Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_1"
                },
                [2] = {
                    label = "Charcoal Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_2"
                },
                [3] = {
                    label = "Black Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_3"
                },
                [4] = {
                    label = "Indigo Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_4"
                },
                [5] = {
                    label = "Light Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_5"
                },
                [6] = {
                    label = "Stonewash Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_6"
                },
                [7] = {
                    label = "Standard Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_7"
                },
                [8] = {
                    label = "Classic Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_8"
                },
                [9] = {
                    label = "Dark Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_9"
                },
                [10] = {
                    label = "Faded White Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_10"
                },
                [11] = {
                    label = "Faded Charcoal Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_11"
                },
                [12] = {
                    label = "Faded Classic Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_12"
                },
                [13] = {
                    label = "Faded Standard Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_13"
                },
                [14] = {
                    label = "Faded Dark Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_14"
                },
                [15] = {
                    label = "Faded Indigo Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_15"
                },
                [16] = {
                    label = "Faded Stonewash Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_16"
                },
                [17] = {
                    label = "Faded Light Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_17"
                },
                [18] = {
                    label = "Burgundy Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_18"
                },
                [19] = {
                    label = "Orange Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_19"
                },
                [20] = {
                    label = "Amber Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_20"
                },
                [21] = {
                    label = "Lemon Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_21"
                },
                [22] = {
                    label = "Lavender Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_22"
                },
                [23] = {
                    label = "Moss Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_23"
                },
                [24] = {
                    label = "Peach Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_24"
                },
                [25] = {
                    label = "Pink Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_153_25"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ash Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_0"
                },
                [1] = {
                    label = "Gray Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_1"
                },
                [2] = {
                    label = "Dark Gray Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_2"
                },
                [3] = {
                    label = "Black Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_3"
                },
                [4] = {
                    label = "Standard Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_4"
                },
                [5] = {
                    label = "Classic Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_5"
                },
                [6] = {
                    label = "Light Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_6"
                },
                [7] = {
                    label = "Stonewash Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_7"
                },
                [8] = {
                    label = "Dark Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_8"
                },
                [9] = {
                    label = "Indigo Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_9"
                },
                [10] = {
                    label = "Faded Gray Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_10"
                },
                [11] = {
                    label = "Faded Dark Gray Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_11"
                },
                [12] = {
                    label = "Faded Dark Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_12"
                },
                [13] = {
                    label = "Faded Standard Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_13"
                },
                [14] = {
                    label = "Faded Classic Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_14"
                },
                [15] = {
                    label = "Faded Stonewash Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_15"
                },
                [16] = {
                    label = "Faded Indigo Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_16"
                },
                [17] = {
                    label = "Faded Black Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_17"
                },
                [18] = {
                    label = "Burgundy Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_18"
                },
                [19] = {
                    label = "Orange Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_19"
                },
                [20] = {
                    label = "Amber Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_20"
                },
                [21] = {
                    label = "Lemon Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_21"
                },
                [22] = {
                    label = "Lavender Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_22"
                },
                [23] = {
                    label = "Moss Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_23"
                },
                [24] = {
                    label = "Peach Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_24"
                },
                [25] = {
                    label = "Pink Denim Skirt",
                    price = 500,
                    type = "money",
                    image = "female_pants_154_25"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_0"
                },
                [1] = {
                    label = "Dark Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_1"
                },
                [2] = {
                    label = "Light Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_2"
                },
                [3] = {
                    label = "White Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_3"
                },
                [4] = {
                    label = "Ox Blood Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_4"
                },
                [5] = {
                    label = "Scarlet Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_5"
                },
                [6] = {
                    label = "Green Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_6"
                },
                [7] = {
                    label = "Red Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_7"
                },
                [8] = {
                    label = "Orange Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_8"
                },
                [9] = {
                    label = "Amber Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_9"
                },
                [10] = {
                    label = "Chestnut Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_10"
                },
                [11] = {
                    label = "Pale Brown Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_11"
                },
                [12] = {
                    label = "Blue Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_12"
                },
                [13] = {
                    label = "Light Blue Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_13"
                },
                [14] = {
                    label = "Black & Red Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_14"
                },
                [15] = {
                    label = "Worn Dirty Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_15"
                },
                [16] = {
                    label = "Worn Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_16"
                },
                [17] = {
                    label = "Worn Dark Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_17"
                },
                [18] = {
                    label = "Worn Chestnut Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_18"
                },
                [19] = {
                    label = "Worn Charcoal Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_19"
                },
                [20] = {
                    label = "Worn Ox Blood Laced Leather",
                    price = 500,
                    type = "money",
                    image = "female_pants_155_20"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_0"
                },
                [1] = {
                    label = "Dark Gray Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_1"
                },
                [2] = {
                    label = "Gray Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_2"
                },
                [3] = {
                    label = "Ice Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_3"
                },
                [4] = {
                    label = "Beige Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_4"
                },
                [5] = {
                    label = "Chocolate Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_5"
                },
                [6] = {
                    label = "Burgundy Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_6"
                },
                [7] = {
                    label = "Hot Pink Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_7"
                },
                [8] = {
                    label = "Scarlet Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_8"
                },
                [9] = {
                    label = "Orange Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_9"
                },
                [10] = {
                    label = "Amber Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_10"
                },
                [11] = {
                    label = "Lemon Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_11"
                },
                [12] = {
                    label = "Royal Blue Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_12"
                },
                [13] = {
                    label = "Blue Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_13"
                },
                [14] = {
                    label = "Teal Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_14"
                },
                [15] = {
                    label = "Cyan Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_15"
                },
                [16] = {
                    label = "Light Blue Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_16"
                },
                [17] = {
                    label = "Lilac Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_17"
                },
                [18] = {
                    label = "Dark Green Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_18"
                },
                [19] = {
                    label = "Emerald Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_19"
                },
                [20] = {
                    label = "Moss Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_20"
                },
                [21] = {
                    label = "Lime Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_21"
                },
                [22] = {
                    label = "Peach Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_22"
                },
                [23] = {
                    label = "Lavender Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_23"
                },
                [24] = {
                    label = "Purple Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_24"
                },
                [25] = {
                    label = "Magenta Above Knee",
                    price = 500,
                    type = "money",
                    image = "female_pants_156_25"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_0"
                },
                [1] = {
                    label = "Gray Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_1"
                },
                [2] = {
                    label = "Charcoal Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_2"
                },
                [3] = {
                    label = "Black Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_3"
                },
                [4] = {
                    label = "Indigo Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_4"
                },
                [5] = {
                    label = "Light Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_5"
                },
                [6] = {
                    label = "Stonewash Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_6"
                },
                [7] = {
                    label = "Standard Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_7"
                },
                [8] = {
                    label = "Classic Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_8"
                },
                [9] = {
                    label = "Dark Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_9"
                },
                [10] = {
                    label = "Faded Gray Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_10"
                },
                [11] = {
                    label = "Faded Charcoal Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_11"
                },
                [12] = {
                    label = "Faded Black Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_12"
                },
                [13] = {
                    label = "Faded Indigo Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_13"
                },
                [14] = {
                    label = "Faded Stonewash Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_14"
                },
                [15] = {
                    label = "Faded Standard Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_15"
                },
                [16] = {
                    label = "Faded Classic Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_16"
                },
                [17] = {
                    label = "Faded Dark Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_17"
                },
                [18] = {
                    label = "Burgundy Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_18"
                },
                [19] = {
                    label = "Orange Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_19"
                },
                [20] = {
                    label = "Amber Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_20"
                },
                [21] = {
                    label = "Lemon Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_21"
                },
                [22] = {
                    label = "Lavender Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_22"
                },
                [23] = {
                    label = "Moss Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_23"
                },
                [24] = {
                    label = "Peach Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_24"
                },
                [25] = {
                    label = "Pink Turnups",
                    price = 500,
                    type = "money",
                    image = "female_pants_157_25"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (158-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_158_0"
                },
                [1] = {
                    label = "420 Smoking Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_158_1"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Yeti Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_159_0"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Checkerboard Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_160_0"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Checkerboard Cargos",
                    price = 500,
                    type = "money",
                    image = "female_pants_161_0"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (162-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_0"
                },
                [1] = {
                    label = "Pants (162-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_1"
                },
                [2] = {
                    label = "Pants (162-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_2"
                },
                [3] = {
                    label = "Pants (162-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_3"
                },
                [4] = {
                    label = "Pants (162-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_4"
                },
                [5] = {
                    label = "Pants (162-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_5"
                },
                [6] = {
                    label = "Pants (162-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_6"
                },
                [7] = {
                    label = "Pants (162-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_7"
                },
                [8] = {
                    label = "Pants (162-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_8"
                },
                [9] = {
                    label = "Pants (162-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_9"
                },
                [10] = {
                    label = "Pants (162-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_10"
                },
                [11] = {
                    label = "Pants (162-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_11"
                },
                [12] = {
                    label = "Pants (162-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_12"
                },
                [13] = {
                    label = "Pants (162-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_13"
                },
                [14] = {
                    label = "Pants (162-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_14"
                },
                [15] = {
                    label = "Pants (162-15)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_15"
                },
                [16] = {
                    label = "Pants (162-16)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_16"
                },
                [17] = {
                    label = "Pants (162-17)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_17"
                },
                [18] = {
                    label = "Pants (162-18)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_18"
                },
                [19] = {
                    label = "Pants (162-19)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_19"
                },
                [20] = {
                    label = "Pants (162-20)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_20"
                },
                [21] = {
                    label = "Pants (162-21)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_21"
                },
                [22] = {
                    label = "Pants (162-22)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_22"
                },
                [23] = {
                    label = "Pants (162-23)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_23"
                },
                [24] = {
                    label = "Pants (162-24)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_24"
                },
                [25] = {
                    label = "Pants (162-25)",
                    price = 500,
                    type = "money",
                    image = "female_pants_162_25"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Cimicino Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_0"
                },
                [1] = {
                    label = "Light Cimicino Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_1"
                },
                [2] = {
                    label = "Black DS Pantsher Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_2"
                },
                [3] = {
                    label = "Light DS Pantsher Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_3"
                },
                [4] = {
                    label = "Classic DS Tiger Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_4"
                },
                [5] = {
                    label = "Gray DS Tiger Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_5"
                },
                [6] = {
                    label = "Black Big Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_6"
                },
                [7] = {
                    label = "Light Big Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_7"
                },
                [8] = {
                    label = "Dark Small Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_8"
                },
                [9] = {
                    label = "Light Small Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_9"
                },
                [10] = {
                    label = "Classic FB Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_10"
                },
                [11] = {
                    label = "Gray FB Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_11"
                },
                [12] = {
                    label = "Black SC Coins Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_12"
                },
                [13] = {
                    label = "Light SC Coins Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_13"
                },
                [14] = {
                    label = "Light SC Dragon Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_14"
                },
                [15] = {
                    label = "Red SC Dragon Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_15"
                },
                [16] = {
                    label = "Light Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_16"
                },
                [17] = {
                    label = "Gray Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_17"
                },
                [18] = {
                    label = "Red Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "female_pants_163_18"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'component',
            textures = {
                [0] = {
                    label = "Zebra Bigness Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_1"
                },
                [2] = {
                    label = "Black Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_2"
                },
                [3] = {
                    label = "Blue Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_3"
                },
                [4] = {
                    label = "Red Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_4"
                },
                [5] = {
                    label = "White Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_5"
                },
                [6] = {
                    label = "Green Flames Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_6"
                },
                [7] = {
                    label = "Orange Flames Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_7"
                },
                [8] = {
                    label = "Pink Flames Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_8"
                },
                [9] = {
                    label = "Purple Flames Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_9"
                },
                [10] = {
                    label = "Red Flames Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_10"
                },
                [11] = {
                    label = "Blue Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_11"
                },
                [12] = {
                    label = "White Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_12"
                },
                [13] = {
                    label = "Green Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_13"
                },
                [14] = {
                    label = "Orange Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_14"
                },
                [15] = {
                    label = "Purple Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_15"
                },
                [16] = {
                    label = "Pink Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_16"
                },
                [17] = {
                    label = "Blue Marble Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_17"
                },
                [18] = {
                    label = "White Marble Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_18"
                },
                [19] = {
                    label = "Pink Marble Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_19"
                },
                [20] = {
                    label = "Blue Bones Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_20"
                },
                [21] = {
                    label = "Black Bones Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_21"
                },
                [22] = {
                    label = "Red Bones Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_22"
                },
                [23] = {
                    label = "Taupe Bones Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_23"
                },
                [24] = {
                    label = "Black Trickster Type Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_24"
                },
                [25] = {
                    label = "Orange Trickster Type Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_164_25"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_165_0"
                },
                [1] = {
                    label = "White VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_165_1"
                },
                [2] = {
                    label = "Blue Fade VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_165_2"
                },
                [3] = {
                    label = "Pink Fade VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "female_pants_165_3"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (166-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_166_0"
                },
                [1] = {
                    label = "Pants (166-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_166_1"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (167-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_167_0"
                },
                [1] = {
                    label = "Pants (167-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_167_1"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (168-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_168_0"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'component',
            textures = {
                [0] = {
                    label = "Zebra Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_0"
                },
                [1] = {
                    label = "Pink Zebra Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_1"
                },
                [2] = {
                    label = "Black Blagueurs Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_2"
                },
                [3] = {
                    label = "Blue Blagueurs Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_3"
                },
                [4] = {
                    label = "Red Blagueurs Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_4"
                },
                [5] = {
                    label = "White Blagueurs Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_5"
                },
                [6] = {
                    label = "Black Enema Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_6"
                },
                [7] = {
                    label = "Cyan Enema Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_7"
                },
                [8] = {
                    label = "Magenta Enema Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_8"
                },
                [9] = {
                    label = "Green Flames Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_9"
                },
                [10] = {
                    label = "Orange Flames Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_10"
                },
                [11] = {
                    label = "Pink Flames Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_11"
                },
                [12] = {
                    label = "Purple Flames Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_12"
                },
                [13] = {
                    label = "Red Flames Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_13"
                },
                [14] = {
                    label = "Blue Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_14"
                },
                [15] = {
                    label = "Gray Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_15"
                },
                [16] = {
                    label = "Green Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_16"
                },
                [17] = {
                    label = "Orange Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_17"
                },
                [18] = {
                    label = "Purple Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_18"
                },
                [19] = {
                    label = "Red Lightning Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_19"
                },
                [20] = {
                    label = "Blue Marble Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_20"
                },
                [21] = {
                    label = "White Marble Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_21"
                },
                [22] = {
                    label = "Pink Marble Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_22"
                },
                [23] = {
                    label = "Wine Red SD Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_23"
                },
                [24] = {
                    label = "Yellow SD Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_24"
                },
                [25] = {
                    label = "Camo Yeti Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_169_25"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Camo Yeti Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_170_0"
                },
                [1] = {
                    label = "Pink Camo Yeti Mini",
                    price = 500,
                    type = "money",
                    image = "female_pants_170_1"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (171-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_171_0"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'component',
            textures = {
                [0] = {
                    label = "PRB Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_172_0"
                },
                [1] = {
                    label = "Bleedin' Tasty Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_172_1"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "female_pants_173_0"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'component',
            textures = {
                [0] = {
                    label = "Santo Capra x Manor Chinos",
                    price = 500,
                    type = "money",
                    image = "female_pants_174_0"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (175-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_175_0"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (176-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_176_0"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (177-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_177_0"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (178-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_178_0"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'component',
            textures = {
                [0] = {
                    label = "Hinterland Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_179_0"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (180-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_180_0"
                },
                [1] = {
                    label = "Pants (180-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_180_1"
                },
                [2] = {
                    label = "Pants (180-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_180_2"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (181-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_181_0"
                },
                [1] = {
                    label = "Pants (181-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_181_1"
                },
                [2] = {
                    label = "Pants (181-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_181_2"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_0"
                },
                [1] = {
                    label = "Dark Gray Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_1"
                },
                [2] = {
                    label = "Gray Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_2"
                },
                [3] = {
                    label = "Ice Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_3"
                },
                [4] = {
                    label = "Beige Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_4"
                },
                [5] = {
                    label = "Chocolate Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_5"
                },
                [6] = {
                    label = "Burgundy Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_6"
                },
                [7] = {
                    label = "Hot Pink Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_7"
                },
                [8] = {
                    label = "Scarlet Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_8"
                },
                [9] = {
                    label = "Orange Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_9"
                },
                [10] = {
                    label = "Amber Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_10"
                },
                [11] = {
                    label = "Lemon Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_11"
                },
                [12] = {
                    label = "Royal Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_12"
                },
                [13] = {
                    label = "Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_13"
                },
                [14] = {
                    label = "Teal Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_14"
                },
                [15] = {
                    label = "Cyan Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_15"
                },
                [16] = {
                    label = "Light Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_16"
                },
                [17] = {
                    label = "Lilac Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_17"
                },
                [18] = {
                    label = "Dark Green Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_18"
                },
                [19] = {
                    label = "Emerald Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_19"
                },
                [20] = {
                    label = "Moss Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_20"
                },
                [21] = {
                    label = "Lime Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_21"
                },
                [22] = {
                    label = "Peach Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_22"
                },
                [23] = {
                    label = "Lavender Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_23"
                },
                [24] = {
                    label = "Purple Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_24"
                },
                [25] = {
                    label = "Magenta Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "female_pants_182_25"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (183-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_183_0"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (184-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_184_0"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (185-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_185_0"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (186-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_186_0"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (187-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_187_0"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'component',
            textures = {
                [0] = {
                    label = "Alien Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_188_0"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (189-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_189_0"
                },
                [1] = {
                    label = "Pants (189-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_189_1"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (190-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_190_0"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (191-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_191_0"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (192-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_192_0"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (193-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_193_0"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (194-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_194_0"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'component',
            textures = {
                [0] = {
                    label = "Graffiti Jeans",
                    price = 500,
                    type = "money",
                    image = "female_pants_195_0"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Lunar New Year Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_196_0"
                },
                [1] = {
                    label = "Red Lunar New Year Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_196_1"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'component',
            textures = {
                [0] = {
                    label = "St Patrick's Day Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_197_0"
                },
                [1] = {
                    label = "New Year's Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_197_1"
                },
                [2] = {
                    label = "Independence Day Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_197_2"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (198-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_198_0"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'component',
            textures = {
                [0] = {
                    label = "Western MC Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_199_0"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (200-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_200_0"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (201-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_201_0"
                },
            },
        },
        [202] = {
            drawable = 202,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (202-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_202_0"
                },
            },
        },
        [203] = {
            drawable = 203,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (203-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_0"
                },
                [1] = {
                    label = "Pants (203-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_1"
                },
                [2] = {
                    label = "Pants (203-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_2"
                },
                [3] = {
                    label = "Pants (203-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_3"
                },
                [4] = {
                    label = "Pants (203-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_4"
                },
                [5] = {
                    label = "Pants (203-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_203_5"
                },
            },
        },
        [204] = {
            drawable = 204,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (204-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_204_0"
                },
            },
        },
        [205] = {
            drawable = 205,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (205-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_205_0"
                },
                [1] = {
                    label = "Pants (205-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_205_1"
                },
            },
        },
        [206] = {
            drawable = 206,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (206-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_206_0"
                },
            },
        },
        [207] = {
            drawable = 207,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (207-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_207_0"
                },
            },
        },
        [208] = {
            drawable = 208,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (208-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_208_0"
                },
                [1] = {
                    label = "Pants (208-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_208_1"
                },
            },
        },
        [209] = {
            drawable = 209,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cobalt Jackal Racing Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_209_0"
                },
            },
        },
        [210] = {
            drawable = 210,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pisswasser Shorts",
                    price = 500,
                    type = "money",
                    image = "female_pants_210_0"
                },
            },
        },
        [211] = {
            drawable = 211,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (211-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_211_0"
                },
            },
        },
        [212] = {
            drawable = 212,
            type = 'component',
            textures = {
                [0] = {
                    label = "Khaki 247 Chino Pantss",
                    price = 500,
                    type = "money",
                    image = "female_pants_212_0"
                },
            },
        },
        [213] = {
            drawable = 213,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (213-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_213_0"
                },
            },
        },
        [214] = {
            drawable = 214,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (214-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_0"
                },
                [1] = {
                    label = "Pants (214-1)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_1"
                },
                [2] = {
                    label = "Pants (214-2)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_2"
                },
                [3] = {
                    label = "Pants (214-3)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_3"
                },
                [4] = {
                    label = "Pants (214-4)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_4"
                },
                [5] = {
                    label = "Pants (214-5)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_5"
                },
                [6] = {
                    label = "Pants (214-6)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_6"
                },
                [7] = {
                    label = "Pants (214-7)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_7"
                },
                [8] = {
                    label = "Pants (214-8)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_8"
                },
                [9] = {
                    label = "Pants (214-9)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_9"
                },
                [10] = {
                    label = "Pants (214-10)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_10"
                },
                [11] = {
                    label = "Pants (214-11)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_11"
                },
                [12] = {
                    label = "Pants (214-12)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_12"
                },
                [13] = {
                    label = "Pants (214-13)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_13"
                },
                [14] = {
                    label = "Pants (214-14)",
                    price = 500,
                    type = "money",
                    image = "female_pants_214_14"
                },
            },
        },
        [215] = {
            drawable = 215,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (215-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_215_0"
                },
            },
        },
        [216] = {
            drawable = 216,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (216-0)",
                    price = 500,
                    type = "money",
                    image = "female_pants_216_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_0"
                },
                [1] = {
                    label = "Pants (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_1"
                },
                [2] = {
                    label = "Pants (0-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_2"
                },
                [3] = {
                    label = "Pants (0-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_3"
                },
                [4] = {
                    label = "Pants (0-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_4"
                },
                [5] = {
                    label = "Pants (0-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_5"
                },
                [6] = {
                    label = "Pants (0-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_6"
                },
                [7] = {
                    label = "Pants (0-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_7"
                },
                [8] = {
                    label = "Pants (0-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_8"
                },
                [9] = {
                    label = "Pants (0-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_9"
                },
                [10] = {
                    label = "Pants (0-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_10"
                },
                [11] = {
                    label = "Pants (0-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_11"
                },
                [12] = {
                    label = "Pants (0-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_12"
                },
                [13] = {
                    label = "Pants (0-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_13"
                },
                [14] = {
                    label = "Pants (0-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_14"
                },
                [15] = {
                    label = "Pants (0-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_0_15"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_0"
                },
                [1] = {
                    label = "Pants (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_1"
                },
                [2] = {
                    label = "Pants (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_2"
                },
                [3] = {
                    label = "Pants (1-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_3"
                },
                [4] = {
                    label = "Pants (1-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_4"
                },
                [5] = {
                    label = "Pants (1-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_5"
                },
                [6] = {
                    label = "Pants (1-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_6"
                },
                [7] = {
                    label = "Pants (1-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_7"
                },
                [8] = {
                    label = "Pants (1-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_8"
                },
                [9] = {
                    label = "Pants (1-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_9"
                },
                [10] = {
                    label = "Pants (1-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_10"
                },
                [11] = {
                    label = "Pants (1-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_11"
                },
                [12] = {
                    label = "Pants (1-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_12"
                },
                [13] = {
                    label = "Pants (1-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_13"
                },
                [14] = {
                    label = "Pants (1-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_14"
                },
                [15] = {
                    label = "Pants (1-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_1_15"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_0"
                },
                [1] = {
                    label = "Pants (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_1"
                },
                [2] = {
                    label = "Pants (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_2"
                },
                [3] = {
                    label = "Pants (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_3"
                },
                [4] = {
                    label = "Pants (2-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_4"
                },
                [5] = {
                    label = "Pants (2-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_5"
                },
                [6] = {
                    label = "Pants (2-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_6"
                },
                [7] = {
                    label = "Pants (2-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_7"
                },
                [8] = {
                    label = "Pants (2-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_8"
                },
                [9] = {
                    label = "Pants (2-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_9"
                },
                [10] = {
                    label = "Pants (2-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_10"
                },
                [11] = {
                    label = "Pants (2-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_11"
                },
                [12] = {
                    label = "Pants (2-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_12"
                },
                [13] = {
                    label = "Pants (2-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_13"
                },
                [14] = {
                    label = "Pants (2-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_14"
                },
                [15] = {
                    label = "Pants (2-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_2_15"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_0"
                },
                [1] = {
                    label = "Pants (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_1"
                },
                [2] = {
                    label = "Pants (3-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_2"
                },
                [3] = {
                    label = "Pants (3-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_3"
                },
                [4] = {
                    label = "Pants (3-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_4"
                },
                [5] = {
                    label = "Pants (3-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_5"
                },
                [6] = {
                    label = "Pants (3-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_6"
                },
                [7] = {
                    label = "Pants (3-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_7"
                },
                [8] = {
                    label = "Pants (3-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_8"
                },
                [9] = {
                    label = "Pants (3-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_9"
                },
                [10] = {
                    label = "Pants (3-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_10"
                },
                [11] = {
                    label = "Pants (3-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_11"
                },
                [12] = {
                    label = "Pants (3-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_12"
                },
                [13] = {
                    label = "Pants (3-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_13"
                },
                [14] = {
                    label = "Pants (3-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_14"
                },
                [15] = {
                    label = "Pants (3-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_3_15"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_0"
                },
                [1] = {
                    label = "Pants (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_1"
                },
                [2] = {
                    label = "Pants (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_2"
                },
                [3] = {
                    label = "Pants (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_3"
                },
                [4] = {
                    label = "Pants (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_4"
                },
                [5] = {
                    label = "Pants (4-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_5"
                },
                [6] = {
                    label = "Pants (4-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_6"
                },
                [7] = {
                    label = "Pants (4-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_7"
                },
                [8] = {
                    label = "Pants (4-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_8"
                },
                [9] = {
                    label = "Pants (4-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_9"
                },
                [10] = {
                    label = "Pants (4-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_10"
                },
                [11] = {
                    label = "Pants (4-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_11"
                },
                [12] = {
                    label = "Pants (4-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_12"
                },
                [13] = {
                    label = "Pants (4-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_13"
                },
                [14] = {
                    label = "Pants (4-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_14"
                },
                [15] = {
                    label = "Pants (4-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_4_15"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_0"
                },
                [1] = {
                    label = "Pants (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_1"
                },
                [2] = {
                    label = "Pants (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_2"
                },
                [3] = {
                    label = "Pants (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_3"
                },
                [4] = {
                    label = "Pants (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_4"
                },
                [5] = {
                    label = "Pants (5-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_5"
                },
                [6] = {
                    label = "Pants (5-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_6"
                },
                [7] = {
                    label = "Pants (5-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_7"
                },
                [8] = {
                    label = "Pants (5-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_8"
                },
                [9] = {
                    label = "Pants (5-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_9"
                },
                [10] = {
                    label = "Pants (5-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_10"
                },
                [11] = {
                    label = "Pants (5-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_11"
                },
                [12] = {
                    label = "Pants (5-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_12"
                },
                [13] = {
                    label = "Pants (5-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_13"
                },
                [14] = {
                    label = "Pants (5-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_14"
                },
                [15] = {
                    label = "Pants (5-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_5_15"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_0"
                },
                [1] = {
                    label = "Pants (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_1"
                },
                [2] = {
                    label = "Pants (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_2"
                },
                [3] = {
                    label = "Pants (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_3"
                },
                [4] = {
                    label = "Pants (6-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_4"
                },
                [5] = {
                    label = "Pants (6-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_5"
                },
                [6] = {
                    label = "Pants (6-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_6"
                },
                [7] = {
                    label = "Pants (6-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_7"
                },
                [8] = {
                    label = "Pants (6-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_8"
                },
                [9] = {
                    label = "Pants (6-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_9"
                },
                [10] = {
                    label = "Pants (6-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_10"
                },
                [11] = {
                    label = "Pants (6-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_11"
                },
                [12] = {
                    label = "Pants (6-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_12"
                },
                [13] = {
                    label = "Pants (6-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_13"
                },
                [14] = {
                    label = "Pants (6-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_14"
                },
                [15] = {
                    label = "Pants (6-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_6_15"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_0"
                },
                [1] = {
                    label = "Pants (7-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_1"
                },
                [2] = {
                    label = "Pants (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_2"
                },
                [3] = {
                    label = "Pants (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_3"
                },
                [4] = {
                    label = "Pants (7-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_4"
                },
                [5] = {
                    label = "Pants (7-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_5"
                },
                [6] = {
                    label = "Pants (7-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_6"
                },
                [7] = {
                    label = "Pants (7-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_7"
                },
                [8] = {
                    label = "Pants (7-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_8"
                },
                [9] = {
                    label = "Pants (7-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_9"
                },
                [10] = {
                    label = "Pants (7-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_10"
                },
                [11] = {
                    label = "Pants (7-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_11"
                },
                [12] = {
                    label = "Pants (7-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_12"
                },
                [13] = {
                    label = "Pants (7-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_13"
                },
                [14] = {
                    label = "Pants (7-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_14"
                },
                [15] = {
                    label = "Pants (7-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_7_15"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (8-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_0"
                },
                [1] = {
                    label = "Pants (8-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_1"
                },
                [2] = {
                    label = "Pants (8-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_2"
                },
                [3] = {
                    label = "Pants (8-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_3"
                },
                [4] = {
                    label = "Pants (8-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_4"
                },
                [5] = {
                    label = "Pants (8-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_5"
                },
                [6] = {
                    label = "Pants (8-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_6"
                },
                [7] = {
                    label = "Pants (8-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_7"
                },
                [8] = {
                    label = "Pants (8-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_8"
                },
                [9] = {
                    label = "Pants (8-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_9"
                },
                [10] = {
                    label = "Pants (8-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_10"
                },
                [11] = {
                    label = "Pants (8-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_11"
                },
                [12] = {
                    label = "Pants (8-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_12"
                },
                [13] = {
                    label = "Pants (8-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_13"
                },
                [14] = {
                    label = "Pants (8-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_14"
                },
                [15] = {
                    label = "Pants (8-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_8_15"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (9-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_0"
                },
                [1] = {
                    label = "Pants (9-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_1"
                },
                [2] = {
                    label = "Pants (9-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_2"
                },
                [3] = {
                    label = "Pants (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_3"
                },
                [4] = {
                    label = "Pants (9-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_4"
                },
                [5] = {
                    label = "Pants (9-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_5"
                },
                [6] = {
                    label = "Pants (9-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_6"
                },
                [7] = {
                    label = "Pants (9-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_7"
                },
                [8] = {
                    label = "Pants (9-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_8"
                },
                [9] = {
                    label = "Pants (9-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_9"
                },
                [10] = {
                    label = "Pants (9-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_10"
                },
                [11] = {
                    label = "Pants (9-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_11"
                },
                [12] = {
                    label = "Pants (9-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_12"
                },
                [13] = {
                    label = "Pants (9-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_13"
                },
                [14] = {
                    label = "Pants (9-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_14"
                },
                [15] = {
                    label = "Pants (9-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_9_15"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (10-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_0"
                },
                [1] = {
                    label = "Pants (10-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_1"
                },
                [2] = {
                    label = "Pants (10-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_2"
                },
                [3] = {
                    label = "Pants (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_3"
                },
                [4] = {
                    label = "Pants (10-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_4"
                },
                [5] = {
                    label = "Pants (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_5"
                },
                [6] = {
                    label = "Pants (10-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_6"
                },
                [7] = {
                    label = "Pants (10-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_7"
                },
                [8] = {
                    label = "Pants (10-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_8"
                },
                [9] = {
                    label = "Pants (10-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_9"
                },
                [10] = {
                    label = "Pants (10-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_10"
                },
                [11] = {
                    label = "Pants (10-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_11"
                },
                [12] = {
                    label = "Pants (10-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_12"
                },
                [13] = {
                    label = "Pants (10-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_13"
                },
                [14] = {
                    label = "Pants (10-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_14"
                },
                [15] = {
                    label = "Pants (10-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_10_15"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (11-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_0"
                },
                [1] = {
                    label = "Pants (11-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_1"
                },
                [2] = {
                    label = "Pants (11-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_2"
                },
                [3] = {
                    label = "Pants (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_3"
                },
                [4] = {
                    label = "Pants (11-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_4"
                },
                [5] = {
                    label = "Pants (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_5"
                },
                [6] = {
                    label = "Pants (11-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_6"
                },
                [7] = {
                    label = "Pants (11-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_7"
                },
                [8] = {
                    label = "Pants (11-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_8"
                },
                [9] = {
                    label = "Pants (11-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_9"
                },
                [10] = {
                    label = "Pants (11-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_10"
                },
                [11] = {
                    label = "Pants (11-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_11"
                },
                [12] = {
                    label = "Pants (11-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_12"
                },
                [13] = {
                    label = "Pants (11-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_13"
                },
                [14] = {
                    label = "Pants (11-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_14"
                },
                [15] = {
                    label = "Pants (11-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_11_15"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (12-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_0"
                },
                [1] = {
                    label = "Pants (12-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_1"
                },
                [2] = {
                    label = "Pants (12-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_2"
                },
                [3] = {
                    label = "Pants (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_3"
                },
                [4] = {
                    label = "Pants (12-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_4"
                },
                [5] = {
                    label = "Pants (12-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_5"
                },
                [6] = {
                    label = "Pants (12-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_6"
                },
                [7] = {
                    label = "Pants (12-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_7"
                },
                [8] = {
                    label = "Pants (12-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_8"
                },
                [9] = {
                    label = "Pants (12-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_9"
                },
                [10] = {
                    label = "Pants (12-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_10"
                },
                [11] = {
                    label = "Pants (12-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_11"
                },
                [12] = {
                    label = "Pants (12-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_12"
                },
                [13] = {
                    label = "Pants (12-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_13"
                },
                [14] = {
                    label = "Pants (12-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_14"
                },
                [15] = {
                    label = "Pants (12-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_12_15"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (13-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_0"
                },
                [1] = {
                    label = "Pants (13-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_1"
                },
                [2] = {
                    label = "Pants (13-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_2"
                },
                [3] = {
                    label = "Pants (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_3"
                },
                [4] = {
                    label = "Pants (13-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_4"
                },
                [5] = {
                    label = "Pants (13-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_5"
                },
                [6] = {
                    label = "Pants (13-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_6"
                },
                [7] = {
                    label = "Pants (13-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_7"
                },
                [8] = {
                    label = "Pants (13-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_8"
                },
                [9] = {
                    label = "Pants (13-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_9"
                },
                [10] = {
                    label = "Pants (13-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_10"
                },
                [11] = {
                    label = "Pants (13-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_11"
                },
                [12] = {
                    label = "Pants (13-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_12"
                },
                [13] = {
                    label = "Pants (13-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_13"
                },
                [14] = {
                    label = "Pants (13-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_14"
                },
                [15] = {
                    label = "Pants (13-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_13_15"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (14-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_0"
                },
                [1] = {
                    label = "Pants (14-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_1"
                },
                [2] = {
                    label = "Pants (14-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_2"
                },
                [3] = {
                    label = "Pants (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_3"
                },
                [4] = {
                    label = "Pants (14-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_4"
                },
                [5] = {
                    label = "Pants (14-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_5"
                },
                [6] = {
                    label = "Pants (14-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_6"
                },
                [7] = {
                    label = "Pants (14-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_7"
                },
                [8] = {
                    label = "Pants (14-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_8"
                },
                [9] = {
                    label = "Pants (14-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_9"
                },
                [10] = {
                    label = "Pants (14-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_10"
                },
                [11] = {
                    label = "Pants (14-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_11"
                },
                [12] = {
                    label = "Pants (14-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_12"
                },
                [13] = {
                    label = "Pants (14-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_13"
                },
                [14] = {
                    label = "Pants (14-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_14"
                },
                [15] = {
                    label = "Pants (14-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (15-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_0"
                },
                [1] = {
                    label = "Pants (15-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_1"
                },
                [2] = {
                    label = "Pants (15-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_2"
                },
                [3] = {
                    label = "Pants (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_3"
                },
                [4] = {
                    label = "Pants (15-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_4"
                },
                [5] = {
                    label = "Pants (15-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_5"
                },
                [6] = {
                    label = "Pants (15-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_6"
                },
                [7] = {
                    label = "Pants (15-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_7"
                },
                [8] = {
                    label = "Pants (15-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_8"
                },
                [9] = {
                    label = "Pants (15-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_9"
                },
                [10] = {
                    label = "Pants (15-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_10"
                },
                [11] = {
                    label = "Pants (15-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_11"
                },
                [12] = {
                    label = "Pants (15-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_12"
                },
                [13] = {
                    label = "Pants (15-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_13"
                },
                [14] = {
                    label = "Pants (15-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_14"
                },
                [15] = {
                    label = "Pants (15-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_15_15"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Two-Tone Navy Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_0"
                },
                [1] = {
                    label = "Harsh Souls Checked Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_1"
                },
                [2] = {
                    label = "Sunrise Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_2"
                },
                [3] = {
                    label = "Sunset Floral Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_3"
                },
                [4] = {
                    label = "Green Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_4"
                },
                [5] = {
                    label = "Purple Floral Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_5"
                },
                [6] = {
                    label = "Two-Tone Green Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_6"
                },
                [7] = {
                    label = "Tim Vapid Plaid Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_7"
                },
                [8] = {
                    label = "Aqua Floral Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_8"
                },
                [9] = {
                    label = "Pink Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_9"
                },
                [10] = {
                    label = "Lime Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_10"
                },
                [11] = {
                    label = "Tan Boards",
                    price = 500,
                    type = "money",
                    image = "male_pants_16_11"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_0"
                },
                [1] = {
                    label = "Pfister Design Plaid Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_1"
                },
                [2] = {
                    label = "Yellow Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_2"
                },
                [3] = {
                    label = "Silver Plaid Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_3"
                },
                [4] = {
                    label = "Baby Blue Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_4"
                },
                [5] = {
                    label = "White Plaid Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_5"
                },
                [6] = {
                    label = "Gray Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_6"
                },
                [7] = {
                    label = "Green Plaid Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_7"
                },
                [8] = {
                    label = "Brown Plaid Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_8"
                },
                [9] = {
                    label = "Red Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_9"
                },
                [10] = {
                    label = "Olive Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_17_10"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_0"
                },
                [1] = {
                    label = "Two-Tone Blue Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_1"
                },
                [2] = {
                    label = "Tropical Print Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_2"
                },
                [3] = {
                    label = "Red Stripe Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_3"
                },
                [4] = {
                    label = "Aqua Plaid Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_4"
                },
                [5] = {
                    label = "White Plaid Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_5"
                },
                [6] = {
                    label = "Navy Plaid Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_6"
                },
                [7] = {
                    label = "Brown Floral Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_7"
                },
                [8] = {
                    label = "Blue Banded Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_8"
                },
                [9] = {
                    label = "Fruity Floral Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_9"
                },
                [10] = {
                    label = "Santo Capra Resort Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_10"
                },
                [11] = {
                    label = "Santo Capra Tropics Running",
                    price = 500,
                    type = "money",
                    image = "male_pants_18_11"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Santa Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_19_0"
                },
                [1] = {
                    label = "Elf Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_19_1"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Ivory Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_20_0"
                },
                [1] = {
                    label = "Navy Pinstripe Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_20_1"
                },
                [2] = {
                    label = "Charcoal Pinstripe Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_20_2"
                },
                [3] = {
                    label = "Brown Pinstripe Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_20_3"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Love Heart Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_21_0"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Gray Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_0"
                },
                [1] = {
                    label = "Olive Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_1"
                },
                [2] = {
                    label = "Purple Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_2"
                },
                [3] = {
                    label = "Lobster Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_3"
                },
                [4] = {
                    label = "Subtle Blue Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_4"
                },
                [5] = {
                    label = "Brown Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_5"
                },
                [6] = {
                    label = "Vintage Woven Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_6"
                },
                [7] = {
                    label = "Cream Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_7"
                },
                [8] = {
                    label = "Ash Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_8"
                },
                [9] = {
                    label = "Navy Plaid Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_9"
                },
                [10] = {
                    label = "Silver Plaid Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_10"
                },
                [11] = {
                    label = "Gray Plaid Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_11"
                },
                [12] = {
                    label = "White Regular",
                    price = 500,
                    type = "money",
                    image = "male_pants_22_12"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Light Gray Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_0"
                },
                [1] = {
                    label = "Olive Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_1"
                },
                [2] = {
                    label = "Purple Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_2"
                },
                [3] = {
                    label = "Lobster Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_3"
                },
                [4] = {
                    label = "Subtle Blue Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_4"
                },
                [5] = {
                    label = "Brown Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_5"
                },
                [6] = {
                    label = "Vintage Woven Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_6"
                },
                [7] = {
                    label = "Cream Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_7"
                },
                [8] = {
                    label = "Ash Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_8"
                },
                [9] = {
                    label = "Navy Plaid Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_9"
                },
                [10] = {
                    label = "Silver Plaid Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_10"
                },
                [11] = {
                    label = "Gray Plaid Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_11"
                },
                [12] = {
                    label = "White Baggy",
                    price = 500,
                    type = "money",
                    image = "male_pants_23_12"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_0"
                },
                [1] = {
                    label = "Gray Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_1"
                },
                [2] = {
                    label = "Navy Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_2"
                },
                [3] = {
                    label = "Teal Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_3"
                },
                [4] = {
                    label = "Red Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_4"
                },
                [5] = {
                    label = "White Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_5"
                },
                [6] = {
                    label = "Brown Skinny Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_24_6"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_0"
                },
                [1] = {
                    label = "Gray Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_1"
                },
                [2] = {
                    label = "Navy Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_2"
                },
                [3] = {
                    label = "Teal Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_3"
                },
                [4] = {
                    label = "Red Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_4"
                },
                [5] = {
                    label = "White Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_5"
                },
                [6] = {
                    label = "Brown Regular Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_25_6"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Midnight Camo Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_0"
                },
                [1] = {
                    label = "Purple Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_1"
                },
                [2] = {
                    label = "Dark Olive Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_2"
                },
                [3] = {
                    label = "Green Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_3"
                },
                [4] = {
                    label = "Blue Splatter Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_4"
                },
                [5] = {
                    label = "Red Splatter Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_5"
                },
                [6] = {
                    label = "Light Blue Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_6"
                },
                [7] = {
                    label = "Mint Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_7"
                },
                [8] = {
                    label = "Rocker Print Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_8"
                },
                [9] = {
                    label = "Leopard Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_9"
                },
                [10] = {
                    label = "Zebra Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_10"
                },
                [11] = {
                    label = "Tartan Fitted",
                    price = 500,
                    type = "money",
                    image = "male_pants_26_11"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_0"
                },
                [1] = {
                    label = "Blue Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_1"
                },
                [2] = {
                    label = "Orange Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_2"
                },
                [3] = {
                    label = "White Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_3"
                },
                [4] = {
                    label = "Red Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_4"
                },
                [5] = {
                    label = "Baby Blue Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_5"
                },
                [6] = {
                    label = "Fuchsia Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_6"
                },
                [7] = {
                    label = "Mint Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_7"
                },
                [8] = {
                    label = "Brown Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_8"
                },
                [9] = {
                    label = "Dark Teal Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_9"
                },
                [10] = {
                    label = "Green Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_10"
                },
                [11] = {
                    label = "Lilac Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_27_11"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_0"
                },
                [1] = {
                    label = "White Stripe Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_1"
                },
                [2] = {
                    label = "Lobster Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_2"
                },
                [3] = {
                    label = "Gray Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_3"
                },
                [4] = {
                    label = "Olive Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_4"
                },
                [5] = {
                    label = "Brown Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_5"
                },
                [6] = {
                    label = "Light Gray Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_6"
                },
                [7] = {
                    label = "Vintage Woven Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_7"
                },
                [8] = {
                    label = "White Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_8"
                },
                [9] = {
                    label = "Purple Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_9"
                },
                [10] = {
                    label = "Slate Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_10"
                },
                [11] = {
                    label = "Navy Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_11"
                },
                [12] = {
                    label = "Leopard Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_12"
                },
                [13] = {
                    label = "Navy Plaid Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_13"
                },
                [14] = {
                    label = "Cream Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_14"
                },
                [15] = {
                    label = "Cream Stripe Slim Fit",
                    price = 500,
                    type = "money",
                    image = "male_pants_28_15"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Thin Stripy Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_29_0"
                },
                [1] = {
                    label = "Wide Stripy Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_29_1"
                },
                [2] = {
                    label = "Star Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_29_2"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Flight Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_30_0"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_31_0"
                },
                [1] = {
                    label = "Gray Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_31_1"
                },
                [2] = {
                    label = "Charcoal Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_31_2"
                },
                [3] = {
                    label = "Tan Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_31_3"
                },
                [4] = {
                    label = "Forest Combat Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_31_4"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Long Johns",
                    price = 500,
                    type = "money",
                    image = "male_pants_32_0"
                },
                [1] = {
                    label = "Stripy Long Johns",
                    price = 500,
                    type = "money",
                    image = "male_pants_32_1"
                },
                [2] = {
                    label = "Winter Long Johns",
                    price = 500,
                    type = "money",
                    image = "male_pants_32_2"
                },
                [3] = {
                    label = "Festive Long Johns",
                    price = 500,
                    type = "money",
                    image = "male_pants_32_3"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Heist Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_34_0"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (35-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_35_0"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (36-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_36_0"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_37_0"
                },
                [1] = {
                    label = "Beige Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_37_1"
                },
                [2] = {
                    label = "Black Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_37_2"
                },
                [3] = {
                    label = "Blue Scruffy Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_37_3"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (38-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_38_0"
                },
                [1] = {
                    label = "Pants (38-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_38_1"
                },
                [2] = {
                    label = "Pants (38-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_38_2"
                },
                [3] = {
                    label = "Pants (38-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_38_3"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (39-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_39_0"
                },
                [1] = {
                    label = "Pants (39-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_39_1"
                },
                [2] = {
                    label = "Pants (39-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_39_2"
                },
                [3] = {
                    label = "Pants (39-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_39_3"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (40-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_40_0"
                },
                [1] = {
                    label = "Pants (40-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_40_1"
                },
                [2] = {
                    label = "Pants (40-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_40_2"
                },
                [3] = {
                    label = "Pants (40-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_40_3"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Flight Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_41_0"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_0"
                },
                [1] = {
                    label = "Gray Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_1"
                },
                [2] = {
                    label = "White Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_2"
                },
                [3] = {
                    label = "Blue Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_3"
                },
                [4] = {
                    label = "Red Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_4"
                },
                [5] = {
                    label = "Yellow Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_5"
                },
                [6] = {
                    label = "Green Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_6"
                },
                [7] = {
                    label = "Brown Jogging Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_42_7"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Loose Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_43_0"
                },
                [1] = {
                    label = "Black Loose Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_43_1"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (44-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_44_0"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (45-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_0"
                },
                [1] = {
                    label = "Pants (45-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_1"
                },
                [2] = {
                    label = "Pants (45-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_2"
                },
                [3] = {
                    label = "Pants (45-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_3"
                },
                [4] = {
                    label = "Pants (45-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_4"
                },
                [5] = {
                    label = "Pants (45-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_5"
                },
                [6] = {
                    label = "Pants (45-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_45_6"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_46_0"
                },
                [1] = {
                    label = "Khaki Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_46_1"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Utility Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_47_0"
                },
                [1] = {
                    label = "Khaki Utility Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_47_1"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_48_0"
                },
                [1] = {
                    label = "Navy Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_48_1"
                },
                [2] = {
                    label = "Blue Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_48_2"
                },
                [3] = {
                    label = "Lilac Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_48_3"
                },
                [4] = {
                    label = "Yellow Continental Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_48_4"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_49_0"
                },
                [1] = {
                    label = "Navy Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_49_1"
                },
                [2] = {
                    label = "Blue Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_49_2"
                },
                [3] = {
                    label = "Lilac Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_49_3"
                },
                [4] = {
                    label = "Yellow Continental Slim Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_49_4"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_50_0"
                },
                [1] = {
                    label = "Blue Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_50_1"
                },
                [2] = {
                    label = "Black Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_50_2"
                },
                [3] = {
                    label = "Green Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_50_3"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Print Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_51_0"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_52_0"
                },
                [1] = {
                    label = "Blue Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_52_1"
                },
                [2] = {
                    label = "Black Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_52_2"
                },
                [3] = {
                    label = "Green Fitted Shiny Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_52_3"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Print Fitted Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_53_0"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dix Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_0"
                },
                [1] = {
                    label = "Le Chien Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_1"
                },
                [2] = {
                    label = "SN Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_2"
                },
                [3] = {
                    label = "Perseus Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_3"
                },
                [4] = {
                    label = "Blossom Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_4"
                },
                [5] = {
                    label = "Floral Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_5"
                },
                [6] = {
                    label = "Dragon Swim Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_54_6"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_55_0"
                },
                [1] = {
                    label = "Charcoal Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_55_1"
                },
                [2] = {
                    label = "Navy Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_55_2"
                },
                [3] = {
                    label = "Teal Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_55_3"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (56-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_0"
                },
                [1] = {
                    label = "Pants (56-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_1"
                },
                [2] = {
                    label = "Pants (56-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_2"
                },
                [3] = {
                    label = "Pants (56-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_3"
                },
                [4] = {
                    label = "Pants (56-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_4"
                },
                [5] = {
                    label = "Pants (56-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_5"
                },
                [6] = {
                    label = "Pants (56-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_6"
                },
                [7] = {
                    label = "Pants (56-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_56_7"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (57-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_57_0"
                },
                [1] = {
                    label = "Pants (57-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_57_1"
                },
                [2] = {
                    label = "Pants (57-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_57_2"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (58-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_0"
                },
                [1] = {
                    label = "Pants (58-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_1"
                },
                [2] = {
                    label = "Pants (58-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_2"
                },
                [3] = {
                    label = "Pants (58-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_3"
                },
                [4] = {
                    label = "Pants (58-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_4"
                },
                [5] = {
                    label = "Pants (58-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_5"
                },
                [6] = {
                    label = "Pants (58-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_6"
                },
                [7] = {
                    label = "Pants (58-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_7"
                },
                [8] = {
                    label = "Pants (58-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_8"
                },
                [9] = {
                    label = "Pants (58-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_9"
                },
                [10] = {
                    label = "Pants (58-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_10"
                },
                [11] = {
                    label = "Pants (58-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_11"
                },
                [12] = {
                    label = "Pants (58-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_12"
                },
                [13] = {
                    label = "Pants (58-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_13"
                },
                [14] = {
                    label = "Pants (58-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_14"
                },
                [15] = {
                    label = "Pants (58-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_58_15"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (59-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_0"
                },
                [1] = {
                    label = "Pants (59-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_1"
                },
                [2] = {
                    label = "Pants (59-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_2"
                },
                [3] = {
                    label = "Pants (59-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_3"
                },
                [4] = {
                    label = "Pants (59-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_4"
                },
                [5] = {
                    label = "Pants (59-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_5"
                },
                [6] = {
                    label = "Pants (59-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_6"
                },
                [7] = {
                    label = "Pants (59-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_7"
                },
                [8] = {
                    label = "Pants (59-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_8"
                },
                [9] = {
                    label = "Pants (59-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_59_9"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_0"
                },
                [1] = {
                    label = "Red Pinstripe Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_1"
                },
                [2] = {
                    label = "Dusk Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_2"
                },
                [3] = {
                    label = "Purple Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_3"
                },
                [4] = {
                    label = "Gray Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_4"
                },
                [5] = {
                    label = "Sky Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_5"
                },
                [6] = {
                    label = "Chocolate Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_6"
                },
                [7] = {
                    label = "Mustard Pinstripe Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_7"
                },
                [8] = {
                    label = "Crimson Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_8"
                },
                [9] = {
                    label = "Classic Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_9"
                },
                [10] = {
                    label = "Beige Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_10"
                },
                [11] = {
                    label = "Royal Check Suit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_60_11"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_0"
                },
                [1] = {
                    label = "Black Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_1"
                },
                [2] = {
                    label = "Gray Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_2"
                },
                [3] = {
                    label = "Red Leopard Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_3"
                },
                [4] = {
                    label = "White Heart Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_4"
                },
                [5] = {
                    label = "Black Heart Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_5"
                },
                [6] = {
                    label = "Red Heart Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_6"
                },
                [7] = {
                    label = "Purple Stripe Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_7"
                },
                [8] = {
                    label = "Tan Stripe Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_8"
                },
                [9] = {
                    label = "Black Leopard Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_9"
                },
                [10] = {
                    label = "Red Stripe Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_10"
                },
                [11] = {
                    label = "Blue Dot Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_11"
                },
                [12] = {
                    label = "Red Plaid Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_12"
                },
                [13] = {
                    label = "Lilac Plaid Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_61_13"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Work Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_62_0"
                },
                [1] = {
                    label = "Tan Work Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_62_1"
                },
                [2] = {
                    label = "Blue Work Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_62_2"
                },
                [3] = {
                    label = "Khaki Work Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_62_3"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Blue Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_63_0"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_0"
                },
                [1] = {
                    label = "Burgundy Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_1"
                },
                [2] = {
                    label = "Tan Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_2"
                },
                [3] = {
                    label = "Royal Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_3"
                },
                [4] = {
                    label = "Red Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_4"
                },
                [5] = {
                    label = "Light Blue Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_5"
                },
                [6] = {
                    label = "Orange Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_6"
                },
                [7] = {
                    label = "Purple Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_7"
                },
                [8] = {
                    label = "Gray Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_8"
                },
                [9] = {
                    label = "Green Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_9"
                },
                [10] = {
                    label = "White Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_64_10"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (65-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_0"
                },
                [1] = {
                    label = "Pants (65-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_1"
                },
                [2] = {
                    label = "Pants (65-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_2"
                },
                [3] = {
                    label = "Pants (65-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_3"
                },
                [4] = {
                    label = "Pants (65-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_4"
                },
                [5] = {
                    label = "Pants (65-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_5"
                },
                [6] = {
                    label = "Pants (65-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_6"
                },
                [7] = {
                    label = "Pants (65-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_7"
                },
                [8] = {
                    label = "Pants (65-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_8"
                },
                [9] = {
                    label = "Pants (65-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_9"
                },
                [10] = {
                    label = "Pants (65-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_10"
                },
                [11] = {
                    label = "Pants (65-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_11"
                },
                [12] = {
                    label = "Pants (65-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_12"
                },
                [13] = {
                    label = "Pants (65-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_65_13"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (66-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_0"
                },
                [1] = {
                    label = "Pants (66-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_1"
                },
                [2] = {
                    label = "Pants (66-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_2"
                },
                [3] = {
                    label = "Pants (66-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_3"
                },
                [4] = {
                    label = "Pants (66-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_4"
                },
                [5] = {
                    label = "Pants (66-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_5"
                },
                [6] = {
                    label = "Pants (66-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_6"
                },
                [7] = {
                    label = "Pants (66-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_7"
                },
                [8] = {
                    label = "Pants (66-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_8"
                },
                [9] = {
                    label = "Pants (66-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_66_9"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (67-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_0"
                },
                [1] = {
                    label = "Pants (67-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_1"
                },
                [2] = {
                    label = "Pants (67-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_2"
                },
                [3] = {
                    label = "Pants (67-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_3"
                },
                [4] = {
                    label = "Pants (67-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_4"
                },
                [5] = {
                    label = "Pants (67-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_5"
                },
                [6] = {
                    label = "Pants (67-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_6"
                },
                [7] = {
                    label = "Pants (67-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_7"
                },
                [8] = {
                    label = "Pants (67-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_8"
                },
                [9] = {
                    label = "Pants (67-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_9"
                },
                [10] = {
                    label = "Pants (67-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_10"
                },
                [11] = {
                    label = "Pants (67-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_67_11"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (68-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_0"
                },
                [1] = {
                    label = "Pants (68-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_1"
                },
                [2] = {
                    label = "Pants (68-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_2"
                },
                [3] = {
                    label = "Pants (68-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_3"
                },
                [4] = {
                    label = "Pants (68-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_4"
                },
                [5] = {
                    label = "Pants (68-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_5"
                },
                [6] = {
                    label = "Pants (68-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_6"
                },
                [7] = {
                    label = "Pants (68-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_7"
                },
                [8] = {
                    label = "Pants (68-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_8"
                },
                [9] = {
                    label = "Pants (68-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_68_9"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Skull Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_0"
                },
                [1] = {
                    label = "Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_1"
                },
                [2] = {
                    label = "Urban Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_2"
                },
                [3] = {
                    label = "Star Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_3"
                },
                [4] = {
                    label = "Pants (69-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_4"
                },
                [5] = {
                    label = "Pants (69-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_5"
                },
                [6] = {
                    label = "Pants (69-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_6"
                },
                [7] = {
                    label = "Pants (69-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_7"
                },
                [8] = {
                    label = "Lazer Force Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_8"
                },
                [9] = {
                    label = "Impotent Rage Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_9"
                },
                [10] = {
                    label = "Hamburgers Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_10"
                },
                [11] = {
                    label = "Up-n-Atom Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_11"
                },
                [12] = {
                    label = "Barfs Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_12"
                },
                [13] = {
                    label = "Bubblegum Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_13"
                },
                [14] = {
                    label = "Neon Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_14"
                },
                [15] = {
                    label = "Space Ranger Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_15"
                },
                [16] = {
                    label = "Sprunk Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_16"
                },
                [17] = {
                    label = "Ripple Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_69_17"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (70-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_70_0"
                },
                [1] = {
                    label = "Pants (70-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_70_1"
                },
                [2] = {
                    label = "Pants (70-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_70_2"
                },
                [3] = {
                    label = "Pants (70-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_70_3"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_0"
                },
                [1] = {
                    label = "Ox Blood Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_1"
                },
                [2] = {
                    label = "Chocolate Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_2"
                },
                [3] = {
                    label = "Worn Black Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_3"
                },
                [4] = {
                    label = "Worn Ox Blood Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_4"
                },
                [5] = {
                    label = "Worn Chocolate Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_71_5"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_0"
                },
                [1] = {
                    label = "Ox Blood Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_1"
                },
                [2] = {
                    label = "Chocolate Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_2"
                },
                [3] = {
                    label = "Worn Black Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_3"
                },
                [4] = {
                    label = "Worn Ox Blood Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_4"
                },
                [5] = {
                    label = "Worn Chocolate Plain",
                    price = 500,
                    type = "money",
                    image = "male_pants_72_5"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_0"
                },
                [1] = {
                    label = "Ox Blood Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_1"
                },
                [2] = {
                    label = "Chocolate Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_2"
                },
                [3] = {
                    label = "Worn Black Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_3"
                },
                [4] = {
                    label = "Worn Ox Blood Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_4"
                },
                [5] = {
                    label = "Worn Chocolate Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_73_5"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_0"
                },
                [1] = {
                    label = "Ox Blood Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_1"
                },
                [2] = {
                    label = "Chocolate Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_2"
                },
                [3] = {
                    label = "Worn Black Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_3"
                },
                [4] = {
                    label = "Worn Ox Blood Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_4"
                },
                [5] = {
                    label = "Worn Chocolate Padded",
                    price = 500,
                    type = "money",
                    image = "male_pants_74_5"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Indigo Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_0"
                },
                [1] = {
                    label = "Midnight Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_1"
                },
                [2] = {
                    label = "Faded Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_2"
                },
                [3] = {
                    label = "Navy Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_3"
                },
                [4] = {
                    label = "Classic Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_4"
                },
                [5] = {
                    label = "Dark Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_5"
                },
                [6] = {
                    label = "Slate Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_6"
                },
                [7] = {
                    label = "Black Ribbed",
                    price = 500,
                    type = "money",
                    image = "male_pants_75_7"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Indigo Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_0"
                },
                [1] = {
                    label = "Midnight Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_1"
                },
                [2] = {
                    label = "Faded Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_2"
                },
                [3] = {
                    label = "Navy Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_3"
                },
                [4] = {
                    label = "Classic Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_4"
                },
                [5] = {
                    label = "Dark Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_5"
                },
                [6] = {
                    label = "Slate Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_6"
                },
                [7] = {
                    label = "Black Roadworn",
                    price = 500,
                    type = "money",
                    image = "male_pants_76_7"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (77-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_0"
                },
                [1] = {
                    label = "Pants (77-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_1"
                },
                [2] = {
                    label = "Pants (77-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_2"
                },
                [3] = {
                    label = "Pants (77-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_3"
                },
                [4] = {
                    label = "Pants (77-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_4"
                },
                [5] = {
                    label = "Pants (77-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_5"
                },
                [6] = {
                    label = "Pants (77-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_6"
                },
                [7] = {
                    label = "Pants (77-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_7"
                },
                [8] = {
                    label = "Pants (77-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_8"
                },
                [9] = {
                    label = "Pants (77-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_9"
                },
                [10] = {
                    label = "Pants (77-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_77_10"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chocolate Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_0"
                },
                [1] = {
                    label = "Camo Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_1"
                },
                [2] = {
                    label = "Black Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_2"
                },
                [3] = {
                    label = "Blue Camo Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_3"
                },
                [4] = {
                    label = "Light Gray Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_4"
                },
                [5] = {
                    label = "Charcoal Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_5"
                },
                [6] = {
                    label = "Diamond Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_6"
                },
                [7] = {
                    label = "Hatched Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_78_7"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_79_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_79_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_79_2"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chocolate Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_0"
                },
                [1] = {
                    label = "Camo Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_1"
                },
                [2] = {
                    label = "Black Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_2"
                },
                [3] = {
                    label = "Blue Camo Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_3"
                },
                [4] = {
                    label = "Light Gray Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_4"
                },
                [5] = {
                    label = "Charcoal Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_5"
                },
                [6] = {
                    label = "Diamond Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_6"
                },
                [7] = {
                    label = "Hatched Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_80_7"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_81_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_81_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_81_2"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_0"
                },
                [1] = {
                    label = "Slate Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_1"
                },
                [2] = {
                    label = "Classic Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_2"
                },
                [3] = {
                    label = "Charcoal Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_3"
                },
                [4] = {
                    label = "Black Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_4"
                },
                [5] = {
                    label = "Navy Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_5"
                },
                [6] = {
                    label = "Slate Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_6"
                },
                [7] = {
                    label = "Classic Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_7"
                },
                [8] = {
                    label = "Charcoal Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_8"
                },
                [9] = {
                    label = "Black Faded Low Crotch",
                    price = 500,
                    type = "money",
                    image = "male_pants_82_9"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_83_0"
                },
                [1] = {
                    label = "Red Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_83_1"
                },
                [2] = {
                    label = "White Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_83_2"
                },
                [3] = {
                    label = "Brown Leather Low Crotch Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_83_3"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (84-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_0"
                },
                [1] = {
                    label = "Pants (84-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_1"
                },
                [2] = {
                    label = "Pants (84-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_2"
                },
                [3] = {
                    label = "Pants (84-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_3"
                },
                [4] = {
                    label = "Pants (84-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_4"
                },
                [5] = {
                    label = "Pants (84-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_5"
                },
                [6] = {
                    label = "Pants (84-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_6"
                },
                [7] = {
                    label = "Pants (84-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_7"
                },
                [8] = {
                    label = "Pants (84-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_8"
                },
                [9] = {
                    label = "Pants (84-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_9"
                },
                [10] = {
                    label = "Pants (84-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_84_10"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (85-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_85_0"
                },
                [1] = {
                    label = "Pants (85-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_85_1"
                },
                [2] = {
                    label = "Pants (85-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_85_2"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_0"
                },
                [1] = {
                    label = "Brown Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_1"
                },
                [2] = {
                    label = "Green Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_2"
                },
                [3] = {
                    label = "Gray Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_3"
                },
                [4] = {
                    label = "Peach Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_4"
                },
                [5] = {
                    label = "Fall Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_6"
                },
                [7] = {
                    label = "Crosshatch Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_7"
                },
                [8] = {
                    label = "Moss Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_10"
                },
                [11] = {
                    label = "Splinter Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_12"
                },
                [13] = {
                    label = "Cobble Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_13"
                },
                [14] = {
                    label = "Peach Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_14"
                },
                [15] = {
                    label = "Brushstroke Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_15"
                },
                [16] = {
                    label = "Flecktarn Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_16"
                },
                [17] = {
                    label = "Light Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_17"
                },
                [18] = {
                    label = "Moss Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_18"
                },
                [19] = {
                    label = "Sand Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_19"
                },
                [20] = {
                    label = "Pants (86-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_20"
                },
                [21] = {
                    label = "Pants (86-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_21"
                },
                [22] = {
                    label = "Pants (86-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_22"
                },
                [23] = {
                    label = "Pants (86-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_86_23"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_0"
                },
                [1] = {
                    label = "Brown Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_1"
                },
                [2] = {
                    label = "Green Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_2"
                },
                [3] = {
                    label = "Gray Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_3"
                },
                [4] = {
                    label = "Peach Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_4"
                },
                [5] = {
                    label = "Fall Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_6"
                },
                [7] = {
                    label = "Crosshatch Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_7"
                },
                [8] = {
                    label = "Moss Digital Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_10"
                },
                [11] = {
                    label = "Splinter Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_12"
                },
                [13] = {
                    label = "Cobble Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_13"
                },
                [14] = {
                    label = "Peach Camo Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_14"
                },
                [15] = {
                    label = "Brushstroke Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_15"
                },
                [16] = {
                    label = "Flecktarn Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_16"
                },
                [17] = {
                    label = "Light Woodland Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_17"
                },
                [18] = {
                    label = "Moss Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_18"
                },
                [19] = {
                    label = "Sand Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_19"
                },
                [20] = {
                    label = "Pants (87-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_20"
                },
                [21] = {
                    label = "Pants (87-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_21"
                },
                [22] = {
                    label = "Pants (87-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_22"
                },
                [23] = {
                    label = "Pants (87-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_87_23"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_0"
                },
                [1] = {
                    label = "Brown Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_1"
                },
                [2] = {
                    label = "Green Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_2"
                },
                [3] = {
                    label = "Gray Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_3"
                },
                [4] = {
                    label = "Peach Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_4"
                },
                [5] = {
                    label = "Fall Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_5"
                },
                [6] = {
                    label = "Dark Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_6"
                },
                [7] = {
                    label = "Crosshatch Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_7"
                },
                [8] = {
                    label = "Moss Digital Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_8"
                },
                [9] = {
                    label = "Gray Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_9"
                },
                [10] = {
                    label = "Aqua Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_10"
                },
                [11] = {
                    label = "Splinter Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_11"
                },
                [12] = {
                    label = "Contrast Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_12"
                },
                [13] = {
                    label = "Cobble Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_13"
                },
                [14] = {
                    label = "Peach Camo Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_14"
                },
                [15] = {
                    label = "Brushstroke Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_15"
                },
                [16] = {
                    label = "Flecktarn Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_16"
                },
                [17] = {
                    label = "Light Woodland Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_17"
                },
                [18] = {
                    label = "Moss Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_18"
                },
                [19] = {
                    label = "Sand Cargo Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_19"
                },
                [20] = {
                    label = "Pants (88-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_20"
                },
                [21] = {
                    label = "Pants (88-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_21"
                },
                [22] = {
                    label = "Pants (88-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_22"
                },
                [23] = {
                    label = "Pants (88-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_88_23"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_0"
                },
                [1] = {
                    label = "Brown Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_1"
                },
                [2] = {
                    label = "Green Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_2"
                },
                [3] = {
                    label = "Gray Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_3"
                },
                [4] = {
                    label = "Peach Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_4"
                },
                [5] = {
                    label = "Fall Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_5"
                },
                [6] = {
                    label = "Dark Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_6"
                },
                [7] = {
                    label = "Crosshatch Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_7"
                },
                [8] = {
                    label = "Moss Digital Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_8"
                },
                [9] = {
                    label = "Gray Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_9"
                },
                [10] = {
                    label = "Aqua Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_10"
                },
                [11] = {
                    label = "Splinter Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_11"
                },
                [12] = {
                    label = "Contrast Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_12"
                },
                [13] = {
                    label = "Cobble Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_13"
                },
                [14] = {
                    label = "Peach Camo Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_14"
                },
                [15] = {
                    label = "Brushstroke Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_15"
                },
                [16] = {
                    label = "Flecktarn Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_16"
                },
                [17] = {
                    label = "Light Woodland Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_17"
                },
                [18] = {
                    label = "Moss Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_18"
                },
                [19] = {
                    label = "Sand Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_19"
                },
                [20] = {
                    label = "Black Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_20"
                },
                [21] = {
                    label = "Slate Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_21"
                },
                [22] = {
                    label = "White Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_22"
                },
                [23] = {
                    label = "Chocolate Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_23"
                },
                [24] = {
                    label = "Olive Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_24"
                },
                [25] = {
                    label = "Light Brown Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_89_25"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Indigo Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_0"
                },
                [1] = {
                    label = "Faded Indigo Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_1"
                },
                [2] = {
                    label = "Dark Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_2"
                },
                [3] = {
                    label = "Faded Dark Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_3"
                },
                [4] = {
                    label = "Light Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_4"
                },
                [5] = {
                    label = "Faded Light Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_5"
                },
                [6] = {
                    label = "Slate Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_6"
                },
                [7] = {
                    label = "Faded Slate Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_7"
                },
                [8] = {
                    label = "Black Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_8"
                },
                [9] = {
                    label = "Faded Black Denim Overalls",
                    price = 500,
                    type = "money",
                    image = "male_pants_90_9"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (91-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_0"
                },
                [1] = {
                    label = "Pants (91-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_1"
                },
                [2] = {
                    label = "Pants (91-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_2"
                },
                [3] = {
                    label = "Pants (91-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_3"
                },
                [4] = {
                    label = "Pants (91-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_4"
                },
                [5] = {
                    label = "Pants (91-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_5"
                },
                [6] = {
                    label = "Pants (91-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_6"
                },
                [7] = {
                    label = "Pants (91-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_7"
                },
                [8] = {
                    label = "Pants (91-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_8"
                },
                [9] = {
                    label = "Pants (91-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_9"
                },
                [10] = {
                    label = "Pants (91-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_10"
                },
                [11] = {
                    label = "Pants (91-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_11"
                },
                [12] = {
                    label = "Pants (91-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_12"
                },
                [13] = {
                    label = "Pants (91-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_91_13"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (92-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_0"
                },
                [1] = {
                    label = "Pants (92-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_1"
                },
                [2] = {
                    label = "Pants (92-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_2"
                },
                [3] = {
                    label = "Pants (92-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_3"
                },
                [4] = {
                    label = "Pants (92-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_4"
                },
                [5] = {
                    label = "Pants (92-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_5"
                },
                [6] = {
                    label = "Pants (92-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_6"
                },
                [7] = {
                    label = "Pants (92-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_7"
                },
                [8] = {
                    label = "Pants (92-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_8"
                },
                [9] = {
                    label = "Pants (92-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_9"
                },
                [10] = {
                    label = "Pants (92-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_10"
                },
                [11] = {
                    label = "Pants (92-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_11"
                },
                [12] = {
                    label = "Pants (92-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_12"
                },
                [13] = {
                    label = "Pants (92-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_13"
                },
                [14] = {
                    label = "Pants (92-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_14"
                },
                [15] = {
                    label = "Pants (92-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_15"
                },
                [16] = {
                    label = "Pants (92-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_16"
                },
                [17] = {
                    label = "Pants (92-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_17"
                },
                [18] = {
                    label = "Pants (92-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_18"
                },
                [19] = {
                    label = "Pants (92-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_92_19"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (93-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_93_0"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (94-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_0"
                },
                [1] = {
                    label = "Pants (94-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_1"
                },
                [2] = {
                    label = "Pants (94-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_2"
                },
                [3] = {
                    label = "Pants (94-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_3"
                },
                [4] = {
                    label = "Pants (94-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_4"
                },
                [5] = {
                    label = "Pants (94-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_5"
                },
                [6] = {
                    label = "Pants (94-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_6"
                },
                [7] = {
                    label = "Pants (94-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_7"
                },
                [8] = {
                    label = "Pants (94-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_8"
                },
                [9] = {
                    label = "Pants (94-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_9"
                },
                [10] = {
                    label = "Pants (94-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_10"
                },
                [11] = {
                    label = "Pants (94-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_11"
                },
                [12] = {
                    label = "Pants (94-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_12"
                },
                [13] = {
                    label = "Pants (94-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_13"
                },
                [14] = {
                    label = "Pants (94-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_14"
                },
                [15] = {
                    label = "Pants (94-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_15"
                },
                [16] = {
                    label = "Pants (94-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_16"
                },
                [17] = {
                    label = "Pants (94-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_17"
                },
                [18] = {
                    label = "Pants (94-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_18"
                },
                [19] = {
                    label = "Pants (94-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_19"
                },
                [20] = {
                    label = "Pants (94-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_20"
                },
                [21] = {
                    label = "Pants (94-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_21"
                },
                [22] = {
                    label = "Pants (94-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_22"
                },
                [23] = {
                    label = "Pants (94-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_23"
                },
                [24] = {
                    label = "Pants (94-24)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_24"
                },
                [25] = {
                    label = "Pants (94-25)",
                    price = 500,
                    type = "money",
                    image = "male_pants_94_25"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (95-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_0"
                },
                [1] = {
                    label = "Pants (95-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_1"
                },
                [2] = {
                    label = "Pants (95-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_2"
                },
                [3] = {
                    label = "Pants (95-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_3"
                },
                [4] = {
                    label = "Pants (95-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_4"
                },
                [5] = {
                    label = "Pants (95-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_5"
                },
                [6] = {
                    label = "Pants (95-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_6"
                },
                [7] = {
                    label = "Pants (95-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_7"
                },
                [8] = {
                    label = "Pants (95-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_8"
                },
                [9] = {
                    label = "Pants (95-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_9"
                },
                [10] = {
                    label = "Pants (95-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_10"
                },
                [11] = {
                    label = "Pants (95-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_95_11"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (96-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_96_0"
                },
                [1] = {
                    label = "Pants (96-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_96_1"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (97-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_0"
                },
                [1] = {
                    label = "Pants (97-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_1"
                },
                [2] = {
                    label = "Pants (97-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_2"
                },
                [3] = {
                    label = "Pants (97-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_3"
                },
                [4] = {
                    label = "Pants (97-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_4"
                },
                [5] = {
                    label = "Pants (97-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_5"
                },
                [6] = {
                    label = "Pants (97-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_6"
                },
                [7] = {
                    label = "Pants (97-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_7"
                },
                [8] = {
                    label = "Pants (97-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_8"
                },
                [9] = {
                    label = "Pants (97-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_9"
                },
                [10] = {
                    label = "Pants (97-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_10"
                },
                [11] = {
                    label = "Pants (97-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_11"
                },
                [12] = {
                    label = "Pants (97-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_12"
                },
                [13] = {
                    label = "Pants (97-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_13"
                },
                [14] = {
                    label = "Pants (97-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_14"
                },
                [15] = {
                    label = "Pants (97-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_15"
                },
                [16] = {
                    label = "Pants (97-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_16"
                },
                [17] = {
                    label = "Pants (97-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_17"
                },
                [18] = {
                    label = "Pants (97-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_18"
                },
                [19] = {
                    label = "Pants (97-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_19"
                },
                [20] = {
                    label = "Pants (97-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_20"
                },
                [21] = {
                    label = "Pants (97-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_21"
                },
                [22] = {
                    label = "Pants (97-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_22"
                },
                [23] = {
                    label = "Pants (97-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_23"
                },
                [24] = {
                    label = "Pants (97-24)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_24"
                },
                [25] = {
                    label = "Pants (97-25)",
                    price = 500,
                    type = "money",
                    image = "male_pants_97_25"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (98-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_0"
                },
                [1] = {
                    label = "Pants (98-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_1"
                },
                [2] = {
                    label = "Pants (98-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_2"
                },
                [3] = {
                    label = "Pants (98-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_3"
                },
                [4] = {
                    label = "Pants (98-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_4"
                },
                [5] = {
                    label = "Pants (98-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_5"
                },
                [6] = {
                    label = "Pants (98-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_6"
                },
                [7] = {
                    label = "Pants (98-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_7"
                },
                [8] = {
                    label = "Pants (98-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_8"
                },
                [9] = {
                    label = "Pants (98-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_9"
                },
                [10] = {
                    label = "Pants (98-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_10"
                },
                [11] = {
                    label = "Pants (98-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_11"
                },
                [12] = {
                    label = "Pants (98-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_12"
                },
                [13] = {
                    label = "Pants (98-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_13"
                },
                [14] = {
                    label = "Pants (98-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_14"
                },
                [15] = {
                    label = "Pants (98-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_15"
                },
                [16] = {
                    label = "Pants (98-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_16"
                },
                [17] = {
                    label = "Pants (98-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_17"
                },
                [18] = {
                    label = "Pants (98-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_18"
                },
                [19] = {
                    label = "Pants (98-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_19"
                },
                [20] = {
                    label = "Pants (98-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_20"
                },
                [21] = {
                    label = "Pants (98-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_21"
                },
                [22] = {
                    label = "Pants (98-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_22"
                },
                [23] = {
                    label = "Pants (98-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_23"
                },
                [24] = {
                    label = "Pants (98-24)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_24"
                },
                [25] = {
                    label = "Pants (98-25)",
                    price = 500,
                    type = "money",
                    image = "male_pants_98_25"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (99-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_0"
                },
                [1] = {
                    label = "Pants (99-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_1"
                },
                [2] = {
                    label = "Pants (99-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_2"
                },
                [3] = {
                    label = "Pants (99-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_3"
                },
                [4] = {
                    label = "Pants (99-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_4"
                },
                [5] = {
                    label = "Pants (99-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_5"
                },
                [6] = {
                    label = "Pants (99-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_99_6"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_0"
                },
                [1] = {
                    label = "White Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_1"
                },
                [2] = {
                    label = "Peach Botanical Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_2"
                },
                [3] = {
                    label = "Teal Motif Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_3"
                },
                [4] = {
                    label = "Green Motif Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_4"
                },
                [5] = {
                    label = "Fall Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_5"
                },
                [6] = {
                    label = "Orange Fall Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_6"
                },
                [7] = {
                    label = "Purple Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_7"
                },
                [8] = {
                    label = "White Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_8"
                },
                [9] = {
                    label = "Dark Camo Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_9"
                },
                [10] = {
                    label = "Geometric Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_10"
                },
                [11] = {
                    label = "Abstract Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_11"
                },
                [12] = {
                    label = "Striped Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_12"
                },
                [13] = {
                    label = "Spotted Muscle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_100_13"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (101-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_101_0"
                },
                [1] = {
                    label = "Pants (101-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_101_1"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_0"
                },
                [1] = {
                    label = "Gray Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_1"
                },
                [2] = {
                    label = "White Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_2"
                },
                [3] = {
                    label = "Brown Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_3"
                },
                [4] = {
                    label = "Tan Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_4"
                },
                [5] = {
                    label = "Beige Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_5"
                },
                [6] = {
                    label = "Gray Camo Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_6"
                },
                [7] = {
                    label = "Green Camo Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_7"
                },
                [8] = {
                    label = "Dark Woodland Chain Paints",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_8"
                },
                [9] = {
                    label = "Cobble Chain Paints",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_9"
                },
                [10] = {
                    label = "Green Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_10"
                },
                [11] = {
                    label = "Beige Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_11"
                },
                [12] = {
                    label = "Gray Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_12"
                },
                [13] = {
                    label = "Tan Forest Chain Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_13"
                },
                [14] = {
                    label = "Pants (102-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_14"
                },
                [15] = {
                    label = "Pants (102-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_15"
                },
                [16] = {
                    label = "Pants (102-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_16"
                },
                [17] = {
                    label = "Pants (102-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_102_17"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_0"
                },
                [1] = {
                    label = "Gray Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_1"
                },
                [2] = {
                    label = "White Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_2"
                },
                [3] = {
                    label = "Brown Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_3"
                },
                [4] = {
                    label = "Tan Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_4"
                },
                [5] = {
                    label = "Beige Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_5"
                },
                [6] = {
                    label = "Gray Camo Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_6"
                },
                [7] = {
                    label = "Green Camo Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_7"
                },
                [8] = {
                    label = "Dark Woodland Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_8"
                },
                [9] = {
                    label = "Cobble Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_9"
                },
                [10] = {
                    label = "Green Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_10"
                },
                [11] = {
                    label = "Beige Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_11"
                },
                [12] = {
                    label = "Gray Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_12"
                },
                [13] = {
                    label = "Tan Forest Chain Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_13"
                },
                [14] = {
                    label = "Pants (103-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_14"
                },
                [15] = {
                    label = "Pants (103-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_15"
                },
                [16] = {
                    label = "Pants (103-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_16"
                },
                [17] = {
                    label = "Pants (103-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_103_17"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (104-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_104_0"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_0"
                },
                [1] = {
                    label = "Black & Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_1"
                },
                [2] = {
                    label = "White Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_2"
                },
                [3] = {
                    label = "Dark Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_3"
                },
                [4] = {
                    label = "Red Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_4"
                },
                [5] = {
                    label = "Blue Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_5"
                },
                [6] = {
                    label = "Moss Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_6"
                },
                [7] = {
                    label = "Gray Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_7"
                },
                [8] = {
                    label = "Brown Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_8"
                },
                [9] = {
                    label = "Orange Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_9"
                },
                [10] = {
                    label = "Ash Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_10"
                },
                [11] = {
                    label = "Magenta Leather Stitch Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_105_11"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (106-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_0"
                },
                [1] = {
                    label = "Pants (106-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_1"
                },
                [2] = {
                    label = "Pants (106-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_2"
                },
                [3] = {
                    label = "Pants (106-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_3"
                },
                [4] = {
                    label = "Pants (106-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_4"
                },
                [5] = {
                    label = "Pants (106-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_5"
                },
                [6] = {
                    label = "Pants (106-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_6"
                },
                [7] = {
                    label = "Pants (106-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_7"
                },
                [8] = {
                    label = "Pants (106-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_8"
                },
                [9] = {
                    label = "Pants (106-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_9"
                },
                [10] = {
                    label = "Pants (106-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_10"
                },
                [11] = {
                    label = "Pants (106-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_11"
                },
                [12] = {
                    label = "Pants (106-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_12"
                },
                [13] = {
                    label = "Pants (106-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_13"
                },
                [14] = {
                    label = "Pants (106-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_14"
                },
                [15] = {
                    label = "Pants (106-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_15"
                },
                [16] = {
                    label = "Pants (106-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_16"
                },
                [17] = {
                    label = "Pants (106-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_17"
                },
                [18] = {
                    label = "Pants (106-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_18"
                },
                [19] = {
                    label = "Pants (106-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_106_19"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_0"
                },
                [1] = {
                    label = "Black Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_1"
                },
                [2] = {
                    label = "Green Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_2"
                },
                [3] = {
                    label = "Beige Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_3"
                },
                [4] = {
                    label = "Blue Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_4"
                },
                [5] = {
                    label = "Green Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_5"
                },
                [6] = {
                    label = "White Camo Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_6"
                },
                [7] = {
                    label = "Crosshatch Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_7"
                },
                [8] = {
                    label = "Yellow Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_8"
                },
                [9] = {
                    label = "Black & White Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_9"
                },
                [10] = {
                    label = "Red Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_10"
                },
                [11] = {
                    label = "Blue Raider Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_11"
                },
                [12] = {
                    label = "Pants (107-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_12"
                },
                [13] = {
                    label = "Pants (107-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_13"
                },
                [14] = {
                    label = "Pants (107-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_14"
                },
                [15] = {
                    label = "Pants (107-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_107_15"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (108-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_0"
                },
                [1] = {
                    label = "Pants (108-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_1"
                },
                [2] = {
                    label = "Pants (108-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_2"
                },
                [3] = {
                    label = "Pants (108-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_3"
                },
                [4] = {
                    label = "Pants (108-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_4"
                },
                [5] = {
                    label = "Pants (108-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_5"
                },
                [6] = {
                    label = "Pants (108-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_6"
                },
                [7] = {
                    label = "Pants (108-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_7"
                },
                [8] = {
                    label = "Pants (108-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_8"
                },
                [9] = {
                    label = "Pants (108-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_9"
                },
                [10] = {
                    label = "Pants (108-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_10"
                },
                [11] = {
                    label = "Pants (108-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_108_11"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (109-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_0"
                },
                [1] = {
                    label = "Pants (109-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_1"
                },
                [2] = {
                    label = "Pants (109-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_2"
                },
                [3] = {
                    label = "Pants (109-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_3"
                },
                [4] = {
                    label = "Pants (109-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_4"
                },
                [5] = {
                    label = "Pants (109-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_5"
                },
                [6] = {
                    label = "Pants (109-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_6"
                },
                [7] = {
                    label = "Pants (109-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_7"
                },
                [8] = {
                    label = "Pants (109-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_8"
                },
                [9] = {
                    label = "Pants (109-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_9"
                },
                [10] = {
                    label = "Pants (109-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_10"
                },
                [11] = {
                    label = "Pants (109-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_11"
                },
                [12] = {
                    label = "Pants (109-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_12"
                },
                [13] = {
                    label = "Pants (109-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_13"
                },
                [14] = {
                    label = "Pants (109-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_14"
                },
                [15] = {
                    label = "Pants (109-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_15"
                },
                [16] = {
                    label = "Pants (109-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_16"
                },
                [17] = {
                    label = "Pants (109-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_109_17"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (110-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_0"
                },
                [1] = {
                    label = "Pants (110-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_1"
                },
                [2] = {
                    label = "Pants (110-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_2"
                },
                [3] = {
                    label = "Pants (110-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_3"
                },
                [4] = {
                    label = "Pants (110-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_4"
                },
                [5] = {
                    label = "Pants (110-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_5"
                },
                [6] = {
                    label = "Pants (110-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_6"
                },
                [7] = {
                    label = "Pants (110-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_7"
                },
                [8] = {
                    label = "Pants (110-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_8"
                },
                [9] = {
                    label = "Pants (110-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_9"
                },
                [10] = {
                    label = "Pants (110-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_10"
                },
                [11] = {
                    label = "Pants (110-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_110_11"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (111-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_111_0"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (112-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_112_0"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (113-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_113_0"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (114-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_0"
                },
                [1] = {
                    label = "Pants (114-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_1"
                },
                [2] = {
                    label = "Pants (114-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_2"
                },
                [3] = {
                    label = "Pants (114-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_3"
                },
                [4] = {
                    label = "Pants (114-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_4"
                },
                [5] = {
                    label = "Pants (114-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_5"
                },
                [6] = {
                    label = "Pants (114-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_6"
                },
                [7] = {
                    label = "Pants (114-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_7"
                },
                [8] = {
                    label = "Pants (114-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_8"
                },
                [9] = {
                    label = "Pants (114-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_9"
                },
                [10] = {
                    label = "Pants (114-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_10"
                },
                [11] = {
                    label = "Pants (114-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_11"
                },
                [12] = {
                    label = "Pants (114-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_12"
                },
                [13] = {
                    label = "Pants (114-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_114_13"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (115-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_115_0"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown SN High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_0"
                },
                [1] = {
                    label = "Tartan High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_1"
                },
                [2] = {
                    label = "Knit High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_2"
                },
                [3] = {
                    label = "Green High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_3"
                },
                [4] = {
                    label = "Sand High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_4"
                },
                [5] = {
                    label = "Swirl High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_5"
                },
                [6] = {
                    label = "Camo High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_6"
                },
                [7] = {
                    label = "Weave High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_7"
                },
                [8] = {
                    label = "Black Floral High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_8"
                },
                [9] = {
                    label = "Blue Floral High Roller Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_116_9"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_0"
                },
                [1] = {
                    label = "Blue Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_1"
                },
                [2] = {
                    label = "White Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_2"
                },
                [3] = {
                    label = "Black Baroque Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_3"
                },
                [4] = {
                    label = "Adorned Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_4"
                },
                [5] = {
                    label = "Snake Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_5"
                },
                [6] = {
                    label = "White SC Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_6"
                },
                [7] = {
                    label = "Black SC Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_7"
                },
                [8] = {
                    label = "Broker Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_8"
                },
                [9] = {
                    label = "Purple Painted Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_9"
                },
                [10] = {
                    label = "Black Painted Knee Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_117_10"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_0"
                },
                [1] = {
                    label = "Teal Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_1"
                },
                [2] = {
                    label = "Blue Perseus Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_2"
                },
                [3] = {
                    label = "Blue P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_3"
                },
                [4] = {
                    label = "White P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_4"
                },
                [5] = {
                    label = "Black P Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_5"
                },
                [6] = {
                    label = "Black E Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_6"
                },
                [7] = {
                    label = "White Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_7"
                },
                [8] = {
                    label = "Purple Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_8"
                },
                [9] = {
                    label = "Red Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_9"
                },
                [10] = {
                    label = "Teal SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_10"
                },
                [11] = {
                    label = "Blue Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_11"
                },
                [12] = {
                    label = "Black Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_12"
                },
                [13] = {
                    label = "White SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_13"
                },
                [14] = {
                    label = "Black Vinewood Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_14"
                },
                [15] = {
                    label = "Pink Vinewood Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_15"
                },
                [16] = {
                    label = "Gray Lazerforce Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_16"
                },
                [17] = {
                    label = "Green Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_17"
                },
                [18] = {
                    label = "Blue Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_18"
                },
                [19] = {
                    label = "Yellow Sci-Fi Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_19"
                },
                [20] = {
                    label = "Gray Blagueurs Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_20"
                },
                [21] = {
                    label = "Gray Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_21"
                },
                [22] = {
                    label = "Blue Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_22"
                },
                [23] = {
                    label = "Orange Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_23"
                },
                [24] = {
                    label = "Pink Patterned Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_24"
                },
                [25] = {
                    label = "Black SC Broker Wide Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_118_25"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (119-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_0"
                },
                [1] = {
                    label = "Pants (119-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_1"
                },
                [2] = {
                    label = "Pants (119-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_2"
                },
                [3] = {
                    label = "Pants (119-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_3"
                },
                [4] = {
                    label = "Pants (119-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_4"
                },
                [5] = {
                    label = "Pants (119-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_5"
                },
                [6] = {
                    label = "Pants (119-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_6"
                },
                [7] = {
                    label = "Pants (119-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_7"
                },
                [8] = {
                    label = "Pants (119-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_8"
                },
                [9] = {
                    label = "Pants (119-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_9"
                },
                [10] = {
                    label = "Pants (119-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_119_10"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (120-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_120_0"
                },
                [1] = {
                    label = "Pants (120-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_120_1"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (121-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_121_0"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Correctional Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_122_0"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Correctional Cargo",
                    price = 500,
                    type = "money",
                    image = "male_pants_123_0"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_0"
                },
                [1] = {
                    label = "Black Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_1"
                },
                [2] = {
                    label = "Dark Gray Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_2"
                },
                [3] = {
                    label = "Beige Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_3"
                },
                [4] = {
                    label = "Cream Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_4"
                },
                [5] = {
                    label = "Forest Green Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_5"
                },
                [6] = {
                    label = "Pants (124-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_6"
                },
                [7] = {
                    label = "Pants (124-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_7"
                },
                [8] = {
                    label = "Pants (124-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_8"
                },
                [9] = {
                    label = "Pants (124-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_9"
                },
                [10] = {
                    label = "Blue Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_10"
                },
                [11] = {
                    label = "Splinter Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_11"
                },
                [12] = {
                    label = "Contrast Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_12"
                },
                [13] = {
                    label = "Green Digital Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_13"
                },
                [14] = {
                    label = "Desert Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_14"
                },
                [15] = {
                    label = "Woodland Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_15"
                },
                [16] = {
                    label = "Forest Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_16"
                },
                [17] = {
                    label = "Blue Digital Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_17"
                },
                [18] = {
                    label = "Cobble Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_18"
                },
                [19] = {
                    label = "Beige Camo Knee Pad Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_124_19"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dark Gray Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_0"
                },
                [1] = {
                    label = "Black Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_1"
                },
                [2] = {
                    label = "Charcoal Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_2"
                },
                [3] = {
                    label = "Beige Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_3"
                },
                [4] = {
                    label = "White Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_4"
                },
                [5] = {
                    label = "Forest Green Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_5"
                },
                [6] = {
                    label = "Pants (125-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_6"
                },
                [7] = {
                    label = "Pants (125-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_7"
                },
                [8] = {
                    label = "Pants (125-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_8"
                },
                [9] = {
                    label = "Pants (125-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_9"
                },
                [10] = {
                    label = "Blue Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_10"
                },
                [11] = {
                    label = "Splinter Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_11"
                },
                [12] = {
                    label = "Contrast Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_12"
                },
                [13] = {
                    label = "Green Digital Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_13"
                },
                [14] = {
                    label = "Desert Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_14"
                },
                [15] = {
                    label = "Woodland Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_15"
                },
                [16] = {
                    label = "Forest Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_16"
                },
                [17] = {
                    label = "Blue Digital Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_17"
                },
                [18] = {
                    label = "Cobble Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_18"
                },
                [19] = {
                    label = "Beige Camo Guarded Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_125_19"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_126_0"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (127-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_127_0"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cream Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_0"
                },
                [1] = {
                    label = "Gray Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_1"
                },
                [2] = {
                    label = "Mustard Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_2"
                },
                [3] = {
                    label = "Purple Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_3"
                },
                [4] = {
                    label = "Orange Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_4"
                },
                [5] = {
                    label = "Pink Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_5"
                },
                [6] = {
                    label = "White Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_6"
                },
                [7] = {
                    label = "Cyan Heat Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_7"
                },
                [8] = {
                    label = "Stone Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_8"
                },
                [9] = {
                    label = "Blue Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_9"
                },
                [10] = {
                    label = "Ash Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_10"
                },
                [11] = {
                    label = "Cyan Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_11"
                },
                [12] = {
                    label = "Black Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_12"
                },
                [13] = {
                    label = "Crimson Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_13"
                },
                [14] = {
                    label = "Navy Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_14"
                },
                [15] = {
                    label = "Blue DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_15"
                },
                [16] = {
                    label = "Red DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_16"
                },
                [17] = {
                    label = "Yellow DS Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_17"
                },
                [18] = {
                    label = "Dark Stone Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_18"
                },
                [19] = {
                    label = "Snow Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_19"
                },
                [20] = {
                    label = "Smoke Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_20"
                },
                [21] = {
                    label = "Pants (128-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_21"
                },
                [22] = {
                    label = "Pants (128-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_22"
                },
                [23] = {
                    label = "Pants (128-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_23"
                },
                [24] = {
                    label = "Pants (128-24)",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_24"
                },
                [25] = {
                    label = "Lemon Sports Track Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_128_25"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_0"
                },
                [1] = {
                    label = "Black Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_1"
                },
                [2] = {
                    label = "Khaki Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_2"
                },
                [3] = {
                    label = "Dark Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_3"
                },
                [4] = {
                    label = "Light Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_4"
                },
                [5] = {
                    label = "Stone Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_5"
                },
                [6] = {
                    label = "Ash Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_6"
                },
                [7] = {
                    label = "Blue Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_129_7"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Navy Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_0"
                },
                [1] = {
                    label = "Black Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_1"
                },
                [2] = {
                    label = "Khaki Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_2"
                },
                [3] = {
                    label = "Dark Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_3"
                },
                [4] = {
                    label = "Light Gray Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_4"
                },
                [5] = {
                    label = "Stone Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_5"
                },
                [6] = {
                    label = "Ash Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_6"
                },
                [7] = {
                    label = "Blue Large Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_130_7"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Bigness Tie-dye Sports Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_131_0"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Prolaps Basketball Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_132_0"
                },
                [1] = {
                    label = "Panic Prolaps Basketball Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_132_1"
                },
                [2] = {
                    label = "Exsorbeo 720 Sports Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_132_2"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (133-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_133_0"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (134-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_134_0"
                },
                [1] = {
                    label = "Pants (134-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_134_1"
                },
                [2] = {
                    label = "Pants (134-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_134_2"
                },
                [3] = {
                    label = "Pants (134-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_134_3"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (135-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_135_0"
                },
                [1] = {
                    label = "Pants (135-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_135_1"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (136-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_136_0"
                },
                [1] = {
                    label = "Pants (136-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_136_1"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (137-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_0"
                },
                [1] = {
                    label = "Pants (137-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_1"
                },
                [2] = {
                    label = "Pants (137-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_2"
                },
                [3] = {
                    label = "Pants (137-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_3"
                },
                [4] = {
                    label = "Pants (137-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_4"
                },
                [5] = {
                    label = "Pants (137-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_5"
                },
                [6] = {
                    label = "Pants (137-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_6"
                },
                [7] = {
                    label = "Pants (137-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_137_7"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_0"
                },
                [1] = {
                    label = "Black Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_1"
                },
                [2] = {
                    label = "Gray Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_2"
                },
                [3] = {
                    label = "Beige Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_3"
                },
                [4] = {
                    label = "Navy Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_4"
                },
                [5] = {
                    label = "Dark Nut Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_5"
                },
                [6] = {
                    label = "Dark Green Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_6"
                },
                [7] = {
                    label = "Red FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_7"
                },
                [8] = {
                    label = "Green FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_8"
                },
                [9] = {
                    label = "Blue FB Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_9"
                },
                [10] = {
                    label = "Pink VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_10"
                },
                [11] = {
                    label = "Yellow VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_11"
                },
                [12] = {
                    label = "Blue VDG Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_12"
                },
                [13] = {
                    label = "Black Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_13"
                },
                [14] = {
                    label = "Cyan Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_14"
                },
                [15] = {
                    label = "Yellow Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_15"
                },
                [16] = {
                    label = "Pink Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_16"
                },
                [17] = {
                    label = "Purple Bigness Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_17"
                },
                [18] = {
                    label = "Pink Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_18"
                },
                [19] = {
                    label = "Patchwork Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_19"
                },
                [20] = {
                    label = "Blues Tie-dye Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_20"
                },
                [21] = {
                    label = "Squash Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_21"
                },
                [22] = {
                    label = "Hiding Print Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_22"
                },
                [23] = {
                    label = "Never Triangle Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_23"
                },
                [24] = {
                    label = "Life Static Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_24"
                },
                [25] = {
                    label = "Black Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_138_25"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_0"
                },
                [1] = {
                    label = "Red Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_1"
                },
                [2] = {
                    label = "White Blagueurs Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_2"
                },
                [3] = {
                    label = "Smoke Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_3"
                },
                [4] = {
                    label = "Sunrise Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_4"
                },
                [5] = {
                    label = "Sunset Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_5"
                },
                [6] = {
                    label = "Pink Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_6"
                },
                [7] = {
                    label = "Yellow Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_7"
                },
                [8] = {
                    label = "Earth Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_8"
                },
                [9] = {
                    label = "Green Fade Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_9"
                },
                [10] = {
                    label = "Green Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_10"
                },
                [11] = {
                    label = "Pink Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_11"
                },
                [12] = {
                    label = "Blue Yeti Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_12"
                },
                [13] = {
                    label = "Black Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_13"
                },
                [14] = {
                    label = "Sea Green Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_14"
                },
                [15] = {
                    label = "Yellow Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_15"
                },
                [16] = {
                    label = "Salmon Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_16"
                },
                [17] = {
                    label = "Orange Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_17"
                },
                [18] = {
                    label = "Blue Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_18"
                },
                [19] = {
                    label = "Chocolate Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_19"
                },
                [20] = {
                    label = "Purple Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_20"
                },
                [21] = {
                    label = "Light Brown Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_21"
                },
                [22] = {
                    label = "Lime Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_22"
                },
                [23] = {
                    label = "Mustard Heat Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_23"
                },
                [24] = {
                    label = "Black Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_24"
                },
                [25] = {
                    label = "White Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_139_25"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Teal Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_140_0"
                },
                [1] = {
                    label = "Red Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_140_1"
                },
                [2] = {
                    label = "Yellow Manor Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_140_2"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_0"
                },
                [1] = {
                    label = "Gray Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_1"
                },
                [2] = {
                    label = "Ash Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_2"
                },
                [3] = {
                    label = "White Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_3"
                },
                [4] = {
                    label = "Beige Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_4"
                },
                [5] = {
                    label = "Navy Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_5"
                },
                [6] = {
                    label = "Dark Nut Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_6"
                },
                [7] = {
                    label = "Green SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_7"
                },
                [8] = {
                    label = "Beige SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_8"
                },
                [9] = {
                    label = "Navy SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_9"
                },
                [10] = {
                    label = "Red SC Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_10"
                },
                [11] = {
                    label = "Green SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_11"
                },
                [12] = {
                    label = "Beige SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_12"
                },
                [13] = {
                    label = "Navy SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_13"
                },
                [14] = {
                    label = "Red SN Floral Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_14"
                },
                [15] = {
                    label = "Green FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_15"
                },
                [16] = {
                    label = "Beige FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_16"
                },
                [17] = {
                    label = "Blue FB Pulga Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_17"
                },
                [18] = {
                    label = "White Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_18"
                },
                [19] = {
                    label = "Black Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_19"
                },
                [20] = {
                    label = "Blue Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_20"
                },
                [21] = {
                    label = "Electric Bigness Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_21"
                },
                [22] = {
                    label = "Gray Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_22"
                },
                [23] = {
                    label = "Aqua Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_23"
                },
                [24] = {
                    label = "Orange Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_24"
                },
                [25] = {
                    label = "Green Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_141_25"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Peach Camo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_0"
                },
                [1] = {
                    label = "Black Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_1"
                },
                [2] = {
                    label = "Peach Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_2"
                },
                [3] = {
                    label = "Green Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_3"
                },
                [4] = {
                    label = "Rose Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_4"
                },
                [5] = {
                    label = "Aqua Splinter Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_5"
                },
                [6] = {
                    label = "Black Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_6"
                },
                [7] = {
                    label = "Aqua Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_7"
                },
                [8] = {
                    label = "Red Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_8"
                },
                [9] = {
                    label = "Green Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_9"
                },
                [10] = {
                    label = "Peach Check Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_10"
                },
                [11] = {
                    label = "Black Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_11"
                },
                [12] = {
                    label = "Gray Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_12"
                },
                [13] = {
                    label = "Orange Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_13"
                },
                [14] = {
                    label = "Zest Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_14"
                },
                [15] = {
                    label = "Brown Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_15"
                },
                [16] = {
                    label = "Pastel Tiger Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_16"
                },
                [17] = {
                    label = "Charcoal Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_17"
                },
                [18] = {
                    label = "Navy Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_18"
                },
                [19] = {
                    label = "Brown Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_19"
                },
                [20] = {
                    label = "Gray Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_20"
                },
                [21] = {
                    label = "Russet Geo Straight Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_142_21"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_0"
                },
                [1] = {
                    label = "Gray Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_1"
                },
                [2] = {
                    label = "Ash Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_2"
                },
                [3] = {
                    label = "Ice Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_3"
                },
                [4] = {
                    label = "Beige Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_4"
                },
                [5] = {
                    label = "Olive Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_5"
                },
                [6] = {
                    label = "Purple Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_6"
                },
                [7] = {
                    label = "Light VDG Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_7"
                },
                [8] = {
                    label = "Dark VDG Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_8"
                },
                [9] = {
                    label = "Black VDG Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_9"
                },
                [10] = {
                    label = "Gray Nature Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_10"
                },
                [11] = {
                    label = "Yellow Nature Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_11"
                },
                [12] = {
                    label = "Gray Broker Cash Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_12"
                },
                [13] = {
                    label = "Pink Broker Cash Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_13"
                },
                [14] = {
                    label = "Dark Paint G&B Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_14"
                },
                [15] = {
                    label = "Light Paint G&B Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_15"
                },
                [16] = {
                    label = "Gray Barfs Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_16"
                },
                [17] = {
                    label = "Purple Barfs Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_17"
                },
                [18] = {
                    label = "Smoke Broker Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_18"
                },
                [19] = {
                    label = "Green Broker Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_19"
                },
                [20] = {
                    label = "Red Crevis Woodland Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_20"
                },
                [21] = {
                    label = "Tan Crevis Woodland Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_21"
                },
                [22] = {
                    label = "Blue Güffy Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_22"
                },
                [23] = {
                    label = "Pink Güffy Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_23"
                },
                [24] = {
                    label = "Blue Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_24"
                },
                [25] = {
                    label = "Midnight Swallow Tie-dye Beach",
                    price = 500,
                    type = "money",
                    image = "male_pants_143_25"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_0"
                },
                [1] = {
                    label = "Gray Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_1"
                },
                [2] = {
                    label = "Charcoal Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_2"
                },
                [3] = {
                    label = "Black Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_3"
                },
                [4] = {
                    label = "Indigo Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_4"
                },
                [5] = {
                    label = "Light Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_5"
                },
                [6] = {
                    label = "Stonewash Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_6"
                },
                [7] = {
                    label = "Standard Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_7"
                },
                [8] = {
                    label = "Classic Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_8"
                },
                [9] = {
                    label = "Dark Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_9"
                },
                [10] = {
                    label = "Faded White Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_10"
                },
                [11] = {
                    label = "Faded Charcoal Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_11"
                },
                [12] = {
                    label = "Faded Classic Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_12"
                },
                [13] = {
                    label = "Faded Standard Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_13"
                },
                [14] = {
                    label = "Faded Dark Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_14"
                },
                [15] = {
                    label = "Faded Indigo Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_15"
                },
                [16] = {
                    label = "Faded Stonewash Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_16"
                },
                [17] = {
                    label = "Faded Light Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_17"
                },
                [18] = {
                    label = "Burgundy Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_18"
                },
                [19] = {
                    label = "Orange Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_19"
                },
                [20] = {
                    label = "Amber Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_20"
                },
                [21] = {
                    label = "Lemon Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_21"
                },
                [22] = {
                    label = "Lavender Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_22"
                },
                [23] = {
                    label = "Moss Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_23"
                },
                [24] = {
                    label = "Peach Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_24"
                },
                [25] = {
                    label = "Pink Jean Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_144_25"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (145-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_145_0"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green UFO Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_146_0"
                },
                [1] = {
                    label = "White UFO Boxer Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_146_1"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_0"
                },
                [1] = {
                    label = "Dark Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_1"
                },
                [2] = {
                    label = "Light Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_2"
                },
                [3] = {
                    label = "White Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_3"
                },
                [4] = {
                    label = "Ox Blood Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_4"
                },
                [5] = {
                    label = "Scarlet Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_5"
                },
                [6] = {
                    label = "Green Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_6"
                },
                [7] = {
                    label = "Red Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_7"
                },
                [8] = {
                    label = "Orange Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_8"
                },
                [9] = {
                    label = "Amber Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_9"
                },
                [10] = {
                    label = "Chestnut Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_10"
                },
                [11] = {
                    label = "Pale Brown Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_11"
                },
                [12] = {
                    label = "Blue Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_12"
                },
                [13] = {
                    label = "Light Blue Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_13"
                },
                [14] = {
                    label = "Black & Red Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_14"
                },
                [15] = {
                    label = "Worn Dirty Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_15"
                },
                [16] = {
                    label = "Worn Gray Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_16"
                },
                [17] = {
                    label = "Worn Dark Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_17"
                },
                [18] = {
                    label = "Worn Chestnut Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_18"
                },
                [19] = {
                    label = "Worn Charcoal Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_19"
                },
                [20] = {
                    label = "Worn Ox Blood Laced Leather",
                    price = 500,
                    type = "money",
                    image = "male_pants_147_20"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_0"
                },
                [1] = {
                    label = "Gray Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_1"
                },
                [2] = {
                    label = "Charcoal Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_2"
                },
                [3] = {
                    label = "Black Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_3"
                },
                [4] = {
                    label = "Indigo Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_4"
                },
                [5] = {
                    label = "Light Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_5"
                },
                [6] = {
                    label = "Stonewash Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_6"
                },
                [7] = {
                    label = "Standard Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_7"
                },
                [8] = {
                    label = "Classic Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_8"
                },
                [9] = {
                    label = "Dark Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_9"
                },
                [10] = {
                    label = "Faded Gray Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_10"
                },
                [11] = {
                    label = "Faded Charcoal Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_11"
                },
                [12] = {
                    label = "Faded Black Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_12"
                },
                [13] = {
                    label = "Faded Indigo Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_13"
                },
                [14] = {
                    label = "Faded Stonewash Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_14"
                },
                [15] = {
                    label = "Faded Standard Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_15"
                },
                [16] = {
                    label = "Faded Classic Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_16"
                },
                [17] = {
                    label = "Faded Dark Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_17"
                },
                [18] = {
                    label = "Burgundy Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_18"
                },
                [19] = {
                    label = "Orange Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_19"
                },
                [20] = {
                    label = "Amber Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_20"
                },
                [21] = {
                    label = "Lemon Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_21"
                },
                [22] = {
                    label = "Lavender Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_22"
                },
                [23] = {
                    label = "Moss Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_23"
                },
                [24] = {
                    label = "Peach Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_24"
                },
                [25] = {
                    label = "Pink Turnups",
                    price = 500,
                    type = "money",
                    image = "male_pants_148_25"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (149-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_149_0"
                },
                [1] = {
                    label = "420 Smoking Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_149_1"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Yeti Battle Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_150_0"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Checkerboard Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_151_0"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Broker Checkerboard Cargos",
                    price = 500,
                    type = "money",
                    image = "male_pants_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (153-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_0"
                },
                [1] = {
                    label = "Pants (153-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_1"
                },
                [2] = {
                    label = "Pants (153-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_2"
                },
                [3] = {
                    label = "Pants (153-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_3"
                },
                [4] = {
                    label = "Pants (153-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_4"
                },
                [5] = {
                    label = "Pants (153-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_5"
                },
                [6] = {
                    label = "Pants (153-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_6"
                },
                [7] = {
                    label = "Pants (153-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_7"
                },
                [8] = {
                    label = "Pants (153-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_8"
                },
                [9] = {
                    label = "Pants (153-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_9"
                },
                [10] = {
                    label = "Pants (153-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_10"
                },
                [11] = {
                    label = "Pants (153-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_11"
                },
                [12] = {
                    label = "Pants (153-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_12"
                },
                [13] = {
                    label = "Pants (153-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_13"
                },
                [14] = {
                    label = "Pants (153-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_14"
                },
                [15] = {
                    label = "Pants (153-15)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_15"
                },
                [16] = {
                    label = "Pants (153-16)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_16"
                },
                [17] = {
                    label = "Pants (153-17)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_17"
                },
                [18] = {
                    label = "Pants (153-18)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_18"
                },
                [19] = {
                    label = "Pants (153-19)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_19"
                },
                [20] = {
                    label = "Pants (153-20)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_20"
                },
                [21] = {
                    label = "Pants (153-21)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_21"
                },
                [22] = {
                    label = "Pants (153-22)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_22"
                },
                [23] = {
                    label = "Pants (153-23)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_23"
                },
                [24] = {
                    label = "Pants (153-24)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_24"
                },
                [25] = {
                    label = "Pants (153-25)",
                    price = 500,
                    type = "money",
                    image = "male_pants_153_25"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Cimicino Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_0"
                },
                [1] = {
                    label = "Light Cimicino Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_1"
                },
                [2] = {
                    label = "Black DS Pantsher Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_2"
                },
                [3] = {
                    label = "Light DS Pantsher Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_3"
                },
                [4] = {
                    label = "Classic DS Tiger Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_4"
                },
                [5] = {
                    label = "Gray DS Tiger Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_5"
                },
                [6] = {
                    label = "Black Big Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_6"
                },
                [7] = {
                    label = "Light Big Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_7"
                },
                [8] = {
                    label = "Dark Small Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_8"
                },
                [9] = {
                    label = "Light Small Flames Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_9"
                },
                [10] = {
                    label = "Classic FB Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_10"
                },
                [11] = {
                    label = "Gray FB Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_11"
                },
                [12] = {
                    label = "Black SC Coins Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_12"
                },
                [13] = {
                    label = "Light SC Coins Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_13"
                },
                [14] = {
                    label = "Light SC Dragon Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_14"
                },
                [15] = {
                    label = "Red SC Dragon Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_15"
                },
                [16] = {
                    label = "Light Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_16"
                },
                [17] = {
                    label = "Gray Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_17"
                },
                [18] = {
                    label = "Red Stars Embroidered",
                    price = 500,
                    type = "money",
                    image = "male_pants_154_18"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Zebra Bigness Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_1"
                },
                [2] = {
                    label = "Black Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_2"
                },
                [3] = {
                    label = "Blue Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_3"
                },
                [4] = {
                    label = "Red Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_4"
                },
                [5] = {
                    label = "White Blagueurs Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_5"
                },
                [6] = {
                    label = "Green Flames Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_6"
                },
                [7] = {
                    label = "Orange Flames Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_7"
                },
                [8] = {
                    label = "Pink Flames Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_8"
                },
                [9] = {
                    label = "Purple Flames Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_9"
                },
                [10] = {
                    label = "Red Flames Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_10"
                },
                [11] = {
                    label = "Blue Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_11"
                },
                [12] = {
                    label = "White Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_12"
                },
                [13] = {
                    label = "Green Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_13"
                },
                [14] = {
                    label = "Orange Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_14"
                },
                [15] = {
                    label = "Purple Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_15"
                },
                [16] = {
                    label = "Pink Lightning Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_16"
                },
                [17] = {
                    label = "Blue Marble Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_17"
                },
                [18] = {
                    label = "White Marble Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_18"
                },
                [19] = {
                    label = "Pink Marble Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_19"
                },
                [20] = {
                    label = "Blue Bones Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_20"
                },
                [21] = {
                    label = "Black Bones Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_21"
                },
                [22] = {
                    label = "Red Bones Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_22"
                },
                [23] = {
                    label = "Taupe Bones Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_23"
                },
                [24] = {
                    label = "Black Trickster Type Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_24"
                },
                [25] = {
                    label = "Orange Trickster Type Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_155_25"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_156_0"
                },
                [1] = {
                    label = "White VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_156_1"
                },
                [2] = {
                    label = "Blue Fade VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_156_2"
                },
                [3] = {
                    label = "Pink Fade VDG Bandana Wide",
                    price = 500,
                    type = "money",
                    image = "male_pants_156_3"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (157-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_157_0"
                },
                [1] = {
                    label = "Pants (157-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_157_1"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (158-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_158_0"
                },
                [1] = {
                    label = "Pants (158-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_158_1"
                },
            },
        },
        [159] = {
            drawable = 159,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (159-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_159_0"
                },
            },
        },
        [160] = {
            drawable = 160,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (160-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_160_0"
                },
            },
        },
        [161] = {
            drawable = 161,
            type = 'component',
            textures = {
                [0] = {
                    label = "PRB Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_161_0"
                },
                [1] = {
                    label = "Bleedin' Tasty Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_161_1"
                },
            },
        },
        [162] = {
            drawable = 162,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cluckin' Bell Cuffed Sweats",
                    price = 500,
                    type = "money",
                    image = "male_pants_162_0"
                },
            },
        },
        [163] = {
            drawable = 163,
            type = 'component',
            textures = {
                [0] = {
                    label = "Santo Capra x Manor Chinos",
                    price = 500,
                    type = "money",
                    image = "male_pants_163_0"
                },
            },
        },
        [164] = {
            drawable = 164,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (164-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_164_0"
                },
            },
        },
        [165] = {
            drawable = 165,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (165-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_165_0"
                },
            },
        },
        [166] = {
            drawable = 166,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (166-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_166_0"
                },
            },
        },
        [167] = {
            drawable = 167,
            type = 'component',
            textures = {
                [0] = {
                    label = "Hinterland Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_167_0"
                },
            },
        },
        [168] = {
            drawable = 168,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (168-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_168_0"
                },
                [1] = {
                    label = "Pants (168-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_168_1"
                },
                [2] = {
                    label = "Pants (168-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_168_2"
                },
            },
        },
        [169] = {
            drawable = 169,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (169-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_169_0"
                },
                [1] = {
                    label = "Pants (169-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_169_1"
                },
                [2] = {
                    label = "Pants (169-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_169_2"
                },
            },
        },
        [170] = {
            drawable = 170,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_0"
                },
                [1] = {
                    label = "Dark Gray Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_1"
                },
                [2] = {
                    label = "Gray Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_2"
                },
                [3] = {
                    label = "Ice Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_3"
                },
                [4] = {
                    label = "Beige Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_4"
                },
                [5] = {
                    label = "Chocolate Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_5"
                },
                [6] = {
                    label = "Burgundy Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_6"
                },
                [7] = {
                    label = "Hot Pink Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_7"
                },
                [8] = {
                    label = "Scarlet Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_8"
                },
                [9] = {
                    label = "Orange Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_9"
                },
                [10] = {
                    label = "Amber Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_10"
                },
                [11] = {
                    label = "Lemon Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_11"
                },
                [12] = {
                    label = "Royal Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_12"
                },
                [13] = {
                    label = "Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_13"
                },
                [14] = {
                    label = "Teal Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_14"
                },
                [15] = {
                    label = "Cyan Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_15"
                },
                [16] = {
                    label = "Light Blue Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_16"
                },
                [17] = {
                    label = "Lilac Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_17"
                },
                [18] = {
                    label = "Dark Green Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_18"
                },
                [19] = {
                    label = "Emerald Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_19"
                },
                [20] = {
                    label = "Moss Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_20"
                },
                [21] = {
                    label = "Lime Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_21"
                },
                [22] = {
                    label = "Peach Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_22"
                },
                [23] = {
                    label = "Lavender Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_23"
                },
                [24] = {
                    label = "Purple Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_24"
                },
                [25] = {
                    label = "Magenta Snap Joggers",
                    price = 500,
                    type = "money",
                    image = "male_pants_170_25"
                },
            },
        },
        [171] = {
            drawable = 171,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (171-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_171_0"
                },
            },
        },
        [172] = {
            drawable = 172,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (172-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_172_0"
                },
            },
        },
        [173] = {
            drawable = 173,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (173-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_173_0"
                },
            },
        },
        [174] = {
            drawable = 174,
            type = 'component',
            textures = {
                [0] = {
                    label = "Alien Tracksuit Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_174_0"
                },
            },
        },
        [175] = {
            drawable = 175,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (175-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_175_0"
                },
                [1] = {
                    label = "Pants (175-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_175_1"
                },
            },
        },
        [176] = {
            drawable = 176,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (176-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_176_0"
                },
            },
        },
        [177] = {
            drawable = 177,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (177-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_177_0"
                },
            },
        },
        [178] = {
            drawable = 178,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (178-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_178_0"
                },
            },
        },
        [179] = {
            drawable = 179,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (179-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_179_0"
                },
            },
        },
        [180] = {
            drawable = 180,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (180-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_180_0"
                },
            },
        },
        [181] = {
            drawable = 181,
            type = 'component',
            textures = {
                [0] = {
                    label = "Graffiti Jeans",
                    price = 500,
                    type = "money",
                    image = "male_pants_181_0"
                },
            },
        },
        [182] = {
            drawable = 182,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Lunar New Year Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_182_0"
                },
                [1] = {
                    label = "Red Lunar New Year Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_182_1"
                },
            },
        },
        [183] = {
            drawable = 183,
            type = 'component',
            textures = {
                [0] = {
                    label = "St Patrick's Day Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_183_0"
                },
                [1] = {
                    label = "New Year's Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_183_1"
                },
                [2] = {
                    label = "Independence Day Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_183_2"
                },
            },
        },
        [184] = {
            drawable = 184,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (184-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_184_0"
                },
            },
        },
        [185] = {
            drawable = 185,
            type = 'component',
            textures = {
                [0] = {
                    label = "Western MC Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_185_0"
                },
            },
        },
        [186] = {
            drawable = 186,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (186-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_186_0"
                },
            },
        },
        [187] = {
            drawable = 187,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (187-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_187_0"
                },
            },
        },
        [188] = {
            drawable = 188,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (188-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_188_0"
                },
            },
        },
        [189] = {
            drawable = 189,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (189-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_0"
                },
                [1] = {
                    label = "Pants (189-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_1"
                },
                [2] = {
                    label = "Pants (189-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_2"
                },
                [3] = {
                    label = "Pants (189-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_3"
                },
                [4] = {
                    label = "Pants (189-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_4"
                },
                [5] = {
                    label = "Pants (189-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_189_5"
                },
            },
        },
        [190] = {
            drawable = 190,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (190-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_190_0"
                },
            },
        },
        [191] = {
            drawable = 191,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (191-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_191_0"
                },
                [1] = {
                    label = "Pants (191-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_191_1"
                },
            },
        },
        [192] = {
            drawable = 192,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (192-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_192_0"
                },
            },
        },
        [193] = {
            drawable = 193,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (193-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_193_0"
                },
            },
        },
        [194] = {
            drawable = 194,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (194-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_194_0"
                },
                [1] = {
                    label = "Pants (194-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_194_1"
                },
            },
        },
        [195] = {
            drawable = 195,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cobalt Jackal Racing Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_195_0"
                },
            },
        },
        [196] = {
            drawable = 196,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gold Pisswasser Shorts",
                    price = 500,
                    type = "money",
                    image = "male_pants_196_0"
                },
            },
        },
        [197] = {
            drawable = 197,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (197-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_197_0"
                },
            },
        },
        [198] = {
            drawable = 198,
            type = 'component',
            textures = {
                [0] = {
                    label = "Khaki 247 Chino Pantss",
                    price = 500,
                    type = "money",
                    image = "male_pants_198_0"
                },
            },
        },
        [199] = {
            drawable = 199,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (199-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_199_0"
                },
            },
        },
        [200] = {
            drawable = 200,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (200-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_0"
                },
                [1] = {
                    label = "Pants (200-1)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_1"
                },
                [2] = {
                    label = "Pants (200-2)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_2"
                },
                [3] = {
                    label = "Pants (200-3)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_3"
                },
                [4] = {
                    label = "Pants (200-4)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_4"
                },
                [5] = {
                    label = "Pants (200-5)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_5"
                },
                [6] = {
                    label = "Pants (200-6)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_6"
                },
                [7] = {
                    label = "Pants (200-7)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_7"
                },
                [8] = {
                    label = "Pants (200-8)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_8"
                },
                [9] = {
                    label = "Pants (200-9)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_9"
                },
                [10] = {
                    label = "Pants (200-10)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_10"
                },
                [11] = {
                    label = "Pants (200-11)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_11"
                },
                [12] = {
                    label = "Pants (200-12)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_12"
                },
                [13] = {
                    label = "Pants (200-13)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_13"
                },
                [14] = {
                    label = "Pants (200-14)",
                    price = 500,
                    type = "money",
                    image = "male_pants_200_14"
                },
            },
        },
        [201] = {
            drawable = 201,
            type = 'component',
            textures = {
                [0] = {
                    label = "Pants (201-0)",
                    price = 500,
                    type = "money",
                    image = "male_pants_201_0"
                },
            },
        },
    },
}
