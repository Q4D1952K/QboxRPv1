shoes = {

    female = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_0"
                },
                [1] = {
                    label = "Shoes (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_1"
                },
                [2] = {
                    label = "Shoes (0-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_2"
                },
                [3] = {
                    label = "Shoes (0-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_3"
                },
                [4] = {
                    label = "Shoes (0-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_4"
                },
                [5] = {
                    label = "Shoes (0-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_5"
                },
                [6] = {
                    label = "Shoes (0-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_6"
                },
                [7] = {
                    label = "Shoes (0-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_7"
                },
                [8] = {
                    label = "Shoes (0-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_8"
                },
                [9] = {
                    label = "Shoes (0-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_9"
                },
                [10] = {
                    label = "Shoes (0-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_10"
                },
                [11] = {
                    label = "Shoes (0-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_11"
                },
                [12] = {
                    label = "Shoes (0-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_12"
                },
                [13] = {
                    label = "Shoes (0-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_13"
                },
                [14] = {
                    label = "Shoes (0-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_14"
                },
                [15] = {
                    label = "Shoes (0-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_0_15"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_0"
                },
                [1] = {
                    label = "Shoes (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_1"
                },
                [2] = {
                    label = "Shoes (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_2"
                },
                [3] = {
                    label = "Shoes (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_3"
                },
                [4] = {
                    label = "Shoes (1-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_4"
                },
                [5] = {
                    label = "Shoes (1-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_5"
                },
                [6] = {
                    label = "Shoes (1-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_6"
                },
                [7] = {
                    label = "Shoes (1-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_7"
                },
                [8] = {
                    label = "Shoes (1-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_8"
                },
                [9] = {
                    label = "Shoes (1-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_9"
                },
                [10] = {
                    label = "Shoes (1-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_10"
                },
                [11] = {
                    label = "Shoes (1-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_11"
                },
                [12] = {
                    label = "Shoes (1-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_12"
                },
                [13] = {
                    label = "Shoes (1-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_13"
                },
                [14] = {
                    label = "Shoes (1-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_14"
                },
                [15] = {
                    label = "Shoes (1-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_1_15"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (2-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_0"
                },
                [1] = {
                    label = "Shoes (2-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_1"
                },
                [2] = {
                    label = "Shoes (2-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_2"
                },
                [3] = {
                    label = "Shoes (2-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_3"
                },
                [4] = {
                    label = "Shoes (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_4"
                },
                [5] = {
                    label = "Shoes (2-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_5"
                },
                [6] = {
                    label = "Shoes (2-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_6"
                },
                [7] = {
                    label = "Shoes (2-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_7"
                },
                [8] = {
                    label = "Shoes (2-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_8"
                },
                [9] = {
                    label = "Shoes (2-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_9"
                },
                [10] = {
                    label = "Shoes (2-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_10"
                },
                [11] = {
                    label = "Shoes (2-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_11"
                },
                [12] = {
                    label = "Shoes (2-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_12"
                },
                [13] = {
                    label = "Shoes (2-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_13"
                },
                [14] = {
                    label = "Shoes (2-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_14"
                },
                [15] = {
                    label = "Shoes (2-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_2_15"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (3-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_0"
                },
                [1] = {
                    label = "Shoes (3-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_1"
                },
                [2] = {
                    label = "Shoes (3-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_2"
                },
                [3] = {
                    label = "Shoes (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_3"
                },
                [4] = {
                    label = "Shoes (3-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_4"
                },
                [5] = {
                    label = "Shoes (3-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_5"
                },
                [6] = {
                    label = "Shoes (3-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_6"
                },
                [7] = {
                    label = "Shoes (3-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_7"
                },
                [8] = {
                    label = "Shoes (3-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_8"
                },
                [9] = {
                    label = "Shoes (3-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_9"
                },
                [10] = {
                    label = "Shoes (3-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_10"
                },
                [11] = {
                    label = "Shoes (3-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_11"
                },
                [12] = {
                    label = "Shoes (3-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_12"
                },
                [13] = {
                    label = "Shoes (3-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_13"
                },
                [14] = {
                    label = "Shoes (3-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_14"
                },
                [15] = {
                    label = "Shoes (3-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_3_15"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (4-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_0"
                },
                [1] = {
                    label = "Shoes (4-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_1"
                },
                [2] = {
                    label = "Shoes (4-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_2"
                },
                [3] = {
                    label = "Shoes (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_3"
                },
                [4] = {
                    label = "Shoes (4-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_4"
                },
                [5] = {
                    label = "Shoes (4-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_5"
                },
                [6] = {
                    label = "Shoes (4-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_6"
                },
                [7] = {
                    label = "Shoes (4-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_7"
                },
                [8] = {
                    label = "Shoes (4-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_8"
                },
                [9] = {
                    label = "Shoes (4-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_9"
                },
                [10] = {
                    label = "Shoes (4-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_10"
                },
                [11] = {
                    label = "Shoes (4-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_11"
                },
                [12] = {
                    label = "Shoes (4-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_12"
                },
                [13] = {
                    label = "Shoes (4-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_13"
                },
                [14] = {
                    label = "Shoes (4-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_14"
                },
                [15] = {
                    label = "Shoes (4-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_4_15"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (5-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_0"
                },
                [1] = {
                    label = "Shoes (5-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_1"
                },
                [2] = {
                    label = "Shoes (5-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_2"
                },
                [3] = {
                    label = "Shoes (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_3"
                },
                [4] = {
                    label = "Shoes (5-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_4"
                },
                [5] = {
                    label = "Shoes (5-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_5"
                },
                [6] = {
                    label = "Shoes (5-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_6"
                },
                [7] = {
                    label = "Shoes (5-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_7"
                },
                [8] = {
                    label = "Shoes (5-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_8"
                },
                [9] = {
                    label = "Shoes (5-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_9"
                },
                [10] = {
                    label = "Shoes (5-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_10"
                },
                [11] = {
                    label = "Shoes (5-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_11"
                },
                [12] = {
                    label = "Shoes (5-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_12"
                },
                [13] = {
                    label = "Shoes (5-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_13"
                },
                [14] = {
                    label = "Shoes (5-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_14"
                },
                [15] = {
                    label = "Shoes (5-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_5_15"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (6-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_0"
                },
                [1] = {
                    label = "Shoes (6-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_1"
                },
                [2] = {
                    label = "Shoes (6-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_2"
                },
                [3] = {
                    label = "Shoes (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_3"
                },
                [4] = {
                    label = "Shoes (6-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_4"
                },
                [5] = {
                    label = "Shoes (6-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_5"
                },
                [6] = {
                    label = "Shoes (6-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_6"
                },
                [7] = {
                    label = "Shoes (6-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_7"
                },
                [8] = {
                    label = "Shoes (6-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_8"
                },
                [9] = {
                    label = "Shoes (6-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_9"
                },
                [10] = {
                    label = "Shoes (6-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_10"
                },
                [11] = {
                    label = "Shoes (6-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_11"
                },
                [12] = {
                    label = "Shoes (6-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_12"
                },
                [13] = {
                    label = "Shoes (6-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_13"
                },
                [14] = {
                    label = "Shoes (6-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_14"
                },
                [15] = {
                    label = "Shoes (6-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_6_15"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (7-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_0"
                },
                [1] = {
                    label = "Shoes (7-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_1"
                },
                [2] = {
                    label = "Shoes (7-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_2"
                },
                [3] = {
                    label = "Shoes (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_3"
                },
                [4] = {
                    label = "Shoes (7-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_4"
                },
                [5] = {
                    label = "Shoes (7-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_5"
                },
                [6] = {
                    label = "Shoes (7-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_6"
                },
                [7] = {
                    label = "Shoes (7-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_7"
                },
                [8] = {
                    label = "Shoes (7-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_8"
                },
                [9] = {
                    label = "Shoes (7-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_9"
                },
                [10] = {
                    label = "Shoes (7-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_10"
                },
                [11] = {
                    label = "Shoes (7-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_11"
                },
                [12] = {
                    label = "Shoes (7-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_12"
                },
                [13] = {
                    label = "Shoes (7-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_13"
                },
                [14] = {
                    label = "Shoes (7-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_14"
                },
                [15] = {
                    label = "Shoes (7-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_7_15"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (8-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_0"
                },
                [1] = {
                    label = "Shoes (8-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_1"
                },
                [2] = {
                    label = "Shoes (8-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_2"
                },
                [3] = {
                    label = "Shoes (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_3"
                },
                [4] = {
                    label = "Shoes (8-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_4"
                },
                [5] = {
                    label = "Shoes (8-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_5"
                },
                [6] = {
                    label = "Shoes (8-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_6"
                },
                [7] = {
                    label = "Shoes (8-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_7"
                },
                [8] = {
                    label = "Shoes (8-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_8"
                },
                [9] = {
                    label = "Shoes (8-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_9"
                },
                [10] = {
                    label = "Shoes (8-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_10"
                },
                [11] = {
                    label = "Shoes (8-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_11"
                },
                [12] = {
                    label = "Shoes (8-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_12"
                },
                [13] = {
                    label = "Shoes (8-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_13"
                },
                [14] = {
                    label = "Shoes (8-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_14"
                },
                [15] = {
                    label = "Shoes (8-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_8_15"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (9-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_0"
                },
                [1] = {
                    label = "Shoes (9-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_1"
                },
                [2] = {
                    label = "Shoes (9-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_2"
                },
                [3] = {
                    label = "Shoes (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_3"
                },
                [4] = {
                    label = "Shoes (9-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_4"
                },
                [5] = {
                    label = "Shoes (9-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_5"
                },
                [6] = {
                    label = "Shoes (9-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_6"
                },
                [7] = {
                    label = "Shoes (9-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_7"
                },
                [8] = {
                    label = "Shoes (9-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_8"
                },
                [9] = {
                    label = "Shoes (9-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_9"
                },
                [10] = {
                    label = "Shoes (9-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_10"
                },
                [11] = {
                    label = "Shoes (9-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_11"
                },
                [12] = {
                    label = "Shoes (9-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_12"
                },
                [13] = {
                    label = "Shoes (9-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_13"
                },
                [14] = {
                    label = "Shoes (9-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_14"
                },
                [15] = {
                    label = "Shoes (9-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_9_15"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (10-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_0"
                },
                [1] = {
                    label = "Shoes (10-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_1"
                },
                [2] = {
                    label = "Shoes (10-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_2"
                },
                [3] = {
                    label = "Shoes (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_3"
                },
                [4] = {
                    label = "Shoes (10-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_4"
                },
                [5] = {
                    label = "Shoes (10-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_5"
                },
                [6] = {
                    label = "Shoes (10-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_6"
                },
                [7] = {
                    label = "Shoes (10-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_7"
                },
                [8] = {
                    label = "Shoes (10-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_8"
                },
                [9] = {
                    label = "Shoes (10-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_9"
                },
                [10] = {
                    label = "Shoes (10-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_10"
                },
                [11] = {
                    label = "Shoes (10-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_11"
                },
                [12] = {
                    label = "Shoes (10-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_12"
                },
                [13] = {
                    label = "Shoes (10-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_13"
                },
                [14] = {
                    label = "Shoes (10-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_14"
                },
                [15] = {
                    label = "Shoes (10-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_10_15"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (11-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_0"
                },
                [1] = {
                    label = "Shoes (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_1"
                },
                [2] = {
                    label = "Shoes (11-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_2"
                },
                [3] = {
                    label = "Shoes (11-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_3"
                },
                [4] = {
                    label = "Shoes (11-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_4"
                },
                [5] = {
                    label = "Shoes (11-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_5"
                },
                [6] = {
                    label = "Shoes (11-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_6"
                },
                [7] = {
                    label = "Shoes (11-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_7"
                },
                [8] = {
                    label = "Shoes (11-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_8"
                },
                [9] = {
                    label = "Shoes (11-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_9"
                },
                [10] = {
                    label = "Shoes (11-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_10"
                },
                [11] = {
                    label = "Shoes (11-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_11"
                },
                [12] = {
                    label = "Shoes (11-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_12"
                },
                [13] = {
                    label = "Shoes (11-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_13"
                },
                [14] = {
                    label = "Shoes (11-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_14"
                },
                [15] = {
                    label = "Shoes (11-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_11_15"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (12-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_0"
                },
                [1] = {
                    label = "Shoes (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_1"
                },
                [2] = {
                    label = "Shoes (12-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_2"
                },
                [3] = {
                    label = "Shoes (12-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_3"
                },
                [4] = {
                    label = "Shoes (12-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_4"
                },
                [5] = {
                    label = "Shoes (12-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_5"
                },
                [6] = {
                    label = "Shoes (12-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_6"
                },
                [7] = {
                    label = "Shoes (12-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_7"
                },
                [8] = {
                    label = "Shoes (12-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_8"
                },
                [9] = {
                    label = "Shoes (12-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_9"
                },
                [10] = {
                    label = "Shoes (12-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_10"
                },
                [11] = {
                    label = "Shoes (12-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_11"
                },
                [12] = {
                    label = "Shoes (12-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_12"
                },
                [13] = {
                    label = "Shoes (12-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_13"
                },
                [14] = {
                    label = "Shoes (12-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_14"
                },
                [15] = {
                    label = "Shoes (12-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_12_15"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (13-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_0"
                },
                [1] = {
                    label = "Shoes (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_1"
                },
                [2] = {
                    label = "Shoes (13-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_2"
                },
                [3] = {
                    label = "Shoes (13-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_3"
                },
                [4] = {
                    label = "Shoes (13-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_4"
                },
                [5] = {
                    label = "Shoes (13-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_5"
                },
                [6] = {
                    label = "Shoes (13-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_6"
                },
                [7] = {
                    label = "Shoes (13-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_7"
                },
                [8] = {
                    label = "Shoes (13-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_8"
                },
                [9] = {
                    label = "Shoes (13-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_9"
                },
                [10] = {
                    label = "Shoes (13-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_10"
                },
                [11] = {
                    label = "Shoes (13-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_11"
                },
                [12] = {
                    label = "Shoes (13-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_12"
                },
                [13] = {
                    label = "Shoes (13-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_13"
                },
                [14] = {
                    label = "Shoes (13-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_14"
                },
                [15] = {
                    label = "Shoes (13-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_13_15"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (14-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_0"
                },
                [1] = {
                    label = "Shoes (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_1"
                },
                [2] = {
                    label = "Shoes (14-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_2"
                },
                [3] = {
                    label = "Shoes (14-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_3"
                },
                [4] = {
                    label = "Shoes (14-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_4"
                },
                [5] = {
                    label = "Shoes (14-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_5"
                },
                [6] = {
                    label = "Shoes (14-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_6"
                },
                [7] = {
                    label = "Shoes (14-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_7"
                },
                [8] = {
                    label = "Shoes (14-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_8"
                },
                [9] = {
                    label = "Shoes (14-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_9"
                },
                [10] = {
                    label = "Shoes (14-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_10"
                },
                [11] = {
                    label = "Shoes (14-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_11"
                },
                [12] = {
                    label = "Shoes (14-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_12"
                },
                [13] = {
                    label = "Shoes (14-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_13"
                },
                [14] = {
                    label = "Shoes (14-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_14"
                },
                [15] = {
                    label = "Shoes (14-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (15-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_0"
                },
                [1] = {
                    label = "Shoes (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_1"
                },
                [2] = {
                    label = "Shoes (15-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_2"
                },
                [3] = {
                    label = "Shoes (15-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_3"
                },
                [4] = {
                    label = "Shoes (15-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_4"
                },
                [5] = {
                    label = "Shoes (15-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_5"
                },
                [6] = {
                    label = "Shoes (15-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_6"
                },
                [7] = {
                    label = "Shoes (15-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_7"
                },
                [8] = {
                    label = "Shoes (15-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_8"
                },
                [9] = {
                    label = "Shoes (15-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_9"
                },
                [10] = {
                    label = "Shoes (15-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_10"
                },
                [11] = {
                    label = "Shoes (15-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_11"
                },
                [12] = {
                    label = "Shoes (15-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_12"
                },
                [13] = {
                    label = "Shoes (15-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_13"
                },
                [14] = {
                    label = "Shoes (15-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_14"
                },
                [15] = {
                    label = "Shoes (15-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_15_15"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Charcoal Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_0"
                },
                [1] = {
                    label = "Tan Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_1"
                },
                [2] = {
                    label = "Blue Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_2"
                },
                [3] = {
                    label = "Gutter & Blood Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_3"
                },
                [4] = {
                    label = "Lobster Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_4"
                },
                [5] = {
                    label = "Green Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_5"
                },
                [6] = {
                    label = "Woodland Camo Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_6"
                },
                [7] = {
                    label = "Hawaiian Snow Sun Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_7"
                },
                [8] = {
                    label = "Purple Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_8"
                },
                [9] = {
                    label = "Pink Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_9"
                },
                [10] = {
                    label = "Swingers Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_10"
                },
                [11] = {
                    label = "Penetrators Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_16_11"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Elf Shoes",
                    price = 500,
                    type = "money",
                    image = "female_shoes_17_0"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (18-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_18_0"
                },
                [1] = {
                    label = "Shoes (18-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_18_1"
                },
                [2] = {
                    label = "Shoes (18-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_18_2"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Olive Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_0"
                },
                [1] = {
                    label = "Turquoise Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_1"
                },
                [2] = {
                    label = "Earth Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_2"
                },
                [3] = {
                    label = "Red Crush Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_3"
                },
                [4] = {
                    label = "Pink Flash Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_4"
                },
                [5] = {
                    label = "Kitty Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_5"
                },
                [6] = {
                    label = "Rouge Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_6"
                },
                [7] = {
                    label = "Hot Pink Crush Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_7"
                },
                [8] = {
                    label = "Peach Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_8"
                },
                [9] = {
                    label = "Dipped Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_9"
                },
                [10] = {
                    label = "Candy Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_10"
                },
                [11] = {
                    label = "Blue Platforms",
                    price = 500,
                    type = "money",
                    image = "female_shoes_19_11"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Leopard Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_0"
                },
                [1] = {
                    label = "Olive Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_1"
                },
                [2] = {
                    label = "Burgundy Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_2"
                },
                [3] = {
                    label = "Gray Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_3"
                },
                [4] = {
                    label = "Red Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_4"
                },
                [5] = {
                    label = "Pink Leopard Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_5"
                },
                [6] = {
                    label = "Blue Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_6"
                },
                [7] = {
                    label = "Sky Blue Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_7"
                },
                [8] = {
                    label = "Neon Pink Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_8"
                },
                [9] = {
                    label = "Neon Yellow Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_9"
                },
                [10] = {
                    label = "White Dipped Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_10"
                },
                [11] = {
                    label = "Zebra Patent Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_20_11"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ochre Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_0"
                },
                [1] = {
                    label = "Chestnut Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_1"
                },
                [2] = {
                    label = "Purple Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_2"
                },
                [3] = {
                    label = "Burgundy Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_3"
                },
                [4] = {
                    label = "Blue Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_4"
                },
                [5] = {
                    label = "Red Accent Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_5"
                },
                [6] = {
                    label = "Coffee Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_6"
                },
                [7] = {
                    label = "Ochre Accent Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_7"
                },
                [8] = {
                    label = "Purple Accent Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_8"
                },
                [9] = {
                    label = "Gray Accent Knee High",
                    price = 500,
                    type = "money",
                    image = "female_shoes_21_9"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Beige Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_0"
                },
                [1] = {
                    label = "Black Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_1"
                },
                [2] = {
                    label = "Coffee Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_2"
                },
                [3] = {
                    label = "White Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_3"
                },
                [4] = {
                    label = "Gray Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_4"
                },
                [5] = {
                    label = "Black & White Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_5"
                },
                [6] = {
                    label = "Olive Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_6"
                },
                [7] = {
                    label = "Blue Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_7"
                },
                [8] = {
                    label = "Tan Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_8"
                },
                [9] = {
                    label = "Red Accent Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_9"
                },
                [10] = {
                    label = "Chocolate Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_10"
                },
                [11] = {
                    label = "Pink Accent Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_11"
                },
                [12] = {
                    label = "Purple Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_12"
                },
                [13] = {
                    label = "Copper Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_13"
                },
                [14] = {
                    label = "Leopard Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_14"
                },
                [15] = {
                    label = "Gold Studded Folded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_22_15"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Sparkly Shoes",
                    price = 500,
                    type = "money",
                    image = "female_shoes_23_0"
                },
                [1] = {
                    label = "Red Sparkly Shoes",
                    price = 500,
                    type = "money",
                    image = "female_shoes_23_1"
                },
                [2] = {
                    label = "White Sparkly Shoes",
                    price = 500,
                    type = "money",
                    image = "female_shoes_23_2"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Flight Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_24_0"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_25_0"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Scruffy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_26_0"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Backside",
                    price = 500,
                    type = "money",
                    image = "female_shoes_27_0"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Sports",
                    price = 500,
                    type = "money",
                    image = "female_shoes_28_0"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_29_0"
                },
                [1] = {
                    label = "White Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_29_1"
                },
                [2] = {
                    label = "Brown Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_29_2"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Leather Studded Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_30_0"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Golden Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_31_0"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Calypso Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_32_0"
                },
                [1] = {
                    label = "Buzz Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_32_1"
                },
                [2] = {
                    label = "Fresh Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_32_2"
                },
                [3] = {
                    label = "Jinx Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_32_3"
                },
                [4] = {
                    label = "Animal Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_32_4"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_0"
                },
                [1] = {
                    label = "Black Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_1"
                },
                [2] = {
                    label = "Gray Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_2"
                },
                [3] = {
                    label = "White Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_3"
                },
                [4] = {
                    label = "Red Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_4"
                },
                [5] = {
                    label = "Blue Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_5"
                },
                [6] = {
                    label = "Green Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_6"
                },
                [7] = {
                    label = "Brown Canvas Snugs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_33_7"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (34-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_34_0"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "No Shoes",
                    price = 500,
                    type = "money",
                    image = "female_shoes_35_0"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Walking Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_36_0"
                },
                [1] = {
                    label = "Khaki Walking Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_36_1"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "Sienna Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_37_0"
                },
                [1] = {
                    label = "Orange Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_37_1"
                },
                [2] = {
                    label = "Brown Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_37_2"
                },
                [3] = {
                    label = "Black Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_37_3"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_38_0"
                },
                [1] = {
                    label = "Sienna Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_38_1"
                },
                [2] = {
                    label = "Cream Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_38_2"
                },
                [3] = {
                    label = "Brown Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_38_3"
                },
                [4] = {
                    label = "Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_38_4"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_39_0"
                },
                [1] = {
                    label = "Sienna Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_39_1"
                },
                [2] = {
                    label = "Cream Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_39_2"
                },
                [3] = {
                    label = "Brown Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_39_3"
                },
                [4] = {
                    label = "Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_39_4"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (40-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_40_0"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (41-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_0"
                },
                [1] = {
                    label = "Shoes (41-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_1"
                },
                [2] = {
                    label = "Shoes (41-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_2"
                },
                [3] = {
                    label = "Shoes (41-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_3"
                },
                [4] = {
                    label = "Shoes (41-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_4"
                },
                [5] = {
                    label = "Shoes (41-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_5"
                },
                [6] = {
                    label = "Shoes (41-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_6"
                },
                [7] = {
                    label = "Shoes (41-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_7"
                },
                [8] = {
                    label = "Shoes (41-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_8"
                },
                [9] = {
                    label = "Shoes (41-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_9"
                },
                [10] = {
                    label = "Shoes (41-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_10"
                },
                [11] = {
                    label = "Shoes (41-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_41_11"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Nude Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_0"
                },
                [1] = {
                    label = "Purple Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_1"
                },
                [2] = {
                    label = "Black Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_2"
                },
                [3] = {
                    label = "Blue Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_3"
                },
                [4] = {
                    label = "Red Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_4"
                },
                [5] = {
                    label = "Hot Pink Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_5"
                },
                [6] = {
                    label = "Pink Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_6"
                },
                [7] = {
                    label = "Crimson Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_7"
                },
                [8] = {
                    label = "Lilac Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_8"
                },
                [9] = {
                    label = "Cream Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_9"
                },
                [10] = {
                    label = "Leopard Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_10"
                },
                [11] = {
                    label = "Red Sparkle Rounded Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_42_11"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_0"
                },
                [1] = {
                    label = "Black Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_1"
                },
                [2] = {
                    label = "Gray Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_2"
                },
                [3] = {
                    label = "White Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_3"
                },
                [4] = {
                    label = "Red Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_4"
                },
                [5] = {
                    label = "Blue Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_5"
                },
                [6] = {
                    label = "Green Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_6"
                },
                [7] = {
                    label = "Brown Sneaker Wedges",
                    price = 500,
                    type = "money",
                    image = "female_shoes_43_7"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_0"
                },
                [1] = {
                    label = "Black Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_1"
                },
                [2] = {
                    label = "Gray Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_2"
                },
                [3] = {
                    label = "White Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_3"
                },
                [4] = {
                    label = "Red Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_4"
                },
                [5] = {
                    label = "Blue Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_5"
                },
                [6] = {
                    label = "Green Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_6"
                },
                [7] = {
                    label = "Brown Sneaker Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_44_7"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_0"
                },
                [1] = {
                    label = "Hot Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_1"
                },
                [2] = {
                    label = "White Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_2"
                },
                [3] = {
                    label = "Red Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_3"
                },
                [4] = {
                    label = "Wine Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_4"
                },
                [5] = {
                    label = "Crimson Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_5"
                },
                [6] = {
                    label = "Green Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_6"
                },
                [7] = {
                    label = "Purple Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_7"
                },
                [8] = {
                    label = "Orange Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_8"
                },
                [9] = {
                    label = "Navy Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_9"
                },
                [10] = {
                    label = "Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_45_10"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_0"
                },
                [1] = {
                    label = "Hot Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_1"
                },
                [2] = {
                    label = "White Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_2"
                },
                [3] = {
                    label = "Red Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_3"
                },
                [4] = {
                    label = "Wine Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_4"
                },
                [5] = {
                    label = "Crimson Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_5"
                },
                [6] = {
                    label = "Green Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_6"
                },
                [7] = {
                    label = "Purple Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_7"
                },
                [8] = {
                    label = "Orange Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_8"
                },
                [9] = {
                    label = "Navy Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_9"
                },
                [10] = {
                    label = "Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_46_10"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (47-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_0"
                },
                [1] = {
                    label = "Shoes (47-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_1"
                },
                [2] = {
                    label = "Shoes (47-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_2"
                },
                [3] = {
                    label = "Shoes (47-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_3"
                },
                [4] = {
                    label = "Shoes (47-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_4"
                },
                [5] = {
                    label = "Shoes (47-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_5"
                },
                [6] = {
                    label = "Shoes (47-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_6"
                },
                [7] = {
                    label = "Shoes (47-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_7"
                },
                [8] = {
                    label = "Shoes (47-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_8"
                },
                [9] = {
                    label = "Shoes (47-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_47_9"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (48-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_0"
                },
                [1] = {
                    label = "Shoes (48-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_1"
                },
                [2] = {
                    label = "Shoes (48-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_2"
                },
                [3] = {
                    label = "Shoes (48-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_3"
                },
                [4] = {
                    label = "Shoes (48-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_4"
                },
                [5] = {
                    label = "Shoes (48-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_5"
                },
                [6] = {
                    label = "Shoes (48-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_6"
                },
                [7] = {
                    label = "Shoes (48-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_7"
                },
                [8] = {
                    label = "Shoes (48-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_8"
                },
                [9] = {
                    label = "Shoes (48-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_9"
                },
                [10] = {
                    label = "Shoes (48-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_10"
                },
                [11] = {
                    label = "Shoes (48-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_48_11"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (49-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_49_0"
                },
                [1] = {
                    label = "Shoes (49-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (50-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_50_0"
                },
                [1] = {
                    label = "Shoes (50-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_50_1"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_0"
                },
                [1] = {
                    label = "Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_1"
                },
                [2] = {
                    label = "Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_2"
                },
                [3] = {
                    label = "Worn Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_3"
                },
                [4] = {
                    label = "Worn Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_4"
                },
                [5] = {
                    label = "Worn Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_51_5"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_0"
                },
                [1] = {
                    label = "Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_1"
                },
                [2] = {
                    label = "Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_2"
                },
                [3] = {
                    label = "Worn Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_3"
                },
                [4] = {
                    label = "Worn Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_4"
                },
                [5] = {
                    label = "Worn Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_52_5"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_53_0"
                },
                [1] = {
                    label = "Black Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_53_1"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_0"
                },
                [1] = {
                    label = "Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_1"
                },
                [2] = {
                    label = "Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_2"
                },
                [3] = {
                    label = "Worn Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_3"
                },
                [4] = {
                    label = "Worn Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_4"
                },
                [5] = {
                    label = "Worn Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_54_5"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_0"
                },
                [1] = {
                    label = "Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_1"
                },
                [2] = {
                    label = "Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_2"
                },
                [3] = {
                    label = "Worn Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_3"
                },
                [4] = {
                    label = "Worn Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_4"
                },
                [5] = {
                    label = "Worn Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_55_5"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_56_0"
                },
                [1] = {
                    label = "Ox Blood Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_56_1"
                },
                [2] = {
                    label = "Tan Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_56_2"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_57_0"
                },
                [1] = {
                    label = "Ox Blood Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_57_1"
                },
                [2] = {
                    label = "Tan Calf Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_57_2"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (58-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_0"
                },
                [1] = {
                    label = "Shoes (58-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_1"
                },
                [2] = {
                    label = "Shoes (58-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_2"
                },
                [3] = {
                    label = "Shoes (58-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_3"
                },
                [4] = {
                    label = "Shoes (58-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_4"
                },
                [5] = {
                    label = "Shoes (58-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_5"
                },
                [6] = {
                    label = "Shoes (58-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_6"
                },
                [7] = {
                    label = "Shoes (58-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_7"
                },
                [8] = {
                    label = "Shoes (58-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_8"
                },
                [9] = {
                    label = "Shoes (58-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_9"
                },
                [10] = {
                    label = "Shoes (58-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_58_10"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_59_0"
                },
                [1] = {
                    label = "Black Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_59_1"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Peach Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_0"
                },
                [1] = {
                    label = "Purple Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_1"
                },
                [2] = {
                    label = "Blue Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_2"
                },
                [3] = {
                    label = "Bronze Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_3"
                },
                [4] = {
                    label = "Pearl Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_4"
                },
                [5] = {
                    label = "Copper Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_5"
                },
                [6] = {
                    label = "Silver Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_6"
                },
                [7] = {
                    label = "Green Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_7"
                },
                [8] = {
                    label = "Cherry Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_8"
                },
                [9] = {
                    label = "White Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_9"
                },
                [10] = {
                    label = "Black Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_10"
                },
                [11] = {
                    label = "Pink Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_60_11"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (61-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_61_0"
                },
                [1] = {
                    label = "Shoes (61-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_61_1"
                },
                [2] = {
                    label = "Shoes (61-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_61_2"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_0"
                },
                [1] = {
                    label = "Brown Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_1"
                },
                [2] = {
                    label = "Green Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_2"
                },
                [3] = {
                    label = "Gray Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_3"
                },
                [4] = {
                    label = "Peach Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_4"
                },
                [5] = {
                    label = "Fall Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_5"
                },
                [6] = {
                    label = "Dark Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_6"
                },
                [7] = {
                    label = "Crosshatch Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_7"
                },
                [8] = {
                    label = "Moss Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_8"
                },
                [9] = {
                    label = "Gray Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_9"
                },
                [10] = {
                    label = "Aqua Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_10"
                },
                [11] = {
                    label = "Splinter Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_11"
                },
                [12] = {
                    label = "Contrast Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_12"
                },
                [13] = {
                    label = "Cobble Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_13"
                },
                [14] = {
                    label = "Peach Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_14"
                },
                [15] = {
                    label = "Brushstroke Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_15"
                },
                [16] = {
                    label = "Flecktarn Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_16"
                },
                [17] = {
                    label = "Light Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_17"
                },
                [18] = {
                    label = "Moss Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_18"
                },
                [19] = {
                    label = "Sand Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_19"
                },
                [20] = {
                    label = "Black Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_20"
                },
                [21] = {
                    label = "Slate Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_21"
                },
                [22] = {
                    label = "White Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_22"
                },
                [23] = {
                    label = "Brown Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_23"
                },
                [24] = {
                    label = "Green Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_24"
                },
                [25] = {
                    label = "Red Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_62_25"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_0"
                },
                [1] = {
                    label = "Beige Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_1"
                },
                [2] = {
                    label = "Brown Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_2"
                },
                [3] = {
                    label = "Moss Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_3"
                },
                [4] = {
                    label = "Tawny Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_4"
                },
                [5] = {
                    label = "Venom Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_5"
                },
                [6] = {
                    label = "Desert Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_6"
                },
                [7] = {
                    label = "Chocolate Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_63_7"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_0"
                },
                [1] = {
                    label = "Beige Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_1"
                },
                [2] = {
                    label = "Brown Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_2"
                },
                [3] = {
                    label = "Moss Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_3"
                },
                [4] = {
                    label = "Tawny Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_4"
                },
                [5] = {
                    label = "Venom Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_5"
                },
                [6] = {
                    label = "Desert Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_6"
                },
                [7] = {
                    label = "Chocolate Tech Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_64_7"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Desert Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_0"
                },
                [1] = {
                    label = "Sage Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_1"
                },
                [2] = {
                    label = "Blue Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_2"
                },
                [3] = {
                    label = "Khaki Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_3"
                },
                [4] = {
                    label = "Charcoal Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_4"
                },
                [5] = {
                    label = "Walnut Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_5"
                },
                [6] = {
                    label = "Silver Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_6"
                },
                [7] = {
                    label = "Olive Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_65_7"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Desert Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_0"
                },
                [1] = {
                    label = "Sage Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_1"
                },
                [2] = {
                    label = "Blue Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_2"
                },
                [3] = {
                    label = "Khaki Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_3"
                },
                [4] = {
                    label = "Charcoal Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_4"
                },
                [5] = {
                    label = "Walnut Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_5"
                },
                [6] = {
                    label = "Silver Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_6"
                },
                [7] = {
                    label = "Olive Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_66_7"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (67-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_0"
                },
                [1] = {
                    label = "Shoes (67-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_1"
                },
                [2] = {
                    label = "Shoes (67-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_2"
                },
                [3] = {
                    label = "Shoes (67-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_3"
                },
                [4] = {
                    label = "Shoes (67-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_4"
                },
                [5] = {
                    label = "Shoes (67-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_5"
                },
                [6] = {
                    label = "Shoes (67-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_6"
                },
                [7] = {
                    label = "Shoes (67-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_7"
                },
                [8] = {
                    label = "Shoes (67-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_8"
                },
                [9] = {
                    label = "Shoes (67-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_9"
                },
                [10] = {
                    label = "Shoes (67-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_10"
                },
                [11] = {
                    label = "Shoes (67-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_11"
                },
                [12] = {
                    label = "Shoes (67-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_12"
                },
                [13] = {
                    label = "Shoes (67-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_67_13"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_0"
                },
                [1] = {
                    label = "Black Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_1"
                },
                [2] = {
                    label = "Charcoal Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_2"
                },
                [3] = {
                    label = "Chocolate Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_3"
                },
                [4] = {
                    label = "Tan Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_4"
                },
                [5] = {
                    label = "Rust Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_5"
                },
                [6] = {
                    label = "Russet Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_68_6"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_0"
                },
                [1] = {
                    label = "Black Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_1"
                },
                [2] = {
                    label = "Charcoal Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_2"
                },
                [3] = {
                    label = "Chocolate Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_3"
                },
                [4] = {
                    label = "Tan Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_4"
                },
                [5] = {
                    label = "Rust Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_5"
                },
                [6] = {
                    label = "Russet Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_69_6"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (70-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_0"
                },
                [1] = {
                    label = "Shoes (70-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_1"
                },
                [2] = {
                    label = "Shoes (70-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_2"
                },
                [3] = {
                    label = "Shoes (70-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_3"
                },
                [4] = {
                    label = "Shoes (70-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_4"
                },
                [5] = {
                    label = "Shoes (70-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_5"
                },
                [6] = {
                    label = "Shoes (70-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_6"
                },
                [7] = {
                    label = "Shoes (70-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_7"
                },
                [8] = {
                    label = "Shoes (70-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_8"
                },
                [9] = {
                    label = "Shoes (70-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_9"
                },
                [10] = {
                    label = "Shoes (70-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_10"
                },
                [11] = {
                    label = "Shoes (70-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_11"
                },
                [12] = {
                    label = "Shoes (70-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_12"
                },
                [13] = {
                    label = "Shoes (70-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_13"
                },
                [14] = {
                    label = "Shoes (70-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_14"
                },
                [15] = {
                    label = "Shoes (70-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_15"
                },
                [16] = {
                    label = "Shoes (70-16)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_16"
                },
                [17] = {
                    label = "Shoes (70-17)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_17"
                },
                [18] = {
                    label = "Shoes (70-18)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_18"
                },
                [19] = {
                    label = "Shoes (70-19)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_19"
                },
                [20] = {
                    label = "Shoes (70-20)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_20"
                },
                [21] = {
                    label = "Shoes (70-21)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_21"
                },
                [22] = {
                    label = "Shoes (70-22)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_22"
                },
                [23] = {
                    label = "Shoes (70-23)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_23"
                },
                [24] = {
                    label = "Shoes (70-24)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_24"
                },
                [25] = {
                    label = "Shoes (70-25)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_70_25"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (71-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_0"
                },
                [1] = {
                    label = "Shoes (71-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_1"
                },
                [2] = {
                    label = "Shoes (71-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_2"
                },
                [3] = {
                    label = "Shoes (71-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_3"
                },
                [4] = {
                    label = "Shoes (71-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_4"
                },
                [5] = {
                    label = "Shoes (71-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_5"
                },
                [6] = {
                    label = "Shoes (71-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_6"
                },
                [7] = {
                    label = "Shoes (71-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_7"
                },
                [8] = {
                    label = "Shoes (71-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_8"
                },
                [9] = {
                    label = "Shoes (71-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_9"
                },
                [10] = {
                    label = "Shoes (71-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_10"
                },
                [11] = {
                    label = "Shoes (71-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_71_11"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (72-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_0"
                },
                [1] = {
                    label = "Shoes (72-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_1"
                },
                [2] = {
                    label = "Shoes (72-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_2"
                },
                [3] = {
                    label = "Shoes (72-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_3"
                },
                [4] = {
                    label = "Shoes (72-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_4"
                },
                [5] = {
                    label = "Shoes (72-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_5"
                },
                [6] = {
                    label = "Shoes (72-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_6"
                },
                [7] = {
                    label = "Shoes (72-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_7"
                },
                [8] = {
                    label = "Shoes (72-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_8"
                },
                [9] = {
                    label = "Shoes (72-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_9"
                },
                [10] = {
                    label = "Shoes (72-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_10"
                },
                [11] = {
                    label = "Shoes (72-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_11"
                },
                [12] = {
                    label = "Shoes (72-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_12"
                },
                [13] = {
                    label = "Shoes (72-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_13"
                },
                [14] = {
                    label = "Shoes (72-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_14"
                },
                [15] = {
                    label = "Shoes (72-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_15"
                },
                [16] = {
                    label = "Shoes (72-16)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_16"
                },
                [17] = {
                    label = "Shoes (72-17)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_17"
                },
                [18] = {
                    label = "Shoes (72-18)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_18"
                },
                [19] = {
                    label = "Shoes (72-19)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_19"
                },
                [20] = {
                    label = "Shoes (72-20)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_20"
                },
                [21] = {
                    label = "Shoes (72-21)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_21"
                },
                [22] = {
                    label = "Shoes (72-22)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_22"
                },
                [23] = {
                    label = "Shoes (72-23)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_23"
                },
                [24] = {
                    label = "Shoes (72-24)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_24"
                },
                [25] = {
                    label = "Shoes (72-25)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_72_25"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Earth Tones Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_0"
                },
                [1] = {
                    label = "Mono Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_1"
                },
                [2] = {
                    label = "Gray & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_2"
                },
                [3] = {
                    label = "Grayscale Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_3"
                },
                [4] = {
                    label = "Khaki Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_4"
                },
                [5] = {
                    label = "Tan Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_5"
                },
                [6] = {
                    label = "Rust Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_6"
                },
                [7] = {
                    label = "Woodland Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_7"
                },
                [8] = {
                    label = "Aqua Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_8"
                },
                [9] = {
                    label = "Cyan Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_9"
                },
                [10] = {
                    label = "Pink Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_10"
                },
                [11] = {
                    label = "Gray Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_11"
                },
                [12] = {
                    label = "Blue & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_12"
                },
                [13] = {
                    label = "Navy & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_13"
                },
                [14] = {
                    label = "Houndstooth Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_14"
                },
                [15] = {
                    label = "Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_15"
                },
                [16] = {
                    label = "Orange Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_16"
                },
                [17] = {
                    label = "Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_17"
                },
                [18] = {
                    label = "Moss Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_18"
                },
                [19] = {
                    label = "Dark Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_19"
                },
                [20] = {
                    label = "Fall Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_20"
                },
                [21] = {
                    label = "Splinter Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_21"
                },
                [22] = {
                    label = "White & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_22"
                },
                [23] = {
                    label = "Black & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_23"
                },
                [24] = {
                    label = "Black & Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_24"
                },
                [25] = {
                    label = "Chocolate Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_73_25"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Earth Tones Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_0"
                },
                [1] = {
                    label = "Mono Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_1"
                },
                [2] = {
                    label = "Gray & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_2"
                },
                [3] = {
                    label = "Grayscale Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_3"
                },
                [4] = {
                    label = "Khaki Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_4"
                },
                [5] = {
                    label = "Tan Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_5"
                },
                [6] = {
                    label = "Rust Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_6"
                },
                [7] = {
                    label = "Woodland Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_7"
                },
                [8] = {
                    label = "Aqua Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_8"
                },
                [9] = {
                    label = "Cyan Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_9"
                },
                [10] = {
                    label = "Pink Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_10"
                },
                [11] = {
                    label = "Gray Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_11"
                },
                [12] = {
                    label = "Blue & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_12"
                },
                [13] = {
                    label = "Navy & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_13"
                },
                [14] = {
                    label = "Houndstooth Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_14"
                },
                [15] = {
                    label = "Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_15"
                },
                [16] = {
                    label = "Orange Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_16"
                },
                [17] = {
                    label = "Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_17"
                },
                [18] = {
                    label = "Moss Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_18"
                },
                [19] = {
                    label = "Dark Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_19"
                },
                [20] = {
                    label = "Fall Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_20"
                },
                [21] = {
                    label = "Splinter Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_21"
                },
                [22] = {
                    label = "White & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_22"
                },
                [23] = {
                    label = "Black & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_23"
                },
                [24] = {
                    label = "Black & Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_24"
                },
                [25] = {
                    label = "Chocolate Rubberized",
                    price = 500,
                    type = "money",
                    image = "female_shoes_74_25"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_0"
                },
                [1] = {
                    label = "Black & Sand Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_1"
                },
                [2] = {
                    label = "Black & Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_2"
                },
                [3] = {
                    label = "Buff Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_3"
                },
                [4] = {
                    label = "Gray & Yellow Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_4"
                },
                [5] = {
                    label = "Fall Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_5"
                },
                [6] = {
                    label = "Black & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_6"
                },
                [7] = {
                    label = "Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_7"
                },
                [8] = {
                    label = "Black & Light Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_8"
                },
                [9] = {
                    label = "White Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_9"
                },
                [10] = {
                    label = "Woodland Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_10"
                },
                [11] = {
                    label = "Slate Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_11"
                },
                [12] = {
                    label = "Tan Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_12"
                },
                [13] = {
                    label = "Moss Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_13"
                },
                [14] = {
                    label = "Khaki Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_14"
                },
                [15] = {
                    label = "Gray Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_15"
                },
                [16] = {
                    label = "Charcoal Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_16"
                },
                [17] = {
                    label = "Red Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_17"
                },
                [18] = {
                    label = "Orange Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_18"
                },
                [19] = {
                    label = "Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_19"
                },
                [20] = {
                    label = "Navy Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_20"
                },
                [21] = {
                    label = "Earth Tones Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_21"
                },
                [22] = {
                    label = "Light Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_22"
                },
                [23] = {
                    label = "Blue & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_23"
                },
                [24] = {
                    label = "Gray Camo Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_24"
                },
                [25] = {
                    label = "Aqua Camo Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_75_25"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_0"
                },
                [1] = {
                    label = "Black & Sand Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_1"
                },
                [2] = {
                    label = "Black & Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_2"
                },
                [3] = {
                    label = "Buff Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_3"
                },
                [4] = {
                    label = "Gray & Yellow Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_4"
                },
                [5] = {
                    label = "Fall Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_5"
                },
                [6] = {
                    label = "Black & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_6"
                },
                [7] = {
                    label = "Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_7"
                },
                [8] = {
                    label = "Black & Light Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_8"
                },
                [9] = {
                    label = "White Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_9"
                },
                [10] = {
                    label = "Woodland Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_10"
                },
                [11] = {
                    label = "Slate Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_11"
                },
                [12] = {
                    label = "Tan Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_12"
                },
                [13] = {
                    label = "Moss Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_13"
                },
                [14] = {
                    label = "Khaki Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_14"
                },
                [15] = {
                    label = "Gray Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_15"
                },
                [16] = {
                    label = "Charcoal Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_16"
                },
                [17] = {
                    label = "Red Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_17"
                },
                [18] = {
                    label = "Orange Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_18"
                },
                [19] = {
                    label = "Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_19"
                },
                [20] = {
                    label = "Navy Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_20"
                },
                [21] = {
                    label = "Earth Tones Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_21"
                },
                [22] = {
                    label = "Light Blue Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_22"
                },
                [23] = {
                    label = "Blue & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_23"
                },
                [24] = {
                    label = "Gray Camo Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_24"
                },
                [25] = {
                    label = "Aqua Camo Trail",
                    price = 500,
                    type = "money",
                    image = "female_shoes_76_25"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Catsuit Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_0"
                },
                [1] = {
                    label = "Gray Catsuit Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_1"
                },
                [2] = {
                    label = "Dark Brown Catsuit Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_2"
                },
                [3] = {
                    label = "Light Brown Catsuit Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_3"
                },
                [4] = {
                    label = "Yellow Catsuit Heels",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_4"
                },
                [5] = {
                    label = "Shoes (77-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_5"
                },
                [6] = {
                    label = "Shoes (77-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_6"
                },
                [7] = {
                    label = "Shoes (77-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_7"
                },
                [8] = {
                    label = "Shoes (77-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_77_8"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (78-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_78_0"
                },
                [1] = {
                    label = "Shoes (78-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_78_1"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Purple Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_0"
                },
                [1] = {
                    label = "Midnight Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_1"
                },
                [2] = {
                    label = "Sunset Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_2"
                },
                [3] = {
                    label = "Green Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_3"
                },
                [4] = {
                    label = "Cream & Pink Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_4"
                },
                [5] = {
                    label = "Black & Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_5"
                },
                [6] = {
                    label = "Gray & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_6"
                },
                [7] = {
                    label = "Shoes (79-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_7"
                },
                [8] = {
                    label = "Shoes (79-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_8"
                },
                [9] = {
                    label = "Shoes (79-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_9"
                },
                [10] = {
                    label = "Shoes (79-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_10"
                },
                [11] = {
                    label = "Orange Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_11"
                },
                [12] = {
                    label = "Pink Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_12"
                },
                [13] = {
                    label = "White & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_13"
                },
                [14] = {
                    label = "Vibrant Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_14"
                },
                [15] = {
                    label = "Ash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_15"
                },
                [16] = {
                    label = "Sage Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_16"
                },
                [17] = {
                    label = "All Gray Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_17"
                },
                [18] = {
                    label = "Blue Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_18"
                },
                [19] = {
                    label = "Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_19"
                },
                [20] = {
                    label = "Grayscale Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_20"
                },
                [21] = {
                    label = "Blue Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_21"
                },
                [22] = {
                    label = "White Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_22"
                },
                [23] = {
                    label = "Graphite Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_23"
                },
                [24] = {
                    label = "Mocha Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_24"
                },
                [25] = {
                    label = "Mono Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_79_25"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Purple Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_0"
                },
                [1] = {
                    label = "Midnight Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_1"
                },
                [2] = {
                    label = "Sunset Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_2"
                },
                [3] = {
                    label = "Green Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_3"
                },
                [4] = {
                    label = "Cream & Pink Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_4"
                },
                [5] = {
                    label = "Black & Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_5"
                },
                [6] = {
                    label = "Gray & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_6"
                },
                [7] = {
                    label = "Shoes (80-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_7"
                },
                [8] = {
                    label = "Shoes (80-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_8"
                },
                [9] = {
                    label = "Shoes (80-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_9"
                },
                [10] = {
                    label = "Shoes (80-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_10"
                },
                [11] = {
                    label = "Orange Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_11"
                },
                [12] = {
                    label = "Pink Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_12"
                },
                [13] = {
                    label = "White & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_13"
                },
                [14] = {
                    label = "Vibrant Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_14"
                },
                [15] = {
                    label = "Ash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_15"
                },
                [16] = {
                    label = "Sage Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_16"
                },
                [17] = {
                    label = "All Gray Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_17"
                },
                [18] = {
                    label = "Blue Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_18"
                },
                [19] = {
                    label = "Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_19"
                },
                [20] = {
                    label = "Grayscale Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_20"
                },
                [21] = {
                    label = "Blue Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_21"
                },
                [22] = {
                    label = "White Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_22"
                },
                [23] = {
                    label = "Graphite Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_23"
                },
                [24] = {
                    label = "Mocha Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_24"
                },
                [25] = {
                    label = "Mono Retro Runners",
                    price = 500,
                    type = "money",
                    image = "female_shoes_80_25"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "White & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_0"
                },
                [1] = {
                    label = "White & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_1"
                },
                [2] = {
                    label = "White & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_2"
                },
                [3] = {
                    label = "White & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_3"
                },
                [4] = {
                    label = "Gray & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_4"
                },
                [5] = {
                    label = "Gray & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_5"
                },
                [6] = {
                    label = "Gray & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_6"
                },
                [7] = {
                    label = "Gray & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_7"
                },
                [8] = {
                    label = "Black & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_8"
                },
                [9] = {
                    label = "Black & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_9"
                },
                [10] = {
                    label = "Black & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_10"
                },
                [11] = {
                    label = "Black & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_11"
                },
                [12] = {
                    label = "Pink & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_12"
                },
                [13] = {
                    label = "Pink & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_13"
                },
                [14] = {
                    label = "Ash & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_14"
                },
                [15] = {
                    label = "Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_15"
                },
                [16] = {
                    label = "Blue Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_16"
                },
                [17] = {
                    label = "Green Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_17"
                },
                [18] = {
                    label = "Pink Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_18"
                },
                [19] = {
                    label = "Red Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_19"
                },
                [20] = {
                    label = "Red Camo Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_20"
                },
                [21] = {
                    label = "Pink Camo Light Ups",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_21"
                },
                [22] = {
                    label = "Shoes (81-22)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_22"
                },
                [23] = {
                    label = "Shoes (81-23)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_23"
                },
                [24] = {
                    label = "Shoes (81-24)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_24"
                },
                [25] = {
                    label = "Shoes (81-25)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_81_25"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (82-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_0"
                },
                [1] = {
                    label = "Shoes (82-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_1"
                },
                [2] = {
                    label = "Shoes (82-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_2"
                },
                [3] = {
                    label = "Shoes (82-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_3"
                },
                [4] = {
                    label = "Shoes (82-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_4"
                },
                [5] = {
                    label = "Shoes (82-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_5"
                },
                [6] = {
                    label = "Shoes (82-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_6"
                },
                [7] = {
                    label = "Shoes (82-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_7"
                },
                [8] = {
                    label = "Shoes (82-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_8"
                },
                [9] = {
                    label = "Shoes (82-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_9"
                },
                [10] = {
                    label = "Shoes (82-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_10"
                },
                [11] = {
                    label = "Shoes (82-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_11"
                },
                [12] = {
                    label = "Shoes (82-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_12"
                },
                [13] = {
                    label = "Shoes (82-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_82_13"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_83_0"
                },
                [1] = {
                    label = "Red Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_83_1"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_84_0"
                },
                [1] = {
                    label = "Red Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_84_1"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_85_0"
                },
                [1] = {
                    label = "Dark Brown Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_85_1"
                },
                [2] = {
                    label = "Tan Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_85_2"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_86_0"
                },
                [1] = {
                    label = "Dark Brown Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_86_1"
                },
                [2] = {
                    label = "Tan Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_86_2"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (87-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_0"
                },
                [1] = {
                    label = "Shoes (87-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_1"
                },
                [2] = {
                    label = "Shoes (87-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_2"
                },
                [3] = {
                    label = "Shoes (87-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_3"
                },
                [4] = {
                    label = "Shoes (87-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_4"
                },
                [5] = {
                    label = "Shoes (87-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_5"
                },
                [6] = {
                    label = "Shoes (87-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_6"
                },
                [7] = {
                    label = "Shoes (87-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_7"
                },
                [8] = {
                    label = "Shoes (87-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_8"
                },
                [9] = {
                    label = "Shoes (87-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_9"
                },
                [10] = {
                    label = "Shoes (87-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_10"
                },
                [11] = {
                    label = "Shoes (87-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_11"
                },
                [12] = {
                    label = "Shoes (87-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_12"
                },
                [13] = {
                    label = "Shoes (87-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_13"
                },
                [14] = {
                    label = "Shoes (87-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_14"
                },
                [15] = {
                    label = "Shoes (87-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_15"
                },
                [16] = {
                    label = "Shoes (87-16)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_16"
                },
                [17] = {
                    label = "Shoes (87-17)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_17"
                },
                [18] = {
                    label = "Shoes (87-18)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_18"
                },
                [19] = {
                    label = "Shoes (87-19)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_87_19"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_0"
                },
                [1] = {
                    label = "Dark Brown Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_1"
                },
                [2] = {
                    label = "Green Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_2"
                },
                [3] = {
                    label = "Beige Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_3"
                },
                [4] = {
                    label = "White Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_4"
                },
                [5] = {
                    label = "Gray Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_5"
                },
                [6] = {
                    label = "Red Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_6"
                },
                [7] = {
                    label = "Brown & White Raider Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_88_7"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_0"
                },
                [1] = {
                    label = "Black Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_1"
                },
                [2] = {
                    label = "Light Green Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_2"
                },
                [3] = {
                    label = "Beige Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_3"
                },
                [4] = {
                    label = "Blue Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_4"
                },
                [5] = {
                    label = "Green Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_5"
                },
                [6] = {
                    label = "White Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_6"
                },
                [7] = {
                    label = "Crosshatch Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_7"
                },
                [8] = {
                    label = "Yellow Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_8"
                },
                [9] = {
                    label = "Steel Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_9"
                },
                [10] = {
                    label = "Red Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_10"
                },
                [11] = {
                    label = "Blue Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_11"
                },
                [12] = {
                    label = "Shoes (89-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_12"
                },
                [13] = {
                    label = "Shoes (89-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_13"
                },
                [14] = {
                    label = "Shoes (89-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_14"
                },
                [15] = {
                    label = "Shoes (89-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_89_15"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_0"
                },
                [1] = {
                    label = "Black Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_1"
                },
                [2] = {
                    label = "Light Green Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_2"
                },
                [3] = {
                    label = "Beige Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_3"
                },
                [4] = {
                    label = "Blue Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_4"
                },
                [5] = {
                    label = "Green Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_5"
                },
                [6] = {
                    label = "White Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_6"
                },
                [7] = {
                    label = "Crosshatch Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_7"
                },
                [8] = {
                    label = "Yellow Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_8"
                },
                [9] = {
                    label = "Steel Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_9"
                },
                [10] = {
                    label = "Red Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_10"
                },
                [11] = {
                    label = "Blue Plated Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_11"
                },
                [12] = {
                    label = "Shoes (90-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_12"
                },
                [13] = {
                    label = "Shoes (90-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_13"
                },
                [14] = {
                    label = "Shoes (90-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_14"
                },
                [15] = {
                    label = "Shoes (90-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_90_15"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (91-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_0"
                },
                [1] = {
                    label = "Shoes (91-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_1"
                },
                [2] = {
                    label = "Shoes (91-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_2"
                },
                [3] = {
                    label = "Shoes (91-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_3"
                },
                [4] = {
                    label = "Shoes (91-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_4"
                },
                [5] = {
                    label = "Shoes (91-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_5"
                },
                [6] = {
                    label = "Shoes (91-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_6"
                },
                [7] = {
                    label = "Shoes (91-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_7"
                },
                [8] = {
                    label = "Shoes (91-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_8"
                },
                [9] = {
                    label = "Shoes (91-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_9"
                },
                [10] = {
                    label = "Shoes (91-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_10"
                },
                [11] = {
                    label = "Shoes (91-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_11"
                },
                [12] = {
                    label = "Shoes (91-12)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_12"
                },
                [13] = {
                    label = "Shoes (91-13)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_13"
                },
                [14] = {
                    label = "Shoes (91-14)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_14"
                },
                [15] = {
                    label = "Shoes (91-15)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_15"
                },
                [16] = {
                    label = "Shoes (91-16)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_16"
                },
                [17] = {
                    label = "Shoes (91-17)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_91_17"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (92-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_0"
                },
                [1] = {
                    label = "Shoes (92-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_1"
                },
                [2] = {
                    label = "Shoes (92-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_2"
                },
                [3] = {
                    label = "Shoes (92-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_3"
                },
                [4] = {
                    label = "Shoes (92-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_4"
                },
                [5] = {
                    label = "Shoes (92-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_5"
                },
                [6] = {
                    label = "Shoes (92-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_6"
                },
                [7] = {
                    label = "Shoes (92-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_7"
                },
                [8] = {
                    label = "Shoes (92-8)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_8"
                },
                [9] = {
                    label = "Shoes (92-9)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_9"
                },
                [10] = {
                    label = "Shoes (92-10)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_10"
                },
                [11] = {
                    label = "Shoes (92-11)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_92_11"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (93-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_93_0"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (94-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_94_0"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (95-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_95_0"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_0"
                },
                [1] = {
                    label = "Brown Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_1"
                },
                [2] = {
                    label = "Green Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_2"
                },
                [3] = {
                    label = "Violet Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_3"
                },
                [4] = {
                    label = "Red Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_4"
                },
                [5] = {
                    label = "Two Tone Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_5"
                },
                [6] = {
                    label = "Mono Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_6"
                },
                [7] = {
                    label = "Blue Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_7"
                },
                [8] = {
                    label = "Mauve Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_8"
                },
                [9] = {
                    label = "Purple Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_9"
                },
                [10] = {
                    label = "Orange Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_10"
                },
                [11] = {
                    label = "Grayscale Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_11"
                },
                [12] = {
                    label = "Ash Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_12"
                },
                [13] = {
                    label = "Gray Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_13"
                },
                [14] = {
                    label = "White Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_96_14"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_0"
                },
                [1] = {
                    label = "Brown Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_1"
                },
                [2] = {
                    label = "Green Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_2"
                },
                [3] = {
                    label = "Violet Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_3"
                },
                [4] = {
                    label = "Red Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_4"
                },
                [5] = {
                    label = "Two Tone Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_5"
                },
                [6] = {
                    label = "Mono Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_6"
                },
                [7] = {
                    label = "Blue Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_7"
                },
                [8] = {
                    label = "Mauve Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_8"
                },
                [9] = {
                    label = "Purple Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_9"
                },
                [10] = {
                    label = "Orange Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_10"
                },
                [11] = {
                    label = "Grayscale Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_11"
                },
                [12] = {
                    label = "Ash Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_12"
                },
                [13] = {
                    label = "Gray Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_13"
                },
                [14] = {
                    label = "White Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_97_14"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_0"
                },
                [1] = {
                    label = "Blue FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_1"
                },
                [2] = {
                    label = "Green FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_2"
                },
                [3] = {
                    label = "Red FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_3"
                },
                [4] = {
                    label = "Yellow FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_4"
                },
                [5] = {
                    label = "Blue FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_5"
                },
                [6] = {
                    label = "Red FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_6"
                },
                [7] = {
                    label = "Yellow FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_98_7"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "female_shoes_99_0"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heavy Uniform Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_100_0"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heavy Uniform Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_101_0"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (102-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_102_0"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ice Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_0"
                },
                [1] = {
                    label = "White Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_1"
                },
                [2] = {
                    label = "Aqua Sole Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_2"
                },
                [3] = {
                    label = "Black Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_3"
                },
                [4] = {
                    label = "Cream Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_4"
                },
                [5] = {
                    label = "Smoky Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_5"
                },
                [6] = {
                    label = "Lime Highlight Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_6"
                },
                [7] = {
                    label = "Pink Vibrant Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_7"
                },
                [8] = {
                    label = "Lilac Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_8"
                },
                [9] = {
                    label = "Red Highlight Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_9"
                },
                [10] = {
                    label = "Cyan Fade Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_10"
                },
                [11] = {
                    label = "Purple Fade Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_11"
                },
                [12] = {
                    label = "Beige Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_12"
                },
                [13] = {
                    label = "Grayscale Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_13"
                },
                [14] = {
                    label = "Gray & Cyan Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_14"
                },
                [15] = {
                    label = "Gray & Aqua Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_15"
                },
                [16] = {
                    label = "Black & Lime Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_16"
                },
                [17] = {
                    label = "Teal Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_17"
                },
                [18] = {
                    label = "Gray & Purple Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_18"
                },
                [19] = {
                    label = "Gray & Magenta Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_19"
                },
                [20] = {
                    label = "Gray & Yellow Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_20"
                },
                [21] = {
                    label = "Orange Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_21"
                },
                [22] = {
                    label = "White & Gold Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_22"
                },
                [23] = {
                    label = "White & Pink Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_103_23"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (104-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_104_0"
                },
                [1] = {
                    label = "Shoes (104-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_104_1"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (105-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_0"
                },
                [1] = {
                    label = "Shoes (105-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_1"
                },
                [2] = {
                    label = "Shoes (105-2)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_2"
                },
                [3] = {
                    label = "Shoes (105-3)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_3"
                },
                [4] = {
                    label = "Shoes (105-4)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_4"
                },
                [5] = {
                    label = "Shoes (105-5)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_5"
                },
                [6] = {
                    label = "Shoes (105-6)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_6"
                },
                [7] = {
                    label = "Shoes (105-7)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_105_7"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_0"
                },
                [1] = {
                    label = "Ox Blood Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_1"
                },
                [2] = {
                    label = "Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_2"
                },
                [3] = {
                    label = "Chestnut Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_3"
                },
                [4] = {
                    label = "Ash Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_4"
                },
                [5] = {
                    label = "Dark Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_5"
                },
                [6] = {
                    label = "Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_6"
                },
                [7] = {
                    label = "Dark Green Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_7"
                },
                [8] = {
                    label = "Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_8"
                },
                [9] = {
                    label = "Dark Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_9"
                },
                [10] = {
                    label = "Orange Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_10"
                },
                [11] = {
                    label = "Dark Nut Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_11"
                },
                [12] = {
                    label = "Navy Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_12"
                },
                [13] = {
                    label = "Blue Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_106_13"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_0"
                },
                [1] = {
                    label = "Ox Blood Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_1"
                },
                [2] = {
                    label = "Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_2"
                },
                [3] = {
                    label = "Chestnut Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_3"
                },
                [4] = {
                    label = "Ash Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_4"
                },
                [5] = {
                    label = "Dark Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_5"
                },
                [6] = {
                    label = "Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_6"
                },
                [7] = {
                    label = "Dark Green Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_7"
                },
                [8] = {
                    label = "Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_8"
                },
                [9] = {
                    label = "Dark Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_9"
                },
                [10] = {
                    label = "Orange Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_10"
                },
                [11] = {
                    label = "Dark Nut Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_11"
                },
                [12] = {
                    label = "Navy Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_12"
                },
                [13] = {
                    label = "Blue Road Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_107_13"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Walnut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_0"
                },
                [1] = {
                    label = "Black Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_1"
                },
                [2] = {
                    label = "Gray Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_2"
                },
                [3] = {
                    label = "Ice Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_3"
                },
                [4] = {
                    label = "Dark Nut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_4"
                },
                [5] = {
                    label = "Chocolate Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_5"
                },
                [6] = {
                    label = "Chestnut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_6"
                },
                [7] = {
                    label = "Beige Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_7"
                },
                [8] = {
                    label = "Blue Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_8"
                },
                [9] = {
                    label = "Green Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_9"
                },
                [10] = {
                    label = "Pink Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_10"
                },
                [11] = {
                    label = "Crimson Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "female_shoes_108_11"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Clover Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_0"
                },
                [1] = {
                    label = "Green Clover Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_1"
                },
                [2] = {
                    label = "Green Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_2"
                },
                [3] = {
                    label = "Light Blue Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_3"
                },
                [4] = {
                    label = "Red Botanical Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_4"
                },
                [5] = {
                    label = "Navy Botanical Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_5"
                },
                [6] = {
                    label = "Pink Lemon Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_6"
                },
                [7] = {
                    label = "Blue Lemon Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_7"
                },
                [8] = {
                    label = "Blue Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_8"
                },
                [9] = {
                    label = "Red Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_9"
                },
                [10] = {
                    label = "Vivid Stripes Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_10"
                },
                [11] = {
                    label = "Vibrant Stripes Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_11"
                },
                [12] = {
                    label = "Blue Striped Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_12"
                },
                [13] = {
                    label = "Red Striped Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_13"
                },
                [14] = {
                    label = "White Borrachas Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_14"
                },
                [15] = {
                    label = "Black Borrachas Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_15"
                },
                [16] = {
                    label = "Green Rectangles Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_16"
                },
                [17] = {
                    label = "Yellow Rectangles Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_17"
                },
                [18] = {
                    label = "Lilac Squares Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_18"
                },
                [19] = {
                    label = "Yellow Squares Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_19"
                },
                [20] = {
                    label = "Black Text Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_20"
                },
                [21] = {
                    label = "White Text Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_21"
                },
                [22] = {
                    label = "Red Zig Zag Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_22"
                },
                [23] = {
                    label = "Blue Zig Zag Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_109_23"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_0"
                },
                [1] = {
                    label = "Gray Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_1"
                },
                [2] = {
                    label = "Lilac Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_2"
                },
                [3] = {
                    label = "Chocolate Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_3"
                },
                [4] = {
                    label = "Ox Blood Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_4"
                },
                [5] = {
                    label = "Dark Tan Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_5"
                },
                [6] = {
                    label = "Beige Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_6"
                },
                [7] = {
                    label = "Blue Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_7"
                },
                [8] = {
                    label = "Green Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_8"
                },
                [9] = {
                    label = "Pink Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_9"
                },
                [10] = {
                    label = "Red Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_110_10"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wild Striped Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_0"
                },
                [1] = {
                    label = "Neon Striped Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_1"
                },
                [2] = {
                    label = "Black SC Coin Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_2"
                },
                [3] = {
                    label = "White SC Coin Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_3"
                },
                [4] = {
                    label = "Black SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_4"
                },
                [5] = {
                    label = "Pink SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_5"
                },
                [6] = {
                    label = "Blue SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_6"
                },
                [7] = {
                    label = "Camo Yeti Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_7"
                },
                [8] = {
                    label = "Gray Camo Yeti Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_111_8"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_0"
                },
                [1] = {
                    label = "Purple Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_1"
                },
                [2] = {
                    label = "Camo Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_2"
                },
                [3] = {
                    label = "Black Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_3"
                },
                [4] = {
                    label = "White Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_4"
                },
                [5] = {
                    label = "Pink Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_5"
                },
                [6] = {
                    label = "Gray Cimicino Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_6"
                },
                [7] = {
                    label = "Rouge Cimicino Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_7"
                },
                [8] = {
                    label = "Navy DS Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_8"
                },
                [9] = {
                    label = "Red DS Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_9"
                },
                [10] = {
                    label = "Floral Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_10"
                },
                [11] = {
                    label = "Green Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_11"
                },
                [12] = {
                    label = "White Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_12"
                },
                [13] = {
                    label = "Blue Heat Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_13"
                },
                [14] = {
                    label = "Red ProLaps Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "female_shoes_112_14"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Walnut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_0"
                },
                [1] = {
                    label = "Black Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_1"
                },
                [2] = {
                    label = "Gray Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_2"
                },
                [3] = {
                    label = "Ice Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_3"
                },
                [4] = {
                    label = "Dark Nut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_4"
                },
                [5] = {
                    label = "Chocolate Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_5"
                },
                [6] = {
                    label = "Chestnut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_6"
                },
                [7] = {
                    label = "Beige Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_7"
                },
                [8] = {
                    label = "Blue Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_8"
                },
                [9] = {
                    label = "Green Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_9"
                },
                [10] = {
                    label = "Pink Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_10"
                },
                [11] = {
                    label = "Crimson Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "female_shoes_113_11"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_0"
                },
                [1] = {
                    label = "Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_1"
                },
                [2] = {
                    label = "Light Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_2"
                },
                [3] = {
                    label = "Ice Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_3"
                },
                [4] = {
                    label = "Chocolate Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_4"
                },
                [5] = {
                    label = "Russet Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_5"
                },
                [6] = {
                    label = "Green Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_6"
                },
                [7] = {
                    label = "Red Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_7"
                },
                [8] = {
                    label = "Orange Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_8"
                },
                [9] = {
                    label = "Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_9"
                },
                [10] = {
                    label = "Chestnut Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_10"
                },
                [11] = {
                    label = "Dark Nut Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_11"
                },
                [12] = {
                    label = "Navy Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_12"
                },
                [13] = {
                    label = "Blue Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_114_13"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_0"
                },
                [1] = {
                    label = "Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_1"
                },
                [2] = {
                    label = "Light Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_2"
                },
                [3] = {
                    label = "Ice Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_3"
                },
                [4] = {
                    label = "Chocolate Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_4"
                },
                [5] = {
                    label = "Russet Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_5"
                },
                [6] = {
                    label = "Green Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_6"
                },
                [7] = {
                    label = "Red Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_7"
                },
                [8] = {
                    label = "Orange Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_8"
                },
                [9] = {
                    label = "Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_9"
                },
                [10] = {
                    label = "Chestnut Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_10"
                },
                [11] = {
                    label = "Dark Nut Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_11"
                },
                [12] = {
                    label = "Navy Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_12"
                },
                [13] = {
                    label = "Blue Loggers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_115_13"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_0"
                },
                [1] = {
                    label = "Dark Gray Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_1"
                },
                [2] = {
                    label = "Gray Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_2"
                },
                [3] = {
                    label = "Ice Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_3"
                },
                [4] = {
                    label = "Beige Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_4"
                },
                [5] = {
                    label = "Chocolate Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_5"
                },
                [6] = {
                    label = "Burgundy Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_6"
                },
                [7] = {
                    label = "Hot Pink Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_7"
                },
                [8] = {
                    label = "Scarlet Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_8"
                },
                [9] = {
                    label = "Orange Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_9"
                },
                [10] = {
                    label = "Amber Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_10"
                },
                [11] = {
                    label = "Lemon Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_11"
                },
                [12] = {
                    label = "Royal Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_12"
                },
                [13] = {
                    label = "Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_13"
                },
                [14] = {
                    label = "Teal Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_14"
                },
                [15] = {
                    label = "Cyan Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_15"
                },
                [16] = {
                    label = "Light Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_16"
                },
                [17] = {
                    label = "Lilac Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_17"
                },
                [18] = {
                    label = "Dark Green Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_18"
                },
                [19] = {
                    label = "Emerald Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_19"
                },
                [20] = {
                    label = "Moss Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_20"
                },
                [21] = {
                    label = "Lime Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_21"
                },
                [22] = {
                    label = "Peach Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_22"
                },
                [23] = {
                    label = "Lavender Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_23"
                },
                [24] = {
                    label = "Purple Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_24"
                },
                [25] = {
                    label = "Magenta Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_116_25"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_0"
                },
                [1] = {
                    label = "Dark Gray Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_1"
                },
                [2] = {
                    label = "Gray Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_2"
                },
                [3] = {
                    label = "Ice Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_3"
                },
                [4] = {
                    label = "Beige Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_4"
                },
                [5] = {
                    label = "Chocolate Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_5"
                },
                [6] = {
                    label = "Burgundy Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_6"
                },
                [7] = {
                    label = "Hot Pink Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_7"
                },
                [8] = {
                    label = "Scarlet Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_8"
                },
                [9] = {
                    label = "Orange Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_9"
                },
                [10] = {
                    label = "Amber Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_10"
                },
                [11] = {
                    label = "Lemon Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_11"
                },
                [12] = {
                    label = "Royal Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_12"
                },
                [13] = {
                    label = "Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_13"
                },
                [14] = {
                    label = "Teal Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_14"
                },
                [15] = {
                    label = "Cyan Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_15"
                },
                [16] = {
                    label = "Light Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_16"
                },
                [17] = {
                    label = "Lilac Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_17"
                },
                [18] = {
                    label = "Dark Green Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_18"
                },
                [19] = {
                    label = "Emerald Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_19"
                },
                [20] = {
                    label = "Moss Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_20"
                },
                [21] = {
                    label = "Lime Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_21"
                },
                [22] = {
                    label = "Peach Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_22"
                },
                [23] = {
                    label = "Lavender Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_23"
                },
                [24] = {
                    label = "Purple Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_24"
                },
                [25] = {
                    label = "Magenta Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_117_25"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_0"
                },
                [1] = {
                    label = "Dark Gray Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_1"
                },
                [2] = {
                    label = "Gray Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_2"
                },
                [3] = {
                    label = "Ice Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_3"
                },
                [4] = {
                    label = "Beige Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_4"
                },
                [5] = {
                    label = "Chocolate Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_5"
                },
                [6] = {
                    label = "Burgundy Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_6"
                },
                [7] = {
                    label = "Hot Pink Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_7"
                },
                [8] = {
                    label = "Scarlet Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_8"
                },
                [9] = {
                    label = "Orange Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_9"
                },
                [10] = {
                    label = "Amber Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_10"
                },
                [11] = {
                    label = "Lemon Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_11"
                },
                [12] = {
                    label = "Royal Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_12"
                },
                [13] = {
                    label = "Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_13"
                },
                [14] = {
                    label = "Teal Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_14"
                },
                [15] = {
                    label = "Cyan Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_15"
                },
                [16] = {
                    label = "Light Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_16"
                },
                [17] = {
                    label = "Lilac Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_17"
                },
                [18] = {
                    label = "Dark Green Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_18"
                },
                [19] = {
                    label = "Emerald Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_19"
                },
                [20] = {
                    label = "Moss Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_20"
                },
                [21] = {
                    label = "Lime Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_21"
                },
                [22] = {
                    label = "Peach Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_22"
                },
                [23] = {
                    label = "Lavender Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_23"
                },
                [24] = {
                    label = "Purple Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_24"
                },
                [25] = {
                    label = "Magenta Low Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_118_25"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Zebra Bigness Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_4"
                },
                [5] = {
                    label = "Pink Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_5"
                },
                [6] = {
                    label = "Cyan Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_6"
                },
                [7] = {
                    label = "Brown Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_7"
                },
                [8] = {
                    label = "Neon Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_8"
                },
                [9] = {
                    label = "Camo Roses Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_10"
                },
                [11] = {
                    label = "White Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_13"
                },
                [14] = {
                    label = "Black S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_14"
                },
                [15] = {
                    label = "Blue S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_15"
                },
                [16] = {
                    label = "Green S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_16"
                },
                [17] = {
                    label = "Light Blue S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_17"
                },
                [18] = {
                    label = "Pink S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_18"
                },
                [19] = {
                    label = "Red S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_19"
                },
                [20] = {
                    label = "White S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_20"
                },
                [21] = {
                    label = "Black Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_21"
                },
                [22] = {
                    label = "Blue Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_22"
                },
                [23] = {
                    label = "Red Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_23"
                },
                [24] = {
                    label = "Taupe Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_24"
                },
                [25] = {
                    label = "White Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_119_25"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_120_0"
                },
                [1] = {
                    label = "Neon Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_120_1"
                },
                [2] = {
                    label = "Blue Signs Squash Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_120_2"
                },
                [3] = {
                    label = "White Signs Squash Canvas",
                    price = 500,
                    type = "money",
                    image = "female_shoes_120_3"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (121-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_121_0"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (122-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_122_0"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_0"
                },
                [1] = {
                    label = "Cyan Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_1"
                },
                [2] = {
                    label = "Magenta Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_2"
                },
                [3] = {
                    label = "Green Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_3"
                },
                [4] = {
                    label = "Orange Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_4"
                },
                [5] = {
                    label = "Pink Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_5"
                },
                [6] = {
                    label = "Purple Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_6"
                },
                [7] = {
                    label = "Red Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_7"
                },
                [8] = {
                    label = "Green Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_8"
                },
                [9] = {
                    label = "Orange Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_9"
                },
                [10] = {
                    label = "Purple Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_10"
                },
                [11] = {
                    label = "Red Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_11"
                },
                [12] = {
                    label = "Blue Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_12"
                },
                [13] = {
                    label = "Green Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_13"
                },
                [14] = {
                    label = "Orange Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_14"
                },
                [15] = {
                    label = "Purple Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_15"
                },
                [16] = {
                    label = "Pink Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_16"
                },
                [17] = {
                    label = "Blue Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_17"
                },
                [18] = {
                    label = "Green Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_18"
                },
                [19] = {
                    label = "Orange Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_19"
                },
                [20] = {
                    label = "Purple Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_20"
                },
                [21] = {
                    label = "Blue Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_21"
                },
                [22] = {
                    label = "White Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_22"
                },
                [23] = {
                    label = "Gray Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_23"
                },
                [24] = {
                    label = "Chocolate Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_24"
                },
                [25] = {
                    label = "Black SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_123_25"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_124_0"
                },
                [1] = {
                    label = "Pink SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_124_1"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_0"
                },
                [1] = {
                    label = "Cyan Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_1"
                },
                [2] = {
                    label = "Magenta Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_2"
                },
                [3] = {
                    label = "Green Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_3"
                },
                [4] = {
                    label = "Orange Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_4"
                },
                [5] = {
                    label = "Pink Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_5"
                },
                [6] = {
                    label = "Purple Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_6"
                },
                [7] = {
                    label = "Red Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_7"
                },
                [8] = {
                    label = "Green Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_8"
                },
                [9] = {
                    label = "Orange Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_9"
                },
                [10] = {
                    label = "Purple Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_10"
                },
                [11] = {
                    label = "Red Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_11"
                },
                [12] = {
                    label = "Blue Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_12"
                },
                [13] = {
                    label = "Green Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_13"
                },
                [14] = {
                    label = "Orange Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_14"
                },
                [15] = {
                    label = "Purple Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_15"
                },
                [16] = {
                    label = "Pink Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_16"
                },
                [17] = {
                    label = "Blue Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_17"
                },
                [18] = {
                    label = "Green Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_18"
                },
                [19] = {
                    label = "Orange Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_19"
                },
                [20] = {
                    label = "Purple Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_20"
                },
                [21] = {
                    label = "Blue Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_21"
                },
                [22] = {
                    label = "White Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_22"
                },
                [23] = {
                    label = "Gray Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_23"
                },
                [24] = {
                    label = "Chocolate Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_24"
                },
                [25] = {
                    label = "Black SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_125_25"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_126_0"
                },
                [1] = {
                    label = "Pink SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_126_1"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_0"
                },
                [1] = {
                    label = "Blue Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_1"
                },
                [2] = {
                    label = "Red Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_2"
                },
                [3] = {
                    label = "White Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_3"
                },
                [4] = {
                    label = "Blue DS Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_4"
                },
                [5] = {
                    label = "Blue DS Tiger Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_5"
                },
                [6] = {
                    label = "White Signs Squash Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_6"
                },
                [7] = {
                    label = "Cluckin' Bell Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "female_shoes_127_7"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_0"
                },
                [1] = {
                    label = "Blue Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_1"
                },
                [2] = {
                    label = "Red Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_2"
                },
                [3] = {
                    label = "White Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_3"
                },
                [4] = {
                    label = "Blue DS Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_4"
                },
                [5] = {
                    label = "Blue DS Tiger Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_5"
                },
                [6] = {
                    label = "White Signs Squash Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_6"
                },
                [7] = {
                    label = "Cluckin' Bell Ugglies",
                    price = 500,
                    type = "money",
                    image = "female_shoes_128_7"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (129-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_129_0"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_0"
                },
                [1] = {
                    label = "Dark Gray Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_1"
                },
                [2] = {
                    label = "Gray Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_2"
                },
                [3] = {
                    label = "Ice Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_3"
                },
                [4] = {
                    label = "Beige Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_4"
                },
                [5] = {
                    label = "Chocolate Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_5"
                },
                [6] = {
                    label = "Burgundy Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_6"
                },
                [7] = {
                    label = "Hot Pink Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_7"
                },
                [8] = {
                    label = "Scarlet Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_8"
                },
                [9] = {
                    label = "Orange Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_9"
                },
                [10] = {
                    label = "Amber Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_10"
                },
                [11] = {
                    label = "Lemon Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_11"
                },
                [12] = {
                    label = "Royal Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_12"
                },
                [13] = {
                    label = "Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_13"
                },
                [14] = {
                    label = "Teal Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_14"
                },
                [15] = {
                    label = "Cyan Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_15"
                },
                [16] = {
                    label = "Light Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_16"
                },
                [17] = {
                    label = "Lilac Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_17"
                },
                [18] = {
                    label = "Dark Green Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_18"
                },
                [19] = {
                    label = "Emerald Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_19"
                },
                [20] = {
                    label = "Moss Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_20"
                },
                [21] = {
                    label = "Lime Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_21"
                },
                [22] = {
                    label = "Peach Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_22"
                },
                [23] = {
                    label = "Lavender Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_23"
                },
                [24] = {
                    label = "Purple Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_24"
                },
                [25] = {
                    label = "Magenta Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "female_shoes_130_25"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (131-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_131_0"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (132-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_132_0"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (133-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_133_0"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (134-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_134_0"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (135-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_135_0"
                },
                [1] = {
                    label = "Shoes (135-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_135_1"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (136-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_136_0"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (137-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_137_0"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (138-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_138_0"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (139-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_139_0"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (140-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_140_0"
                },
                [1] = {
                    label = "Shoes (140-1)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_140_1"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (141-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_141_0"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (142-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_142_0"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (143-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_143_0"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_0"
                },
                [1] = {
                    label = "Dark Gray Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_1"
                },
                [2] = {
                    label = "Gray Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_2"
                },
                [3] = {
                    label = "Ice Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_3"
                },
                [4] = {
                    label = "Beige Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_4"
                },
                [5] = {
                    label = "Chocolate Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_5"
                },
                [6] = {
                    label = "Burgundy Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_6"
                },
                [7] = {
                    label = "Hot Pink Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_7"
                },
                [8] = {
                    label = "Scarlet Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_8"
                },
                [9] = {
                    label = "Orange Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_9"
                },
                [10] = {
                    label = "Amber Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_10"
                },
                [11] = {
                    label = "Lemon Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_11"
                },
                [12] = {
                    label = "Royal Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_12"
                },
                [13] = {
                    label = "Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_13"
                },
                [14] = {
                    label = "Teal Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_14"
                },
                [15] = {
                    label = "Cyan Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_15"
                },
                [16] = {
                    label = "Light Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_16"
                },
                [17] = {
                    label = "Lilac Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_17"
                },
                [18] = {
                    label = "Dark Green Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_18"
                },
                [19] = {
                    label = "Emerald Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_19"
                },
                [20] = {
                    label = "Moss Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_20"
                },
                [21] = {
                    label = "Lime Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_21"
                },
                [22] = {
                    label = "Peach Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_22"
                },
                [23] = {
                    label = "Lavender Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_23"
                },
                [24] = {
                    label = "Purple Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_24"
                },
                [25] = {
                    label = "Magenta Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "female_shoes_144_25"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_0"
                },
                [1] = {
                    label = "Dark Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_1"
                },
                [2] = {
                    label = "Light Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_2"
                },
                [3] = {
                    label = "Ice Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_3"
                },
                [4] = {
                    label = "Beige Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_4"
                },
                [5] = {
                    label = "Chocolate Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_5"
                },
                [6] = {
                    label = "Fuchsia Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_6"
                },
                [7] = {
                    label = "Neon Pink Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_7"
                },
                [8] = {
                    label = "Scarlet Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_8"
                },
                [9] = {
                    label = "Orange Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_9"
                },
                [10] = {
                    label = "Amber Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_10"
                },
                [11] = {
                    label = "Lemon Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_11"
                },
                [12] = {
                    label = "Royal Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_12"
                },
                [13] = {
                    label = "Cobalt Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_13"
                },
                [14] = {
                    label = "Teal Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_14"
                },
                [15] = {
                    label = "Cyan Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_15"
                },
                [16] = {
                    label = "Light Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_16"
                },
                [17] = {
                    label = "Lilac Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_17"
                },
                [18] = {
                    label = "Dark Green Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_18"
                },
                [19] = {
                    label = "Emerald Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_19"
                },
                [20] = {
                    label = "Moss Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_20"
                },
                [21] = {
                    label = "Lime Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_21"
                },
                [22] = {
                    label = "Peach Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_22"
                },
                [23] = {
                    label = "Lavender Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_23"
                },
                [24] = {
                    label = "Purple Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_24"
                },
                [25] = {
                    label = "Magenta Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_145_25"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_0"
                },
                [1] = {
                    label = "Dark Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_1"
                },
                [2] = {
                    label = "Light Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_2"
                },
                [3] = {
                    label = "Ice Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_3"
                },
                [4] = {
                    label = "Beige Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_4"
                },
                [5] = {
                    label = "Chocolate Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_5"
                },
                [6] = {
                    label = "Fuchsia Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_6"
                },
                [7] = {
                    label = "Neon Pink Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_7"
                },
                [8] = {
                    label = "Scarlet Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_8"
                },
                [9] = {
                    label = "Orange Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_9"
                },
                [10] = {
                    label = "Amber Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_10"
                },
                [11] = {
                    label = "Lemon Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_11"
                },
                [12] = {
                    label = "Royal Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_12"
                },
                [13] = {
                    label = "Cobalt Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_13"
                },
                [14] = {
                    label = "Teal Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_14"
                },
                [15] = {
                    label = "Cyan Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_15"
                },
                [16] = {
                    label = "Light Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_16"
                },
                [17] = {
                    label = "Lilac Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_17"
                },
                [18] = {
                    label = "Dark Green Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_18"
                },
                [19] = {
                    label = "Emerald Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_19"
                },
                [20] = {
                    label = "Moss Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_20"
                },
                [21] = {
                    label = "Lime Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_21"
                },
                [22] = {
                    label = "Peach Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_22"
                },
                [23] = {
                    label = "Lavender Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_23"
                },
                [24] = {
                    label = "Purple Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_24"
                },
                [25] = {
                    label = "Magenta Winter Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_146_25"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Vespucci Beach Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "female_shoes_147_0"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_0"
                },
                [1] = {
                    label = "Gray Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_1"
                },
                [2] = {
                    label = "Ash Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_2"
                },
                [3] = {
                    label = "Ice Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_3"
                },
                [4] = {
                    label = "Ox Blood Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_4"
                },
                [5] = {
                    label = "Scarlet Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_5"
                },
                [6] = {
                    label = "Dark Green Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_6"
                },
                [7] = {
                    label = "Red Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_7"
                },
                [8] = {
                    label = "Orange Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_8"
                },
                [9] = {
                    label = "Mustard Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_9"
                },
                [10] = {
                    label = "Chestnut Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_10"
                },
                [11] = {
                    label = "Dark Nut Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_11"
                },
                [12] = {
                    label = "Dark Blue Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_12"
                },
                [13] = {
                    label = "Light Blue Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_148_13"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_0"
                },
                [1] = {
                    label = "Gray Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_1"
                },
                [2] = {
                    label = "Ash Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_2"
                },
                [3] = {
                    label = "Ice Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_3"
                },
                [4] = {
                    label = "Ox Blood Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_4"
                },
                [5] = {
                    label = "Scarlet Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_5"
                },
                [6] = {
                    label = "Dark Green Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_6"
                },
                [7] = {
                    label = "Red Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_7"
                },
                [8] = {
                    label = "Orange Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_8"
                },
                [9] = {
                    label = "Mustard Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_9"
                },
                [10] = {
                    label = "Chestnut Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_10"
                },
                [11] = {
                    label = "Dark Nut Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_11"
                },
                [12] = {
                    label = "Dark Blue Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_12"
                },
                [13] = {
                    label = "Light Blue Riding Boots",
                    price = 500,
                    type = "money",
                    image = "female_shoes_149_13"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (150-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_150_0"
                },
            },
        },
        [151] = {
            drawable = 151,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (151-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_151_0"
                },
            },
        },
        [152] = {
            drawable = 152,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (152-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_152_0"
                },
            },
        },
        [153] = {
            drawable = 153,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (153-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_153_0"
                },
            },
        },
        [154] = {
            drawable = 154,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue & Green Zebra Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_0"
                },
                [1] = {
                    label = "Black & White Zebra Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_1"
                },
                [2] = {
                    label = "Aqua Geo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_2"
                },
                [3] = {
                    label = "Gray Geo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_3"
                },
                [4] = {
                    label = "Contrast Camo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_4"
                },
                [5] = {
                    label = "Gray Camo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_5"
                },
                [6] = {
                    label = "Bronze Honeycomb Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_6"
                },
                [7] = {
                    label = "Blue Honeycomb Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_7"
                },
                [8] = {
                    label = "Aqua Wave Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_8"
                },
                [9] = {
                    label = "Black Wave Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_9"
                },
                [10] = {
                    label = "Blue Check Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_10"
                },
                [11] = {
                    label = "Black Check Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_11"
                },
                [12] = {
                    label = "Aqua Pixel Camo Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_12"
                },
                [13] = {
                    label = "Black Pixel Camo Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_154_13"
                },
            },
        },
        [155] = {
            drawable = 155,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (155-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_155_0"
                },
            },
        },
        [156] = {
            drawable = 156,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (156-0)",
                    price = 500,
                    type = "money",
                    image = "female_shoes_156_0"
                },
            },
        },
        [157] = {
            drawable = 157,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_0"
                },
                [1] = {
                    label = "White Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_1"
                },
                [2] = {
                    label = "Red Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_2"
                },
                [3] = {
                    label = "Light Blue Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_3"
                },
                [4] = {
                    label = "Yellow Hi Top Panic Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_4"
                },
                [5] = {
                    label = "Purple Hi Top Panic Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_5"
                },
                [6] = {
                    label = "Pink Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_6"
                },
                [7] = {
                    label = "Green Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_7"
                },
                [8] = {
                    label = "B&W Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_8"
                },
                [9] = {
                    label = "White Flame Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_9"
                },
                [10] = {
                    label = "O&G Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_10"
                },
                [11] = {
                    label = "P&W Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_11"
                },
                [12] = {
                    label = "Blue Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_157_12"
                },
            },
        },
        [158] = {
            drawable = 158,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cyan Güffy Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_0"
                },
                [1] = {
                    label = "Magenta Güffy Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_1"
                },
                [2] = {
                    label = "B&Y Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_2"
                },
                [3] = {
                    label = "Pastel Retro Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_3"
                },
                [4] = {
                    label = "Abstract Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_4"
                },
                [5] = {
                    label = "Military Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "female_shoes_158_5"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_0"
                },
                [1] = {
                    label = "Shoes (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_1"
                },
                [2] = {
                    label = "Shoes (0-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_2"
                },
                [3] = {
                    label = "Shoes (0-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_3"
                },
                [4] = {
                    label = "Shoes (0-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_4"
                },
                [5] = {
                    label = "Shoes (0-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_5"
                },
                [6] = {
                    label = "Shoes (0-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_6"
                },
                [7] = {
                    label = "Shoes (0-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_7"
                },
                [8] = {
                    label = "Shoes (0-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_8"
                },
                [9] = {
                    label = "Shoes (0-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_9"
                },
                [10] = {
                    label = "Shoes (0-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_10"
                },
                [11] = {
                    label = "Shoes (0-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_11"
                },
                [12] = {
                    label = "Shoes (0-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_12"
                },
                [13] = {
                    label = "Shoes (0-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_13"
                },
                [14] = {
                    label = "Shoes (0-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_14"
                },
                [15] = {
                    label = "Shoes (0-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_0_15"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_0"
                },
                [1] = {
                    label = "Shoes (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_1"
                },
                [2] = {
                    label = "Shoes (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_2"
                },
                [3] = {
                    label = "Shoes (1-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_3"
                },
                [4] = {
                    label = "Shoes (1-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_4"
                },
                [5] = {
                    label = "Shoes (1-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_5"
                },
                [6] = {
                    label = "Shoes (1-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_6"
                },
                [7] = {
                    label = "Shoes (1-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_7"
                },
                [8] = {
                    label = "Shoes (1-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_8"
                },
                [9] = {
                    label = "Shoes (1-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_9"
                },
                [10] = {
                    label = "Shoes (1-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_10"
                },
                [11] = {
                    label = "Shoes (1-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_11"
                },
                [12] = {
                    label = "Shoes (1-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_12"
                },
                [13] = {
                    label = "Shoes (1-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_13"
                },
                [14] = {
                    label = "Shoes (1-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_14"
                },
                [15] = {
                    label = "Shoes (1-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_1_15"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_0"
                },
                [1] = {
                    label = "Shoes (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_1"
                },
                [2] = {
                    label = "Shoes (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_2"
                },
                [3] = {
                    label = "Shoes (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_3"
                },
                [4] = {
                    label = "Shoes (2-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_4"
                },
                [5] = {
                    label = "Shoes (2-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_5"
                },
                [6] = {
                    label = "Shoes (2-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_6"
                },
                [7] = {
                    label = "Shoes (2-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_7"
                },
                [8] = {
                    label = "Shoes (2-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_8"
                },
                [9] = {
                    label = "Shoes (2-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_9"
                },
                [10] = {
                    label = "Shoes (2-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_10"
                },
                [11] = {
                    label = "Shoes (2-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_11"
                },
                [12] = {
                    label = "Shoes (2-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_12"
                },
                [13] = {
                    label = "Shoes (2-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_13"
                },
                [14] = {
                    label = "Shoes (2-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_14"
                },
                [15] = {
                    label = "Shoes (2-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_2_15"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (3-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_0"
                },
                [1] = {
                    label = "Shoes (3-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_1"
                },
                [2] = {
                    label = "Shoes (3-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_2"
                },
                [3] = {
                    label = "Shoes (3-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_3"
                },
                [4] = {
                    label = "Shoes (3-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_4"
                },
                [5] = {
                    label = "Shoes (3-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_5"
                },
                [6] = {
                    label = "Shoes (3-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_6"
                },
                [7] = {
                    label = "Shoes (3-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_7"
                },
                [8] = {
                    label = "Shoes (3-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_8"
                },
                [9] = {
                    label = "Shoes (3-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_9"
                },
                [10] = {
                    label = "Shoes (3-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_10"
                },
                [11] = {
                    label = "Shoes (3-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_11"
                },
                [12] = {
                    label = "Shoes (3-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_12"
                },
                [13] = {
                    label = "Shoes (3-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_13"
                },
                [14] = {
                    label = "Shoes (3-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_14"
                },
                [15] = {
                    label = "Shoes (3-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_3_15"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (4-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_0"
                },
                [1] = {
                    label = "Shoes (4-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_1"
                },
                [2] = {
                    label = "Shoes (4-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_2"
                },
                [3] = {
                    label = "Shoes (4-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_3"
                },
                [4] = {
                    label = "Shoes (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_4"
                },
                [5] = {
                    label = "Shoes (4-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_5"
                },
                [6] = {
                    label = "Shoes (4-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_6"
                },
                [7] = {
                    label = "Shoes (4-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_7"
                },
                [8] = {
                    label = "Shoes (4-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_8"
                },
                [9] = {
                    label = "Shoes (4-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_9"
                },
                [10] = {
                    label = "Shoes (4-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_10"
                },
                [11] = {
                    label = "Shoes (4-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_11"
                },
                [12] = {
                    label = "Shoes (4-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_12"
                },
                [13] = {
                    label = "Shoes (4-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_13"
                },
                [14] = {
                    label = "Shoes (4-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_14"
                },
                [15] = {
                    label = "Shoes (4-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_4_15"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (5-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_0"
                },
                [1] = {
                    label = "Shoes (5-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_1"
                },
                [2] = {
                    label = "Shoes (5-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_2"
                },
                [3] = {
                    label = "Shoes (5-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_3"
                },
                [4] = {
                    label = "Shoes (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_4"
                },
                [5] = {
                    label = "Shoes (5-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_5"
                },
                [6] = {
                    label = "Shoes (5-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_6"
                },
                [7] = {
                    label = "Shoes (5-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_7"
                },
                [8] = {
                    label = "Shoes (5-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_8"
                },
                [9] = {
                    label = "Shoes (5-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_9"
                },
                [10] = {
                    label = "Shoes (5-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_10"
                },
                [11] = {
                    label = "Shoes (5-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_11"
                },
                [12] = {
                    label = "Shoes (5-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_12"
                },
                [13] = {
                    label = "Shoes (5-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_13"
                },
                [14] = {
                    label = "Shoes (5-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_14"
                },
                [15] = {
                    label = "Shoes (5-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_5_15"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (6-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_0"
                },
                [1] = {
                    label = "Shoes (6-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_1"
                },
                [2] = {
                    label = "Shoes (6-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_2"
                },
                [3] = {
                    label = "Shoes (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_3"
                },
                [4] = {
                    label = "Shoes (6-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_4"
                },
                [5] = {
                    label = "Shoes (6-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_5"
                },
                [6] = {
                    label = "Shoes (6-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_6"
                },
                [7] = {
                    label = "Shoes (6-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_7"
                },
                [8] = {
                    label = "Shoes (6-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_8"
                },
                [9] = {
                    label = "Shoes (6-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_9"
                },
                [10] = {
                    label = "Shoes (6-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_10"
                },
                [11] = {
                    label = "Shoes (6-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_11"
                },
                [12] = {
                    label = "Shoes (6-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_12"
                },
                [13] = {
                    label = "Shoes (6-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_13"
                },
                [14] = {
                    label = "Shoes (6-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_14"
                },
                [15] = {
                    label = "Shoes (6-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_6_15"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (7-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_0"
                },
                [1] = {
                    label = "Shoes (7-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_1"
                },
                [2] = {
                    label = "Shoes (7-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_2"
                },
                [3] = {
                    label = "Shoes (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_3"
                },
                [4] = {
                    label = "Shoes (7-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_4"
                },
                [5] = {
                    label = "Shoes (7-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_5"
                },
                [6] = {
                    label = "Shoes (7-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_6"
                },
                [7] = {
                    label = "Shoes (7-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_7"
                },
                [8] = {
                    label = "Shoes (7-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_8"
                },
                [9] = {
                    label = "Shoes (7-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_9"
                },
                [10] = {
                    label = "Shoes (7-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_10"
                },
                [11] = {
                    label = "Shoes (7-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_11"
                },
                [12] = {
                    label = "Shoes (7-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_12"
                },
                [13] = {
                    label = "Shoes (7-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_13"
                },
                [14] = {
                    label = "Shoes (7-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_14"
                },
                [15] = {
                    label = "Shoes (7-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_7_15"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (8-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_0"
                },
                [1] = {
                    label = "Shoes (8-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_1"
                },
                [2] = {
                    label = "Shoes (8-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_2"
                },
                [3] = {
                    label = "Shoes (8-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_3"
                },
                [4] = {
                    label = "Shoes (8-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_4"
                },
                [5] = {
                    label = "Shoes (8-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_5"
                },
                [6] = {
                    label = "Shoes (8-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_6"
                },
                [7] = {
                    label = "Shoes (8-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_7"
                },
                [8] = {
                    label = "Shoes (8-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_8"
                },
                [9] = {
                    label = "Shoes (8-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_9"
                },
                [10] = {
                    label = "Shoes (8-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_10"
                },
                [11] = {
                    label = "Shoes (8-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_11"
                },
                [12] = {
                    label = "Shoes (8-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_12"
                },
                [13] = {
                    label = "Shoes (8-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_13"
                },
                [14] = {
                    label = "Shoes (8-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_14"
                },
                [15] = {
                    label = "Shoes (8-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_8_15"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (9-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_0"
                },
                [1] = {
                    label = "Shoes (9-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_1"
                },
                [2] = {
                    label = "Shoes (9-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_2"
                },
                [3] = {
                    label = "Shoes (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_3"
                },
                [4] = {
                    label = "Shoes (9-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_4"
                },
                [5] = {
                    label = "Shoes (9-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_5"
                },
                [6] = {
                    label = "Shoes (9-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_6"
                },
                [7] = {
                    label = "Shoes (9-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_7"
                },
                [8] = {
                    label = "Shoes (9-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_8"
                },
                [9] = {
                    label = "Shoes (9-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_9"
                },
                [10] = {
                    label = "Shoes (9-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_10"
                },
                [11] = {
                    label = "Shoes (9-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_11"
                },
                [12] = {
                    label = "Shoes (9-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_12"
                },
                [13] = {
                    label = "Shoes (9-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_13"
                },
                [14] = {
                    label = "Shoes (9-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_14"
                },
                [15] = {
                    label = "Shoes (9-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_9_15"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (10-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_0"
                },
                [1] = {
                    label = "Shoes (10-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_1"
                },
                [2] = {
                    label = "Shoes (10-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_2"
                },
                [3] = {
                    label = "Shoes (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_3"
                },
                [4] = {
                    label = "Shoes (10-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_4"
                },
                [5] = {
                    label = "Shoes (10-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_5"
                },
                [6] = {
                    label = "Shoes (10-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_6"
                },
                [7] = {
                    label = "Shoes (10-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_7"
                },
                [8] = {
                    label = "Shoes (10-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_8"
                },
                [9] = {
                    label = "Shoes (10-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_9"
                },
                [10] = {
                    label = "Shoes (10-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_10"
                },
                [11] = {
                    label = "Shoes (10-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_11"
                },
                [12] = {
                    label = "Shoes (10-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_12"
                },
                [13] = {
                    label = "Shoes (10-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_13"
                },
                [14] = {
                    label = "Shoes (10-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_14"
                },
                [15] = {
                    label = "Shoes (10-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_10_15"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (11-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_0"
                },
                [1] = {
                    label = "Shoes (11-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_1"
                },
                [2] = {
                    label = "Shoes (11-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_2"
                },
                [3] = {
                    label = "Shoes (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_3"
                },
                [4] = {
                    label = "Shoes (11-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_4"
                },
                [5] = {
                    label = "Shoes (11-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_5"
                },
                [6] = {
                    label = "Shoes (11-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_6"
                },
                [7] = {
                    label = "Shoes (11-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_7"
                },
                [8] = {
                    label = "Shoes (11-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_8"
                },
                [9] = {
                    label = "Shoes (11-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_9"
                },
                [10] = {
                    label = "Shoes (11-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_10"
                },
                [11] = {
                    label = "Shoes (11-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_11"
                },
                [12] = {
                    label = "Shoes (11-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_12"
                },
                [13] = {
                    label = "Shoes (11-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_13"
                },
                [14] = {
                    label = "Shoes (11-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_14"
                },
                [15] = {
                    label = "Shoes (11-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_11_15"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (12-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_0"
                },
                [1] = {
                    label = "Shoes (12-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_1"
                },
                [2] = {
                    label = "Shoes (12-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_2"
                },
                [3] = {
                    label = "Shoes (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_3"
                },
                [4] = {
                    label = "Shoes (12-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_4"
                },
                [5] = {
                    label = "Shoes (12-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_5"
                },
                [6] = {
                    label = "Shoes (12-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_6"
                },
                [7] = {
                    label = "Shoes (12-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_7"
                },
                [8] = {
                    label = "Shoes (12-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_8"
                },
                [9] = {
                    label = "Shoes (12-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_9"
                },
                [10] = {
                    label = "Shoes (12-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_10"
                },
                [11] = {
                    label = "Shoes (12-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_11"
                },
                [12] = {
                    label = "Shoes (12-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_12"
                },
                [13] = {
                    label = "Shoes (12-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_13"
                },
                [14] = {
                    label = "Shoes (12-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_14"
                },
                [15] = {
                    label = "Shoes (12-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_12_15"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (13-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_0"
                },
                [1] = {
                    label = "Shoes (13-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_1"
                },
                [2] = {
                    label = "Shoes (13-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_2"
                },
                [3] = {
                    label = "Shoes (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_3"
                },
                [4] = {
                    label = "Shoes (13-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_4"
                },
                [5] = {
                    label = "Shoes (13-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_5"
                },
                [6] = {
                    label = "Shoes (13-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_6"
                },
                [7] = {
                    label = "Shoes (13-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_7"
                },
                [8] = {
                    label = "Shoes (13-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_8"
                },
                [9] = {
                    label = "Shoes (13-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_9"
                },
                [10] = {
                    label = "Shoes (13-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_10"
                },
                [11] = {
                    label = "Shoes (13-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_11"
                },
                [12] = {
                    label = "Shoes (13-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_12"
                },
                [13] = {
                    label = "Shoes (13-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_13"
                },
                [14] = {
                    label = "Shoes (13-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_14"
                },
                [15] = {
                    label = "Shoes (13-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_13_15"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (14-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_0"
                },
                [1] = {
                    label = "Shoes (14-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_1"
                },
                [2] = {
                    label = "Shoes (14-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_2"
                },
                [3] = {
                    label = "Shoes (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_3"
                },
                [4] = {
                    label = "Shoes (14-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_4"
                },
                [5] = {
                    label = "Shoes (14-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_5"
                },
                [6] = {
                    label = "Shoes (14-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_6"
                },
                [7] = {
                    label = "Shoes (14-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_7"
                },
                [8] = {
                    label = "Shoes (14-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_8"
                },
                [9] = {
                    label = "Shoes (14-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_9"
                },
                [10] = {
                    label = "Shoes (14-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_10"
                },
                [11] = {
                    label = "Shoes (14-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_11"
                },
                [12] = {
                    label = "Shoes (14-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_12"
                },
                [13] = {
                    label = "Shoes (14-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_13"
                },
                [14] = {
                    label = "Shoes (14-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_14"
                },
                [15] = {
                    label = "Shoes (14-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_14_15"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (15-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_0"
                },
                [1] = {
                    label = "Shoes (15-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_1"
                },
                [2] = {
                    label = "Shoes (15-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_2"
                },
                [3] = {
                    label = "Shoes (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_3"
                },
                [4] = {
                    label = "Shoes (15-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_4"
                },
                [5] = {
                    label = "Shoes (15-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_5"
                },
                [6] = {
                    label = "Shoes (15-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_6"
                },
                [7] = {
                    label = "Shoes (15-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_7"
                },
                [8] = {
                    label = "Shoes (15-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_8"
                },
                [9] = {
                    label = "Shoes (15-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_9"
                },
                [10] = {
                    label = "Shoes (15-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_10"
                },
                [11] = {
                    label = "Shoes (15-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_11"
                },
                [12] = {
                    label = "Shoes (15-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_12"
                },
                [13] = {
                    label = "Shoes (15-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_13"
                },
                [14] = {
                    label = "Shoes (15-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_14"
                },
                [15] = {
                    label = "Shoes (15-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_15_15"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'component',
            textures = {
                [0] = {
                    label = "Anna Rex Gray Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_0"
                },
                [1] = {
                    label = "Perseus Green Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_1"
                },
                [2] = {
                    label = "Lezard Purple Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_2"
                },
                [3] = {
                    label = "Lilac Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_3"
                },
                [4] = {
                    label = "Blue Two-Tone Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_4"
                },
                [5] = {
                    label = "Double P Red Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_5"
                },
                [6] = {
                    label = "Lemon Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_6"
                },
                [7] = {
                    label = "Heat Striped Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_7"
                },
                [8] = {
                    label = "Prolaps Yellow Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_8"
                },
                [9] = {
                    label = "Gray Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_9"
                },
                [10] = {
                    label = "Suburban White Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_10"
                },
                [11] = {
                    label = "Stank Blue Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_16_11"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'component',
            textures = {
                [0] = {
                    label = "Elf Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_17_0"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Toe Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_18_0"
                },
                [1] = {
                    label = "White Toe Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_18_1"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'component',
            textures = {
                [0] = {
                    label = "Spats",
                    price = 500,
                    type = "money",
                    image = "male_shoes_19_0"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'component',
            textures = {
                [0] = {
                    label = "Chocolate Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_0"
                },
                [1] = {
                    label = "Chestnut Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_1"
                },
                [2] = {
                    label = "Tan Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_2"
                },
                [3] = {
                    label = "White Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_3"
                },
                [4] = {
                    label = "Ash Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_4"
                },
                [5] = {
                    label = "Gray Two-Tone Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_5"
                },
                [6] = {
                    label = "Topaz Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_6"
                },
                [7] = {
                    label = "Black Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_7"
                },
                [8] = {
                    label = "Lime Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_8"
                },
                [9] = {
                    label = "Yellow Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_9"
                },
                [10] = {
                    label = "Gray Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_10"
                },
                [11] = {
                    label = "Navy Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_20_11"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_0"
                },
                [1] = {
                    label = "Red Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_1"
                },
                [2] = {
                    label = "Brown Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_2"
                },
                [3] = {
                    label = "Cobra Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_3"
                },
                [4] = {
                    label = "Green Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_4"
                },
                [5] = {
                    label = "Copper Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_5"
                },
                [6] = {
                    label = "Panel Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_6"
                },
                [7] = {
                    label = "Navy Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_7"
                },
                [8] = {
                    label = "Blue Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_8"
                },
                [9] = {
                    label = "White Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_9"
                },
                [10] = {
                    label = "Tan Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_10"
                },
                [11] = {
                    label = "Black & White Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_21_11"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'component',
            textures = {
                [0] = {
                    label = "Sky Blue Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_0"
                },
                [1] = {
                    label = "Green Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_1"
                },
                [2] = {
                    label = "Orange Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_2"
                },
                [3] = {
                    label = "Yellow Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_3"
                },
                [4] = {
                    label = "Purple Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_4"
                },
                [5] = {
                    label = "Gray Two-Tone Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_5"
                },
                [6] = {
                    label = "Checked Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_6"
                },
                [7] = {
                    label = "Camo Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_7"
                },
                [8] = {
                    label = "Coffee Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_8"
                },
                [9] = {
                    label = "Plaid Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_9"
                },
                [10] = {
                    label = "Green Checked Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_10"
                },
                [11] = {
                    label = "Tan Canvas Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_22_11"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Soled Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_0"
                },
                [1] = {
                    label = "Navy Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_1"
                },
                [2] = {
                    label = "Orange Soled Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_2"
                },
                [3] = {
                    label = "Burgundy Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_3"
                },
                [4] = {
                    label = "Blue Soled Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_4"
                },
                [5] = {
                    label = "Woodland Camo Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_5"
                },
                [6] = {
                    label = "Black Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_6"
                },
                [7] = {
                    label = "Gentleman Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_7"
                },
                [8] = {
                    label = "Pink Soled Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_8"
                },
                [9] = {
                    label = "Brown Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_9"
                },
                [10] = {
                    label = "Chocolate Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_10"
                },
                [11] = {
                    label = "Green Soled Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_11"
                },
                [12] = {
                    label = "Ash Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_12"
                },
                [13] = {
                    label = "Olive Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_13"
                },
                [14] = {
                    label = "Gray Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_14"
                },
                [15] = {
                    label = "Yellow Wingtips",
                    price = 500,
                    type = "money",
                    image = "male_shoes_23_15"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Flight Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_24_0"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_25_0"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (26-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_0"
                },
                [1] = {
                    label = "Shoes (26-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_1"
                },
                [2] = {
                    label = "Shoes (26-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_2"
                },
                [3] = {
                    label = "Shoes (26-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_3"
                },
                [4] = {
                    label = "Shoes (26-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_4"
                },
                [5] = {
                    label = "Shoes (26-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_5"
                },
                [6] = {
                    label = "Shoes (26-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_6"
                },
                [7] = {
                    label = "Shoes (26-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_7"
                },
                [8] = {
                    label = "Shoes (26-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_8"
                },
                [9] = {
                    label = "Shoes (26-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_9"
                },
                [10] = {
                    label = "Shoes (26-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_10"
                },
                [11] = {
                    label = "Shoes (26-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_11"
                },
                [12] = {
                    label = "Shoes (26-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_12"
                },
                [13] = {
                    label = "Shoes (26-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_13"
                },
                [14] = {
                    label = "Shoes (26-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_14"
                },
                [15] = {
                    label = "Shoes (26-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_26_15"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Scruffy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_27_0"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'component',
            textures = {
                [0] = {
                    label = "White Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_0"
                },
                [1] = {
                    label = "Black Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_1"
                },
                [2] = {
                    label = "All Red Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_2"
                },
                [3] = {
                    label = "Red Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_3"
                },
                [4] = {
                    label = "Tan Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_4"
                },
                [5] = {
                    label = "Blue Studded Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_28_5"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'component',
            textures = {
                [0] = {
                    label = "Golden Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_29_0"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dual Driving Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_30_0"
                },
                [1] = {
                    label = "Gray Driving Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_30_1"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'component',
            textures = {
                [0] = {
                    label = "Calypso Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_31_0"
                },
                [1] = {
                    label = "Buzz Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_31_1"
                },
                [2] = {
                    label = "Fresh Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_31_2"
                },
                [3] = {
                    label = "Jinx Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_31_3"
                },
                [4] = {
                    label = "Animal Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_31_4"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_0"
                },
                [1] = {
                    label = "White Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_1"
                },
                [2] = {
                    label = "Dual Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_2"
                },
                [3] = {
                    label = "Venom Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_3"
                },
                [4] = {
                    label = "Ice Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_4"
                },
                [5] = {
                    label = "Trio Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_5"
                },
                [6] = {
                    label = "Pink Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_6"
                },
                [7] = {
                    label = "Hazard Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_7"
                },
                [8] = {
                    label = "Camo Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_8"
                },
                [9] = {
                    label = "Bounce Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_9"
                },
                [10] = {
                    label = "Earth Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_10"
                },
                [11] = {
                    label = "Neon Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_11"
                },
                [12] = {
                    label = "Crimson Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_12"
                },
                [13] = {
                    label = "Sunrise Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_13"
                },
                [14] = {
                    label = "Sting Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_14"
                },
                [15] = {
                    label = "Court Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_32_15"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (33-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_33_0"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'component',
            textures = {
                [0] = {
                    label = "No Shoes",
                    price = 500,
                    type = "money",
                    image = "male_shoes_34_0"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Walking Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_35_0"
                },
                [1] = {
                    label = "Khaki Walking Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_35_1"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'component',
            textures = {
                [0] = {
                    label = "Sienna Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_36_0"
                },
                [1] = {
                    label = "Orange Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_36_1"
                },
                [2] = {
                    label = "Brown Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_36_2"
                },
                [3] = {
                    label = "Black Leather Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_36_3"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_37_0"
                },
                [1] = {
                    label = "Sienna Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_37_1"
                },
                [2] = {
                    label = "Cream Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_37_2"
                },
                [3] = {
                    label = "Brown Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_37_3"
                },
                [4] = {
                    label = "Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_37_4"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'component',
            textures = {
                [0] = {
                    label = "All Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_38_0"
                },
                [1] = {
                    label = "Sienna Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_38_1"
                },
                [2] = {
                    label = "Cream Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_38_2"
                },
                [3] = {
                    label = "Brown Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_38_3"
                },
                [4] = {
                    label = "Black Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_38_4"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (39-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_39_0"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_0"
                },
                [1] = {
                    label = "White Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_1"
                },
                [2] = {
                    label = "Dusk Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_2"
                },
                [3] = {
                    label = "Purple Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_3"
                },
                [4] = {
                    label = "Gray Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_4"
                },
                [5] = {
                    label = "Sky Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_5"
                },
                [6] = {
                    label = "Brown Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_6"
                },
                [7] = {
                    label = "Hazard Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_7"
                },
                [8] = {
                    label = "All Red Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_8"
                },
                [9] = {
                    label = "Charcoal Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_9"
                },
                [10] = {
                    label = "Pink Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_10"
                },
                [11] = {
                    label = "Royal Tip Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_40_11"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'component',
            textures = {
                [0] = {
                    label = "Red Suede Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_41_0"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'component',
            textures = {
                [0] = {
                    label = "Gray Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_0"
                },
                [1] = {
                    label = "Black Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_1"
                },
                [2] = {
                    label = "White Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_2"
                },
                [3] = {
                    label = "Red Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_3"
                },
                [4] = {
                    label = "Blue Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_4"
                },
                [5] = {
                    label = "Stripy Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_5"
                },
                [6] = {
                    label = "Brown Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_6"
                },
                [7] = {
                    label = "Camo Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_7"
                },
                [8] = {
                    label = "Tropical Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_8"
                },
                [9] = {
                    label = "Green Canvas Slip-ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_42_9"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'component',
            textures = {
                [0] = {
                    label = "Yellow Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_0"
                },
                [1] = {
                    label = "Dark Gray Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_1"
                },
                [2] = {
                    label = "Denim Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_2"
                },
                [3] = {
                    label = "Black Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_3"
                },
                [4] = {
                    label = "Blue Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_4"
                },
                [5] = {
                    label = "Red Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_5"
                },
                [6] = {
                    label = "Green Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_6"
                },
                [7] = {
                    label = "All Black Ankle Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_43_7"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_0"
                },
                [1] = {
                    label = "Hot Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_1"
                },
                [2] = {
                    label = "White Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_2"
                },
                [3] = {
                    label = "Red Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_3"
                },
                [4] = {
                    label = "Wine Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_4"
                },
                [5] = {
                    label = "Crimson Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_5"
                },
                [6] = {
                    label = "Green Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_6"
                },
                [7] = {
                    label = "Purple Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_7"
                },
                [8] = {
                    label = "Orange Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_8"
                },
                [9] = {
                    label = "Navy Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_9"
                },
                [10] = {
                    label = "Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_44_10"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_0"
                },
                [1] = {
                    label = "Hot Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_1"
                },
                [2] = {
                    label = "White Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_2"
                },
                [3] = {
                    label = "Red Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_3"
                },
                [4] = {
                    label = "Wine Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_4"
                },
                [5] = {
                    label = "Crimson Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_5"
                },
                [6] = {
                    label = "Green Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_6"
                },
                [7] = {
                    label = "Purple Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_7"
                },
                [8] = {
                    label = "Orange Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_8"
                },
                [9] = {
                    label = "Navy Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_9"
                },
                [10] = {
                    label = "Pink Cowboy Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_45_10"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (46-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_0"
                },
                [1] = {
                    label = "Shoes (46-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_1"
                },
                [2] = {
                    label = "Shoes (46-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_2"
                },
                [3] = {
                    label = "Shoes (46-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_3"
                },
                [4] = {
                    label = "Shoes (46-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_4"
                },
                [5] = {
                    label = "Shoes (46-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_5"
                },
                [6] = {
                    label = "Shoes (46-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_6"
                },
                [7] = {
                    label = "Shoes (46-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_7"
                },
                [8] = {
                    label = "Shoes (46-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_8"
                },
                [9] = {
                    label = "Shoes (46-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_46_9"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (47-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_0"
                },
                [1] = {
                    label = "Shoes (47-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_1"
                },
                [2] = {
                    label = "Shoes (47-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_2"
                },
                [3] = {
                    label = "Shoes (47-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_3"
                },
                [4] = {
                    label = "Shoes (47-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_4"
                },
                [5] = {
                    label = "Shoes (47-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_5"
                },
                [6] = {
                    label = "Shoes (47-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_6"
                },
                [7] = {
                    label = "Shoes (47-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_7"
                },
                [8] = {
                    label = "Shoes (47-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_8"
                },
                [9] = {
                    label = "Shoes (47-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_9"
                },
                [10] = {
                    label = "Shoes (47-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_10"
                },
                [11] = {
                    label = "Shoes (47-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_47_11"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (48-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_48_0"
                },
                [1] = {
                    label = "Shoes (48-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_48_1"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (49-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_49_0"
                },
                [1] = {
                    label = "Shoes (49-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_49_1"
                },
            },
        },
        [50] = {
            drawable = 50,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_0"
                },
                [1] = {
                    label = "Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_1"
                },
                [2] = {
                    label = "Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_2"
                },
                [3] = {
                    label = "Worn Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_3"
                },
                [4] = {
                    label = "Worn Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_4"
                },
                [5] = {
                    label = "Worn Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_50_5"
                },
            },
        },
        [51] = {
            drawable = 51,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_0"
                },
                [1] = {
                    label = "Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_1"
                },
                [2] = {
                    label = "Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_2"
                },
                [3] = {
                    label = "Worn Black Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_3"
                },
                [4] = {
                    label = "Worn Ox Blood Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_4"
                },
                [5] = {
                    label = "Worn Chocolate Laceup Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_51_5"
                },
            },
        },
        [52] = {
            drawable = 52,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_52_0"
                },
                [1] = {
                    label = "Black Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_52_1"
                },
            },
        },
        [53] = {
            drawable = 53,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_0"
                },
                [1] = {
                    label = "Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_1"
                },
                [2] = {
                    label = "Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_2"
                },
                [3] = {
                    label = "Worn Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_3"
                },
                [4] = {
                    label = "Worn Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_4"
                },
                [5] = {
                    label = "Worn Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_53_5"
                },
            },
        },
        [54] = {
            drawable = 54,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_0"
                },
                [1] = {
                    label = "Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_1"
                },
                [2] = {
                    label = "Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_2"
                },
                [3] = {
                    label = "Worn Black Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_3"
                },
                [4] = {
                    label = "Worn Ox Blood Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_4"
                },
                [5] = {
                    label = "Worn Chocolate Slack Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_54_5"
                },
            },
        },
        [55] = {
            drawable = 55,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (55-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_0"
                },
                [1] = {
                    label = "Shoes (55-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_1"
                },
                [2] = {
                    label = "Shoes (55-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_2"
                },
                [3] = {
                    label = "Shoes (55-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_3"
                },
                [4] = {
                    label = "Shoes (55-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_4"
                },
                [5] = {
                    label = "Shoes (55-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_5"
                },
                [6] = {
                    label = "Shoes (55-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_6"
                },
                [7] = {
                    label = "Shoes (55-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_7"
                },
                [8] = {
                    label = "Shoes (55-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_8"
                },
                [9] = {
                    label = "Shoes (55-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_9"
                },
                [10] = {
                    label = "Shoes (55-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_55_10"
                },
            },
        },
        [56] = {
            drawable = 56,
            type = 'component',
            textures = {
                [0] = {
                    label = "Tan Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_56_0"
                },
                [1] = {
                    label = "Black Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_56_1"
                },
            },
        },
        [57] = {
            drawable = 57,
            type = 'component',
            textures = {
                [0] = {
                    label = "Peach Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_0"
                },
                [1] = {
                    label = "Purple Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_1"
                },
                [2] = {
                    label = "Blue Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_2"
                },
                [3] = {
                    label = "Bronze Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_3"
                },
                [4] = {
                    label = "Pearl Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_4"
                },
                [5] = {
                    label = "Copper Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_5"
                },
                [6] = {
                    label = "Silver Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_6"
                },
                [7] = {
                    label = "Green Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_7"
                },
                [8] = {
                    label = "Cherry Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_8"
                },
                [9] = {
                    label = "White Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_9"
                },
                [10] = {
                    label = "Black Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_10"
                },
                [11] = {
                    label = "Pink Plain Hi Tops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_57_11"
                },
            },
        },
        [58] = {
            drawable = 58,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (58-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_58_0"
                },
                [1] = {
                    label = "Shoes (58-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_58_1"
                },
                [2] = {
                    label = "Shoes (58-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_58_2"
                },
            },
        },
        [59] = {
            drawable = 59,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_0"
                },
                [1] = {
                    label = "Brown Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_1"
                },
                [2] = {
                    label = "Green Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_2"
                },
                [3] = {
                    label = "Gray Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_3"
                },
                [4] = {
                    label = "Peach Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_4"
                },
                [5] = {
                    label = "Fall Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_5"
                },
                [6] = {
                    label = "Dark Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_6"
                },
                [7] = {
                    label = "Crosshatch Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_7"
                },
                [8] = {
                    label = "Moss Digital Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_8"
                },
                [9] = {
                    label = "Gray Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_9"
                },
                [10] = {
                    label = "Aqua Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_10"
                },
                [11] = {
                    label = "Splinter Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_11"
                },
                [12] = {
                    label = "Contrast Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_12"
                },
                [13] = {
                    label = "Cobble Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_13"
                },
                [14] = {
                    label = "Peach Camo Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_14"
                },
                [15] = {
                    label = "Brushstroke Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_15"
                },
                [16] = {
                    label = "Flecktarn Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_16"
                },
                [17] = {
                    label = "Light Woodland Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_17"
                },
                [18] = {
                    label = "Moss Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_18"
                },
                [19] = {
                    label = "Sand Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_19"
                },
                [20] = {
                    label = "Black Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_20"
                },
                [21] = {
                    label = "Slate Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_21"
                },
                [22] = {
                    label = "White Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_22"
                },
                [23] = {
                    label = "Brown Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_23"
                },
                [24] = {
                    label = "Green Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_24"
                },
                [25] = {
                    label = "Red Cross Trainers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_59_25"
                },
            },
        },
        [60] = {
            drawable = 60,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_0"
                },
                [1] = {
                    label = "Beige Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_1"
                },
                [2] = {
                    label = "Brown Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_2"
                },
                [3] = {
                    label = "Moss Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_3"
                },
                [4] = {
                    label = "Tawny Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_4"
                },
                [5] = {
                    label = "Venom Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_5"
                },
                [6] = {
                    label = "Desert Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_6"
                },
                [7] = {
                    label = "Chocolate Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_60_7"
                },
            },
        },
        [61] = {
            drawable = 61,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_0"
                },
                [1] = {
                    label = "Beige Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_1"
                },
                [2] = {
                    label = "Brown Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_2"
                },
                [3] = {
                    label = "Moss Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_3"
                },
                [4] = {
                    label = "Tawny Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_4"
                },
                [5] = {
                    label = "Venom Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_5"
                },
                [6] = {
                    label = "Desert Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_6"
                },
                [7] = {
                    label = "Chocolate Tech Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_61_7"
                },
            },
        },
        [62] = {
            drawable = 62,
            type = 'component',
            textures = {
                [0] = {
                    label = "Desert Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_0"
                },
                [1] = {
                    label = "Sage Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_1"
                },
                [2] = {
                    label = "Blue Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_2"
                },
                [3] = {
                    label = "Khaki Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_3"
                },
                [4] = {
                    label = "Charcoal Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_4"
                },
                [5] = {
                    label = "Walnut Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_5"
                },
                [6] = {
                    label = "Silver Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_6"
                },
                [7] = {
                    label = "Olive Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_62_7"
                },
            },
        },
        [63] = {
            drawable = 63,
            type = 'component',
            textures = {
                [0] = {
                    label = "Desert Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_0"
                },
                [1] = {
                    label = "Sage Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_1"
                },
                [2] = {
                    label = "Blue Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_2"
                },
                [3] = {
                    label = "Khaki Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_3"
                },
                [4] = {
                    label = "Charcoal Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_4"
                },
                [5] = {
                    label = "Walnut Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_5"
                },
                [6] = {
                    label = "Silver Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_6"
                },
                [7] = {
                    label = "Olive Tactical Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_63_7"
                },
            },
        },
        [64] = {
            drawable = 64,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (64-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_0"
                },
                [1] = {
                    label = "Shoes (64-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_1"
                },
                [2] = {
                    label = "Shoes (64-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_2"
                },
                [3] = {
                    label = "Shoes (64-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_3"
                },
                [4] = {
                    label = "Shoes (64-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_4"
                },
                [5] = {
                    label = "Shoes (64-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_5"
                },
                [6] = {
                    label = "Shoes (64-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_6"
                },
                [7] = {
                    label = "Shoes (64-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_7"
                },
                [8] = {
                    label = "Shoes (64-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_8"
                },
                [9] = {
                    label = "Shoes (64-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_9"
                },
                [10] = {
                    label = "Shoes (64-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_10"
                },
                [11] = {
                    label = "Shoes (64-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_11"
                },
                [12] = {
                    label = "Shoes (64-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_12"
                },
                [13] = {
                    label = "Shoes (64-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_64_13"
                },
            },
        },
        [65] = {
            drawable = 65,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_0"
                },
                [1] = {
                    label = "Black Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_1"
                },
                [2] = {
                    label = "Charcoal Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_2"
                },
                [3] = {
                    label = "Chocolate Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_3"
                },
                [4] = {
                    label = "Tan Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_4"
                },
                [5] = {
                    label = "Rust Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_5"
                },
                [6] = {
                    label = "Russet Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_65_6"
                },
            },
        },
        [66] = {
            drawable = 66,
            type = 'component',
            textures = {
                [0] = {
                    label = "Classic Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_0"
                },
                [1] = {
                    label = "Black Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_1"
                },
                [2] = {
                    label = "Charcoal Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_2"
                },
                [3] = {
                    label = "Chocolate Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_3"
                },
                [4] = {
                    label = "Tan Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_4"
                },
                [5] = {
                    label = "Rust Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_5"
                },
                [6] = {
                    label = "Russet Moc Toe Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_66_6"
                },
            },
        },
        [67] = {
            drawable = 67,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (67-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_0"
                },
                [1] = {
                    label = "Shoes (67-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_1"
                },
                [2] = {
                    label = "Shoes (67-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_2"
                },
                [3] = {
                    label = "Shoes (67-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_3"
                },
                [4] = {
                    label = "Shoes (67-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_4"
                },
                [5] = {
                    label = "Shoes (67-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_5"
                },
                [6] = {
                    label = "Shoes (67-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_6"
                },
                [7] = {
                    label = "Shoes (67-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_7"
                },
                [8] = {
                    label = "Shoes (67-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_8"
                },
                [9] = {
                    label = "Shoes (67-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_9"
                },
                [10] = {
                    label = "Shoes (67-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_10"
                },
                [11] = {
                    label = "Shoes (67-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_11"
                },
                [12] = {
                    label = "Shoes (67-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_12"
                },
                [13] = {
                    label = "Shoes (67-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_13"
                },
                [14] = {
                    label = "Shoes (67-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_14"
                },
                [15] = {
                    label = "Shoes (67-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_15"
                },
                [16] = {
                    label = "Shoes (67-16)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_16"
                },
                [17] = {
                    label = "Shoes (67-17)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_17"
                },
                [18] = {
                    label = "Shoes (67-18)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_18"
                },
                [19] = {
                    label = "Shoes (67-19)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_19"
                },
                [20] = {
                    label = "Shoes (67-20)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_20"
                },
                [21] = {
                    label = "Shoes (67-21)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_21"
                },
                [22] = {
                    label = "Shoes (67-22)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_22"
                },
                [23] = {
                    label = "Shoes (67-23)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_23"
                },
                [24] = {
                    label = "Shoes (67-24)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_24"
                },
                [25] = {
                    label = "Shoes (67-25)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_67_25"
                },
            },
        },
        [68] = {
            drawable = 68,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (68-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_0"
                },
                [1] = {
                    label = "Shoes (68-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_1"
                },
                [2] = {
                    label = "Shoes (68-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_2"
                },
                [3] = {
                    label = "Shoes (68-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_3"
                },
                [4] = {
                    label = "Shoes (68-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_4"
                },
                [5] = {
                    label = "Shoes (68-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_5"
                },
                [6] = {
                    label = "Shoes (68-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_6"
                },
                [7] = {
                    label = "Shoes (68-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_7"
                },
                [8] = {
                    label = "Shoes (68-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_8"
                },
                [9] = {
                    label = "Shoes (68-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_9"
                },
                [10] = {
                    label = "Shoes (68-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_10"
                },
                [11] = {
                    label = "Shoes (68-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_68_11"
                },
            },
        },
        [69] = {
            drawable = 69,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (69-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_0"
                },
                [1] = {
                    label = "Shoes (69-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_1"
                },
                [2] = {
                    label = "Shoes (69-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_2"
                },
                [3] = {
                    label = "Shoes (69-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_3"
                },
                [4] = {
                    label = "Shoes (69-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_4"
                },
                [5] = {
                    label = "Shoes (69-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_5"
                },
                [6] = {
                    label = "Shoes (69-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_6"
                },
                [7] = {
                    label = "Shoes (69-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_7"
                },
                [8] = {
                    label = "Shoes (69-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_8"
                },
                [9] = {
                    label = "Shoes (69-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_9"
                },
                [10] = {
                    label = "Shoes (69-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_10"
                },
                [11] = {
                    label = "Shoes (69-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_11"
                },
                [12] = {
                    label = "Shoes (69-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_12"
                },
                [13] = {
                    label = "Shoes (69-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_13"
                },
                [14] = {
                    label = "Shoes (69-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_14"
                },
                [15] = {
                    label = "Shoes (69-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_15"
                },
                [16] = {
                    label = "Shoes (69-16)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_16"
                },
                [17] = {
                    label = "Shoes (69-17)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_17"
                },
                [18] = {
                    label = "Shoes (69-18)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_18"
                },
                [19] = {
                    label = "Shoes (69-19)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_19"
                },
                [20] = {
                    label = "Shoes (69-20)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_20"
                },
                [21] = {
                    label = "Shoes (69-21)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_21"
                },
                [22] = {
                    label = "Shoes (69-22)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_22"
                },
                [23] = {
                    label = "Shoes (69-23)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_23"
                },
                [24] = {
                    label = "Shoes (69-24)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_24"
                },
                [25] = {
                    label = "Shoes (69-25)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_69_25"
                },
            },
        },
        [70] = {
            drawable = 70,
            type = 'component',
            textures = {
                [0] = {
                    label = "Earth Tones Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_0"
                },
                [1] = {
                    label = "Mono Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_1"
                },
                [2] = {
                    label = "Gray & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_2"
                },
                [3] = {
                    label = "Grayscale Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_3"
                },
                [4] = {
                    label = "Khaki Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_4"
                },
                [5] = {
                    label = "Tan Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_5"
                },
                [6] = {
                    label = "Rust Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_6"
                },
                [7] = {
                    label = "Woodland Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_7"
                },
                [8] = {
                    label = "Aqua Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_8"
                },
                [9] = {
                    label = "Cyan Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_9"
                },
                [10] = {
                    label = "Pink Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_10"
                },
                [11] = {
                    label = "Gray Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_11"
                },
                [12] = {
                    label = "Blue & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_12"
                },
                [13] = {
                    label = "Navy & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_13"
                },
                [14] = {
                    label = "Houndstooth Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_14"
                },
                [15] = {
                    label = "Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_15"
                },
                [16] = {
                    label = "Orange Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_16"
                },
                [17] = {
                    label = "Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_17"
                },
                [18] = {
                    label = "Moss Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_18"
                },
                [19] = {
                    label = "Dark Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_19"
                },
                [20] = {
                    label = "Fall Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_20"
                },
                [21] = {
                    label = "Splinter Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_21"
                },
                [22] = {
                    label = "White & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_22"
                },
                [23] = {
                    label = "Black & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_23"
                },
                [24] = {
                    label = "Black & Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_24"
                },
                [25] = {
                    label = "Chocolate Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_70_25"
                },
            },
        },
        [71] = {
            drawable = 71,
            type = 'component',
            textures = {
                [0] = {
                    label = "Earth Tones Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_0"
                },
                [1] = {
                    label = "Mono Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_1"
                },
                [2] = {
                    label = "Gray & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_2"
                },
                [3] = {
                    label = "Grayscale Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_3"
                },
                [4] = {
                    label = "Khaki Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_4"
                },
                [5] = {
                    label = "Tan Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_5"
                },
                [6] = {
                    label = "Rust Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_6"
                },
                [7] = {
                    label = "Woodland Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_7"
                },
                [8] = {
                    label = "Aqua Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_8"
                },
                [9] = {
                    label = "Cyan Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_9"
                },
                [10] = {
                    label = "Pink Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_10"
                },
                [11] = {
                    label = "Gray Camo Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_11"
                },
                [12] = {
                    label = "Blue & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_12"
                },
                [13] = {
                    label = "Navy & Brown Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_13"
                },
                [14] = {
                    label = "Houndstooth Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_14"
                },
                [15] = {
                    label = "Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_15"
                },
                [16] = {
                    label = "Orange Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_16"
                },
                [17] = {
                    label = "Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_17"
                },
                [18] = {
                    label = "Moss Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_18"
                },
                [19] = {
                    label = "Dark Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_19"
                },
                [20] = {
                    label = "Fall Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_20"
                },
                [21] = {
                    label = "Splinter Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_21"
                },
                [22] = {
                    label = "White & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_22"
                },
                [23] = {
                    label = "Black & Red Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_23"
                },
                [24] = {
                    label = "Black & Blue Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_24"
                },
                [25] = {
                    label = "Chocolate Rubberized",
                    price = 500,
                    type = "money",
                    image = "male_shoes_71_25"
                },
            },
        },
        [72] = {
            drawable = 72,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_0"
                },
                [1] = {
                    label = "Black & Sand Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_1"
                },
                [2] = {
                    label = "Black & Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_2"
                },
                [3] = {
                    label = "Buff Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_3"
                },
                [4] = {
                    label = "Gray & Yellow Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_4"
                },
                [5] = {
                    label = "Fall Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_5"
                },
                [6] = {
                    label = "Black & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_6"
                },
                [7] = {
                    label = "Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_7"
                },
                [8] = {
                    label = "Black & Light Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_8"
                },
                [9] = {
                    label = "White Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_9"
                },
                [10] = {
                    label = "Woodland Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_10"
                },
                [11] = {
                    label = "Slate Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_11"
                },
                [12] = {
                    label = "Tan Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_12"
                },
                [13] = {
                    label = "Moss Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_13"
                },
                [14] = {
                    label = "Khaki Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_14"
                },
                [15] = {
                    label = "Gray Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_15"
                },
                [16] = {
                    label = "Charcoal Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_16"
                },
                [17] = {
                    label = "Red Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_17"
                },
                [18] = {
                    label = "Orange Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_18"
                },
                [19] = {
                    label = "Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_19"
                },
                [20] = {
                    label = "Navy Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_20"
                },
                [21] = {
                    label = "Earth Tones Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_21"
                },
                [22] = {
                    label = "Light Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_22"
                },
                [23] = {
                    label = "Blue & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_23"
                },
                [24] = {
                    label = "Gray Camo Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_24"
                },
                [25] = {
                    label = "Aqua Camo Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_72_25"
                },
            },
        },
        [73] = {
            drawable = 73,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_0"
                },
                [1] = {
                    label = "Black & Sand Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_1"
                },
                [2] = {
                    label = "Black & Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_2"
                },
                [3] = {
                    label = "Buff Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_3"
                },
                [4] = {
                    label = "Gray & Yellow Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_4"
                },
                [5] = {
                    label = "Fall Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_5"
                },
                [6] = {
                    label = "Black & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_6"
                },
                [7] = {
                    label = "Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_7"
                },
                [8] = {
                    label = "Black & Light Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_8"
                },
                [9] = {
                    label = "White Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_9"
                },
                [10] = {
                    label = "Woodland Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_10"
                },
                [11] = {
                    label = "Slate Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_11"
                },
                [12] = {
                    label = "Tan Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_12"
                },
                [13] = {
                    label = "Moss Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_13"
                },
                [14] = {
                    label = "Khaki Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_14"
                },
                [15] = {
                    label = "Gray Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_15"
                },
                [16] = {
                    label = "Charcoal Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_16"
                },
                [17] = {
                    label = "Red Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_17"
                },
                [18] = {
                    label = "Orange Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_18"
                },
                [19] = {
                    label = "Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_19"
                },
                [20] = {
                    label = "Navy Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_20"
                },
                [21] = {
                    label = "Earth Tones Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_21"
                },
                [22] = {
                    label = "Light Blue Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_22"
                },
                [23] = {
                    label = "Blue & Brown Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_23"
                },
                [24] = {
                    label = "Gray Camo Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_24"
                },
                [25] = {
                    label = "Aqua Camo Trail",
                    price = 500,
                    type = "money",
                    image = "male_shoes_73_25"
                },
            },
        },
        [74] = {
            drawable = 74,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (74-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_74_0"
                },
                [1] = {
                    label = "Shoes (74-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_74_1"
                },
            },
        },
        [75] = {
            drawable = 75,
            type = 'component',
            textures = {
                [0] = {
                    label = "Purple Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_0"
                },
                [1] = {
                    label = "Midnight Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_1"
                },
                [2] = {
                    label = "Sunset Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_2"
                },
                [3] = {
                    label = "Green Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_3"
                },
                [4] = {
                    label = "Cream & Pink Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_4"
                },
                [5] = {
                    label = "Black & Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_5"
                },
                [6] = {
                    label = "Gray & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_6"
                },
                [7] = {
                    label = "Shoes (75-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_7"
                },
                [8] = {
                    label = "Shoes (75-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_8"
                },
                [9] = {
                    label = "Shoes (75-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_9"
                },
                [10] = {
                    label = "Shoes (75-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_10"
                },
                [11] = {
                    label = "Orange Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_11"
                },
                [12] = {
                    label = "Pink Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_12"
                },
                [13] = {
                    label = "White & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_13"
                },
                [14] = {
                    label = "Vibrant Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_14"
                },
                [15] = {
                    label = "Ash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_15"
                },
                [16] = {
                    label = "Sage Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_16"
                },
                [17] = {
                    label = "All Gray Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_17"
                },
                [18] = {
                    label = "Blue Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_18"
                },
                [19] = {
                    label = "Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_19"
                },
                [20] = {
                    label = "Grayscale Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_20"
                },
                [21] = {
                    label = "Blue Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_21"
                },
                [22] = {
                    label = "White Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_22"
                },
                [23] = {
                    label = "Graphite Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_23"
                },
                [24] = {
                    label = "Mocha Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_24"
                },
                [25] = {
                    label = "Mono Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_75_25"
                },
            },
        },
        [76] = {
            drawable = 76,
            type = 'component',
            textures = {
                [0] = {
                    label = "Purple Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_0"
                },
                [1] = {
                    label = "Midnight Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_1"
                },
                [2] = {
                    label = "Sunset Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_2"
                },
                [3] = {
                    label = "Green Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_3"
                },
                [4] = {
                    label = "Cream & Pink Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_4"
                },
                [5] = {
                    label = "Black & Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_5"
                },
                [6] = {
                    label = "Gray & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_6"
                },
                [7] = {
                    label = "Shoes (76-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_7"
                },
                [8] = {
                    label = "Shoes (76-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_8"
                },
                [9] = {
                    label = "Shoes (76-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_9"
                },
                [10] = {
                    label = "Shoes (76-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_10"
                },
                [11] = {
                    label = "Orange Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_11"
                },
                [12] = {
                    label = "Pink Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_12"
                },
                [13] = {
                    label = "White & Orange Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_13"
                },
                [14] = {
                    label = "Vibrant Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_14"
                },
                [15] = {
                    label = "Ash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_15"
                },
                [16] = {
                    label = "Sage Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_16"
                },
                [17] = {
                    label = "All Gray Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_17"
                },
                [18] = {
                    label = "Blue Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_18"
                },
                [19] = {
                    label = "Red Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_19"
                },
                [20] = {
                    label = "Grayscale Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_20"
                },
                [21] = {
                    label = "Blue Flash Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_21"
                },
                [22] = {
                    label = "White Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_22"
                },
                [23] = {
                    label = "Graphite Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_23"
                },
                [24] = {
                    label = "Mocha Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_24"
                },
                [25] = {
                    label = "Mono Retro Runners",
                    price = 500,
                    type = "money",
                    image = "male_shoes_76_25"
                },
            },
        },
        [77] = {
            drawable = 77,
            type = 'component',
            textures = {
                [0] = {
                    label = "White & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_0"
                },
                [1] = {
                    label = "White & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_1"
                },
                [2] = {
                    label = "White & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_2"
                },
                [3] = {
                    label = "White & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_3"
                },
                [4] = {
                    label = "Gray & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_4"
                },
                [5] = {
                    label = "Gray & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_5"
                },
                [6] = {
                    label = "Gray & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_6"
                },
                [7] = {
                    label = "Gray & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_7"
                },
                [8] = {
                    label = "Black & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_8"
                },
                [9] = {
                    label = "Black & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_9"
                },
                [10] = {
                    label = "Black & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_10"
                },
                [11] = {
                    label = "Black & Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_11"
                },
                [12] = {
                    label = "Pink & Blue Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_12"
                },
                [13] = {
                    label = "Pink & Green Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_13"
                },
                [14] = {
                    label = "Ash & Pink Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_14"
                },
                [15] = {
                    label = "Red Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_15"
                },
                [16] = {
                    label = "Blue Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_16"
                },
                [17] = {
                    label = "Green Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_17"
                },
                [18] = {
                    label = "Pink Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_18"
                },
                [19] = {
                    label = "Red Print Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_19"
                },
                [20] = {
                    label = "Red Camo Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_20"
                },
                [21] = {
                    label = "Pink Camo Light Ups",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_21"
                },
                [22] = {
                    label = "Shoes (77-22)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_22"
                },
                [23] = {
                    label = "Shoes (77-23)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_23"
                },
                [24] = {
                    label = "Shoes (77-24)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_24"
                },
                [25] = {
                    label = "Shoes (77-25)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_77_25"
                },
            },
        },
        [78] = {
            drawable = 78,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (78-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_0"
                },
                [1] = {
                    label = "Shoes (78-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_1"
                },
                [2] = {
                    label = "Shoes (78-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_2"
                },
                [3] = {
                    label = "Shoes (78-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_3"
                },
                [4] = {
                    label = "Shoes (78-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_4"
                },
                [5] = {
                    label = "Shoes (78-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_5"
                },
                [6] = {
                    label = "Shoes (78-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_6"
                },
                [7] = {
                    label = "Shoes (78-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_7"
                },
                [8] = {
                    label = "Shoes (78-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_8"
                },
                [9] = {
                    label = "Shoes (78-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_9"
                },
                [10] = {
                    label = "Shoes (78-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_10"
                },
                [11] = {
                    label = "Shoes (78-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_11"
                },
                [12] = {
                    label = "Shoes (78-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_12"
                },
                [13] = {
                    label = "Shoes (78-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_78_13"
                },
            },
        },
        [79] = {
            drawable = 79,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_79_0"
                },
                [1] = {
                    label = "Red Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_79_1"
                },
            },
        },
        [80] = {
            drawable = 80,
            type = 'component',
            textures = {
                [0] = {
                    label = "Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_80_0"
                },
                [1] = {
                    label = "Red Flaming Skull Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_80_1"
                },
            },
        },
        [81] = {
            drawable = 81,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_81_0"
                },
                [1] = {
                    label = "Dark Brown Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_81_1"
                },
                [2] = {
                    label = "Tan Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_81_2"
                },
            },
        },
        [82] = {
            drawable = 82,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_82_0"
                },
                [1] = {
                    label = "Dark Brown Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_82_1"
                },
                [2] = {
                    label = "Tan Skull Harness Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_82_2"
                },
            },
        },
        [83] = {
            drawable = 83,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (83-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_0"
                },
                [1] = {
                    label = "Shoes (83-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_1"
                },
                [2] = {
                    label = "Shoes (83-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_2"
                },
                [3] = {
                    label = "Shoes (83-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_3"
                },
                [4] = {
                    label = "Shoes (83-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_4"
                },
                [5] = {
                    label = "Shoes (83-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_5"
                },
                [6] = {
                    label = "Shoes (83-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_6"
                },
                [7] = {
                    label = "Shoes (83-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_7"
                },
                [8] = {
                    label = "Shoes (83-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_8"
                },
                [9] = {
                    label = "Shoes (83-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_9"
                },
                [10] = {
                    label = "Shoes (83-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_10"
                },
                [11] = {
                    label = "Shoes (83-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_11"
                },
                [12] = {
                    label = "Shoes (83-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_12"
                },
                [13] = {
                    label = "Shoes (83-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_13"
                },
                [14] = {
                    label = "Shoes (83-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_14"
                },
                [15] = {
                    label = "Shoes (83-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_15"
                },
                [16] = {
                    label = "Shoes (83-16)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_16"
                },
                [17] = {
                    label = "Shoes (83-17)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_17"
                },
                [18] = {
                    label = "Shoes (83-18)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_18"
                },
                [19] = {
                    label = "Shoes (83-19)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_83_19"
                },
            },
        },
        [84] = {
            drawable = 84,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_0"
                },
                [1] = {
                    label = "Dark Brown Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_1"
                },
                [2] = {
                    label = "Green Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_2"
                },
                [3] = {
                    label = "Beige Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_3"
                },
                [4] = {
                    label = "White Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_4"
                },
                [5] = {
                    label = "Gray Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_5"
                },
                [6] = {
                    label = "Red Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_6"
                },
                [7] = {
                    label = "Brown & White Raider Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_84_7"
                },
            },
        },
        [85] = {
            drawable = 85,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_0"
                },
                [1] = {
                    label = "Black Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_1"
                },
                [2] = {
                    label = "Light Green Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_2"
                },
                [3] = {
                    label = "Beige Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_3"
                },
                [4] = {
                    label = "Blue Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_4"
                },
                [5] = {
                    label = "Green Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_5"
                },
                [6] = {
                    label = "White Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_6"
                },
                [7] = {
                    label = "Crosshatch Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_7"
                },
                [8] = {
                    label = "Yellow Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_8"
                },
                [9] = {
                    label = "Steel Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_9"
                },
                [10] = {
                    label = "Red Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_10"
                },
                [11] = {
                    label = "Blue Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_11"
                },
                [12] = {
                    label = "Shoes (85-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_12"
                },
                [13] = {
                    label = "Shoes (85-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_13"
                },
                [14] = {
                    label = "Shoes (85-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_14"
                },
                [15] = {
                    label = "Shoes (85-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_85_15"
                },
            },
        },
        [86] = {
            drawable = 86,
            type = 'component',
            textures = {
                [0] = {
                    label = "Brown Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_0"
                },
                [1] = {
                    label = "Black Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_1"
                },
                [2] = {
                    label = "Light Green Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_2"
                },
                [3] = {
                    label = "Beige Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_3"
                },
                [4] = {
                    label = "Blue Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_4"
                },
                [5] = {
                    label = "Green Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_5"
                },
                [6] = {
                    label = "White Camo Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_6"
                },
                [7] = {
                    label = "Crosshatch Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_7"
                },
                [8] = {
                    label = "Yellow Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_8"
                },
                [9] = {
                    label = "Steel Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_9"
                },
                [10] = {
                    label = "Red Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_10"
                },
                [11] = {
                    label = "Blue Plated Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_11"
                },
                [12] = {
                    label = "Shoes (86-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_12"
                },
                [13] = {
                    label = "Shoes (86-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_13"
                },
                [14] = {
                    label = "Shoes (86-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_14"
                },
                [15] = {
                    label = "Shoes (86-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_86_15"
                },
            },
        },
        [87] = {
            drawable = 87,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (87-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_0"
                },
                [1] = {
                    label = "Shoes (87-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_1"
                },
                [2] = {
                    label = "Shoes (87-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_2"
                },
                [3] = {
                    label = "Shoes (87-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_3"
                },
                [4] = {
                    label = "Shoes (87-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_4"
                },
                [5] = {
                    label = "Shoes (87-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_5"
                },
                [6] = {
                    label = "Shoes (87-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_6"
                },
                [7] = {
                    label = "Shoes (87-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_7"
                },
                [8] = {
                    label = "Shoes (87-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_8"
                },
                [9] = {
                    label = "Shoes (87-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_9"
                },
                [10] = {
                    label = "Shoes (87-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_10"
                },
                [11] = {
                    label = "Shoes (87-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_11"
                },
                [12] = {
                    label = "Shoes (87-12)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_12"
                },
                [13] = {
                    label = "Shoes (87-13)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_13"
                },
                [14] = {
                    label = "Shoes (87-14)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_14"
                },
                [15] = {
                    label = "Shoes (87-15)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_15"
                },
                [16] = {
                    label = "Shoes (87-16)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_16"
                },
                [17] = {
                    label = "Shoes (87-17)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_87_17"
                },
            },
        },
        [88] = {
            drawable = 88,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (88-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_0"
                },
                [1] = {
                    label = "Shoes (88-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_1"
                },
                [2] = {
                    label = "Shoes (88-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_2"
                },
                [3] = {
                    label = "Shoes (88-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_3"
                },
                [4] = {
                    label = "Shoes (88-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_4"
                },
                [5] = {
                    label = "Shoes (88-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_5"
                },
                [6] = {
                    label = "Shoes (88-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_6"
                },
                [7] = {
                    label = "Shoes (88-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_7"
                },
                [8] = {
                    label = "Shoes (88-8)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_8"
                },
                [9] = {
                    label = "Shoes (88-9)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_9"
                },
                [10] = {
                    label = "Shoes (88-10)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_10"
                },
                [11] = {
                    label = "Shoes (88-11)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_88_11"
                },
            },
        },
        [89] = {
            drawable = 89,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (89-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_89_0"
                },
            },
        },
        [90] = {
            drawable = 90,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (90-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_90_0"
                },
            },
        },
        [91] = {
            drawable = 91,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (91-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_91_0"
                },
            },
        },
        [92] = {
            drawable = 92,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_0"
                },
                [1] = {
                    label = "Blue FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_1"
                },
                [2] = {
                    label = "Green FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_2"
                },
                [3] = {
                    label = "Red FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_3"
                },
                [4] = {
                    label = "Yellow FB Manor Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_4"
                },
                [5] = {
                    label = "Blue FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_5"
                },
                [6] = {
                    label = "Red FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_6"
                },
                [7] = {
                    label = "Yellow FB Slipper Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_92_7"
                },
            },
        },
        [93] = {
            drawable = 93,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_0"
                },
                [1] = {
                    label = "Brown Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_1"
                },
                [2] = {
                    label = "Green Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_2"
                },
                [3] = {
                    label = "Violet Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_3"
                },
                [4] = {
                    label = "Red Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_4"
                },
                [5] = {
                    label = "Two Tone Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_5"
                },
                [6] = {
                    label = "Mono Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_6"
                },
                [7] = {
                    label = "Blue Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_7"
                },
                [8] = {
                    label = "Mauve Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_8"
                },
                [9] = {
                    label = "Purple Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_9"
                },
                [10] = {
                    label = "Orange Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_10"
                },
                [11] = {
                    label = "Grayscale Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_11"
                },
                [12] = {
                    label = "Ash Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_12"
                },
                [13] = {
                    label = "Gray Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_13"
                },
                [14] = {
                    label = "White Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_93_14"
                },
            },
        },
        [94] = {
            drawable = 94,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_0"
                },
                [1] = {
                    label = "Brown Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_1"
                },
                [2] = {
                    label = "Green Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_2"
                },
                [3] = {
                    label = "Violet Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_3"
                },
                [4] = {
                    label = "Red Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_4"
                },
                [5] = {
                    label = "Two Tone Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_5"
                },
                [6] = {
                    label = "Mono Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_6"
                },
                [7] = {
                    label = "Blue Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_7"
                },
                [8] = {
                    label = "Mauve Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_8"
                },
                [9] = {
                    label = "Purple Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_9"
                },
                [10] = {
                    label = "Orange Fade Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_10"
                },
                [11] = {
                    label = "Grayscale Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_11"
                },
                [12] = {
                    label = "Ash Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_12"
                },
                [13] = {
                    label = "Gray Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_13"
                },
                [14] = {
                    label = "White Pattern Retro Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_94_14"
                },
            },
        },
        [95] = {
            drawable = 95,
            type = 'component',
            textures = {
                [0] = {
                    label = "Dog With Cone Slip-Ons",
                    price = 500,
                    type = "money",
                    image = "male_shoes_95_0"
                },
            },
        },
        [96] = {
            drawable = 96,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heavy Uniform Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_96_0"
                },
            },
        },
        [97] = {
            drawable = 97,
            type = 'component',
            textures = {
                [0] = {
                    label = "Heavy Uniform Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_97_0"
                },
            },
        },
        [98] = {
            drawable = 98,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (98-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_98_0"
                },
            },
        },
        [99] = {
            drawable = 99,
            type = 'component',
            textures = {
                [0] = {
                    label = "Ice Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_0"
                },
                [1] = {
                    label = "White Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_1"
                },
                [2] = {
                    label = "Aqua Sole Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_2"
                },
                [3] = {
                    label = "Black Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_3"
                },
                [4] = {
                    label = "Cream Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_4"
                },
                [5] = {
                    label = "Smoky Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_5"
                },
                [6] = {
                    label = "Lime Highlight Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_6"
                },
                [7] = {
                    label = "Pink Vibrant Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_7"
                },
                [8] = {
                    label = "Lilac Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_8"
                },
                [9] = {
                    label = "Red Highlight Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_9"
                },
                [10] = {
                    label = "Cyan Fade Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_10"
                },
                [11] = {
                    label = "Purple Fade Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_11"
                },
                [12] = {
                    label = "Beige Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_12"
                },
                [13] = {
                    label = "Grayscale Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_13"
                },
                [14] = {
                    label = "Gray & Cyan Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_14"
                },
                [15] = {
                    label = "Gray & Aqua Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_15"
                },
                [16] = {
                    label = "Black & Lime Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_16"
                },
                [17] = {
                    label = "Teal Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_17"
                },
                [18] = {
                    label = "Gray & Purple Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_18"
                },
                [19] = {
                    label = "Gray & Magenta Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_19"
                },
                [20] = {
                    label = "Gray & Yellow Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_20"
                },
                [21] = {
                    label = "Orange Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_21"
                },
                [22] = {
                    label = "White & Gold Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_22"
                },
                [23] = {
                    label = "White & Pink Knit Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_99_23"
                },
            },
        },
        [100] = {
            drawable = 100,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (100-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_100_0"
                },
                [1] = {
                    label = "Shoes (100-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_100_1"
                },
            },
        },
        [101] = {
            drawable = 101,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (101-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_0"
                },
                [1] = {
                    label = "Shoes (101-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_1"
                },
                [2] = {
                    label = "Shoes (101-2)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_2"
                },
                [3] = {
                    label = "Shoes (101-3)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_3"
                },
                [4] = {
                    label = "Shoes (101-4)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_4"
                },
                [5] = {
                    label = "Shoes (101-5)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_5"
                },
                [6] = {
                    label = "Shoes (101-6)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_6"
                },
                [7] = {
                    label = "Shoes (101-7)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_101_7"
                },
            },
        },
        [102] = {
            drawable = 102,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_0"
                },
                [1] = {
                    label = "Ox Blood Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_1"
                },
                [2] = {
                    label = "Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_2"
                },
                [3] = {
                    label = "Chestnut Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_3"
                },
                [4] = {
                    label = "Ash Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_4"
                },
                [5] = {
                    label = "Dark Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_5"
                },
                [6] = {
                    label = "Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_6"
                },
                [7] = {
                    label = "Dark Green Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_7"
                },
                [8] = {
                    label = "Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_8"
                },
                [9] = {
                    label = "Dark Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_9"
                },
                [10] = {
                    label = "Orange Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_10"
                },
                [11] = {
                    label = "Dark Nut Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_11"
                },
                [12] = {
                    label = "Navy Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_12"
                },
                [13] = {
                    label = "Blue Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_102_13"
                },
            },
        },
        [103] = {
            drawable = 103,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_0"
                },
                [1] = {
                    label = "Ox Blood Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_1"
                },
                [2] = {
                    label = "Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_2"
                },
                [3] = {
                    label = "Chestnut Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_3"
                },
                [4] = {
                    label = "Ash Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_4"
                },
                [5] = {
                    label = "Dark Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_5"
                },
                [6] = {
                    label = "Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_6"
                },
                [7] = {
                    label = "Dark Green Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_7"
                },
                [8] = {
                    label = "Gray Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_8"
                },
                [9] = {
                    label = "Dark Red Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_9"
                },
                [10] = {
                    label = "Orange Tan Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_10"
                },
                [11] = {
                    label = "Dark Nut Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_11"
                },
                [12] = {
                    label = "Navy Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_12"
                },
                [13] = {
                    label = "Blue Road Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_103_13"
                },
            },
        },
        [104] = {
            drawable = 104,
            type = 'component',
            textures = {
                [0] = {
                    label = "Walnut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_0"
                },
                [1] = {
                    label = "Black Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_1"
                },
                [2] = {
                    label = "Gray Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_2"
                },
                [3] = {
                    label = "Ice Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_3"
                },
                [4] = {
                    label = "Dark Nut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_4"
                },
                [5] = {
                    label = "Chocolate Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_5"
                },
                [6] = {
                    label = "Chestnut Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_6"
                },
                [7] = {
                    label = "Beige Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_7"
                },
                [8] = {
                    label = "Blue Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_8"
                },
                [9] = {
                    label = "Green Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_9"
                },
                [10] = {
                    label = "Pink Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_10"
                },
                [11] = {
                    label = "Crimson Smart Oxfords",
                    price = 500,
                    type = "money",
                    image = "male_shoes_104_11"
                },
            },
        },
        [105] = {
            drawable = 105,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue Clover Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_0"
                },
                [1] = {
                    label = "Green Clover Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_1"
                },
                [2] = {
                    label = "Green Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_2"
                },
                [3] = {
                    label = "Light Blue Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_3"
                },
                [4] = {
                    label = "Red Botanical Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_4"
                },
                [5] = {
                    label = "Navy Botanical Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_5"
                },
                [6] = {
                    label = "Pink Lemon Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_6"
                },
                [7] = {
                    label = "Blue Lemon Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_7"
                },
                [8] = {
                    label = "Blue Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_8"
                },
                [9] = {
                    label = "Red Floral Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_9"
                },
                [10] = {
                    label = "Vivid Stripes Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_10"
                },
                [11] = {
                    label = "Vibrant Stripes Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_11"
                },
                [12] = {
                    label = "Blue Striped Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_12"
                },
                [13] = {
                    label = "Red Striped Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_13"
                },
                [14] = {
                    label = "White Borrachas Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_14"
                },
                [15] = {
                    label = "Black Borrachas Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_15"
                },
                [16] = {
                    label = "Green Rectangles Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_16"
                },
                [17] = {
                    label = "Yellow Rectangles Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_17"
                },
                [18] = {
                    label = "Lilac Squares Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_18"
                },
                [19] = {
                    label = "Yellow Squares Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_19"
                },
                [20] = {
                    label = "Black Text Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_20"
                },
                [21] = {
                    label = "White Text Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_21"
                },
                [22] = {
                    label = "Red Zig Zag Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_22"
                },
                [23] = {
                    label = "Blue Zig Zag Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_105_23"
                },
            },
        },
        [106] = {
            drawable = 106,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_0"
                },
                [1] = {
                    label = "Gray Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_1"
                },
                [2] = {
                    label = "Lilac Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_2"
                },
                [3] = {
                    label = "Chocolate Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_3"
                },
                [4] = {
                    label = "Ox Blood Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_4"
                },
                [5] = {
                    label = "Dark Tan Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_5"
                },
                [6] = {
                    label = "Beige Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_6"
                },
                [7] = {
                    label = "Blue Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_7"
                },
                [8] = {
                    label = "Green Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_8"
                },
                [9] = {
                    label = "Pink Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_9"
                },
                [10] = {
                    label = "Red Buckled Loafers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_106_10"
                },
            },
        },
        [107] = {
            drawable = 107,
            type = 'component',
            textures = {
                [0] = {
                    label = "Wild Striped Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_0"
                },
                [1] = {
                    label = "Neon Striped Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_1"
                },
                [2] = {
                    label = "Black SC Coin Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_2"
                },
                [3] = {
                    label = "White SC Coin Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_3"
                },
                [4] = {
                    label = "Black SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_4"
                },
                [5] = {
                    label = "Pink SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_5"
                },
                [6] = {
                    label = "Blue SC Pattern Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_6"
                },
                [7] = {
                    label = "Camo Yeti Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_7"
                },
                [8] = {
                    label = "Gray Camo Yeti Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_107_8"
                },
            },
        },
        [108] = {
            drawable = 108,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_0"
                },
                [1] = {
                    label = "Purple Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_1"
                },
                [2] = {
                    label = "Camo Bigness Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_2"
                },
                [3] = {
                    label = "Black Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_3"
                },
                [4] = {
                    label = "White Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_4"
                },
                [5] = {
                    label = "Pink Blagueurs Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_5"
                },
                [6] = {
                    label = "Gray Cimicino Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_6"
                },
                [7] = {
                    label = "Rouge Cimicino Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_7"
                },
                [8] = {
                    label = "Navy DS Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_8"
                },
                [9] = {
                    label = "Red DS Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_9"
                },
                [10] = {
                    label = "Floral Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_10"
                },
                [11] = {
                    label = "Green Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_11"
                },
                [12] = {
                    label = "White Güffy Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_12"
                },
                [13] = {
                    label = "Blue Heat Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_13"
                },
                [14] = {
                    label = "Red ProLaps Pool Sliders",
                    price = 500,
                    type = "money",
                    image = "male_shoes_108_14"
                },
            },
        },
        [109] = {
            drawable = 109,
            type = 'component',
            textures = {
                [0] = {
                    label = "Walnut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_0"
                },
                [1] = {
                    label = "Black Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_1"
                },
                [2] = {
                    label = "Gray Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_2"
                },
                [3] = {
                    label = "Ice Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_3"
                },
                [4] = {
                    label = "Dark Nut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_4"
                },
                [5] = {
                    label = "Chocolate Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_5"
                },
                [6] = {
                    label = "Chestnut Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_6"
                },
                [7] = {
                    label = "Beige Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_7"
                },
                [8] = {
                    label = "Blue Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_8"
                },
                [9] = {
                    label = "Green Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_9"
                },
                [10] = {
                    label = "Pink Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_10"
                },
                [11] = {
                    label = "Crimson Smart Oxfords Ankle",
                    price = 500,
                    type = "money",
                    image = "male_shoes_109_11"
                },
            },
        },
        [110] = {
            drawable = 110,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_0"
                },
                [1] = {
                    label = "Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_1"
                },
                [2] = {
                    label = "Light Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_2"
                },
                [3] = {
                    label = "Ice Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_3"
                },
                [4] = {
                    label = "Chocolate Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_4"
                },
                [5] = {
                    label = "Russet Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_5"
                },
                [6] = {
                    label = "Green Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_6"
                },
                [7] = {
                    label = "Red Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_7"
                },
                [8] = {
                    label = "Orange Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_8"
                },
                [9] = {
                    label = "Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_9"
                },
                [10] = {
                    label = "Chestnut Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_10"
                },
                [11] = {
                    label = "Dark Nut Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_11"
                },
                [12] = {
                    label = "Navy Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_12"
                },
                [13] = {
                    label = "Blue Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_110_13"
                },
            },
        },
        [111] = {
            drawable = 111,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_0"
                },
                [1] = {
                    label = "Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_1"
                },
                [2] = {
                    label = "Light Gray Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_2"
                },
                [3] = {
                    label = "Ice Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_3"
                },
                [4] = {
                    label = "Chocolate Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_4"
                },
                [5] = {
                    label = "Russet Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_5"
                },
                [6] = {
                    label = "Green Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_6"
                },
                [7] = {
                    label = "Red Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_7"
                },
                [8] = {
                    label = "Orange Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_8"
                },
                [9] = {
                    label = "Tan Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_9"
                },
                [10] = {
                    label = "Chestnut Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_10"
                },
                [11] = {
                    label = "Dark Nut Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_11"
                },
                [12] = {
                    label = "Navy Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_12"
                },
                [13] = {
                    label = "Blue Loggers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_111_13"
                },
            },
        },
        [112] = {
            drawable = 112,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_0"
                },
                [1] = {
                    label = "Dark Gray Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_1"
                },
                [2] = {
                    label = "Gray Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_2"
                },
                [3] = {
                    label = "Ice Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_3"
                },
                [4] = {
                    label = "Beige Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_4"
                },
                [5] = {
                    label = "Chocolate Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_5"
                },
                [6] = {
                    label = "Burgundy Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_6"
                },
                [7] = {
                    label = "Hot Pink Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_7"
                },
                [8] = {
                    label = "Scarlet Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_8"
                },
                [9] = {
                    label = "Orange Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_9"
                },
                [10] = {
                    label = "Amber Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_10"
                },
                [11] = {
                    label = "Lemon Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_11"
                },
                [12] = {
                    label = "Royal Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_12"
                },
                [13] = {
                    label = "Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_13"
                },
                [14] = {
                    label = "Teal Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_14"
                },
                [15] = {
                    label = "Cyan Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_15"
                },
                [16] = {
                    label = "Light Blue Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_16"
                },
                [17] = {
                    label = "Lilac Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_17"
                },
                [18] = {
                    label = "Dark Green Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_18"
                },
                [19] = {
                    label = "Emerald Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_19"
                },
                [20] = {
                    label = "Moss Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_20"
                },
                [21] = {
                    label = "Lime Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_21"
                },
                [22] = {
                    label = "Peach Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_22"
                },
                [23] = {
                    label = "Lavender Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_23"
                },
                [24] = {
                    label = "Purple Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_24"
                },
                [25] = {
                    label = "Magenta Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_112_25"
                },
            },
        },
        [113] = {
            drawable = 113,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_0"
                },
                [1] = {
                    label = "Dark Gray Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_1"
                },
                [2] = {
                    label = "Gray Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_2"
                },
                [3] = {
                    label = "Ice Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_3"
                },
                [4] = {
                    label = "Beige Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_4"
                },
                [5] = {
                    label = "Chocolate Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_5"
                },
                [6] = {
                    label = "Burgundy Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_6"
                },
                [7] = {
                    label = "Hot Pink Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_7"
                },
                [8] = {
                    label = "Scarlet Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_8"
                },
                [9] = {
                    label = "Orange Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_9"
                },
                [10] = {
                    label = "Amber Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_10"
                },
                [11] = {
                    label = "Lemon Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_11"
                },
                [12] = {
                    label = "Royal Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_12"
                },
                [13] = {
                    label = "Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_13"
                },
                [14] = {
                    label = "Teal Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_14"
                },
                [15] = {
                    label = "Cyan Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_15"
                },
                [16] = {
                    label = "Light Blue Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_16"
                },
                [17] = {
                    label = "Lilac Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_17"
                },
                [18] = {
                    label = "Dark Green Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_18"
                },
                [19] = {
                    label = "Emerald Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_19"
                },
                [20] = {
                    label = "Moss Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_20"
                },
                [21] = {
                    label = "Lime Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_21"
                },
                [22] = {
                    label = "Peach Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_22"
                },
                [23] = {
                    label = "Lavender Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_23"
                },
                [24] = {
                    label = "Purple Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_24"
                },
                [25] = {
                    label = "Magenta Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_113_25"
                },
            },
        },
        [114] = {
            drawable = 114,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_0"
                },
                [1] = {
                    label = "Dark Gray Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_1"
                },
                [2] = {
                    label = "Gray Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_2"
                },
                [3] = {
                    label = "Ice Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_3"
                },
                [4] = {
                    label = "Beige Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_4"
                },
                [5] = {
                    label = "Chocolate Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_5"
                },
                [6] = {
                    label = "Burgundy Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_6"
                },
                [7] = {
                    label = "Hot Pink Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_7"
                },
                [8] = {
                    label = "Scarlet Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_8"
                },
                [9] = {
                    label = "Orange Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_9"
                },
                [10] = {
                    label = "Amber Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_10"
                },
                [11] = {
                    label = "Lemon Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_11"
                },
                [12] = {
                    label = "Royal Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_12"
                },
                [13] = {
                    label = "Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_13"
                },
                [14] = {
                    label = "Teal Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_14"
                },
                [15] = {
                    label = "Cyan Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_15"
                },
                [16] = {
                    label = "Light Blue Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_16"
                },
                [17] = {
                    label = "Lilac Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_17"
                },
                [18] = {
                    label = "Dark Green Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_18"
                },
                [19] = {
                    label = "Emerald Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_19"
                },
                [20] = {
                    label = "Moss Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_20"
                },
                [21] = {
                    label = "Lime Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_21"
                },
                [22] = {
                    label = "Peach Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_22"
                },
                [23] = {
                    label = "Lavender Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_23"
                },
                [24] = {
                    label = "Purple Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_24"
                },
                [25] = {
                    label = "Magenta Low Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_114_25"
                },
            },
        },
        [115] = {
            drawable = 115,
            type = 'component',
            textures = {
                [0] = {
                    label = "Zebra Bigness Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_0"
                },
                [1] = {
                    label = "Pink Zebra Bigness Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_1"
                },
                [2] = {
                    label = "Magenta Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_2"
                },
                [3] = {
                    label = "Cyan Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_3"
                },
                [4] = {
                    label = "Moss Leopard Güffy Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_4"
                },
                [5] = {
                    label = "Pink Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_5"
                },
                [6] = {
                    label = "Cyan Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_6"
                },
                [7] = {
                    label = "Brown Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_7"
                },
                [8] = {
                    label = "Neon Script Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_8"
                },
                [9] = {
                    label = "Camo Roses Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_9"
                },
                [10] = {
                    label = "Black Camo Roses Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_10"
                },
                [11] = {
                    label = "White Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_11"
                },
                [12] = {
                    label = "Blue Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_12"
                },
                [13] = {
                    label = "Lime Leopard Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_13"
                },
                [14] = {
                    label = "Black S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_14"
                },
                [15] = {
                    label = "Blue S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_15"
                },
                [16] = {
                    label = "Green S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_16"
                },
                [17] = {
                    label = "Light Blue S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_17"
                },
                [18] = {
                    label = "Pink S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_18"
                },
                [19] = {
                    label = "Red S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_19"
                },
                [20] = {
                    label = "White S Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_20"
                },
                [21] = {
                    label = "Black Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_21"
                },
                [22] = {
                    label = "Blue Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_22"
                },
                [23] = {
                    label = "Red Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_23"
                },
                [24] = {
                    label = "Taupe Bones Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_24"
                },
                [25] = {
                    label = "White Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_115_25"
                },
            },
        },
        [116] = {
            drawable = 116,
            type = 'component',
            textures = {
                [0] = {
                    label = "Green Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_116_0"
                },
                [1] = {
                    label = "Neon Sloped Slab Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_116_1"
                },
                [2] = {
                    label = "Blue Signs Squash Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_116_2"
                },
                [3] = {
                    label = "White Signs Squash Canvas",
                    price = 500,
                    type = "money",
                    image = "male_shoes_116_3"
                },
            },
        },
        [117] = {
            drawable = 117,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (117-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_117_0"
                },
            },
        },
        [118] = {
            drawable = 118,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (118-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_118_0"
                },
            },
        },
        [119] = {
            drawable = 119,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_0"
                },
                [1] = {
                    label = "Cyan Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_1"
                },
                [2] = {
                    label = "Magenta Enema Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_2"
                },
                [3] = {
                    label = "Green Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_3"
                },
                [4] = {
                    label = "Orange Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_4"
                },
                [5] = {
                    label = "Pink Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_5"
                },
                [6] = {
                    label = "Purple Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_6"
                },
                [7] = {
                    label = "Red Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_7"
                },
                [8] = {
                    label = "Green Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_8"
                },
                [9] = {
                    label = "Orange Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_9"
                },
                [10] = {
                    label = "Purple Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_10"
                },
                [11] = {
                    label = "Red Big Flames Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_11"
                },
                [12] = {
                    label = "Blue Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_12"
                },
                [13] = {
                    label = "Green Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_13"
                },
                [14] = {
                    label = "Orange Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_14"
                },
                [15] = {
                    label = "Purple Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_15"
                },
                [16] = {
                    label = "Pink Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_16"
                },
                [17] = {
                    label = "Blue Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_17"
                },
                [18] = {
                    label = "Green Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_18"
                },
                [19] = {
                    label = "Orange Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_19"
                },
                [20] = {
                    label = "Purple Big Lightning Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_20"
                },
                [21] = {
                    label = "Blue Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_21"
                },
                [22] = {
                    label = "White Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_22"
                },
                [23] = {
                    label = "Gray Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_23"
                },
                [24] = {
                    label = "Chocolate Marble Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_24"
                },
                [25] = {
                    label = "Black SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_119_25"
                },
            },
        },
        [120] = {
            drawable = 120,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_120_0"
                },
                [1] = {
                    label = "Pink SC Baroque Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_120_1"
                },
            },
        },
        [121] = {
            drawable = 121,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_0"
                },
                [1] = {
                    label = "Cyan Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_1"
                },
                [2] = {
                    label = "Magenta Enema Flourish Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_2"
                },
                [3] = {
                    label = "Green Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_3"
                },
                [4] = {
                    label = "Orange Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_4"
                },
                [5] = {
                    label = "Pink Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_5"
                },
                [6] = {
                    label = "Purple Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_6"
                },
                [7] = {
                    label = "Red Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_7"
                },
                [8] = {
                    label = "Green Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_8"
                },
                [9] = {
                    label = "Orange Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_9"
                },
                [10] = {
                    label = "Purple Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_10"
                },
                [11] = {
                    label = "Red Big Flames Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_11"
                },
                [12] = {
                    label = "Blue Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_12"
                },
                [13] = {
                    label = "Green Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_13"
                },
                [14] = {
                    label = "Orange Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_14"
                },
                [15] = {
                    label = "Purple Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_15"
                },
                [16] = {
                    label = "Pink Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_16"
                },
                [17] = {
                    label = "Blue Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_17"
                },
                [18] = {
                    label = "Green Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_18"
                },
                [19] = {
                    label = "Orange Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_19"
                },
                [20] = {
                    label = "Purple Big Lightning Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_20"
                },
                [21] = {
                    label = "Blue Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_21"
                },
                [22] = {
                    label = "White Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_22"
                },
                [23] = {
                    label = "Gray Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_23"
                },
                [24] = {
                    label = "Chocolate Marble Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_24"
                },
                [25] = {
                    label = "Black SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_121_25"
                },
            },
        },
        [122] = {
            drawable = 122,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_122_0"
                },
                [1] = {
                    label = "Pink SC Baroque Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_122_1"
                },
            },
        },
        [123] = {
            drawable = 123,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_0"
                },
                [1] = {
                    label = "Blue Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_1"
                },
                [2] = {
                    label = "Red Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_2"
                },
                [3] = {
                    label = "White Blagueurs Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_3"
                },
                [4] = {
                    label = "Blue DS Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_4"
                },
                [5] = {
                    label = "Blue DS Tiger Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_5"
                },
                [6] = {
                    label = "White Signs Squash Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_6"
                },
                [7] = {
                    label = "Cluckin' Bell Ugglies & Socks",
                    price = 500,
                    type = "money",
                    image = "male_shoes_123_7"
                },
            },
        },
        [124] = {
            drawable = 124,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_0"
                },
                [1] = {
                    label = "Blue Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_1"
                },
                [2] = {
                    label = "Red Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_2"
                },
                [3] = {
                    label = "White Blagueurs Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_3"
                },
                [4] = {
                    label = "Blue DS Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_4"
                },
                [5] = {
                    label = "Blue DS Tiger Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_5"
                },
                [6] = {
                    label = "White Signs Squash Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_6"
                },
                [7] = {
                    label = "Cluckin' Bell Ugglies",
                    price = 500,
                    type = "money",
                    image = "male_shoes_124_7"
                },
            },
        },
        [125] = {
            drawable = 125,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (125-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_125_0"
                },
            },
        },
        [126] = {
            drawable = 126,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_0"
                },
                [1] = {
                    label = "Dark Gray Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_1"
                },
                [2] = {
                    label = "Gray Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_2"
                },
                [3] = {
                    label = "Ice Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_3"
                },
                [4] = {
                    label = "Beige Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_4"
                },
                [5] = {
                    label = "Chocolate Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_5"
                },
                [6] = {
                    label = "Burgundy Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_6"
                },
                [7] = {
                    label = "Hot Pink Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_7"
                },
                [8] = {
                    label = "Scarlet Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_8"
                },
                [9] = {
                    label = "Orange Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_9"
                },
                [10] = {
                    label = "Amber Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_10"
                },
                [11] = {
                    label = "Lemon Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_11"
                },
                [12] = {
                    label = "Royal Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_12"
                },
                [13] = {
                    label = "Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_13"
                },
                [14] = {
                    label = "Teal Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_14"
                },
                [15] = {
                    label = "Cyan Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_15"
                },
                [16] = {
                    label = "Light Blue Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_16"
                },
                [17] = {
                    label = "Lilac Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_17"
                },
                [18] = {
                    label = "Dark Green Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_18"
                },
                [19] = {
                    label = "Emerald Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_19"
                },
                [20] = {
                    label = "Moss Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_20"
                },
                [21] = {
                    label = "Lime Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_21"
                },
                [22] = {
                    label = "Peach Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_22"
                },
                [23] = {
                    label = "Lavender Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_23"
                },
                [24] = {
                    label = "Purple Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_24"
                },
                [25] = {
                    label = "Magenta Designer Lace-Up",
                    price = 500,
                    type = "money",
                    image = "male_shoes_126_25"
                },
            },
        },
        [127] = {
            drawable = 127,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (127-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_127_0"
                },
            },
        },
        [128] = {
            drawable = 128,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (128-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_128_0"
                },
            },
        },
        [129] = {
            drawable = 129,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (129-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_129_0"
                },
            },
        },
        [130] = {
            drawable = 130,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (130-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_130_0"
                },
                [1] = {
                    label = "Shoes (130-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_130_1"
                },
            },
        },
        [131] = {
            drawable = 131,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (131-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_131_0"
                },
            },
        },
        [132] = {
            drawable = 132,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (132-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_132_0"
                },
            },
        },
        [133] = {
            drawable = 133,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (133-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_133_0"
                },
                [1] = {
                    label = "Shoes (133-1)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_133_1"
                },
            },
        },
        [134] = {
            drawable = 134,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (134-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_134_0"
                },
            },
        },
        [135] = {
            drawable = 135,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (135-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_135_0"
                },
            },
        },
        [136] = {
            drawable = 136,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (136-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_136_0"
                },
            },
        },
        [137] = {
            drawable = 137,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_0"
                },
                [1] = {
                    label = "Dark Gray Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_1"
                },
                [2] = {
                    label = "Gray Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_2"
                },
                [3] = {
                    label = "Ice Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_3"
                },
                [4] = {
                    label = "Beige Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_4"
                },
                [5] = {
                    label = "Chocolate Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_5"
                },
                [6] = {
                    label = "Burgundy Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_6"
                },
                [7] = {
                    label = "Hot Pink Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_7"
                },
                [8] = {
                    label = "Scarlet Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_8"
                },
                [9] = {
                    label = "Orange Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_9"
                },
                [10] = {
                    label = "Amber Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_10"
                },
                [11] = {
                    label = "Lemon Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_11"
                },
                [12] = {
                    label = "Royal Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_12"
                },
                [13] = {
                    label = "Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_13"
                },
                [14] = {
                    label = "Teal Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_14"
                },
                [15] = {
                    label = "Cyan Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_15"
                },
                [16] = {
                    label = "Light Blue Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_16"
                },
                [17] = {
                    label = "Lilac Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_17"
                },
                [18] = {
                    label = "Dark Green Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_18"
                },
                [19] = {
                    label = "Emerald Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_19"
                },
                [20] = {
                    label = "Moss Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_20"
                },
                [21] = {
                    label = "Lime Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_21"
                },
                [22] = {
                    label = "Peach Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_22"
                },
                [23] = {
                    label = "Lavender Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_23"
                },
                [24] = {
                    label = "Purple Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_24"
                },
                [25] = {
                    label = "Magenta Cloth Clogs",
                    price = 500,
                    type = "money",
                    image = "male_shoes_137_25"
                },
            },
        },
        [138] = {
            drawable = 138,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_0"
                },
                [1] = {
                    label = "Dark Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_1"
                },
                [2] = {
                    label = "Light Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_2"
                },
                [3] = {
                    label = "Ice Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_3"
                },
                [4] = {
                    label = "Beige Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_4"
                },
                [5] = {
                    label = "Chocolate Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_5"
                },
                [6] = {
                    label = "Fuchsia Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_6"
                },
                [7] = {
                    label = "Neon Pink Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_7"
                },
                [8] = {
                    label = "Scarlet Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_8"
                },
                [9] = {
                    label = "Orange Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_9"
                },
                [10] = {
                    label = "Amber Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_10"
                },
                [11] = {
                    label = "Lemon Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_11"
                },
                [12] = {
                    label = "Royal Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_12"
                },
                [13] = {
                    label = "Cobalt Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_13"
                },
                [14] = {
                    label = "Teal Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_14"
                },
                [15] = {
                    label = "Cyan Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_15"
                },
                [16] = {
                    label = "Light Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_16"
                },
                [17] = {
                    label = "Lilac Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_17"
                },
                [18] = {
                    label = "Dark Green Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_18"
                },
                [19] = {
                    label = "Emerald Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_19"
                },
                [20] = {
                    label = "Moss Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_20"
                },
                [21] = {
                    label = "Lime Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_21"
                },
                [22] = {
                    label = "Peach Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_22"
                },
                [23] = {
                    label = "Lavender Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_23"
                },
                [24] = {
                    label = "Purple Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_24"
                },
                [25] = {
                    label = "Magenta Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_138_25"
                },
            },
        },
        [139] = {
            drawable = 139,
            type = 'component',
            textures = {
                [0] = {
                    label = "Mono Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_0"
                },
                [1] = {
                    label = "Dark Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_1"
                },
                [2] = {
                    label = "Light Gray Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_2"
                },
                [3] = {
                    label = "Ice Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_3"
                },
                [4] = {
                    label = "Beige Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_4"
                },
                [5] = {
                    label = "Chocolate Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_5"
                },
                [6] = {
                    label = "Fuchsia Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_6"
                },
                [7] = {
                    label = "Neon Pink Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_7"
                },
                [8] = {
                    label = "Scarlet Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_8"
                },
                [9] = {
                    label = "Orange Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_9"
                },
                [10] = {
                    label = "Amber Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_10"
                },
                [11] = {
                    label = "Lemon Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_11"
                },
                [12] = {
                    label = "Royal Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_12"
                },
                [13] = {
                    label = "Cobalt Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_13"
                },
                [14] = {
                    label = "Teal Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_14"
                },
                [15] = {
                    label = "Cyan Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_15"
                },
                [16] = {
                    label = "Light Blue Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_16"
                },
                [17] = {
                    label = "Lilac Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_17"
                },
                [18] = {
                    label = "Dark Green Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_18"
                },
                [19] = {
                    label = "Emerald Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_19"
                },
                [20] = {
                    label = "Moss Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_20"
                },
                [21] = {
                    label = "Lime Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_21"
                },
                [22] = {
                    label = "Peach Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_22"
                },
                [23] = {
                    label = "Lavender Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_23"
                },
                [24] = {
                    label = "Purple Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_24"
                },
                [25] = {
                    label = "Magenta Winter Boots",
                    price = 500,
                    type = "money",
                    image = "male_shoes_139_25"
                },
            },
        },
        [140] = {
            drawable = 140,
            type = 'component',
            textures = {
                [0] = {
                    label = "Vespucci Beach Flip-Flops",
                    price = 500,
                    type = "money",
                    image = "male_shoes_140_0"
                },
            },
        },
        [141] = {
            drawable = 141,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (141-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_141_0"
                },
            },
        },
        [142] = {
            drawable = 142,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (142-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_142_0"
                },
            },
        },
        [143] = {
            drawable = 143,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (143-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_143_0"
                },
            },
        },
        [144] = {
            drawable = 144,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (144-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_144_0"
                },
            },
        },
        [145] = {
            drawable = 145,
            type = 'component',
            textures = {
                [0] = {
                    label = "Blue & Green Zebra Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_0"
                },
                [1] = {
                    label = "Black & White Zebra Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_1"
                },
                [2] = {
                    label = "Aqua Geo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_2"
                },
                [3] = {
                    label = "Gray Geo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_3"
                },
                [4] = {
                    label = "Contrast Camo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_4"
                },
                [5] = {
                    label = "Gray Camo SC Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_5"
                },
                [6] = {
                    label = "Bronze Honeycomb Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_6"
                },
                [7] = {
                    label = "Blue Honeycomb Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_7"
                },
                [8] = {
                    label = "Aqua Wave Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_8"
                },
                [9] = {
                    label = "Black Wave Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_9"
                },
                [10] = {
                    label = "Blue Check Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_10"
                },
                [11] = {
                    label = "Black Check Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_11"
                },
                [12] = {
                    label = "Aqua Pixel Camo Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_12"
                },
                [13] = {
                    label = "Black Pixel Camo Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_145_13"
                },
            },
        },
        [146] = {
            drawable = 146,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (146-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_146_0"
                },
            },
        },
        [147] = {
            drawable = 147,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (147-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_147_0"
                },
            },
        },
        [148] = {
            drawable = 148,
            type = 'component',
            textures = {
                [0] = {
                    label = "Shoes (148-0)",
                    price = 500,
                    type = "money",
                    image = "male_shoes_148_0"
                },
            },
        },
        [149] = {
            drawable = 149,
            type = 'component',
            textures = {
                [0] = {
                    label = "Black Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_0"
                },
                [1] = {
                    label = "White Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_1"
                },
                [2] = {
                    label = "Red Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_2"
                },
                [3] = {
                    label = "Light Blue Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_3"
                },
                [4] = {
                    label = "Yellow Hi Top Panic Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_4"
                },
                [5] = {
                    label = "Purple Hi Top Panic Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_5"
                },
                [6] = {
                    label = "Pink Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_6"
                },
                [7] = {
                    label = "Green Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_7"
                },
                [8] = {
                    label = "B&W Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_8"
                },
                [9] = {
                    label = "White Flame Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_9"
                },
                [10] = {
                    label = "O&G Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_10"
                },
                [11] = {
                    label = "P&W Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_11"
                },
                [12] = {
                    label = "Blue Hi Top 69 Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_149_12"
                },
            },
        },
        [150] = {
            drawable = 150,
            type = 'component',
            textures = {
                [0] = {
                    label = "Cyan Güffy Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_0"
                },
                [1] = {
                    label = "Magenta Güffy Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_1"
                },
                [2] = {
                    label = "B&Y Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_2"
                },
                [3] = {
                    label = "Pastel Retro Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_3"
                },
                [4] = {
                    label = "Abstract Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_4"
                },
                [5] = {
                    label = "Military Hi Top Sneakers",
                    price = 500,
                    type = "money",
                    image = "male_shoes_150_5"
                },
            },
        },
    },
}
