watch = {

    female = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (0-0)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_0"
                },
                [1] = {
                    label = "Watch (0-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_1"
                },
                [2] = {
                    label = "Watch (0-2)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_2"
                },
                [3] = {
                    label = "Watch (0-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_3"
                },
                [4] = {
                    label = "Watch (0-4)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_4"
                },
                [5] = {
                    label = "Watch (0-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_0_5"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (1-0)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_0"
                },
                [1] = {
                    label = "Watch (1-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_1"
                },
                [2] = {
                    label = "Watch (1-2)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_2"
                },
                [3] = {
                    label = "Watch (1-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_3"
                },
                [4] = {
                    label = "Watch (1-4)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_4"
                },
                [5] = {
                    label = "Watch (1-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_1_5"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Fashion",
                    price = 500,
                    type = "money",
                    image = "female_watch_2_0"
                },
                [1] = {
                    label = "Silver Fashion",
                    price = 500,
                    type = "money",
                    image = "female_watch_2_1"
                },
                [2] = {
                    label = "Copper Fashion",
                    price = 500,
                    type = "money",
                    image = "female_watch_2_2"
                },
                [3] = {
                    label = "Black Fashion",
                    price = 500,
                    type = "money",
                    image = "female_watch_2_3"
                },
                [4] = {
                    label = "Watch (2-4)",
                    price = 500,
                    type = "money",
                    image = "female_watch_2_4"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold CaCa Di Lusso",
                    price = 500,
                    type = "money",
                    image = "female_watch_3_0"
                },
                [1] = {
                    label = "Silver CaCa Di Lusso",
                    price = 500,
                    type = "money",
                    image = "female_watch_3_1"
                },
                [2] = {
                    label = "Pink Gold CaCa Di Lusso",
                    price = 500,
                    type = "money",
                    image = "female_watch_3_2"
                },
                [3] = {
                    label = "Watch (3-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_3_3"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Didier Sachs Mignon",
                    price = 500,
                    type = "money",
                    image = "female_watch_4_0"
                },
                [1] = {
                    label = "Pink Gold Didier Sachs Mignon",
                    price = 500,
                    type = "money",
                    image = "female_watch_4_1"
                },
                [2] = {
                    label = "Gold Didier Sachs Mignon",
                    price = 500,
                    type = "money",
                    image = "female_watch_4_2"
                },
                [3] = {
                    label = "Watch (4-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_4_3"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold iFruit Link",
                    price = 500,
                    type = "money",
                    image = "female_watch_5_0"
                },
                [1] = {
                    label = "Silver iFruit Link",
                    price = 500,
                    type = "money",
                    image = "female_watch_5_1"
                },
                [2] = {
                    label = "Pink Gold iFruit Link",
                    price = 500,
                    type = "money",
                    image = "female_watch_5_2"
                },
                [3] = {
                    label = "Watch (5-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_5_3"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "White iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "female_watch_6_0"
                },
                [1] = {
                    label = "Pink iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "female_watch_6_1"
                },
                [2] = {
                    label = "PRB iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "female_watch_6_2"
                },
                [3] = {
                    label = "Watch (6-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_6_3"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Le Chien Marquise",
                    price = 500,
                    type = "money",
                    image = "female_watch_7_0"
                },
                [1] = {
                    label = "Silver Le Chien Marquise",
                    price = 500,
                    type = "money",
                    image = "female_watch_7_1"
                },
                [2] = {
                    label = "Pink Gold Le Chien Marquise",
                    price = 500,
                    type = "money",
                    image = "female_watch_7_2"
                },
                [3] = {
                    label = "Watch (7-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_7_3"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gray Fufu Jeunesse",
                    price = 500,
                    type = "money",
                    image = "female_watch_8_0"
                },
                [1] = {
                    label = "Black Fufu Jeunesse",
                    price = 500,
                    type = "money",
                    image = "female_watch_8_1"
                },
                [2] = {
                    label = "Blue Fufu Jeunesse",
                    price = 500,
                    type = "money",
                    image = "female_watch_8_2"
                },
                [3] = {
                    label = "Watch (8-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_8_3"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Anna Rex Prestige",
                    price = 500,
                    type = "money",
                    image = "female_watch_9_0"
                },
                [1] = {
                    label = "Gold Anna Rex Prestige",
                    price = 500,
                    type = "money",
                    image = "female_watch_9_1"
                },
                [2] = {
                    label = "Carbon Anna Rex Prestige",
                    price = 500,
                    type = "money",
                    image = "female_watch_9_2"
                },
                [3] = {
                    label = "Watch (9-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_9_3"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Lime iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "female_watch_10_0"
                },
                [1] = {
                    label = "White iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "female_watch_10_1"
                },
                [2] = {
                    label = "Neon iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "female_watch_10_2"
                },
                [3] = {
                    label = "Watch (10-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_10_3"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Light Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_11_0"
                },
                [1] = {
                    label = "Watch (11-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_11_1"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chunky Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_12_0"
                },
                [1] = {
                    label = "Watch (12-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_12_1"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Square Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_13_0"
                },
                [1] = {
                    label = "Watch (13-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_13_1"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_14_0"
                },
                [1] = {
                    label = "Watch (14-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_14_1"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tread Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_15_0"
                },
                [1] = {
                    label = "Watch (15-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_15_1"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gear Wrist Chains (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_16_0"
                },
                [1] = {
                    label = "Watch (16-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_16_1"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_17_0"
                },
                [1] = {
                    label = "Watch (17-1)",
                    price = 500,
                    type = "money",
                    image = "female_watch_17_1"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_18_0"
                },
                [1] = {
                    label = "Chocolate Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_18_1"
                },
                [2] = {
                    label = "Tan Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_18_2"
                },
                [3] = {
                    label = "Ox Blood Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_18_3"
                },
                [4] = {
                    label = "Watch (18-4)",
                    price = 500,
                    type = "money",
                    image = "female_watch_18_4"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_0"
                },
                [1] = {
                    label = "Silver Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_1"
                },
                [2] = {
                    label = "Black Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_2"
                },
                [3] = {
                    label = "Deck Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_3"
                },
                [4] = {
                    label = "Royal Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_4"
                },
                [5] = {
                    label = "Roulette Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_5"
                },
                [6] = {
                    label = "Watch (19-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_19_6"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_0"
                },
                [1] = {
                    label = "Silver Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_1"
                },
                [2] = {
                    label = "Black Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_2"
                },
                [3] = {
                    label = "Gold Fifty Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_3"
                },
                [4] = {
                    label = "Gold Roulette Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_4"
                },
                [5] = {
                    label = "Baroque Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_5"
                },
                [6] = {
                    label = "Watch (20-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_20_6"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_0"
                },
                [1] = {
                    label = "Silver Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_1"
                },
                [2] = {
                    label = "Black Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_2"
                },
                [3] = {
                    label = "Silver Fifty Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_3"
                },
                [4] = {
                    label = "Silver Roulette Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_4"
                },
                [5] = {
                    label = "Spade Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_5"
                },
                [6] = {
                    label = "Red Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_6"
                },
                [7] = {
                    label = "Green Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_7"
                },
                [8] = {
                    label = "Blue Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_8"
                },
                [9] = {
                    label = "Black Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_9"
                },
                [10] = {
                    label = "Watch (21-10)",
                    price = 500,
                    type = "money",
                    image = "female_watch_21_10"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_0"
                },
                [1] = {
                    label = "Silver Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_1"
                },
                [2] = {
                    label = "Black Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_2"
                },
                [3] = {
                    label = "Gold Fifty Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_3"
                },
                [4] = {
                    label = "Tan Spade Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_4"
                },
                [5] = {
                    label = "Brown Spade Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_5"
                },
                [6] = {
                    label = "Watch (22-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_22_6"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_0"
                },
                [1] = {
                    label = "Silver Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_1"
                },
                [2] = {
                    label = "Black Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_2"
                },
                [3] = {
                    label = "Spade Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_3"
                },
                [4] = {
                    label = "Mixed Metals Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_4"
                },
                [5] = {
                    label = "Roulette Ceaseless",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_5"
                },
                [6] = {
                    label = "Watch (23-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_23_6"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_0"
                },
                [1] = {
                    label = "Gold Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_1"
                },
                [2] = {
                    label = "Black Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_2"
                },
                [3] = {
                    label = "Wheel Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_3"
                },
                [4] = {
                    label = "Suits Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_4"
                },
                [5] = {
                    label = "Roulette Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_5"
                },
                [6] = {
                    label = "Watch (24-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_24_6"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_0"
                },
                [1] = {
                    label = "Silver Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_1"
                },
                [2] = {
                    label = "Black Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_2"
                },
                [3] = {
                    label = "Roulette Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_3"
                },
                [4] = {
                    label = "Fifty Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_4"
                },
                [5] = {
                    label = "Suits Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_5"
                },
                [6] = {
                    label = "Watch (25-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_25_6"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_0"
                },
                [1] = {
                    label = "Gold Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_1"
                },
                [2] = {
                    label = "Black Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_2"
                },
                [3] = {
                    label = "Spade Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_3"
                },
                [4] = {
                    label = "Royalty Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_4"
                },
                [5] = {
                    label = "Dice Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_5"
                },
                [6] = {
                    label = "Watch (26-6)",
                    price = 500,
                    type = "money",
                    image = "female_watch_26_6"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "female_watch_27_0"
                },
                [1] = {
                    label = "Gold SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "female_watch_27_1"
                },
                [2] = {
                    label = "Black SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "female_watch_27_2"
                },
                [3] = {
                    label = "Watch (27-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_27_3"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_28_0"
                },
                [1] = {
                    label = "Gold SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_28_1"
                },
                [2] = {
                    label = "Black SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_28_2"
                },
                [3] = {
                    label = "Watch (28-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_28_3"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_0"
                },
                [1] = {
                    label = "Red Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_1"
                },
                [2] = {
                    label = "Pink Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_2"
                },
                [3] = {
                    label = "Yellow Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_3"
                },
                [4] = {
                    label = "Orange Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_4"
                },
                [5] = {
                    label = "Green Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_5"
                },
                [6] = {
                    label = "Red & Blue Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_6"
                },
                [7] = {
                    label = "Yellow & Orange Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_7"
                },
                [8] = {
                    label = "Green & Pink Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_8"
                },
                [9] = {
                    label = "Rainbow Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_9"
                },
                [10] = {
                    label = "Sunset Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_10"
                },
                [11] = {
                    label = "Tropical Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_11"
                },
                [12] = {
                    label = "Watch (29-12)",
                    price = 500,
                    type = "money",
                    image = "female_watch_29_12"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_30_0"
                },
                [1] = {
                    label = "Silver Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_30_1"
                },
                [2] = {
                    label = "Rose Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_30_2"
                },
                [3] = {
                    label = "Watch (30-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_30_3"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_31_0"
                },
                [1] = {
                    label = "Silver Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_31_1"
                },
                [2] = {
                    label = "Rose Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_31_2"
                },
                [3] = {
                    label = "Watch (31-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_31_3"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_32_0"
                },
                [1] = {
                    label = "Silver Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_32_1"
                },
                [2] = {
                    label = "Rose Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_32_2"
                },
                [3] = {
                    label = "Watch (32-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_32_3"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "female_watch_33_0"
                },
                [1] = {
                    label = "Silver Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "female_watch_33_1"
                },
                [2] = {
                    label = "Rose Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "female_watch_33_2"
                },
                [3] = {
                    label = "Watch (33-3)",
                    price = 500,
                    type = "money",
                    image = "female_watch_33_3"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_0"
                },
                [1] = {
                    label = "Mono Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_1"
                },
                [2] = {
                    label = "Gold Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_2"
                },
                [3] = {
                    label = "Rose Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_3"
                },
                [4] = {
                    label = "Copper Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_4"
                },
                [5] = {
                    label = "Watch (34-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_34_5"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Ox Blood Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_0"
                },
                [1] = {
                    label = "Green Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_1"
                },
                [2] = {
                    label = "Tan Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_2"
                },
                [3] = {
                    label = "Blush Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_3"
                },
                [4] = {
                    label = "Dark Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_4"
                },
                [5] = {
                    label = "Watch (35-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_35_5"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Thick Silver Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_0"
                },
                [1] = {
                    label = "Thick Dark Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_1"
                },
                [2] = {
                    label = "Thick Gold Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_2"
                },
                [3] = {
                    label = "Thick Rose Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_3"
                },
                [4] = {
                    label = "Thick Bronze Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_4"
                },
                [5] = {
                    label = "Watch (36-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_36_5"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_0"
                },
                [1] = {
                    label = "Dark Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_1"
                },
                [2] = {
                    label = "Gold Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_2"
                },
                [3] = {
                    label = "Rose Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_3"
                },
                [4] = {
                    label = "Bronze Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_4"
                },
                [5] = {
                    label = "Watch (37-5)",
                    price = 500,
                    type = "money",
                    image = "female_watch_37_5"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (38-0)",
                    price = 500,
                    type = "money",
                    image = "female_watch_38_0"
                },
            },
        },
    },
    male = {
        [0] = {
            drawable = 0,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (0-0)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_0"
                },
                [1] = {
                    label = "Watch (0-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_1"
                },
                [2] = {
                    label = "Watch (0-2)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_2"
                },
                [3] = {
                    label = "Watch (0-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_3"
                },
                [4] = {
                    label = "Watch (0-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_4"
                },
                [5] = {
                    label = "Watch (0-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_0_5"
                },
            },
        },
        [1] = {
            drawable = 1,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (1-0)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_0"
                },
                [1] = {
                    label = "Watch (1-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_1"
                },
                [2] = {
                    label = "Watch (1-2)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_2"
                },
                [3] = {
                    label = "Watch (1-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_3"
                },
                [4] = {
                    label = "Watch (1-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_4"
                },
                [5] = {
                    label = "Watch (1-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_1_5"
                },
            },
        },
        [2] = {
            drawable = 2,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (2-0)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_0"
                },
                [1] = {
                    label = "Watch (2-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_1"
                },
                [2] = {
                    label = "Watch (2-2)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_2"
                },
                [3] = {
                    label = "Watch (2-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_3"
                },
                [4] = {
                    label = "Watch (2-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_4"
                },
                [5] = {
                    label = "Watch (2-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_2_5"
                },
            },
        },
        [3] = {
            drawable = 3,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pendulus Sport Black Sports",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_0"
                },
                [1] = {
                    label = "Pfister Design Red Sports",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_1"
                },
                [2] = {
                    label = "White Sports",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_2"
                },
                [3] = {
                    label = "Yellow Sports",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_3"
                },
                [4] = {
                    label = "Blue Sports",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_4"
                },
                [5] = {
                    label = "Watch (3-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_3_5"
                },
            },
        },
        [4] = {
            drawable = 4,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_4_0"
                },
                [1] = {
                    label = "Silver Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_4_1"
                },
                [2] = {
                    label = "Black Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_4_2"
                },
                [3] = {
                    label = "White Gold Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_4_3"
                },
                [4] = {
                    label = "Watch (4-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_4_4"
                },
            },
        },
        [5] = {
            drawable = 5,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red LED, White Strap",
                    price = 500,
                    type = "money",
                    image = "male_watch_5_0"
                },
                [1] = {
                    label = "Red LED, Brown Strap",
                    price = 500,
                    type = "money",
                    image = "male_watch_5_1"
                },
                [2] = {
                    label = "White LED, Gold Strap",
                    price = 500,
                    type = "money",
                    image = "male_watch_5_2"
                },
                [3] = {
                    label = "Yellow LED, Yellow Strap",
                    price = 500,
                    type = "money",
                    image = "male_watch_5_3"
                },
                [4] = {
                    label = "Watch (5-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_5_4"
                },
            },
        },
        [6] = {
            drawable = 6,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Gold Kronos Quantum",
                    price = 500,
                    type = "money",
                    image = "male_watch_6_0"
                },
                [1] = {
                    label = "Silver Kronos Quantum",
                    price = 500,
                    type = "money",
                    image = "male_watch_6_1"
                },
                [2] = {
                    label = "Carbon Kronos Quantum",
                    price = 500,
                    type = "money",
                    image = "male_watch_6_2"
                },
                [3] = {
                    label = "Watch (6-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_6_3"
                },
            },
        },
        [7] = {
            drawable = 7,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Gaulle Retro Hex",
                    price = 500,
                    type = "money",
                    image = "male_watch_7_0"
                },
                [1] = {
                    label = "Carbon Gaulle Retro Hex",
                    price = 500,
                    type = "money",
                    image = "male_watch_7_1"
                },
                [2] = {
                    label = "Gold Gaulle Retro Hex",
                    price = 500,
                    type = "money",
                    image = "male_watch_7_2"
                },
                [3] = {
                    label = "Watch (7-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_7_3"
                },
            },
        },
        [8] = {
            drawable = 8,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Covgari Supernova",
                    price = 500,
                    type = "money",
                    image = "male_watch_8_0"
                },
                [1] = {
                    label = "Carbon Covgari Supernova",
                    price = 500,
                    type = "money",
                    image = "male_watch_8_1"
                },
                [2] = {
                    label = "Pink Gold Covgari Supernova",
                    price = 500,
                    type = "money",
                    image = "male_watch_8_2"
                },
                [3] = {
                    label = "Watch (8-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_8_3"
                },
            },
        },
        [9] = {
            drawable = 9,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Platinum Pendulus Galaxis",
                    price = 500,
                    type = "money",
                    image = "male_watch_9_0"
                },
                [1] = {
                    label = "Carbon Pendulus Galaxis",
                    price = 500,
                    type = "money",
                    image = "male_watch_9_1"
                },
                [2] = {
                    label = "Gold Pendulus Galaxis",
                    price = 500,
                    type = "money",
                    image = "male_watch_9_2"
                },
                [3] = {
                    label = "Watch (9-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_9_3"
                },
            },
        },
        [10] = {
            drawable = 10,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Crowex Chromosphere",
                    price = 500,
                    type = "money",
                    image = "male_watch_10_0"
                },
                [1] = {
                    label = "Gold Crowex Chromosphere",
                    price = 500,
                    type = "money",
                    image = "male_watch_10_1"
                },
                [2] = {
                    label = "Carbon Crowex Chromosphere",
                    price = 500,
                    type = "money",
                    image = "male_watch_10_2"
                },
                [3] = {
                    label = "Watch (10-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_10_3"
                },
            },
        },
        [11] = {
            drawable = 11,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Pink Gold Vangelico Geomeister",
                    price = 500,
                    type = "money",
                    image = "male_watch_11_0"
                },
                [1] = {
                    label = "Silver Vangelico Geomeister",
                    price = 500,
                    type = "money",
                    image = "male_watch_11_1"
                },
                [2] = {
                    label = "Gold Vangelico Geomeister",
                    price = 500,
                    type = "money",
                    image = "male_watch_11_2"
                },
                [3] = {
                    label = "Watch (11-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_11_3"
                },
            },
        },
        [12] = {
            drawable = 12,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold iFruit Link",
                    price = 500,
                    type = "money",
                    image = "male_watch_12_0"
                },
                [1] = {
                    label = "Silver iFruit Link",
                    price = 500,
                    type = "money",
                    image = "male_watch_12_1"
                },
                [2] = {
                    label = "Pink Gold iFruit Link",
                    price = 500,
                    type = "money",
                    image = "male_watch_12_2"
                },
                [3] = {
                    label = "Watch (12-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_12_3"
                },
            },
        },
        [13] = {
            drawable = 13,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Carbon iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "male_watch_13_0"
                },
                [1] = {
                    label = "Lime iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "male_watch_13_1"
                },
                [2] = {
                    label = "PRB iFruit Tech",
                    price = 500,
                    type = "money",
                    image = "male_watch_13_2"
                },
                [3] = {
                    label = "Watch (13-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_13_3"
                },
            },
        },
        [14] = {
            drawable = 14,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Covgari Explorer",
                    price = 500,
                    type = "money",
                    image = "male_watch_14_0"
                },
                [1] = {
                    label = "Pink Gold Covgari Explorer",
                    price = 500,
                    type = "money",
                    image = "male_watch_14_1"
                },
                [2] = {
                    label = "Gold Covgari Explorer",
                    price = 500,
                    type = "money",
                    image = "male_watch_14_2"
                },
                [3] = {
                    label = "Watch (14-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_14_3"
                },
            },
        },
        [15] = {
            drawable = 15,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Pendulus Gravity",
                    price = 500,
                    type = "money",
                    image = "male_watch_15_0"
                },
                [1] = {
                    label = "Gold Pendulus Gravity",
                    price = 500,
                    type = "money",
                    image = "male_watch_15_1"
                },
                [2] = {
                    label = "Platinum Pendulus Gravity",
                    price = 500,
                    type = "money",
                    image = "male_watch_15_2"
                },
                [3] = {
                    label = "Watch (15-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_15_3"
                },
            },
        },
        [16] = {
            drawable = 16,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Covgari Universe",
                    price = 500,
                    type = "money",
                    image = "male_watch_16_0"
                },
                [1] = {
                    label = "Silver Covgari Universe",
                    price = 500,
                    type = "money",
                    image = "male_watch_16_1"
                },
                [2] = {
                    label = "Steel Covgari Universe",
                    price = 500,
                    type = "money",
                    image = "male_watch_16_2"
                },
                [3] = {
                    label = "Watch (16-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_16_3"
                },
            },
        },
        [17] = {
            drawable = 17,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Copper Gaulle Destiny",
                    price = 500,
                    type = "money",
                    image = "male_watch_17_0"
                },
                [1] = {
                    label = "Vintage Gaulle Destiny",
                    price = 500,
                    type = "money",
                    image = "male_watch_17_1"
                },
                [2] = {
                    label = "Silver Gaulle Destiny",
                    price = 500,
                    type = "money",
                    image = "male_watch_17_2"
                },
                [3] = {
                    label = "Watch (17-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_17_3"
                },
            },
        },
        [18] = {
            drawable = 18,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Carbon Medici Radial",
                    price = 500,
                    type = "money",
                    image = "male_watch_18_0"
                },
                [1] = {
                    label = "Silver Medici Radial",
                    price = 500,
                    type = "money",
                    image = "male_watch_18_1"
                },
                [2] = {
                    label = "Steel Medici Radial",
                    price = 500,
                    type = "money",
                    image = "male_watch_18_2"
                },
                [3] = {
                    label = "Watch (18-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_18_3"
                },
            },
        },
        [19] = {
            drawable = 19,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Pendulus Timestar",
                    price = 500,
                    type = "money",
                    image = "male_watch_19_0"
                },
                [1] = {
                    label = "Gold Pendulus Timestar",
                    price = 500,
                    type = "money",
                    image = "male_watch_19_1"
                },
                [2] = {
                    label = "Carbon Pendulus Timestar",
                    price = 500,
                    type = "money",
                    image = "male_watch_19_2"
                },
                [3] = {
                    label = "Watch (19-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_19_3"
                },
            },
        },
        [20] = {
            drawable = 20,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Carbon Kronos Submariner",
                    price = 500,
                    type = "money",
                    image = "male_watch_20_0"
                },
                [1] = {
                    label = "Red Kronos Submariner",
                    price = 500,
                    type = "money",
                    image = "male_watch_20_1"
                },
                [2] = {
                    label = "Yellow Kronos Submariner",
                    price = 500,
                    type = "money",
                    image = "male_watch_20_2"
                },
                [3] = {
                    label = "Watch (20-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_20_3"
                },
            },
        },
        [21] = {
            drawable = 21,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Red iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "male_watch_21_0"
                },
                [1] = {
                    label = "Blue iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "male_watch_21_1"
                },
                [2] = {
                    label = "Mint iFruit Snap",
                    price = 500,
                    type = "money",
                    image = "male_watch_21_2"
                },
                [3] = {
                    label = "Watch (21-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_21_3"
                },
            },
        },
        [22] = {
            drawable = 22,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Light Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_22_0"
                },
                [1] = {
                    label = "Watch (22-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_22_1"
                },
            },
        },
        [23] = {
            drawable = 23,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Chunky Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_23_0"
                },
                [1] = {
                    label = "Watch (23-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_23_1"
                },
            },
        },
        [24] = {
            drawable = 24,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Square Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_24_0"
                },
                [1] = {
                    label = "Watch (24-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_24_1"
                },
            },
        },
        [25] = {
            drawable = 25,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Skull Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_25_0"
                },
                [1] = {
                    label = "Watch (25-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_25_1"
                },
            },
        },
        [26] = {
            drawable = 26,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Tread Wrist Chain (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_26_0"
                },
                [1] = {
                    label = "Watch (26-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_26_1"
                },
            },
        },
        [27] = {
            drawable = 27,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gear Wrist Chains (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_27_0"
                },
                [1] = {
                    label = "Watch (27-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_27_1"
                },
            },
        },
        [28] = {
            drawable = 28,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Spiked Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_28_0"
                },
                [1] = {
                    label = "Watch (28-1)",
                    price = 500,
                    type = "money",
                    image = "male_watch_28_1"
                },
            },
        },
        [29] = {
            drawable = 29,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Black Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_29_0"
                },
                [1] = {
                    label = "Chocolate Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_29_1"
                },
                [2] = {
                    label = "Tan Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_29_2"
                },
                [3] = {
                    label = "Ox Blood Gauntlet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_29_3"
                },
                [4] = {
                    label = "Watch (29-4)",
                    price = 500,
                    type = "money",
                    image = "male_watch_29_4"
                },
            },
        },
        [30] = {
            drawable = 30,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_0"
                },
                [1] = {
                    label = "Silver Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_1"
                },
                [2] = {
                    label = "Black Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_2"
                },
                [3] = {
                    label = "Deck Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_3"
                },
                [4] = {
                    label = "Royal Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_4"
                },
                [5] = {
                    label = "Roulette Enduring Watch",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_5"
                },
                [6] = {
                    label = "Watch (30-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_30_6"
                },
            },
        },
        [31] = {
            drawable = 31,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_0"
                },
                [1] = {
                    label = "Silver Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_1"
                },
                [2] = {
                    label = "Black Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_2"
                },
                [3] = {
                    label = "Gold Fifty Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_3"
                },
                [4] = {
                    label = "Gold Roulette Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_4"
                },
                [5] = {
                    label = "Baroque Kronos Tempo",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_5"
                },
                [6] = {
                    label = "Watch (31-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_31_6"
                },
            },
        },
        [32] = {
            drawable = 32,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_0"
                },
                [1] = {
                    label = "Silver Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_1"
                },
                [2] = {
                    label = "Black Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_2"
                },
                [3] = {
                    label = "Silver Fifty Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_3"
                },
                [4] = {
                    label = "Silver Roulette Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_4"
                },
                [5] = {
                    label = "Spade Kronos Pulse",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_5"
                },
                [6] = {
                    label = "Red Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_6"
                },
                [7] = {
                    label = "Green Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_7"
                },
                [8] = {
                    label = "Blue Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_8"
                },
                [9] = {
                    label = "Black Fame or Shame Kronos",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_9"
                },
                [10] = {
                    label = "Watch (32-10)",
                    price = 500,
                    type = "money",
                    image = "male_watch_32_10"
                },
            },
        },
        [33] = {
            drawable = 33,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_0"
                },
                [1] = {
                    label = "Silver Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_1"
                },
                [2] = {
                    label = "Black Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_2"
                },
                [3] = {
                    label = "Gold Fifty Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_3"
                },
                [4] = {
                    label = "Tan Spade Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_4"
                },
                [5] = {
                    label = "Brown Spade Kronos Ära",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_5"
                },
                [6] = {
                    label = "Watch (33-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_33_6"
                },
            },
        },
        [34] = {
            drawable = 34,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_0"
                },
                [1] = {
                    label = "Silver Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_1"
                },
                [2] = {
                    label = "Black Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_2"
                },
                [3] = {
                    label = "Spade Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_3"
                },
                [4] = {
                    label = "Mixed Metals Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_4"
                },
                [5] = {
                    label = "Roulette Ceaseless",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_5"
                },
                [6] = {
                    label = "Watch (34-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_34_6"
                },
            },
        },
        [35] = {
            drawable = 35,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_0"
                },
                [1] = {
                    label = "Gold Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_1"
                },
                [2] = {
                    label = "Black Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_2"
                },
                [3] = {
                    label = "Wheel Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_3"
                },
                [4] = {
                    label = "Suits Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_4"
                },
                [5] = {
                    label = "Roulette Crowex Époque",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_5"
                },
                [6] = {
                    label = "Watch (35-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_35_6"
                },
            },
        },
        [36] = {
            drawable = 36,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_0"
                },
                [1] = {
                    label = "Silver Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_1"
                },
                [2] = {
                    label = "Black Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_2"
                },
                [3] = {
                    label = "Roulette Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_3"
                },
                [4] = {
                    label = "Fifty Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_4"
                },
                [5] = {
                    label = "Suits Kronos Quad",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_5"
                },
                [6] = {
                    label = "Watch (36-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_36_6"
                },
            },
        },
        [37] = {
            drawable = 37,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_0"
                },
                [1] = {
                    label = "Gold Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_1"
                },
                [2] = {
                    label = "Black Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_2"
                },
                [3] = {
                    label = "Spade Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_3"
                },
                [4] = {
                    label = "Royalty Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_4"
                },
                [5] = {
                    label = "Dice Crowex Rond",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_5"
                },
                [6] = {
                    label = "Watch (37-6)",
                    price = 500,
                    type = "money",
                    image = "male_watch_37_6"
                },
            },
        },
        [38] = {
            drawable = 38,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "male_watch_38_0"
                },
                [1] = {
                    label = "Gold SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "male_watch_38_1"
                },
                [2] = {
                    label = "Black SASS Wrist Piece",
                    price = 500,
                    type = "money",
                    image = "male_watch_38_2"
                },
                [3] = {
                    label = "Watch (38-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_38_3"
                },
            },
        },
        [39] = {
            drawable = 39,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_39_0"
                },
                [1] = {
                    label = "Gold SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_39_1"
                },
                [2] = {
                    label = "Black SASS Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_39_2"
                },
                [3] = {
                    label = "Watch (39-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_39_3"
                },
            },
        },
        [40] = {
            drawable = 40,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Blue Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_0"
                },
                [1] = {
                    label = "Red Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_1"
                },
                [2] = {
                    label = "Pink Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_2"
                },
                [3] = {
                    label = "Yellow Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_3"
                },
                [4] = {
                    label = "Orange Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_4"
                },
                [5] = {
                    label = "Green Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_5"
                },
                [6] = {
                    label = "Red & Blue Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_6"
                },
                [7] = {
                    label = "Yellow & Orange Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_7"
                },
                [8] = {
                    label = "Green & Pink Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_8"
                },
                [9] = {
                    label = "Rainbow Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_9"
                },
                [10] = {
                    label = "Sunset Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_10"
                },
                [11] = {
                    label = "Tropical Bangles (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_11"
                },
                [12] = {
                    label = "Watch (40-12)",
                    price = 500,
                    type = "money",
                    image = "male_watch_40_12"
                },
            },
        },
        [41] = {
            drawable = 41,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_41_0"
                },
                [1] = {
                    label = "Silver Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_41_1"
                },
                [2] = {
                    label = "Rose Encrusted Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_41_2"
                },
                [3] = {
                    label = "Watch (41-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_41_3"
                },
            },
        },
        [42] = {
            drawable = 42,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_42_0"
                },
                [1] = {
                    label = "Silver Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_42_1"
                },
                [2] = {
                    label = "Rose Ursine Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_42_2"
                },
                [3] = {
                    label = "Watch (42-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_42_3"
                },
            },
        },
        [43] = {
            drawable = 43,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_43_0"
                },
                [1] = {
                    label = "Silver Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_43_1"
                },
                [2] = {
                    label = "Rose Round Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_43_2"
                },
                [3] = {
                    label = "Watch (43-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_43_3"
                },
            },
        },
        [44] = {
            drawable = 44,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Gold Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "male_watch_44_0"
                },
                [1] = {
                    label = "Silver Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "male_watch_44_1"
                },
                [2] = {
                    label = "Rose Square Jewel Chain",
                    price = 500,
                    type = "money",
                    image = "male_watch_44_2"
                },
                [3] = {
                    label = "Watch (44-3)",
                    price = 500,
                    type = "money",
                    image = "male_watch_44_3"
                },
            },
        },
        [45] = {
            drawable = 45,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_0"
                },
                [1] = {
                    label = "Mono Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_1"
                },
                [2] = {
                    label = "Gold Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_2"
                },
                [3] = {
                    label = "Rose Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_3"
                },
                [4] = {
                    label = "Copper Beaded Bracelet",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_4"
                },
                [5] = {
                    label = "Watch (45-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_45_5"
                },
            },
        },
        [46] = {
            drawable = 46,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Ox Blood Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_0"
                },
                [1] = {
                    label = "Green Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_1"
                },
                [2] = {
                    label = "Tan Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_2"
                },
                [3] = {
                    label = "Blush Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_3"
                },
                [4] = {
                    label = "Dark Bracelet Ensemble",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_4"
                },
                [5] = {
                    label = "Watch (46-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_46_5"
                },
            },
        },
        [47] = {
            drawable = 47,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Thick Silver Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_0"
                },
                [1] = {
                    label = "Thick Dark Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_1"
                },
                [2] = {
                    label = "Thick Gold Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_2"
                },
                [3] = {
                    label = "Thick Rose Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_3"
                },
                [4] = {
                    label = "Thick Bronze Chain Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_4"
                },
                [5] = {
                    label = "Watch (47-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_47_5"
                },
            },
        },
        [48] = {
            drawable = 48,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Silver Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_0"
                },
                [1] = {
                    label = "Dark Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_1"
                },
                [2] = {
                    label = "Gold Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_2"
                },
                [3] = {
                    label = "Rose Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_3"
                },
                [4] = {
                    label = "Bronze Bangle Cuff Bracelet (L)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_4"
                },
                [5] = {
                    label = "Watch (48-5)",
                    price = 500,
                    type = "money",
                    image = "male_watch_48_5"
                },
            },
        },
        [49] = {
            drawable = 49,
            type = 'prop',
            textures = {
                [0] = {
                    label = "Watch (49-0)",
                    price = 500,
                    type = "money",
                    image = "male_watch_49_0"
                },
            },
        },
    },
}
