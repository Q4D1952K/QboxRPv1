fx_version "cerulean"
description "Rep Base"
author "Q4D"
version '1.0.0'
lua54 'yes'
game 'gta5'
client_scripts {'client/*.lua'}
server_scripts {'@oxmysql/lib/MySQL.lua', 'server/*.lua'}
shared_scripts { '@ox_lib/init.lua', 'clothingdata/*.lua', 'config.lua'}