local path = GetResourcePath('rep-base')
local itemsPath = path:gsub('//', '/')..'/clothingdata/'
local itemData = {}

lib.callback.register('rep-base/callback/saveImage', function (source, _type, gender, id, _mau, _label)
    local p = promise.new()
    exports['screenshot-basic']:requestClientScreenshot(source, {
        fileName = ('clothes/%s/%s.png'):format(_type, gender.."_".._type.."_"..id.."_".._mau),
        encoding = 'png',
        quality = 1.0,
        crop = {
            offsetX = 0,
            offsetY = 0,
            width   = 1000,
            height  = 1000
        }
    }, function(err, data)
        print(data, _label)
        p:resolve(data)
    end)
    return Citizen.Await(p)
end)

RegisterNetEvent('rep-base:server:addClothing', function (_type, gender, id, _mau, _label)
    if not itemData[_type] then
        itemData[_type] = {}
    end
    if not itemData[_type][gender] then
        itemData[_type][gender] = {}
    end
    if not itemData[_type][gender][id] then
        itemData[_type][gender][id] = {}
    end
    itemData[_type][gender][id][_mau] = _label
    print(_type, id, _mau,_label)
end)

RegisterNetEvent('rep-base/server/saveClothingData', function (_index)
    local text = "\n"-- _index.." = { \n"
    for _i, _v in pairs(itemData[_index]) do
        if _i == 'male' then
            text = text.." male = { \n"
            for _index2 = 0, #itemData[_index][_i] , 1 do
                text = text.."  [".._index2.."] = { \n"
                    text = text.."  drawable = ".._index2..", \n"
                    if _index == 'mask' or _index == 'jacket' or _index == 'gloves' or _index == 'shirt' or _index == 'neck' or _index == 'shoes' or _index == 'pant' or _index == 'backpack' then
                        text = text.."  type = 'component', \n"
                        if _index == 'gloves' or _index == 'jacket' then
                            text = text.."  arm = 1, \n"
                        end
                    else
                        text = text.."  type = 'prop', \n"
                    end
                    text = text.."  textures = { \n"
                        for _index3 = 0, #itemData[_index][_i][_index2] , 1 do
                            text = text..'  ['.._index3..'] = { \n  label = "'..itemData[_index][_i][_index2][_index3]..'",\n   price = 500,\n  type = "money",\n   image = "'.._i..'_'.._index..'_'.._index2..'_'.._index3..'"},\n'
                        end
                    text = text.."},\n"
                text = text.." },\n"
            end
            text = text.." },\n"
        else
            text = text.." female = {"
            for _index2 = 0, #itemData[_index][_i] , 1 do
                text = text.." [".._index2.."] = { \n"
                    text = text.." drawable = ".._index2..", \n"
                    if _index == 'mask' or _index == 'jacket' or _index == 'gloves' or _index == 'shirt' or _index == 'neck' or _index == 'shoes' or _index == 'pant' or _index == 'backpack' then
                        text = text.." type = 'component', \n"
                        if _index == 'gloves' or _index == 'jacket' then
                            text = text.." arm = 1, \n"
                        end
                    else
                        text = text.." type = 'prop', \n"
                    end
                    text = text.." textures = { \n"
                        for _index3 = 0, #itemData[_index][_i][_index2], 1 do
                              text = text..' ['.._index3..'] = { \n label = "'..itemData[_index][_i][_index2][_index3]..'",\n price = 500,\n type = "money",\n image = "'.._i..'_'.._index..'_'.._index2..'_'.._index3..'"},\n'
                        end
                    text = text.."},\n"
                text = text.." },\n"
            end
            text = text.." },\n"
        end
    end
    -- text = text.." }"
    local file = io.open(itemsPath .._index.. '.lua', 'a+')
    file:write(text)
    file:close()
end)